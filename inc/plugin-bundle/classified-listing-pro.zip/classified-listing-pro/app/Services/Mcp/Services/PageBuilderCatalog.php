<?php

namespace RtclPro\Services\Mcp\Services;

use RtclPro\Services\Mcp\Mcp;

defined( 'ABSPATH' ) || exit;

/**
 * Pro page builder entries for the base MCP page builder abilities:
 * - Gutenberg blocks registered by Pro (BlockProController): rtcl/listing-ads-slider, rtcl/listing-store.
 * - Elementor widgets the Toolkits plugin only registers with Pro: rtcl-listing-slider,
 *   rtcl-listing-cat-slider, rtcl-pricing-table.
 * Inserted at their original position in each base list.
 */
class PageBuilderCatalog {

	public static function init() {
		add_filter( 'rtcl_mcp_block_style_options', [ __CLASS__, 'block_style_options' ] );
		add_filter( 'rtcl_mcp_widget_style_options', [ __CLASS__, 'widget_style_options' ] );
		add_filter( 'rtcl_mcp_elementor_widgets_schema', [ __CLASS__, 'elementor_widgets_schema' ] );
	}

	/**
	 * @param array $options Block style options keyed by block name.
	 *
	 * @return array
	 */
	public static function block_style_options( $options ) {
		return Mcp::insert_before( $options, 'rtcl/pricing-table', [
			'rtcl/listing-ads-slider' => [
				'label'       => __( 'Listings Slider (Pro)', 'classified-listing-pro' ),
				'description' => __( 'Carousel/slider of listings', 'classified-listing-pro' ),
				'pro'         => true,
				'styles'      => [
					'card_style' => [
						'label'       => __( 'Slide Card Style', 'classified-listing-pro' ),
						'description' => __( 'Visual style for each slide', 'classified-listing-pro' ),
						'attribute'   => 'rtcl_style',
						'required'    => true,
						'options'     => [
							[ 'value' => 'style-grid', 'label' => __( 'Style 1 - Classic', 'classified-listing-pro' ), 'recommended' => true ],
							[ 'value' => 'style-grid2', 'label' => __( 'Style 2 - Modern', 'classified-listing-pro' ) ],
							[ 'value' => 'style-grid3', 'label' => __( 'Style 3 - Compact', 'classified-listing-pro' ) ],
							[ 'value' => 'style-grid4', 'label' => __( 'Style 4 - Featured', 'classified-listing-pro' ) ],
							[ 'value' => 'style-grid5', 'label' => __( 'Style 5 - Minimal', 'classified-listing-pro' ) ],
						],
					],
					'slides_per_view' => [
						'label'       => __( 'Visible Slides', 'classified-listing-pro' ),
						'description' => __( 'How many listings visible at once?', 'classified-listing-pro' ),
						'attribute'   => 'slider_options.slidesToShow',
						'options'     => [
							[ 'value' => 2, 'label' => '2 Slides' ],
							[ 'value' => 3, 'label' => '3 Slides', 'recommended' => true ],
							[ 'value' => 4, 'label' => '4 Slides' ],
						],
					],
				],
			],
			'rtcl/listing-store' => [
				'label'       => __( 'Stores Display (Pro)', 'classified-listing-pro' ),
				'description' => __( 'Display vendor/store listings', 'classified-listing-pro' ),
				'pro'         => true,
				'styles'      => [
					'view_mode' => [
						'label'       => __( 'View Mode', 'classified-listing-pro' ),
						'description' => __( 'How to display stores?', 'classified-listing-pro' ),
						'attribute'   => 'rtcl_style',
						'required'    => true,
						'options'     => [
							[ 'value' => 'style-grid', 'label' => __( '📦 Grid Layout', 'classified-listing-pro' ), 'description' => 'Store cards in columns', 'recommended' => true ],
							[ 'value' => 'style-list', 'label' => __( '📋 List Layout', 'classified-listing-pro' ), 'description' => 'Stores in rows' ],
						],
					],
				],
			],
		] );
	}

	/**
	 * @param array $options Widget style options keyed by widget name.
	 *
	 * @return array
	 */
	public static function widget_style_options( $options ) {
		$options = Mcp::insert_before( $options, 'rtcl-listing-store', [
			'rtcl-listing-slider' => [
				'label'       => __( 'Listings Slider (Pro)', 'classified-listing-pro' ),
				'description' => __( 'Carousel/slider of listings', 'classified-listing-pro' ),
				'pro'         => true,
				'styles'      => [
					'card_style' => [
						'label'       => __( 'Card Style', 'classified-listing-pro' ),
						'description' => __( 'Visual style for each slide card', 'classified-listing-pro' ),
						'attribute'   => 'rtcl_listings_style',
						'required'    => true,
						'options'     => [
							[ 'value' => 'style-1', 'label' => __( 'Style 1 - Classic', 'classified-listing-pro' ), 'recommended' => true ],
							[ 'value' => 'style-2', 'label' => __( 'Style 2 - Modern', 'classified-listing-pro' ) ],
							[ 'value' => 'style-3', 'label' => __( 'Style 3 - Compact', 'classified-listing-pro' ) ],
							[ 'value' => 'style-4', 'label' => __( 'Style 4 - Image Focus', 'classified-listing-pro' ) ],
							[ 'value' => 'style-5', 'label' => __( 'Style 5 - Detailed', 'classified-listing-pro' ) ],
						],
					],
					'slides_per_view' => [
						'label'       => __( 'Visible Slides', 'classified-listing-pro' ),
						'description' => __( 'How many listings visible at once?', 'classified-listing-pro' ),
						'attribute'   => 'rtcl_slides_per_view',
						'options'     => [
							[ 'value' => 2, 'label' => '2 Slides' ],
							[ 'value' => 3, 'label' => '3 Slides', 'recommended' => true ],
							[ 'value' => 4, 'label' => '4 Slides' ],
						],
					],
				],
			],
			'rtcl-listing-cat-slider' => [
				'label'       => __( 'Category Slider (Pro)', 'classified-listing-pro' ),
				'description' => __( 'Carousel of category boxes', 'classified-listing-pro' ),
				'pro'         => true,
				'styles'      => [
					'box_style' => [
						'label'       => __( 'Box Style', 'classified-listing-pro' ),
						'description' => __( 'Visual style for category boxes', 'classified-listing-pro' ),
						'attribute'   => 'rtcl_cats_style',
						'required'    => true,
						'options'     => [
							[ 'value' => 'style-1', 'label' => __( 'Style 1 - Basic', 'classified-listing-pro' ), 'recommended' => true ],
							[ 'value' => 'style-2', 'label' => __( 'Style 2 - With Subcategories', 'classified-listing-pro' ) ],
						],
					],
					'slides_per_view' => [
						'label'       => __( 'Visible Slides', 'classified-listing-pro' ),
						'description' => __( 'How many categories visible at once?', 'classified-listing-pro' ),
						'attribute'   => 'rtcl_slides_per_view',
						'options'     => [
							[ 'value' => 3, 'label' => '3 Categories' ],
							[ 'value' => 4, 'label' => '4 Categories', 'recommended' => true ],
							[ 'value' => 5, 'label' => '5 Categories' ],
						],
					],
				],
			],
		] );

		return $options + [
			'rtcl-pricing-table' => [
				'label'       => __( 'Pricing Table (Pro)', 'classified-listing-pro' ),
				'description' => __( 'Display membership/pricing tiers', 'classified-listing-pro' ),
				'pro'         => true,
				'styles'      => [
					'table_style' => [
						'label'       => __( 'Table Style', 'classified-listing-pro' ),
						'description' => __( 'Visual design for pricing table', 'classified-listing-pro' ),
						'attribute'   => 'rtcl_view',
						'required'    => true,
						'options'     => [
							[ 'value' => 'view-1', 'label' => __( '💳 View 1 - Classic', 'classified-listing-pro' ), 'description' => 'Traditional pricing card', 'recommended' => true ],
							[ 'value' => 'view-2', 'label' => __( '✨ View 2 - Modern', 'classified-listing-pro' ), 'description' => 'Contemporary flat design' ],
							[ 'value' => 'view-3', 'label' => __( '🎨 View 3 - Featured', 'classified-listing-pro' ), 'description' => 'Highlighted with accent colors' ],
						],
					],
				],
			],
		];
	}

	/**
	 * @param array $widgets Widget schemas keyed by widget name.
	 *
	 * @return array
	 */
	public static function elementor_widgets_schema( $widgets ) {
		return Mcp::insert_before( $widgets, 'rtcl-listing-store', [
			'rtcl-listing-slider' => [
				'title'       => __( 'Listing Slider (Pro)', 'classified-listing-pro' ),
				'description' => __( 'Listing carousel/slider view.', 'classified-listing-pro' ),
				'pro'         => true,
				'settings'    => [
					'rtcl_listing_per_page' => [ 'type' => 'number', 'default' => 5 ],
					'rtcl_orderby'          => [ 'type' => 'string', 'default' => 'date' ],
					'rtcl_slides_per_view'  => [ 'type' => 'number', 'default' => 3 ],
					'rtcl_autoplay'         => [ 'type' => 'boolean', 'default' => true ],
					'rtcl_loop'             => [ 'type' => 'boolean', 'default' => true ],
				],
			],
			'rtcl-listing-cat-slider' => [
				'title'       => __( 'Category Slider (Pro)', 'classified-listing-pro' ),
				'description' => __( 'Category carousel/slider view.', 'classified-listing-pro' ),
				'pro'         => true,
				'settings'    => [
					'rtcl_category_limit'  => [ 'type' => 'number', 'default' => 10 ],
					'rtcl_slides_per_view' => [ 'type' => 'number', 'default' => 4 ],
					'rtcl_autoplay'        => [ 'type' => 'boolean', 'default' => true ],
				],
			],
			'rtcl-pricing-table' => [
				'title'       => __( 'Pricing Table (Pro)', 'classified-listing-pro' ),
				'description' => __( 'Display membership/pricing tiers.', 'classified-listing-pro' ),
				'pro'         => true,
				'settings'    => [
					'title'    => [ 'type' => 'string', 'default' => 'Basic Plan' ],
					'price'    => [ 'type' => 'string', 'default' => '0' ],
					'currency' => [ 'type' => 'string', 'default' => '$' ],
					'period'   => [ 'type' => 'string', 'default' => 'mo' ],
					'features' => [ 'type' => 'array', 'default' => [] ],
					'btn_text' => [ 'type' => 'string', 'default' => 'Buy Now' ],
					'btn_url'  => [ 'type' => 'string', 'default' => '#' ],
				],
			],
		] );
	}
}
