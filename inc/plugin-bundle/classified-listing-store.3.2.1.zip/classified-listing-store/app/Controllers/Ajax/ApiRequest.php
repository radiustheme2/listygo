<?php
/**
 * Created by PhpStorm.
 * User: mahbubur
 * Date: 7/24/18
 * Time: 12:10 PM
 */

namespace RtclStore\Controllers\Ajax;


use Rtcl\Controllers\Ajax\Checkout;
use Rtcl\Helpers\Functions;
use RtclStore\Helpers\Functions as StoreFunctions;
use RtclStore\Models\Membership;
use WP_Query;
use WP_User_Query;

class ApiRequest {

    public static function init() {
        add_action( 'wp_ajax_rtcl_get_all_membership_list', [ __CLASS__, 'rtcl_get_all_membership_list' ] );
        add_action( 'wp_ajax_rtcl_delete_membership', [ __CLASS__, 'rtcl_delete_membership' ] );
        add_action( 'wp_ajax_rtcl_update_membership_data', [ __CLASS__, 'rtcl_update_membership_data' ] );
        add_action( 'wp_ajax_rtcl_admin_search_users', [ __CLASS__, 'rtcl_admin_search_users' ] );
        add_action( 'wp_ajax_rtcl_admin_search_membership_packages', [ __CLASS__, 'rtcl_admin_search_membership_packages' ] );
        add_action( 'wp_ajax_rtcl_admin_create_membership', [ __CLASS__, 'rtcl_admin_create_membership' ] );
    }

    public static function rtcl_update_membership_data() {

        if ( !Functions::verify_nonce() ) {
            wp_send_json_error( __( "Session not valid", "classified-listing-store" ) );
        }

        if ( !empty( $_POST['data'] ) && !is_array( $_POST['data'] ) ) {
            wp_send_json_error( __( "No data found to update", "classified-listing-store" ) );
        }

        $id = !empty( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
        $membership = rtclStore()->factory->get_membership_by_id( $id );
        if ( !$membership ) {
            wp_send_json_error( __( "No membership found to update", "classified-listing-store" ) );
        }

        $data = $membership->update_membership_data( $_POST['data'] );

        if ( is_wp_error( $data ) ) {
            wp_send_json_error( $data->get_error_message() );
        }

        wp_send_json_success( [
            'message' => __( "Update successfully", "classified-listing-store" ),
            'data'    => $data
        ] );
    }

    public static function rtcl_delete_membership() {
        if ( !Functions::verify_nonce() ) {
            wp_send_json_error( __( "Session not valid", "classified-listing-store" ) );
        }

        $ready_ids = !empty( $_POST['ids'] ) && is_array( $_POST['ids'] ) ? $_POST['ids'] : [];
        if ( empty( $ready_ids ) ) {
            wp_send_json_error( __( "Please select a row to delete", "classified-listing-store" ) );
        }
        $ids = [];

        global $wpdb;
        foreach ( $ready_ids as $id ) {
            if ( $wpdb->delete( $wpdb->prefix . 'rtcl_membership', [ 'id' => $id ], [ '%d' ] ) ) {
                $ids[] = $id;
            }
        }

        if ( empty( $ids ) ) {
            wp_send_json_error( __( "No membership removed", "classified-listing-store" ) );
        }

        wp_send_json_success( [ 'message' => __( "Membership removed successfully", "classified-listing-store" ), 'ids' => $ids ] );

    }

    static function rtcl_get_all_membership_list() {
        if ( !Functions::verify_nonce() ) {
            wp_send_json_error( __( "Session not valid", "classified-listing-store" ) );
        }

        $filters = !empty( $_POST['filters'] ) && is_array( $_POST['filters'] ) ? array_filter( $_POST['filters'] ) : [];

        $data = self::get_membership_list( $filters );
        wp_send_json_success( $data );
    }

    public static function rtcl_admin_search_users() {
        if ( ! Functions::verify_nonce() ) {
            wp_send_json_error( __( "Session not valid", "classified-listing-store" ) );
        }
        if ( ! current_user_can( 'manage_rtcl_options' ) ) {
            wp_send_json_error( __( "Permission denied", "classified-listing-store" ) );
        }

        $search = isset( $_POST['search'] ) ? sanitize_text_field( $_POST['search'] ) : '';
        $args   = [
            'number'         => 20,
            'orderby'        => 'display_name',
            'order'          => 'ASC',
        ];
        if ( $search ) {
            $args['search']         = '*' . $search . '*';
            $args['search_columns'] = [ 'user_login', 'user_email', 'display_name' ];
        }

        $user_query = new WP_User_Query( $args );
        $users      = [];
        foreach ( $user_query->get_results() as $user ) {
            $users[] = [
                'id'    => $user->ID,
                'label' => sprintf( '%s (%s) #%d', esc_html( $user->display_name ), esc_html( $user->user_email ), $user->ID ),
            ];
        }

        wp_send_json_success( [ 'users' => $users ] );
    }

    public static function rtcl_admin_search_membership_packages() {
        if ( ! Functions::verify_nonce() ) {
            wp_send_json_error( __( "Session not valid", "classified-listing-store" ) );
        }
        if ( ! current_user_can( 'manage_rtcl_options' ) ) {
            wp_send_json_error( __( "Permission denied", "classified-listing-store" ) );
        }

        $search = isset( $_POST['search'] ) ? sanitize_text_field( $_POST['search'] ) : '';
        $args   = [
            'post_type'      => rtcl()->post_type_pricing,
            'post_status'    => 'publish',
            'posts_per_page' => 20,
            'meta_query'     => [
                [
                    'key'   => 'pricing_type',
                    'value' => 'membership',
                ],
            ],
        ];
        if ( $search ) {
            $args['s'] = $search;
        }

        $query    = new WP_Query( $args );
        $packages = [];
        foreach ( $query->posts as $post ) {
            $pricing = rtcl()->factory->get_pricing( $post->ID );
            if ( $pricing ) {
                $promotions = get_post_meta( $pricing->getId(), '_rtcl_membership_promotions', true );
                $packages[] = [
                    'id'          => $pricing->getId(),
                    'title'       => $pricing->getTitle(),
                    'price'       => floatval( $pricing->getPrice() ),
                    'visible'     => absint( $pricing->getVisible() ),
                    'regular_ads' => absint( get_post_meta( $pricing->getId(), 'regular_ads', true ) ),
                    'promotions'  => is_array( $promotions ) ? $promotions : [],
                ];
            }
        }

        wp_send_json_success( [ 'packages' => $packages ] );
    }

    public static function rtcl_admin_create_membership() {
        if ( ! Functions::verify_nonce() ) {
            wp_send_json_error( __( "Session not valid", "classified-listing-store" ) );
        }
        if ( ! current_user_can( 'manage_rtcl_options' ) ) {
            wp_send_json_error( __( "Permission denied", "classified-listing-store" ) );
        }

        $user_id    = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
        $pricing_id = isset( $_POST['pricing_id'] ) ? absint( $_POST['pricing_id'] ) : 0;

        if ( ! $user_id || ! get_user_by( 'id', $user_id ) ) {
            wp_send_json_error( __( "Invalid user selected", "classified-listing-store" ) );
        }

        $pricing = rtcl()->factory->get_pricing( $pricing_id );
        if ( ! $pricing || 'membership' !== $pricing->getType() ) {
            wp_send_json_error( __( "Invalid membership package selected", "classified-listing-store" ) );
        }

        // Collect billing fields
        $billing_keys  = [ 'first_name', 'last_name', 'company', 'country', 'address_1',
                           'address_2', 'city', 'state', 'postcode', 'phone', 'email' ];
        $billing_input = isset( $_POST['billing'] ) && is_array( $_POST['billing'] ) ? $_POST['billing'] : [];
        $billing       = [];
        foreach ( $billing_keys as $field ) {
            $billing[ $field ] = isset( $billing_input[ $field ] )
                ? sanitize_text_field( $billing_input[ $field ] )
                : '';
        }
        if ( ! empty( $billing['email'] ) && ! is_email( $billing['email'] ) ) {
            wp_send_json_error( __( "Invalid billing email address", "classified-listing-store" ) );
        }

        // Calculate pricing and tax
        $pricing_price = floatval( $pricing->getPrice() );
        $subtotal      = $pricing_price;
        $tax_amount    = 0.00;

        if ( Functions::is_enable_tax() && ! empty( $billing['country'] ) ) {
            $multiple_tax = Checkout::get_tax_amount(
                $billing['country'],
                ! empty( $billing['state'] ) ? $billing['state'] : '',
                $subtotal
            );
            if ( Functions::is_enable_multiple_tax() ) {
                foreach ( $multiple_tax as $single_tax ) {
                    $tax_amount += $single_tax['raw_amount'];
                }
            } else {
                $single_tax = current( $multiple_tax );
                $tax_amount = $single_tax['raw_amount'];
            }
        }

        $total_price = $subtotal + $tax_amount;

        // Build payment order meta
        $user       = get_user_by( 'id', $user_id );
        $metaInputs = [
            'customer_id'           => $user_id,
            'customer_ip_address'   => Functions::get_ip_address(),
            '_order_key'            => apply_filters( 'rtcl_generate_order_key', uniqid( 'rtcl_oder_' ) ),
            '_pricing_id'           => $pricing->getId(),
            'amount'                => $total_price,
            '_tax_amount'           => $tax_amount,
            '_subtotal'             => $subtotal,
            '_payment_method'       => 'offline',
            '_payment_method_title' => __( 'Offline', 'classified-listing-store' ),
            '_order_currency'       => Functions::get_order_currency(),
            'payment_type'          => 'membership',
            '_rtcl_admin_created'   => 1,
            '_rtcl_created_by'      => get_current_user_id(),
        ];

        // Add billing meta
        foreach ( $billing as $key => $value ) {
            if ( ! empty( $value ) ) {
                $metaInputs[ '_billing_' . $key ] = $value;
            }
        }
        if ( empty( $metaInputs['_billing_email'] ) && $user->user_email ) {
            $metaInputs['_billing_email'] = $user->user_email;
        }
        if ( empty( $metaInputs['_billing_first_name'] ) && $user->first_name ) {
            $metaInputs['_billing_first_name'] = $user->first_name;
        }
        if ( empty( $metaInputs['_billing_last_name'] ) && $user->last_name ) {
            $metaInputs['_billing_last_name'] = $user->last_name;
        }

        // Add membership promotions
        $membership_promotions = get_post_meta( $pricing->getId(), '_rtcl_membership_promotions', true );
        if ( ! empty( $membership_promotions ) ) {
            $metaInputs['_rtcl_membership_promotions'] = $membership_promotions;
        }

        // Create the payment order post
        $newOrderArgs = [
            'post_title'  => esc_html__( 'Order on', 'classified-listing' ) . ' ' . current_time( 'l jS F Y h:i:s A' ),
            'post_status' => 'rtcl-created',
            'post_parent' => '0',
            'ping_status' => 'closed',
            'post_author' => $user_id,
            'post_type'   => rtcl()->post_type_payment,
            'meta_input'  => $metaInputs,
        ];

        $order_id = wp_insert_post(
            apply_filters( 'rtcl_checkout_process_new_order_args', $newOrderArgs, $pricing, 'offline', [] )
        );

        if ( ! $order_id || is_wp_error( $order_id ) ) {
            wp_send_json_error( __( "Failed to create payment order", "classified-listing-store" ) );
        }

        // Set order key and fire hook
        $order = rtcl()->factory->get_order( $order_id );
        $order->set_order_key();
        do_action( 'rtcl_checkout_process_new_payment_created', $order_id, $order );

        // Complete payment immediately (admin-created)
        $order->payment_complete( wp_generate_password( 12, true ) );

        // Safety fallback: apply membership if not applied by hook chain
        if ( ! $order->is_applied() ) {
            StoreFunctions::apply_membership( $order );
        }

        // Flag the membership record as admin-created
        try {
            $membership = new Membership( $user_id );
            if ( $membership->get_id() ) {
                $membership->update_meta( '_rtcl_admin_created', 1 );
                $membership->update_meta( '_rtcl_created_by', get_current_user_id() );
            }
        } catch ( \Exception $e ) {
            // Membership was still created, just meta flag failed
        }

        wp_send_json_success( [
            'message' => __( "Membership created successfully", "classified-listing-store" ),
        ] );
    }

    private static function get_membership_list( $filters ) {

        global $wpdb;
        $prefix = is_multisite() ? $wpdb->base_prefix : $wpdb->prefix;
        $where = '';
        if ( !empty( $filters['id'] ) && $id = absint( $filters['id'] ) ) {
            $where .= ' AND m.id = ' . $id;
        }
        if ( !empty( $filters['user_id'] ) && $user_id = absint( $filters['user_id'] ) ) {
            $where .= ' AND m.user_id = ' . $user_id;
        }
        if ( !empty( $filters['email'] ) && $email = sanitize_text_field( trim( $filters['email'] ) ) ) {
            $where .= $wpdb->prepare( ' AND u.user_email LIKE %s', "%" . $email . "%" );
        }
        if ( !empty( $filters['user_name'] ) && $user_name = sanitize_text_field( trim( $filters['user_name'] ) ) ) {
            $where .= $wpdb->prepare( ' AND u.user_login LIKE %s', "%" . $user_name . "%" );
        }

        $query = "SELECT COUNT(*) FROM {$wpdb->prefix}rtcl_membership m, {$prefix}users u WHERE m.user_id = u.ID {$where}";
        $total = (int)$wpdb->get_var( $query );

        $per_page = 20;
        $page = isset( $_POST['page'] ) ? absint( $_POST['page'] ) : 1;
        $page = !$page ? 1 : $page;
        $offset = ( $page * $per_page ) - $per_page;

        $members = $wpdb->get_results(
            "SELECT m.*, u.user_email as email , u.user_login as user_name, u.ID as user_id 
					  FROM {$wpdb->prefix}rtcl_membership m, {$prefix}users u
					  WHERE m.user_id = u.ID {$where}
					  ORDER BY m.id DESC
					LIMIT $offset, $per_page" );

        return [
            'members'    => $members,
            'pagination' => [
                'current'  => $page,
                'per_page' => $per_page,
                'total'    => $total
            ]
        ];
    }

}