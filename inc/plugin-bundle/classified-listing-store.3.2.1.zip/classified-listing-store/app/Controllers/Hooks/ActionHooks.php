<?php

namespace RtclStore\Controllers\Hooks;

use Rtcl\Controllers\Settings\AdminSettings;
use Rtcl\Helpers\Functions;
use Rtcl\Resources\Options;
use WP_Error;

class ActionHooks {
    public static function init() {
        add_action( 'rtcl_store_contact_form_validation', [ __CLASS__, 'store_contact_form_validation' ], 10, 2 );
        add_action( 'delete_user', [ __CLASS__, 'remove_membership_data' ] );
        add_action( 'before_delete_post', [ __CLASS__, 'update_posting_count' ] );
        add_action( 'wp', [ __CLASS__, 'migrate_store_business_hour' ] );
        add_action( 'rtcl_admin_settings_saved', [ __CLASS__, 'update_pay_per_ad_settings' ], 10, 2 );
        add_action( 'rtcl_save_pricing_meta_data', [ __CLASS__, 'save_trial_period_meta' ], 10, 2 );
        add_action( 'save_post_' . rtcl()->post_type_pricing, [ __CLASS__, 'save_pricing_meta_early' ], 1, 2 );
    }

    public static function save_trial_period_meta( $post_id, $request ) {
        if ( isset( $request['_rtcl_enable_trial'] ) && '1' === (string) $request['_rtcl_enable_trial'] ) {
            update_post_meta( $post_id, '_rtcl_enable_trial', '1' );
            update_post_meta( $post_id, '_rtcl_trial_days', absint( $request['_rtcl_trial_days'] ?? 0 ) );
        } else {
            delete_post_meta( $post_id, '_rtcl_enable_trial' );
            delete_post_meta( $post_id, '_rtcl_trial_days' );
        }
    }

    /**
     * Priority 1 — fires before Pro plugin's wp_die lock (priority 5).
     * Saves all mutable membership fields so they persist even when the Pro plugin blocks the
     * standard save flow for Stripe-linked plans.
     */
    public static function save_pricing_meta_early( $post_id, $post ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
        if ( ! isset( $_POST['post_type'] ) || rtcl()->post_type_pricing !== $post->post_type ) {
            return;
        }
        // phpcs:disable WordPress.Security.NonceVerification.Missing
        // Trial period.
        if ( isset( $_POST['_rtcl_enable_trial'] ) && '1' === (string) $_POST['_rtcl_enable_trial'] ) {
            $trial_days = absint( $_POST['_rtcl_trial_days'] ?? 0 );
            update_post_meta( $post_id, '_rtcl_enable_trial', '1' );
            update_post_meta( $post_id, '_rtcl_trial_days', max( 1, $trial_days ) );
        } else {
            delete_post_meta( $post_id, '_rtcl_enable_trial' );
            delete_post_meta( $post_id, '_rtcl_trial_days' );
        }

        // Regular ads count.
        if ( isset( $_POST['regular_ads'] ) ) {
            update_post_meta( $post_id, 'regular_ads', absint( $_POST['regular_ads'] ) );
        }

        // Membership promotions.
        if ( isset( $_POST['_rtcl_membership_promotions'] ) && is_array( $_POST['_rtcl_membership_promotions'] ) ) {
            $promotions_list = Options::get_listing_promotions();
            $promotions      = [];
            foreach ( $promotions_list as $promotion_key => $promotion_label ) {
                $ads      = absint( $_POST['_rtcl_membership_promotions'][ $promotion_key ]['ads'] ?? 0 );
                $validate = absint( $_POST['_rtcl_membership_promotions'][ $promotion_key ]['validate'] ?? 0 );
                if ( $ads && $validate ) {
                    $promotions[ $promotion_key ]['ads']      = $ads;
                    $promotions[ $promotion_key ]['validate'] = $validate;
                }
            }
            if ( ! empty( $promotions ) ) {
                update_post_meta( $post_id, '_rtcl_membership_promotions', $promotions );
            } else {
                delete_post_meta( $post_id, '_rtcl_membership_promotions' );
            }
        }

        // Membership categories.
        if ( isset( $_POST['membership_categories'] ) && is_array( $_POST['membership_categories'] ) && ! empty( $_POST['membership_categories'] ) ) {
            update_post_meta( $post_id, 'membership_categories', array_map( 'absint', $_POST['membership_categories'] ) );
        } else {
            delete_post_meta( $post_id, 'membership_categories' );
        }
        // phpcs:enable
    }

    /**
     * @param $option
     * @param AdminSettings $SettingsModal
     * @return void
     * if pay_per_ad is enable then forcefully enable free ads and update number_of_free_ads to 999
     */
    public static function update_pay_per_ad_settings( $option, AdminSettings $SettingsModal ) {
        if ( $option !== 'membership_settings' ) {
            return;
        }
        $settings = get_option( 'rtcl_membership_settings', [] );
        if ( !empty( $settings['enable_pay_per_ad'] ) && $settings['enable_pay_per_ad'] === 'yes' ) {
            if ( ( empty( $settings['enable_free_ads'] ) || empty( $settings['number_of_free_ads'] ) ) || ( $settings['enable_free_ads'] !== 'yes' || $settings['number_of_free_ads'] !== 999 ) ) {
                $settings['enable_free_ads'] = 'yes';
                $settings['number_of_free_ads'] = 999;
                update_option( 'rtcl_membership_settings', $settings );
            }
        }
    }

    public static function migrate_store_business_hour() {
        $migrated = get_option( 'rtcl_store_migrated_business_hour' );
        if ( 'yes' !== $migrated ) {
            $stores = get_posts( [ 'post_type' => 'store', 'fields' => 'ids', 'posts_per_page' => -1 ] );
            $data = [];
            if ( !empty( $stores ) ) {
                foreach ( $stores as $store_id ) {
                    $store = rtclStore()->factory->get_store( $store_id );
                    if ( $store ) {
                        $hours = get_post_meta( $store->get_id(), 'oh_hours', true );
                        if ( !empty( $hours ) ) {
                            foreach ( $hours as $key => $hour ) {
                                switch ( $key ) {
                                    case 'sunday':
                                        $key = 0;
                                        break;
                                    case 'monday':
                                        $key = 1;
                                        break;
                                    case 'tuesday':
                                        $key = 2;
                                        break;
                                    case 'wednesday':
                                        $key = 3;
                                        break;
                                    case 'thursday':
                                        $key = 4;
                                        break;
                                    case 'friday':
                                        $key = 5;
                                        break;
                                    case 'saturday':
                                        $key = 6;
                                        break;
                                }
                                $data[$key] = $hour;
                            }
                        }
                        if ( !empty( $data ) ) {
                            update_post_meta( $store->get_id(), 'oh_hours', $data );
                        }
                    }
                }
                add_option( 'rtcl_store_migrated_business_hour', 'yes' );
            }
        }
    }

    public static function update_posting_count( $post_id ) {

        $listing = rtcl()->factory->get_listing( $post_id );

        $permitted_status = apply_filters( 'rtcl_listing_log_permitted_status', [ 'rtcl-reviewed', 'draft', 'pending', 'trash' ] );
        if ( $listing && in_array( $listing->get_status(), $permitted_status ) ) {
            $publish_count = absint( get_post_meta( $listing->get_id(), '_rtcl_publish_count', true ) );
            if ( !$publish_count || apply_filters( 'rtcl_listing_log_ignore_publish_count', false ) ) {
                global $wpdb;
                $table = $wpdb->prefix . 'rtcl_posting_log';
                $log = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE post_id = %d AND user_id = %d AND status = 'new'", $listing->get_id(),
                    $listing->get_author_id() ) );
                if ( $log ) {
                    $wpdb->delete( $table, [
                        'post_id' => $listing->get_id(),
                        'user_id' => $listing->get_author_id(),
                        'status'  => 'new'
                    ], [ '%d', '%d', '%s' ] );
                } else {
                    $member = rtclStore()->factory->get_membership( $listing->get_author_id() );
                    if ( $member ) {
                        $member->add_post_count();
                    }
                }
            }
        }
    }

    public static function remove_membership_data( $user_id ) {
        global $wpdb;
        $membership_table = $wpdb->prefix . "rtcl_membership";
        $membership = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$membership_table} WHERE user_id = %d", $user_id )
        );
        if ( $membership ) {
            $wpdb->delete(
                $wpdb->prefix . "rtcl_membership_meta",
                [ 'membership_id' => $membership->id ],
                [ '%d' ]
            );
            $wpdb->delete(
                $wpdb->prefix . "rtcl_membership",
                [ 'id' => $membership->id ],
                [ '%d' ]
            );
        }
    }


    /**
     * @param WP_Error $error
     * @param array $data
     */
    public static function store_contact_form_validation( $error, $data ) {
        if ( empty( $data['store_id'] ) || empty( $data['name'] ) || empty( $data['email'] ) || empty( $data['message'] ) ) {
            $error->add( 'rtcl_field_required', esc_html__( 'Need to fill all the required field.', 'classified-listing-store' ) );
        }
    }
}