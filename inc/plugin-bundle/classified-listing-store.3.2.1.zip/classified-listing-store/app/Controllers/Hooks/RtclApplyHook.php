<?php

namespace RtclStore\Controllers\Hooks;

use Rtcl\Controllers\Hooks\TemplateHooks;
use Rtcl\Helpers\Functions;
use Rtcl\Helpers\Link;
use Rtcl\Models\Form\Form;
use Rtcl\Models\Listing;
use Rtcl\Models\Payment;
use Rtcl\Models\Pricing;
use Rtcl\Resources\Options;
use RtclStore\Helpers\Functions as StoreFunctions;
use WP_Error;

class RtclApplyHook {

    static function init() {
        add_filter( 'rtcl_option_items', [ __CLASS__, 'add_settings_options' ], 10, 3 );
        self::register_store_menu();
        add_filter( 'rtcl_locate_template', [ __CLASS__, 'locate_store_template' ], 20, 2 );
        add_filter( 'rtcl_get_template_part', [ __CLASS__, 'get_template_part' ], 20, 3 );
        add_filter( 'rtcl_misc_media_settings_options', [ __CLASS__, 'add_misc_options' ] );
        add_filter( 'rtcl_all_ids_for_remove_attachment', [ __CLASS__, 'remove_attachment_for_store' ] );

        // For single page
        // add_filter('rtcl_current_user_can', array(__CLASS__, 'current_user_can'), 10, 3);

        add_filter( 'rtcl_checkout_endpoints', [ __CLASS__, 'add_checkout_membership_endpoint' ] );
        add_filter( 'rtcl_payment_pricing_types', [ __CLASS__, 'add_payment_pricing_type' ] );
        add_filter( 'rtcl_pricing_admin_options', [ __CLASS__, 'add_pricing_options' ], 10, 2 );
        add_action( 'save_post_' . rtcl()->post_type_pricing, [ __CLASS__, 'save_pricing_meta' ], 20, 2 );
        // Membership "Image Count (Per Listing)" override of the form-builder default max images.
        add_filter( 'rtcl_fb_form', [ __CLASS__, 'override_membership_image_count' ] );
        add_filter( 'rtcl_fb_extra_form_validation', [ __CLASS__, 'validate_membership_image_count' ], 10, 2 );
        //add_filter('rtcl_payment_receipt_html', [__CLASS__, 'rtcl_payment_receipt_html'], 10, 2);
        remove_action( 'rtcl_payment_receipt', [ TemplateHooks::class, 'payment_receipt_pricing_info' ], 20 );
        remove_action( 'rtcl_payment_receipt_popup', [
                TemplateHooks::class,
                'payment_receipt_popup_pricing_info',
        ], 20 );
        add_action( 'rtcl_payment_receipt', [ __CLASS__, 'payment_receipt_pricing_info' ], 20, 2 );
        add_action( 'rtcl_payment_receipt_popup', [ __CLASS__, 'payment_receipt_popup_pricing_info' ], 20, 2 );
        add_action( 'rtcl_get_payment_option_features', [ __CLASS__, 'rtcl_get_payment_option_features' ], 10, 2 );
        add_filter( 'rtcl_get_admin_email_notification_options', [
                __CLASS__,
                'add_store_update_admin_email_notification',
        ] );

        add_filter( 'rtcl_recaptcha_form_list', [ __CLASS__, 'add_recaptcha_store_contact_form' ] );
        add_action( 'rtcl_before_enqueue_script', [ __CLASS__, 'add_recaptcha_script_store_contact_form' ] );
        add_filter( 'rtcl_custom_pages_list', [ __CLASS__, 'add_custom_page' ] );

        add_action( 'rtcl_pricing_promotions_column_content', [ __CLASS__, 'add_membership_pricing_promotions' ], 20 );
        add_action( 'rtcl_payment_promotions_content', [ __CLASS__, 'add_membership_payment_promotions' ], 20, 2 );
        add_action( 'rtcl_payment_item_details', [ __CLASS__, 'add_payment_membership_item_details' ], 10, 2 );

        add_filter( 'rtcl_registered_only_options', [ __CLASS__, 'add_registered_only_store_contact_option' ] );
        add_filter( 'rtcl_ajax_filter_load_data_query_args', [ __CLASS__, 'add_store_listing_compatibility' ] );

        if ( StoreFunctions::is_enable_store_manager() ) {
            add_filter( 'rtcl_current_user_can', [ __CLASS__, 'manager_can_manage' ], 100, 3 );
            add_filter( 'rtcl_listing_save_update_args', [
                    __CLASS__,
                    'update_store_id_as_owner_for_manager_post',
            ], 100, 2 );
            add_filter( 'rtcl_insert_temp_post_for_gallery', [
                    __CLASS__,
                    'update_gallery_temp_post_id_as_owner_for_manager_post',
            ] );
            add_filter( 'rtcl_listing_post_user_id', [ __CLASS__, 'rtcl_listing_manager_post_user_id' ] );
            add_action( 'rtcl_listing_form_after_save_or_update', [
                    __CLASS__,
                    'add_manager_id_after_save_new_listing',
            ], 100, 5 );
            add_action( 'rtcl_listing_loop_extra_meta', [ __CLASS__, 'add_listing_managed_by' ] );
            add_filter( 'rtcl_my_listings_args', [ __CLASS__, 'add_store_manager_listing_args' ] );
            add_action( 'rtcl_my_account_before_my_listing', [ __CLASS__, 'add_manager_store_listing_sub_menu' ], 10 );
            add_action( 'rtcl_my_account_before_my_listing', [ __CLASS__, 'add_store_manager_listing_for' ], 50 );
        }
    }

    public static function add_store_listing_compatibility( $args ) {
        if ( ! empty( $_REQUEST['rtcl_store_id'] ) ) {
            $store_id       = absint( $_REQUEST['rtcl_store_id'] );
            $args['author'] = get_post_meta( $store_id, 'store_owner_id', true );
        }

        return $args;
    }

    /**
     * @param  array  $options
     *
     * @return array mixed
     */
    public static function add_registered_only_store_contact_option( $options ) {
        $options['store_contact'] = esc_html__( 'Store contact information', 'classified-listing-store' );

        return $options;
    }

    public static function add_store_manager_listing_for() {
        if ( isset( $_GET['manager'] ) && ( $current_user_store = StoreFunctions::get_current_user_store() )
             && ( $manager = get_user_by( 'login', sanitize_text_field( $_GET['manager'] ) ) )
             && $current_user_store->owner_id() !== $manager->ID
             && in_array( $manager->ID, $current_user_store->get_manager_ids(), true )
        ) {
            $name  = trim( implode( ' ', [ $manager->first_name, $manager->last_name ] ) );
            $name  = $name ? $name : $manager->display_name;
            $pp_id = absint( get_user_meta( $manager->ID, '_rtcl_pp_id', true ) );
            ?>
            <div class="rtcl-store-manager-listing">
                <h5><?php esc_html_e( "Store manager listing:" ); ?></h5>
                <div class="rtcl-store-manager">
                    <div class="rtcl-store-m-avatar"><?php echo $pp_id ? wp_get_attachment_image( $pp_id, [
                                100,
                                100,
                        ] ) : get_avatar( $manager->ID ) ?></div>
                    <div class="rtcl-store-m-info">
                        <div class="rtcl-m-info"><?php esc_html_e( $name ) ?></div>
                        <div class="rtcl-m-info"><?php echo esc_html( $manager->user_email ); ?></div>
                    </div>
                </div>
            </div>
            <?php
        }
    }

    public static function add_manager_store_listing_sub_menu() {
        if ( $store = StoreFunctions::get_manager_store() ) {
            ?>
            <div class="rtcl-account-sub-menu">
                <ul>
                    <li class="rtcl-my-listing<?php echo ! isset( $_GET['store_listing'] ) ? ' active' : ''; ?>">
                        <a href="<?php echo esc_url( Link::get_account_endpoint_url( 'listings' ) ) ?>"><?php esc_html_e( "My Listing",
                                    "classified-listing-store" ); ?></a>
                    </li>
                    <li class="rtcl-store-listing<?php echo isset( $_GET['store_listing'] ) ? ' active' : ''; ?>">
                        <a href="<?php echo esc_url( add_query_arg( 'store_listing',
                                1,
                                Link::get_account_endpoint_url( 'listings' ) ) ) ?>"><?php esc_html_e( "Listing for store", "classified-listing-store" ); ?></a>
                    </li>
                </ul>
            </div>
            <?php
        }
    }

    /**
     * @param  array  $args
     *
     * @return array
     */
    public static function add_store_manager_listing_args( $args ) {
        $current_user_store = StoreFunctions::get_current_user_store();
        $managerStore       = StoreFunctions::get_manager_store();
        if ( isset( $_GET['manager'] ) && $current_user_store && ( $manager = get_user_by( 'login', sanitize_text_field( $_GET['manager'] ) ) )
             && $current_user_store->owner_id() !== $manager->ID
             && in_array( $manager->ID, $current_user_store->get_manager_ids(), true )
        ) {
            $meta_query = [
                    'key'   => '_rtcl_manager_id',
                    'value' => $manager->ID,
            ];

            if ( isset( $args['meta_query'] ) ) {
                $args['meta_query'][] = $meta_query;
            } else {
                $args['meta_query'][] = $meta_query;
            }

            if ( count( $args['meta_query'] ) > 1 ) {
                $args['meta_query']['relation'] = 'AND';
            }
        }
        if ( isset( $_GET['store_listing'] ) && $managerStore ) {
            $args['author'] = $managerStore->owner_id();
            $meta_query     = [
                    'key'   => '_rtcl_manager_id',
                    'value' => get_current_user_id(),
            ];

            if ( isset( $args['meta_query'] ) ) {
                $args['meta_query'][] = $meta_query;
            } else {
                $args['meta_query'][] = $meta_query;
            }

            if ( count( $args['meta_query'] ) > 1 ) {
                $args['meta_query']['relation'] = 'AND';
            }
        }

        return $args;
    }

    /**
     * @param  Listing  $listing
     */
    public static function add_listing_managed_by( $listing ) {
        $manager_id = absint( get_post_meta( $listing->get_id(), '_rtcl_manager_id', true ) );
        if ( $manager_id && is_a( $listing, Listing::class ) && $listing->get_owner_id() !== $manager_id && $user = get_user_by( 'id', $manager_id ) ) {
            $author[] = $user->first_name;
            $author[] = $user->last_name;
            $author   = array_filter( $author );
            if ( ! empty( $author ) ) {
                $author_name = implode( ' ', $author );
            } else {
                $author_name = $user->display_name;
            }
            ?>
            <div class="rtcl-managed-by">
                <strong><?php esc_html_e( 'Managed by', 'classified-listing-store' ); ?></strong>:
                <?php echo esc_html( $author_name ); ?>
            </div>
            <?php
        }
    }

    /**
     * @param  Listing  $listing
     * @param  String  $type
     * @param  int  $category
     * @param  string  $new_listing_status
     * @param  array  $request
     */
    public static function add_manager_id_after_save_new_listing( $listing, $type, $category, $new_listing_status, $request ) {
        if ( empty( $request['data']['isAdminEnd'] ) && $type === "new" && is_a( $listing, Listing::class )
             && $listing->get_owner_id() !== get_current_user_id()
        ) {
            update_post_meta( $listing->get_id(), '_rtcl_manager_id', get_current_user_id() );
        }
    }

    /**
     * @param  array  $post_arg
     * @param  string  $type
     *
     * @return array
     */
    public static function update_store_id_as_owner_for_manager_post( $post_arg, $type ) {
        $current_user_id = get_current_user_id();
        if ( $type === 'new' && $current_user_id && isset( $post_arg['post_author'] )
             && absint( $post_arg['post_author'] )
             && ( $store = StoreFunctions::get_manager_store( $current_user_id ) )
             && $post_arg['post_author'] !== $store->owner_id()
        ) {
            $post_arg['post_author'] = $store->owner_id();
        }

        return $post_arg;
    }

    public static function rtcl_listing_manager_post_user_id( $current_user_id ) {
        if ( $current_user_id && ( $store = StoreFunctions::get_manager_store( $current_user_id ) ) && $current_user_id !== $store->owner_id() ) {
            $current_user_id = $store->owner_id();
        }

        return $current_user_id;
    }

    public static function update_gallery_temp_post_id_as_owner_for_manager_post( $post_arg ) {
        $current_user_id = get_current_user_id();
        if ( $current_user_id && isset( $post_arg['post_author'] ) && absint( $post_arg['post_author'] )
             && ( $store
                        = StoreFunctions::get_manager_store( $current_user_id ) )
             && $post_arg['post_author'] !== $store->owner_id()
        ) {
            $post_arg['post_author'] = $store->owner_id();
        }

        return $post_arg;
    }

    /**
     * @param  bool  $user_can
     * @param  array  $capability
     * @param  Listing  $listing
     *
     * @return mixed
     */
    public static function manager_can_manage( $user_can, $capability, $listing ) {
        if ( $user_can || ! is_a( $listing, Listing::class ) ) {
            return $user_can;
        }
        $manager_id = absint( get_post_meta( $listing->get_id(), '_rtcl_manager_id', true ) );
        if ( $manager_id && $manager_id === get_current_user_id()
             && in_array( $capability, [
                        'edit_rtcl_listing',
                        'delete_rtcl_listing',
                ] )
        ) {
            $user_can = true;
        }

        return $user_can;
    }

    /**
     * @param  int  $payment_id
     * @param  Payment  $payment
     */
    public static function add_payment_membership_item_details( $payment_id, $payment ) {
        if ( $payment && ! empty( $payment->pricing ) && "membership" === $payment->pricing->getType() ) { ?>
            <div class="item-title">
                <a href="<?php echo get_the_permalink( $payment_id ); ?>"><?php echo get_the_title( $payment_id ); ?></a>
            </div>
            <?php
        }
    }

    /**
     * @param  int  $payment_id
     * @param  Payment  $payment
     */
    public static function add_membership_payment_promotions( $payment_id, $payment ) {
        if ( $payment && ! empty( $payment->pricing ) && "membership" === $payment->pricing->getType() ) {
            $promotions  = get_post_meta( $payment->get_id(), '_rtcl_membership_promotions', true );
            $regular_ads = get_post_meta( $payment->pricing->getId(), 'regular_ads', true );
            echo '<div class="membership-promotions rtcl-pricing-promotions">';
            echo '<div class="item"><span class="item-label"></span><span class="listing-count">Ads</span></span><span class="validate">Validate</span></div>';
            echo sprintf( '<div class="item"><span class="item-label">%s:</span><span class="listing-count">%d</span><span class="validate">%s</span></div>',
                    __( "Regular", "classified-listing-store" ),
                    absint( $regular_ads ),
                    __( "--", "classified-listing-store" ),
            );
            if ( ! empty( $promotions ) ) {
                $promotion_list = Options::get_listing_promotions();
                foreach ( $promotion_list as $promotion_key => $promotion_label ) {
                    echo sprintf( '<div class="item"><span class="item-label">%s:</span><span class="listing-count">%d</span><span class="validate">%d</span></div>',
                            $promotion_label,
                            ! empty( $promotions[ $promotion_key ]['ads'] ) ? $promotions[ $promotion_key ]['ads'] : 0,
                            ! empty( $promotions[ $promotion_key ]['validate'] ) ? $promotions[ $promotion_key ]['validate'] : 0,
                    );
                }
            }
            echo "</div>";
        }
    }

    public static function add_membership_pricing_promotions( $pricing_id ) {
        $pricing_type = get_post_meta( $pricing_id, 'pricing_type', true );
        $promotions   = get_post_meta( $pricing_id, '_rtcl_membership_promotions', true );
        if ( "membership" === $pricing_type && ! empty( $promotions ) ) {
            $promotion_list = Options::get_listing_promotions();
            echo '<div class="membership-promotions rtcl-pricing-promotions">';
            echo '<div class="item"><span class="item-label"></span><span class="listing-count">Ads</span></span><span class="validate">Validate</span></div>';
            foreach ( $promotion_list as $promotion_key => $promotion_label ) {
                echo sprintf( '<div class="item"><span class="item-label">%s:</span><span class="listing-count">%d</span><span class="validate">%d</span></div>',
                        $promotion_label,
                        ! empty( $promotions[ $promotion_key ]['ads'] ) ? $promotions[ $promotion_key ]['ads'] : 0,
                        ! empty( $promotions[ $promotion_key ]['validate'] ) ? $promotions[ $promotion_key ]['validate'] : 0,
                );
            }
            echo "</div>";
        }
    }

    static function add_custom_page( $pages ) {
        $pages['store'] = [
                'title'   => __( 'Store', 'classified-listing-store' ),
                'content' => '',
        ];

        return $pages;
    }

    static private function register_store_menu() {
        if ( ! Functions::get_option_item( 'rtcl_membership_settings', 'enable_store', false, 'checkbox' ) ) {
            return;
        }
        add_filter( 'rtcl_advanced_settings_options', [ __CLASS__, 'add_store_end_point_options' ] );


        add_filter( 'rtcl_account_menu_items', [ __CLASS__, 'add_store_menu_item_at_account_menu' ] );
        add_filter( 'rtcl_my_account_endpoint', [ __CLASS__, 'add_my_account_store_end_points' ] );
    }

    /**
     * @param $features
     * @param $pricing Pricing
     *
     * @return array
     */
    public static function rtcl_get_payment_option_features( $features, $pricing ) {
        if ( 'membership' === $pricing->getType() ) {
            $ads                     = get_post_meta( $pricing->getId(), 'regular_ads', true );
            $features['regular_ads'] = sprintf( '<span class="ads-count">%d</span>%s',
                    $ads,
                    __( "Ads", "classified-listing-store" ),
            );
        }

        return $features;
    }

    public static function save_pricing_meta( $post_id, $post ) {
        if ( ! isset( $_POST['post_type'] ) ) {
            return $post_id;
        }

        if ( rtcl()->post_type_pricing != $post->post_type ) {
            return $post_id;
        }

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return $post_id;
        }

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return $post_id;
        }

        if ( isset( $_POST['pricing_type'] ) ) {
            $pricing_type = Functions::sanitize( $_POST['pricing_type'] );
            if ( ! in_array( $pricing_type, array_keys( Options::get_pricing_types() ) ) ) {
                $pricing_type = 'regular';
            }
            update_post_meta( $post_id, 'pricing_type', $pricing_type );
        }

        if ( isset( $_POST['regular_ads'] ) ) {
            $regular_ads = absint( Functions::sanitize( $_POST['regular_ads'] ) );
            update_post_meta( $post_id, 'regular_ads', $regular_ads );
        }

        if ( isset( $_POST['image_count'] ) ) {
            $image_count = absint( Functions::sanitize( $_POST['image_count'] ) );
            if ( $image_count > 0 ) {
                update_post_meta( $post_id, '_rtcl_image_count', $image_count );
            } else {
                // Blank/0 means "no override" — clear it so the field renders empty.
                delete_post_meta( $post_id, '_rtcl_image_count' );
            }
        }

        if ( isset( $_POST['_rtcl_membership_promotions'] ) ) {
            $promotions_list = Options::get_listing_promotions();
            $promotions      = [];
            if ( ! empty( $promotions_list ) ) {
                foreach ( $promotions_list as $promotion_key => $promotion_label ) {
                    if ( ! empty( $_POST['_rtcl_membership_promotions'][ $promotion_key ]['ads'] )
                         && ! empty( $_POST['_rtcl_membership_promotions'][ $promotion_key ]['validate'] )
                    ) {
                        $ads      = absint( $_POST['_rtcl_membership_promotions'][ $promotion_key ]['ads'] );
                        $validate = absint( $_POST['_rtcl_membership_promotions'][ $promotion_key ]['validate'] );
                        if ( $ads && $validate ) {
                            $promotions[ $promotion_key ]['ads']      = $ads;
                            $promotions[ $promotion_key ]['validate'] = $validate;
                        }
                    }
                }
            }
            if ( ! empty( $promotions ) ) {
                update_post_meta( $post_id, '_rtcl_membership_promotions', $promotions );
            } else {
                delete_post_meta( $post_id, '_rtcl_membership_promotions' );
            }
        }

        if ( isset( $_POST['membership_categories'] ) && is_array( $_POST['membership_categories'] ) && ! empty( $_POST['membership_categories'] ) ) {
            $cats = array_map( [
                    Functions::class,
                    'clean',
            ], array_map( 'stripslashes', $_POST['membership_categories'] ) );
            update_post_meta( $post_id, 'membership_categories', $cats );
        } else {
            delete_post_meta( $post_id, 'membership_categories' );
        }

        // Trial period — only for membership plans with subscription enabled
        $pricing_type = get_post_meta( $post_id, 'pricing_type', true );
        if ( 'membership' === $pricing_type && Functions::get_option_item( 'rtcl_payment_settings', 'subscription', false, 'checkbox' ) ) {
            if ( isset( $_POST['_rtcl_enable_trial'] ) && '1' === (string) $_POST['_rtcl_enable_trial'] ) {
                $trial_days = absint( $_POST['_rtcl_trial_days'] ?? 0 );
                if ( $trial_days < 1 ) {
                    $trial_days = 1;
                }
                update_post_meta( $post_id, '_rtcl_enable_trial', '1' );
                update_post_meta( $post_id, '_rtcl_trial_days', $trial_days );
            } else {
                delete_post_meta( $post_id, '_rtcl_enable_trial' );
                delete_post_meta( $post_id, '_rtcl_trial_days' );
            }
        }
    }

    public static function add_payment_pricing_type( $types ) {
        $types['membership'] = esc_html__( "Membership", "classified-listing-store" );

        return $types;
    }

    /**
     * Resolve the per-listing image count granted by the current user's active membership.
     *
     * Returns 0 when the user has no active (non-expired) membership or the plan did not set
     * an image count — callers treat 0 as "use the site default".
     *
     * @return int
     */
    public static function get_current_user_membership_image_count() {
        $user_id = get_current_user_id();
        if ( ! $user_id || ! function_exists( 'rtclStore' ) ) {
            return 0;
        }
        $membership = rtclStore()->factory->get_membership( $user_id );
        if ( ! $membership || ! $membership->has_membership() || $membership->is_expired() ) {
            return 0;
        }

        return absint( $membership->get_meta( '_rtcl_image_count', true ) );
    }

    /**
     * Override the form-builder "images" field max count for membership users when the
     * frontend add-listing form is built (localized through the rtcl_fb_form filter).
     *
     * @param  Form|mixed  $form
     *
     * @return Form|mixed
     */
    public static function override_membership_image_count( $form ) {
        if ( ! is_a( $form, Form::class ) || is_admin() ) {
            return $form;
        }
        $image_count = self::get_current_user_membership_image_count();
        if ( $image_count < 1 ) {
            return $form;
        }
        $fields = $form->fields;
        if ( empty( $fields ) || ! is_array( $fields ) ) {
            return $form;
        }
        foreach ( $fields as $field_id => $field ) {
            if ( isset( $field['element'] ) && 'images' === $field['element'] ) {
                $fields[ $field_id ]['validation']['max_file_count']['value'] = $image_count;
            }
        }
        $form->fields = $fields;

        return $form;
    }

    /**
     * Server-side enforcement of the membership image count on listing submission. Images are
     * uploaded ahead of submit (via AJAX) as attachments on the (temp) listing post, so we count
     * those — the same way the gallery uploader does — against the membership allowance. The form
     * passed here is the raw form (rtcl_fb_form is NOT applied on submit), so we resolve the
     * allowance directly rather than reading the field's max_file_count.
     *
     * @param  WP_Error  $errors
     * @param  Form|mixed  $form
     *
     * @return WP_Error
     */
    public static function validate_membership_image_count( $errors, $form ) {
        if ( ! $errors instanceof WP_Error || ! is_a( $form, Form::class ) ) {
            return $errors;
        }
        $image_count = self::get_current_user_membership_image_count();
        if ( $image_count < 1 ) {
            return $errors;
        }
        // Only relevant when the form actually collects images.
        if ( empty( $form->getFieldByElement( 'images' ) ) ) {
            return $errors;
        }
        $listing_id = ! empty( $_POST['listingId'] ) ? absint( $_POST['listingId'] ) : 0;
        if ( ! $listing_id ) {
            return $errors;
        }
        $uploaded = count( Functions::get_listing_images( $listing_id ) );
        if ( $uploaded > $image_count ) {
            $errors->add(
                    'image_count',
                    sprintf(
                    /* translators: %d: maximum number of images allowed by the membership */
                            esc_html__( 'You can upload maximum %d images for your membership.', 'classified-listing-store' ),
                            $image_count,
                    ),
            );
        }

        return $errors;
    }

    public static function add_pricing_options( $data, $post ) {
        $pricing_type    = get_post_meta( $post->ID, "pricing_type", true );
        $hide_allowed    = $pricing_type == "membership" ? " style='display:none'" : '';
        $regular_ads     = absint( get_post_meta( $post->ID, "regular_ads", true ) );
        $image_count_raw = get_post_meta( $post->ID, "_rtcl_image_count", true );
        $image_count     = ( '' === $image_count_raw || null === $image_count_raw ) ? '' : absint( $image_count_raw );
        $memberCats      = (array) get_post_meta( $post->ID, "membership_categories", true );
        $promotions      = get_post_meta( $post->ID, "_rtcl_membership_promotions", true );
        $promotions_list = Options::get_listing_promotions();
        $pricingTypes    = Options::get_pricing_types();
        $pOpt            = null;
        foreach ( $pricingTypes as $key => $value ) {
            $slt  = $pricing_type == $key ? " selected" : null;
            $pOpt .= "<option value='{$key}' {$slt}>{$value}</option>";
        }
        $promotion_options = '';
        if ( ! empty( $promotions_list ) ) {
            $promotion_options = sprintf( '<div class="rtcl-promotion-item">
                                                    <label> </label>
                                                    <div class="rtcl-promotion-action">
                                                        <span>%s</span>
                                                        <span>%s</span>
                                                    </div>
                                                </div>',
                    __( 'Ads', "classified-listing-store" ),
                    __( 'Validate<small>(Days)</small>', "classified-listing-store" ),
            );
            foreach ( $promotions_list as $promotion_key => $promotion_label ) {
                $promotion_options .= sprintf( '<div class="rtcl-promotion-item">
                                                    <label for="%2$s">%3$s</label>
                                                    <div class="rtcl-promotion-action" id="%2$s">
                                                        <input name="_rtcl_membership_promotions[%1$s][ads]" class="rtcl-form-control" type="number" step="1" value="%4$d">
                                                        <input name="_rtcl_membership_promotions[%1$s][validate]" class="rtcl-form-control" type="number" step="1" value="%5$d">
                                                    </div>
                                                </div>',
                        $promotion_key,
                        'promotion-' . $promotion_key,
                        $promotion_label,
                        ! empty( $promotions[ $promotion_key ]['ads'] ) ? absint( $promotions[ $promotion_key ]['ads'] ) : '',
                        ! empty( $promotions[ $promotion_key ]['validate'] ) ? absint( $promotions[ $promotion_key ]['validate'] ) : '',
                );
            }
        }

        $data['allowed'] = substr_replace( $data['allowed'], " allowed", 20, 0 );
        $data['allowed'] = substr_replace( $data['allowed'], $hide_allowed, 4, 0 );

        $pricing_type_data       = [
                'price_type' => sprintf( '<div class="rtcl-row rtcl-form-group">
                                                    <label class="rtcl-col-2 rtcl-field-label"
                                                           for="pricing-type">%s</label>
                                                    <div class="rtcl-col-10">
                                                        <select class="rtcl-form-control" id="pricing-type" name="pricing_type" required>%s</select>
                                                    </div>
                                                </div>',
                        __( "Pricing Type", "classified-listing-store" ),
                        $pOpt,
                ),
        ];
        $data                    = array_merge( $pricing_type_data, $data );
        $membership_options_data = [
                'regular_ads' => sprintf( '<div class="rtcl-row rtcl-form-group regular-listings"%s>
                                            <label class="rtcl-col-2 rtcl-field-label" for="regular-listings">%s</label>
                                            <div class="rtcl-col-10">
                                                <input type="number" step="1" name="regular_ads" id="regular-listings" value="%d"
                                                       class="rtcl-form-control" required>
                                                <div class="rtcl-hints">%s</div>
                                            </div>
                                        </div>',
                        $pricing_type == "membership" ? '' : " style='display:none'",
                        esc_html__( "Total Number of ads", "classified-listing-store" ),
                        esc_attr( $regular_ads ),
                        esc_html__( "Total Number of ads for Pay per ad", "classified-listing-store" ),
                ),
                'image_count' => sprintf( '<div class="rtcl-row rtcl-form-group image-count"%s>
                                            <label class="rtcl-col-2 rtcl-field-label" for="image-count">%s</label>
                                            <div class="rtcl-col-10">
                                                <input type="number" step="1" min="1" name="image_count" id="image-count" value="%s"
                                                       class="rtcl-form-control" placeholder="%s">
                                                <div class="rtcl-hints">%s</div>
                                            </div>
                                        </div>',
                        $pricing_type == "membership" ? '' : " style='display:none'",
                        esc_html__( "Image Count (Per Listing)", "classified-listing-store" ),
                        esc_attr( $image_count ),
                        esc_attr__( "Site default", "classified-listing-store" ),
                        esc_html__( "Overrides the default maximum images per listing for this membership. Leave blank for the site default (no override).", "classified-listing-store" ),
                ),
                'promotions'  => sprintf( '<div class="rtcl-row rtcl-form-group rtcl-membership-promotions"%s>
                                            <label class="rtcl-col-2 rtcl-field-label">%s<small class="hint d-block text-danger">(%s)</small></label>
                                            <div class="rtcl-col-10 rtcl-promotions-wrap">%s</div>
                                        </div>',
                        $pricing_type == "membership" ? '' : " style='display:none'",
                        esc_html__( "Promotions", "classified-listing-store" ),
                        esc_html__( "Total number of promotions ads must be less then total number of ads", "classified-listing-store" ),
                        $promotion_options,
                ),
        ];
        $data                    = Functions::array_insert_after( 'price', $data, $membership_options_data );
        ob_start();
        ?>
        <div class="rtcl-row rtcl-form-group membership-categories"<?php if ( $pricing_type != "membership" ) { ?> style="display:none"<?php } ?>>
            <label class="rtcl-col-2 rtcl-field-label"><?php esc_html_e( "Categories", "classified-listing-store" ); ?></label>
            <div class="rtcl-col-10">
                <div class="checkbox">
                    <?php
                    $cats = StoreFunctions::get_first_level_category_array();
                    if ( ! empty( $cats ) ):
                        foreach ( $cats as $catId => $cat ):?>
                            <div class="form-check">
                                <input class="form-check-input" name="membership_categories[]" type="checkbox"
                                       value="<?php echo esc_attr( $catId ) ?>"
                                        <?php echo in_array( $catId, $memberCats ) ? ' checked' : null; ?>
                                       id="membership_categories_<?php echo esc_attr( $catId ); ?>">
                                <label class="form-check-label"
                                       for="membership_categories_<?php echo esc_attr( $catId ); ?>"><?php echo esc_html( $cat ) ?></label>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <span class="description"><?php esc_html_e( "If you leave it unchecked, membership will validate for all categories.",
                            "classified-listing-store" ); ?></span>
            </div>
        </div>
        <?php
        $mc_html         = ob_get_clean();
        $categories_data = [ 'membership_categories' => $mc_html ];

        $data = Functions::array_insert_after( 'visible', $data, $categories_data );

        if ( ! Functions::get_option_item( 'rtcl_payment_settings', 'subscription', false, 'checkbox' ) ) {
            return $data;
        }

        $enable_trial = get_post_meta( $post->ID, '_rtcl_enable_trial', true );
        $trial_days   = absint( get_post_meta( $post->ID, '_rtcl_trial_days', true ) );
        ob_start();
        ?>
        <div class="rtcl-row rtcl-form-group membership-categories"<?php if ( $pricing_type !== 'membership' ) { ?> style="display:none"<?php } ?>>
            <label class="rtcl-col-2 rtcl-field-label"><?php esc_html_e( 'Trial Period', 'classified-listing-store' ); ?></label>
            <div class="rtcl-col-10">
                <label style="font-weight:600;display:inline-flex;align-items:center;gap:6px;cursor:pointer;">
                    <input type="checkbox" name="_rtcl_enable_trial" id="rtcl_enable_trial" value="1" <?php checked( $enable_trial, '1' ); ?> style="cursor:pointer;"/>
                    <?php esc_html_e( 'Enable Trial Period', 'classified-listing-store' ); ?>
                </label>
                <div id="rtcl_trial_days_row" style="<?php echo $enable_trial ? '' : 'display:none;'; ?>margin-top:8px;">
                    <input type="number" name="_rtcl_trial_days" id="rtcl_trial_days"
                           value="<?php echo esc_attr( $trial_days ?: 1 ); ?>"
                           min="1" class="rtcl-form-control" style="width:100px;"/>
                    <div class="rtcl-hints"><?php esc_html_e( 'Free trial days before the first Stripe charge.', 'classified-listing-store' ); ?></div>
                </div>
                <script>
                    jQuery(function ($) {
                        $(document).on('change', '#rtcl_enable_trial', function () {
                            $('#rtcl_trial_days_row').toggle(this.checked);
                        });
                    });
                </script>
            </div>
        </div>
        <?php
        $trial_html = ob_get_clean();
        $trial_data = [ 'trial_period' => $trial_html ];

        return Functions::array_insert_after( 'regular_ads', $data, $trial_data );
    }


    public static function remove_attachment_for_store( $excluded_ids ) {
        $store_ids = get_posts( [
                'post_type'        => rtclStore()->post_type,
                'post_status'      => 'any',
                'posts_per_page'   => - 1,
                'fields'           => 'ids',
                'suppress_filters' => false,
        ] );
        if ( ! empty( $store_ids ) ) {
            $excluded_ids = array_merge( $store_ids, (array) $excluded_ids );
        }

        return $excluded_ids;
    }

    public static function add_store_menu_item_at_account_menu( $items ) {
        if ( Functions::is_user_type_buyer() ) {
            return $items;
        }
        if ( Functions::get_option_item( 'rtcl_membership_settings', 'enable_store', false, 'checkbox' ) ) {
            if ( Functions::get_option_item( 'rtcl_membership_settings', 'enable_store_only_membership', false, 'checkbox' ) ) {
                $member = rtclStore()->factory->get_membership();
                if ( ! $member || $member->is_expired() ) {
                    return $items;
                }
            }

            $item = [ 'store' => apply_filters( 'rtcl_store_myaccount_store_title', esc_html__( 'Store', 'classified-listing-store' ) ) ];
            Functions::array_insert( $items, 1, $item );
        }

        return $items;
    }

    // Add membership tab options
    public static function add_settings_options( $option_items ) {
        $fields = [
                'membership_section'                  => [
                        'title' => esc_html__( 'Membership Settings', 'classified-listing-store' ),
                        'type'  => 'section',
                ],
                'enable'                              => [
                        'title'       => esc_html__( 'Enable Membership', 'classified-listing-store' ),
                        'label'       => esc_html__( 'Enable', 'classified-listing-store' ),
                        'type'        => 'switch',
                        'description' => esc_html__( 'Enable Membership option', 'classified-listing-store' ),
                ],
                'renew_only_membership'               => [
                        'title'       => esc_html__( 'Renew Only for Membership', 'classified-listing-store' ),
                        'label'       => esc_html__( 'Enable', 'classified-listing-store' ),
                        'type'        => 'switch',
                        'description' => __( 'Allow renew only for membership user.', 'classified-listing-store' ),
                        'depends'     => [
                                'on' => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                ],
                        ],
                ],
                'expiry_republish_with_subscription'  => [
                        'title'       => esc_html__( 'Listings and Promotions Expiry Mode', 'classified-listing-store' ),
                        'description' => __( 'When set to Unified, listings and promotions will expire and republish together with the subscription plan.', 'classified-listing-store' ),
                        'type'        => 'radio',
                        'options'     => [
                                'independent' => esc_html__( 'Expire Separately (Independent)', 'classified-listing-store' ),
                                'unified'     => esc_html__( 'Follow Membership Expiry (Unified)', 'classified-listing-store' ),
                        ],
                        'default'     => 'independent',
                        'orientation' => 'vertical',
                        'depends'     => [
                                'on' => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                ],
                        ],
                ],
                'enable_pay_per_ad'                   => [
                        'title'       => esc_html__( 'Enable Pay Per Ad', 'classified-listing-store' ),
                        'label'       => esc_html__( 'Enable', 'classified-listing-store' ),
                        'type'        => 'switch',
                        'description' => esc_html__( 'Enable Pay Per Ad posting', 'classified-listing-store' ),
                        'depends'     => [
                                'on' => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                ],
                        ],
                ],
                'enable_free_ads'                     => [
                        'title'       => esc_html__( 'Enable Free Ads', 'classified-listing-store' ),
                        'label'       => esc_html__( 'Enable', 'classified-listing-store' ),
                        'type'        => 'switch',
                        'description' => esc_html__( 'Enable free ad posting', 'classified-listing-store' ),
                        'depends'     => [
                                'relation' => 'and',
                                'on'       => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                        [
                                                'field'     => 'rtcl_membership_settings.enable_pay_per_ad',
                                                'value'     => 'yes',
                                                'condition' => '!=',
                                        ],
                                ],
                        ],
                ],
                'number_of_free_ads'                  => [
                        'title'       => esc_html__( 'Number of Free Ads', 'classified-listing-store' ),
                        'type'        => 'number',
                        'default'     => 3,
                        'description' => __( 'Number of ads to post as free with out membership, if membership is enabled.<br>If this field is blank dy default it will be 3',
                                'classified-listing-store' ),
                        'depends'     => [
                                'relation' => 'and',
                                'on'       => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                        [
                                                'field'     => 'rtcl_membership_settings.enable_free_ads',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                        [
                                                'field'     => 'rtcl_membership_settings.enable_pay_per_ad',
                                                'value'     => 'yes',
                                                'condition' => '!=',
                                        ],
                                ],
                        ],
                ],
                'renewal_days_for_free_ads'           => [
                        'title'       => esc_html__( 'Renewal Days for Free Ads Number', 'classified-listing-store' ),
                        'type'        => 'number',
                        'default'     => 30,
                        'description' => __( 'Free ads number will be renew after this days.<br>If this field is blank it will be 30', 'classified-listing-store' ),
                        'depends'     => [
                                'relation' => 'and',
                                'on'       => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                        [
                                                'field'     => 'rtcl_membership_settings.enable_free_ads',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                        [
                                                'field'     => 'rtcl_membership_settings.enable_pay_per_ad',
                                                'value'     => 'yes',
                                                'condition' => '!=',
                                        ],
                                ],
                        ],
                ],
                'unlimited_free_ads_membership'       => [
                        'title'       => esc_html__( 'Enable Unlimited Free Ads for Membership', 'classified-listing-store' ),
                        'label'       => esc_html__( 'Enable', 'classified-listing-store' ),
                        'type'        => 'switch',
                        'depends'     => [
                                'relation' => 'and',
                                'on'       => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                        [
                                                'field'     => 'rtcl_membership_settings.enable_free_ads',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                ],
                        ],
                        'description' => esc_html__( 'Enable unlimited free ad posting for membership user.', 'classified-listing-store' ),
                ],
                'categories_of_free_ads'              => [
                        'title'       => esc_html__( 'Allowed Category for Free Ads', 'classified-listing-store' ),
                        'type'        => 'multi_checkbox',
                        'orientation' => 'vertical',
                        'options'     => StoreFunctions::get_first_level_category_array(),
                        'description' => esc_html__( 'Select the specific category for free ads, Leave it un select to allow any category.',
                                'classified-listing-store' ),
                        'depends'     => [
                                'relation' => 'and',
                                'on'       => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                        [
                                                'field'     => 'rtcl_membership_settings.enable_free_ads',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                ],
                        ],
                ],
                'store_section'                       => [
                        'title' => esc_html__( 'Store Settings', 'classified-listing-store' ),
                        'type'  => 'section',
                ],
                'enable_store'                        => [
                        'title'       => esc_html__( 'Enable Store', 'classified-listing-store' ),
                        'label'       => esc_html__( 'Enable', 'classified-listing-store' ),
                        'type'        => 'switch',
                        'description' => esc_html__( 'All Store functionality will be active', 'classified-listing-store' ),
                ],
                'stores_per_page'                     => [
                        'title'       => esc_html__( 'Stores per page', 'classified-listing-store' ),
                        'type'        => 'number',
                        'default'     => 12,
                        'css'         => 'width:50px',
                        'description' => esc_html__( 'Number of stores to show per page. Use a value of "0" to show all stores.',
                                'classified-listing-store' ),
                        'depends'     => [
                                'on' => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable_store',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                ],
                        ],
                ],
                'stores_per_row'                      => [
                        'title'       => esc_html__( 'Stores per row', 'classified-listing-store' ),
                        'type'        => 'number',
                        'default'     => 4,
                        'css'         => 'width:50px',
                        'description' => esc_html__( 'Number of stores to show in a row. Added support for maximum 6 columns.', 'classified-listing-store' ),
                        'depends'     => [
                                'on' => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable_store',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                ],
                        ],
                ],
                'enable_store_rating'                 => [
                        'title'       => esc_html__( 'Enable Store Rating', 'classified-listing-store' ),
                        'label'       => esc_html__( 'Enable', 'classified-listing-store' ),
                        'type'        => 'switch',
                        'default'     => 'yes',
                        'description' => esc_html__( 'Enable Store rating. ', 'classified-listing-store' ),
                        'depends'     => [
                                'on' => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable_store',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                ],
                        ],
                ],
                'new_store_status'                    => [
                        'title'       => esc_html__( 'New / Edited Store Status', 'classified-listing-store' ),
                        'type'        => 'select',
                        'default'     => 'publish',
                        'options'     => [
                                'publish' => esc_html__( 'Publish', 'classified-listing-store' ),
                                'pending' => esc_html__( 'Pending', 'classified-listing-store' ),
                        ],
                        'description' => esc_html__( 'Store default status after creation.', 'classified-listing-store' ),
                        'depends'     => [
                                'on' => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable_store',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                ],
                        ],
                ],
                'enable_store_only_membership'        => [
                        'title'       => esc_html__( 'Store Only for Membership', 'classified-listing-store' ),
                        'label'       => esc_html__( 'Enable', 'classified-listing-store' ),
                        'type'        => 'switch',
                        'description' => esc_html__( 'Store menu at My Account page will visible only for the valid membership users. ',
                                'classified-listing-store' ),
                        'depends'     => [
                                'relation' => 'and',
                                'on'       => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable_store',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                        [
                                                'field'     => 'rtcl_membership_settings.enable',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                ],
                        ],
                ],
                'display_store_only_valid_membership' => [
                        'title'       => esc_html__( 'Single Store Only for Membership', 'classified-listing-store' ),
                        'label'       => esc_html__( 'Enable', 'classified-listing-store' ),
                        'type'        => 'switch',
                        'description' => esc_html__( 'Single store page will display only for valid membership owner. If enable, store single page will be only visible until membership is active.',
                                'classified-listing-store' ),
                        'depends'     => [
                                'relation' => 'and',
                                'on'       => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable_store',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                        [
                                                'field'     => 'rtcl_membership_settings.enable',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                ],
                        ],
                ],
                'enable_store_manager'                => [
                        'title'   => esc_html__( 'Store Manager', 'classified-listing-store' ),
                        'label'   => esc_html__( 'Enable', 'classified-listing-store' ),
                        'type'    => 'switch',
                        'depends' => [
                                'on' => [
                                        [
                                                'field'     => 'rtcl_membership_settings.enable_store',
                                                'value'     => 'yes',
                                                'condition' => '=',
                                        ],
                                ],
                        ],
                ],
        ];

        $fields = apply_filters( 'rtcl_membership_settings_options', $fields );

        $option_items['rtcl_membership_settings'] = [
                'label'  => esc_html__( 'Membership', 'classified-listing-store' ),
                'icon'   => 'fas fa-users',
                'fields' => $fields,
        ];

        return $option_items;
    }

    public static function add_misc_options( $options ) {
        $position = array_search( 'image_size_thumbnail', array_keys( $options ) );
        if ( $position > - 1 ) {
            $option = [
                    'store_banner_size' => [
                            'title'       => esc_html__( 'Store Banner', 'classified-listing-store' ),
                            'type'        => 'image_size',
                            'default'     => [ 'width' => 1200, 'height' => 360, 'crop' => 'yes' ],
                            'options'     => [
                                    'width'  => esc_html__( 'Width', 'classified-listing-store' ),
                                    'height' => esc_html__( 'Height', 'classified-listing-store' ),
                                    'crop'   => esc_html__( 'Hard Crop', 'classified-listing-store' ),
                            ],
                            'description' => esc_html__( 'This image size is being used in banner at the store detail page.', "classified-listing-store" ),
                    ],
                    'store_logo_size'   => [
                            'title'       => esc_html__( 'Store Logo', 'classified-listing-store' ),
                            'type'        => 'image_size',
                            'default'     => [ 'width' => 200, 'height' => 150, 'crop' => 'yes' ],
                            'options'     => [
                                    'width'  => esc_html__( 'Width', 'classified-listing-store' ),
                                    'height' => esc_html__( 'Height', 'classified-listing-store' ),
                                    'crop'   => esc_html__( 'Hard Crop', 'classified-listing-store' ),
                            ],
                            'description' => esc_html__( 'This image size is being used at the store detail page and where store link is given.',
                                    "classified-listing-store" ),
                    ],
            ];
            Functions::array_insert( $options, $position, $option );
        }

        return $options;
    }

    public static function add_store_end_point_options( $options ) {
        $position = array_search( 'location_base', array_keys( $options ) );
        if ( $position > - 1 ) {
            $option = [
                    'permalink_store'     => [
                            'title'       => esc_html__( 'Store Base', 'classified-listing-store' ),
                            'type'        => 'text',
                            'default'     => _x( 'store', 'slug', 'classified-listing-store' ),
                            'description' => esc_html__( 'Store base permalink.', 'classified-listing-store' ),
                    ],
                    'store_category_base' => [
                            'title'       => esc_html__( 'Store Category Base', 'classified-listing-store' ),
                            'type'        => 'text',
                            'default'     => _x( 'store-category', 'slug', 'classified-listing-store' ),
                            'description' => esc_html__( 'Store category base permalink.', 'classified-listing-store' ),
                    ],
            ];
            Functions::array_insert( $options, $position, $option );
        }

        $position = array_search( 'checkout', array_keys( $options ) );
        if ( $position > - 1 ) {
            $option = [
                    'store' => [
                            'title'       => esc_html__( 'Store Page', 'classified-listing-store' ),
                            'type'        => 'select',
                            'class'       => 'rtcl-select2',
                            'blank_text'  => esc_html__( "Select a page", 'classified-listing-store' ),
                            'options'     => Functions::get_pages(),
                            'description' => esc_html__( 'This is the page where all the active store lists are displayed.', 'classified-listing-store' ),
                            'css'         => 'min-width:300px;',
                    ],
            ];
            Functions::array_insert( $options, $position, $option );
        }

        $position = array_search( 'myaccount_listings_endpoint', array_keys( $options ) );
        if ( $position > - 1 ) {
            $option = [
                    'myaccount_store_endpoint' => [
                            'title'   => esc_html__( 'Store', 'classified-listing-store' ),
                            'type'    => 'text',
                            'default' => 'store',
                    ],
            ];
            Functions::array_insert( $options, $position, $option );
        }

        $position   = array_search( 'checkout_submission_endpoint', array_keys( $options ) );
        $newOptions = [
                'checkout_membership_endpoint' => [
                        'title'   => esc_html__( 'Membership', 'classified-listing-store' ),
                        'type'    => 'text',
                        'default' => 'membership',
                ],
        ];
        if ( $position > - 1 ) {
            Functions::array_insert( $options, $position, $newOptions );
        } else {
            $options = array_merge( $options, $newOptions );
        }

        return $options;
    }

    public static function add_checkout_membership_endpoint( $endpoints ) {
        if ( StoreFunctions::is_membership_enabled() ) {
            $endpoints['membership'] = Functions::get_option_item( 'rtcl_advanced_settings', 'checkout_membership_endpoint', 'membership' );
        }

        return $endpoints;
    }

    public static function add_my_account_store_end_points( $endpoints ) {
        if ( Functions::is_user_type_buyer() ) {
            return $endpoints;
        }
        if ( Functions::get_option_item( 'rtcl_membership_settings', 'enable_store_only_membership', false, 'checkbox' ) ) {
            $member = rtclStore()->factory->get_membership();
            if ( ! $member || $member->is_expired() ) {
                return $endpoints;
            }
        }
        $endpoints['store'] = Functions::get_option_item( 'rtcl_advanced_settings', 'myaccount_store_endpoint', 'store' );

        return $endpoints;
    }

    public static function get_template_part( $template, $slug, $name ) {
        if ( strpos( $template, "classified-listing/" . $name ) === false && ! file_exists( $template ) ) {
            $cache_key = sanitize_key( implode( '-', [ 'template-part', $slug, $name, RTCL_STORE_VERSION ] ) );
            $template  = (string) wp_cache_get( $cache_key, 'rtcl_store' );

            if ( ! $template ) {
                if ( $name ) {
                    $template = RTCL_STORE_TEMPLATE_DEBUG_MODE
                            ? ''
                            : locate_template(
                                    [
                                            rtcl()->get_template_path() . "{$slug}-{$name}.php",
                                    ],
                            );

                    if ( ! $template ) {
                        $fallback = rtclStore()->plugin_path() . "/templates/{$slug}-{$name}.php";
                        $template = file_exists( $fallback ) ? $fallback : '';
                    }
                }
                wp_cache_set( $cache_key, $template, 'rtcl_store' );
            }
        }

        return $template;
    }

    public static function locate_store_template( $template_file, $name ) {
        if ( strpos( $template_file, "classified-listing/" . $name ) === false && ! file_exists( $template_file ) ) {
            $template_file = rtclStore()->plugin_path() . "/templates/$name.php";
        }

        return $template_file;
    }

    public static function add_store_settings_tab( $tabs ) {
        $tabs['store'] = esc_html__( "Store", "classified-listing-store" );

        return $tabs;
    }


    /**
     * @param  int  $paymentId
     * @param  Payment  $payment
     */
    public static function payment_receipt_pricing_info( $paymentId, $payment ) {
        if ( 'membership' === get_post_meta( $paymentId, 'payment_type', true ) ) {
            Functions::get_template( "checkout/membership-pricing-info", compact( 'payment' ), '', rtclStore()->get_plugin_template_path() );
        } else {
            Functions::get_template( "checkout/pricing-info", compact( 'payment' ) );
        }
    }

    public static function payment_receipt_popup_pricing_info( $paymentId, $payment ) {
        if ( 'membership' === get_post_meta( $paymentId, 'payment_type', true ) ) {
            Functions::get_template( "myaccount/popup-membership-pricing-info", compact( 'payment' ), '', rtclStore()->get_plugin_template_path() );
        } else {
            Functions::get_template( "myaccount/popup-pricing-info", compact( 'payment' ) );
        }
    }

    public static function add_store_update_admin_email_notification( $options ) {
        $options['store_update'] = esc_html__( 'Store Update', 'classified-listing-store' );

        return $options;
    }

    public static function add_recaptcha_store_contact_form( $list ) {
        $list['store_contact'] = esc_html__( 'Store contact form', 'classified-listing-store' );

        return $list;
    }

    public static function add_recaptcha_script_store_contact_form() {
        if ( is_singular( rtclStore()->post_type )
             && Functions::get_option_item( 'rtcl_misc_settings', 'recaptcha_forms', 'store_contact', 'multi_checkbox' )
        ) {
            wp_enqueue_script( 'rtcl-recaptcha' );
        }
    }
}
