<?php
/**
 * Membership checkout
 *
 * @author     RadiusTheme
 * @package    classified-listing/templates
 * @version    1.0.0
 */


use Rtcl\Helpers\Functions;
use Rtcl\Resources\Options;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$currency        = Functions::get_order_currency();
$currency_symbol = Functions::get_currency_symbol( $currency );
?>
<div id="rtcl-checkout-pricing-option">
    <div class="rtcl-checkout-pricing-wrapper rtcl-row rtcl-form-group">
		<?php if ( ! empty( $pricing_options ) ) :
			foreach ( $pricing_options as $option ) :
				$price       = get_post_meta( $option->ID, 'price', true );
				$pricing     = rtcl()->factory->get_pricing( $option->ID );
				$description = $pricing->getDescription();

				// Feature data (label → value rows).
				$regular_ads    = absint( get_post_meta( $option->ID, 'regular_ads', true ) );
				$visible_days   = absint( $pricing->getVisible() );
				$image_count    = absint( get_post_meta( $option->ID, '_rtcl_image_count', true ) );
				$promotions     = get_post_meta( $option->ID, '_rtcl_membership_promotions', true );
				$promotion_list = Options::get_listing_promotions();
				$days_word      = esc_html__( 'Days', 'classified-listing-store' );

				// Icon + featured highlight.
				$pricing_icon   = $pricing->getIcon();
				$icon_class     = $pricing_icon ? ( false !== strpos( $pricing_icon, 'fa-' ) ? $pricing_icon : 'rtcl-icon rtcl-icon-' . $pricing_icon ) : '';
				$is_featured    = $pricing->isFeaturedPlan();
				$featured_label = $pricing->getFeaturedLabel();
				?>
                <div class="rtcl-col-md-4 rtcl-col-12">
                    <div class="rtcl-checkout-pricing<?php echo $is_featured ? ' is-featured' : ''; ?>">
                        <div class="rtcl-checkout-pricing-inner">
							<?php if ( $is_featured ) : ?>
                                <span class="rtcl-featured-badge"><?php echo esc_html( $featured_label ); ?></span>
							<?php endif; ?>
                            <?php if ( ! empty( $option->post_title ) ) : ?>
                                <div class="rtcl-promo-head">
                                    <?php if ( $icon_class ) : ?>
                                        <span class="rtcl-promo-icon"><i class="<?php echo esc_attr( $icon_class ); ?>"></i></span>
                                    <?php endif; ?>
                                    <span class="rtcl-promo-heading">
                                    <span class="rtcl-pricing-title"><?php echo esc_html( $option->post_title ); ?></span>
                                </span>
                                </div>
                            <?php endif; ?>
                            <span class="rtcl-pricing-price"><?php echo Functions::get_payment_formatted_price_html( $price ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<?php if ( $description ): ?>
                                <div class="rtcl-pricing-description"><?php Functions::print_html( nl2br( $description ), true ); ?></div>
							<?php endif; ?>
							<?php
							$_enable_trial = get_post_meta( $option->ID, '_rtcl_enable_trial', true );
							$_trial_days   = absint( get_post_meta( $option->ID, '_rtcl_trial_days', true ) );
							if ( '1' === $_enable_trial && $_trial_days > 0 && Functions::get_option_item( 'rtcl_payment_settings', 'subscription', false, 'checkbox' ) ) :
								?>
                                <div class="rtcl-trial-notice">
									<?php echo esc_html( sprintf(
									/* translators: %d: number of trial days */
										_n( '%d day free trial', '%d days free trial', $_trial_days, 'classified-listing-store' ),
										$_trial_days
									) ); ?>
                                </div>
							<?php endif; ?>
                            <div class="rtcl-promo-meta">
                                <div class="rtcl-promo-row">
                                    <span class="rtcl-promo-label">
										<?php
										/* translators: %d: number of regular ads */
										printf( esc_html__( '%d Regular Ads', 'classified-listing-store' ), $regular_ads );
										?>
                                    </span>
                                    <span class="rtcl-promo-value"><?php echo esc_html( $visible_days . ' ' . $days_word ); ?></span>
                                </div>
								<?php if ( $image_count ) : ?>
                                    <div class="rtcl-promo-row">
                                        <span class="rtcl-promo-label"><?php esc_html_e( 'Images Per Listing', 'classified-listing-store' ); ?></span>
                                        <span class="rtcl-promo-value"><?php echo esc_html( $image_count ); ?></span>
                                    </div>
								<?php endif; ?>
								<?php
								if ( is_array( $promotions ) && ! empty( $promotions ) ) {
									foreach ( $promotions as $promotion_key => $promotion ) {
										$p_label = ! empty( $promotion_list[ $promotion_key ] ) ? $promotion_list[ $promotion_key ] : $promotion_key;
										$p_ads   = absint( ! empty( $promotion['ads'] ) ? $promotion['ads'] : 0 );
										$p_days  = absint( ! empty( $promotion['validate'] ) ? $promotion['validate'] : 0 );
										?>
                                        <div class="rtcl-promo-row">
                                            <span class="rtcl-promo-label">
												<?php
												/* translators: 1: number of ads, 2: promotion name e.g. Featured */
												echo esc_html( sprintf( __( '%1$d %2$s Ads', 'classified-listing-store' ), $p_ads, $p_label ) );
												?>
                                            </span>
                                            <span class="rtcl-promo-value"><?php echo esc_html( $p_days . ' ' . $days_word ); ?></span>
                                        </div>
										<?php
									}
								}
								?>
								<?php
								$membership_cats = get_post_meta( $option->ID, 'membership_categories', true );
								if ( is_array( $membership_cats ) && ! empty( $membership_cats ) ) {
									$cat_names = [];
									foreach ( $membership_cats as $cat_id ) {
										$term = get_term( absint( $cat_id ), rtcl()->category );
										if ( $term && ! is_wp_error( $term ) ) {
											$cat_names[] = $term->name;
										}
									}
									if ( ! empty( $cat_names ) ) :
										?>
										<div class="rtcl-promo-row rtcl-promo-row--categories">
											<span class="rtcl-promo-label"><?php esc_html_e( 'Categories', 'classified-listing-store' ); ?></span>
											<div class="rtcl-promo-cats">
												<?php foreach ( $cat_names as $cat_name ) : ?>
													<span class="rtcl-promo-cat-tag"><?php echo esc_html( $cat_name ); ?></span>
												<?php endforeach; ?>
											</div>
										</div>
									<?php endif;
								}
								?>
                            </div>
                            <div class="rtcl-pricing-btn">
								<?php
								printf( '<input type="radio" name="%s" id="pricing_id_%s" value="%s" class="rtcl-checkout-pricing" required data-price="%s"/><label for="pricing_id_%s">%s</label>',
									'pricing_id', esc_attr( $option->ID ), esc_attr( $option->ID ), esc_attr( $price ), esc_attr( $option->ID ),
									esc_html__( 'Select This Package', 'classified-listing-store' ) );
								?>
                            </div>
                        </div>
                    </div>
                </div>
			<?php endforeach;
		else: ?>
            <div>
                <span><?php esc_html_e( "No plan found.", "classified-listing-store" ); ?></span>
            </div>
		<?php endif; ?>
    </div>
</div>
