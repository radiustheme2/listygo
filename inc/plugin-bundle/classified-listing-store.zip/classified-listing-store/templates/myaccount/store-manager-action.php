<?php

use RtclStore\Models\Store;

/**
 * @author     RadiusTheme
 * @package    classified-listing-store/templates
 * @version    1.0.1
 *
 * @var \WP_User $current_user
 * @var Store    $store
 */

if (!$store)
    return;
?>

<div class="rtcl-store-manager-action rtcl-store-manager-notice">
	<span class="rtcl-store-manager-notice-icon" aria-hidden="true">
		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l1.5-5h15L21 9"/><path d="M3 9h18v1.5a3 3 0 0 1-6 0 3 3 0 0 1-6 0 3 3 0 0 1-6 0z"/><path d="M5 13v7h14v-7"/><path d="M10 20v-4h4v4"/></svg>
	</span>
	<p><?php printf(esc_html__("You are a manager of the store : %s", "classified-listing-store"), sprintf('<a href="%s">%s</a>', esc_url($store->get_the_permalink()), esc_html($store->get_the_title()))) ?></p>
	<button type="button"
			class="btn btn-danger rtcl-self-rm-store-manager"><?php esc_html_e("Remove from store manager", "classified-listing-store"); ?></button>
</div>
