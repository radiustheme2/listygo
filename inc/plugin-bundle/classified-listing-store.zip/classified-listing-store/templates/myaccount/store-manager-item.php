<?php
/**
 * Single row of the My Account > Store > Managers list.
 * Used by the page template and by the invitation AJAX response.
 *
 * @author     RadiusTheme
 * @package    classified-listing-store/templates
 * @version    3.2.3.1
 *
 * @var Store    $store
 * @var \WP_User $user
 * @var bool     $is_pending
 * @var string   $context    'account' (My Account) or 'admin' (store edit screen).
 */

use Rtcl\Helpers\Link;
use RtclStore\Helpers\Functions as StoreFunctions;
use RtclStore\Models\Store;

defined( 'ABSPATH' ) || exit;

if ( empty( $user ) || ! is_a( $user, \WP_User::class ) ) {
	return;
}

$is_pending = ! empty( $is_pending );
$context    = isset( $context ) ? $context : 'account';
$name       = trim( implode( ' ', [ $user->first_name, $user->last_name ] ) );
$name       = $name ? $name : $user->display_name;
$pp_id      = absint( get_user_meta( $user->ID, '_rtcl_pp_id', true ) );
?>
<div class="rtcl-store-manager<?php echo $is_pending ? ' is-pending' : ''; ?>" data-manager_user_id="<?php echo absint( $user->ID ); ?>">
	<div class="rtcl-store-m-avatar">
		<?php echo $pp_id ? wp_get_attachment_image( $pp_id, [ 100, 100 ] ) : get_avatar( $user->ID, 100 ); ?>
	</div>
	<div class="rtcl-store-m-info">
		<div class="rtcl-m-info-name"><?php echo esc_html( $name ); ?></div>
		<?php // Pending invitees have not joined yet, so the store owner sees their address partly hidden. ?>
		<div class="rtcl-m-info-email"><?php echo esc_html( $is_pending && ! ( 'admin' === $context && current_user_can( 'list_users' ) ) ? StoreFunctions::mask_email( $user->user_email ) : $user->user_email ); ?></div>
	</div>
	<div class="rtcl-store-m-meta">
		<?php if ( $is_pending ) : ?>
			<span class="rtcl-m-info-status pending"><?php esc_html_e( 'Pending', 'classified-listing-store' ); ?></span>
		<?php else : ?>
			<span class="rtcl-m-info-status active"><?php esc_html_e( 'Active', 'classified-listing-store' ); ?></span>
			<?php if ( $store && 'admin' === $context ) : ?>
				<span class="rtcl-m-info-listings">
					<?php printf( esc_html__( 'Listings (%s)', 'classified-listing-store' ), count( $store->get_manager_listing_ids( $user->ID ) ) ); ?>
				</span>
			<?php elseif ( $store ) : ?>
				<a class="rtcl-m-info-listings" href="<?php echo esc_url( add_query_arg( [ 'manager' => $user->user_login ], Link::get_account_endpoint_url( 'listings' ) ) ); ?>">
					<?php printf( esc_html__( 'Listings (%s)', 'classified-listing-store' ), count( $store->get_manager_listing_ids( $user->ID ) ) ); ?>
				</a>
			<?php endif; ?>
		<?php endif; ?>
	</div>
	<button type="button" class="rtcl-store-manager-remove"
			data-manager_user_id="<?php echo absint( $user->ID ); ?>"
			title="<?php echo $is_pending ? esc_attr__( 'Cancel invitation', 'classified-listing-store' ) : esc_attr__( 'Remove manager', 'classified-listing-store' ); ?>"
			aria-label="<?php echo $is_pending ? esc_attr__( 'Cancel invitation', 'classified-listing-store' ) : esc_attr__( 'Remove manager', 'classified-listing-store' ); ?>">
		<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>
	</button>
</div>
