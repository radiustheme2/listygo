# Radius Booking

## Overview

Radius Booking Pro is a flexible and extensible WordPress booking plugin designed to support a wide range of appointment and event booking scenarios
## Installation

### Clone the Repository

Clone the repository using one of the following methods:

#### Using HTTPS
```bash
git clone https://github.com/radiustheme/radius-booking-pro.git
```

#### Using SSH
```bash
git clone git@github.com:radiustheme/radius-booking-pro.git
```
#### Navigate to the Plugin Directory
```bash
cd radius-booking-pro
```
#### Navigate to the Plugin Directory
Run the following commands to install the required dependencies:
```bash
composer install
npm install --force
```

#### Creating a Zip Package
To create a zip file for distribution, run:
```bash
npm run package
```


This should now be ready for documentation or distribution! Let me know if you'd like to modify anything.

## Changelog

### 1.0.6
- Improved: User roles and permissions system
- Added: Service extras

### 1.0.5
- Updated roles and permissions UI

### 1.0.4
- Initial public release






