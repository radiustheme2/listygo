<?php

namespace RadiusTheme\RadiusBookingPro\Common;

/**
 * Manage all key strings.
 *
 * @since 1.0.0
 */
class Keys {

    /**
     * Plugin installed option key.
     *
     * @var string
     *
     * @since 1.0.0
     */
    const RADIUS_BOOKING_PRO_INSTALLED = 'radius_booking_pro_installed';

    /**
     * Plugin version key.
     *
     * @var string
     *
     * @since 1.0.0
     */
    const RADIUS_BOOKING_PRO_VERSION = 'radius_booking_pro_version';

    /**
     * Plugin seeder ran key.
     *
     * @var string
     *
     * @since 1.0.0
     */
    const RADIUS_BOOKING_PRO_SEEDER_RAN = 'radius_booking_pro_type_seeder_ran';

    /**
     * Plugin ran key.
     *
     * @var string
     *
     * @since 1.0.0
     */
    const RADIUS_BOOKING_PRO_RAN = 'radius_booking_pro_job_seeder_ran';

    /**
     * Database schema version option key.
     *
     * @var string
     *
     * @since 1.0.0
     */
    const RADIUS_BOOKING_PRO_DB_VERSION = 'radius_booking_pro_db_version';
}
