<?php
namespace RadiusTheme\RadiusBookingPro\Controllers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBooking\Core\Api\Middleware\AuthMiddleware;
use RadiusTheme\RadiusBooking\Core\Api\Middleware\PermissionMiddleware;
use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBookingPro\Services\AnalyticsService;
use WP_REST_Request;
use RadiusTheme\RadiusBooking\Abstracts\BaseController;
use RadiusTheme\RadiusBookingPro\Repositories\AnalyticsRepository;
use RadiusTheme\RadiusBooking\Resources\DashboardResource;

/**
 * Analytics API controller — 360-degree analytics endpoints.
 */
class AnalyticsController extends BaseController {

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct( new AnalyticsRepository() );
		$this->middleware[] = new AuthMiddleware();
		// Analytics endpoints require the "View Reports" capability.
		$this->middleware[] = new PermissionMiddleware( 'rtrb_view_reports' );
	}

	/** @inheritDoc */
	protected function transformItem( $item ): array {
		return ( new DashboardResource() )->transform( $item );
	}

	/** @inheritDoc */
	protected function transformCollection( array $items ): array {
		return DashboardResource::collection( $items );
	}

	/** @inheritDoc */
	protected function getValidationRules( $request, string $context = 'create' ): array {
		return array();
	}

	/** @inheritDoc */
	protected function getResourceType(): string {
		return 'analytics';
	}

	/**
	 * Extract and validate date range from request.
	 *
	 * @param WP_REST_Request $request Request object.
	 *
	 * @return array [ from, to ]
	 */
	private function dateRange( WP_REST_Request $request ): array {
		$to   = $request->get_param( 'date_to' ) ?: gmdate( 'Y-m-d', strtotime( '+90 days' ) );
		$from = $request->get_param( 'date_from' ) ?: gmdate( 'Y-m-d', strtotime( '-90 days' ) );

		return array(
			sanitize_text_field( $from ),
			sanitize_text_field( $to ),
		);
	}

	/**
	 * Guard: return error if pro is not active.
	 *
	 * @return \WP_REST_Response|null Null if pro is active.
	 */
	private function requirePro() {
		$is_analytics_enabled = apply_filters( 'rtrb_analytics_enabled', false );
		if ( ! $is_analytics_enabled ) {
			return ApiResponse::error( __( 'Analytics is a pro feature.', 'radius-booking-pro' ), 403 )->send();
		}

		return null;
	}

	/**
	 * KPI summary endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 */
	public function kpiSummary( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$guard = $this->requirePro();
				if ( $guard ) {
					return $guard;
				}
				list( $from, $to ) = $this->dateRange( $request );
				$service = Container::resolve( AnalyticsService::class );
				return ApiResponse::success( $service->kpiSummary( $from, $to ) )->send();
			}
		);
	}

	/**
	 * Revenue analytics endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 */
	public function revenue( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$guard = $this->requirePro();
				if ( $guard ) {
					return $guard;
				}
				list( $from, $to ) = $this->dateRange( $request );
				$service = Container::resolve( AnalyticsService::class );
				return ApiResponse::success( $service->revenue( $from, $to ) )->send();
			}
		);
	}

	/**
	 * Appointment analytics endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 */
	public function appointments( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$guard = $this->requirePro();
				if ( $guard ) {
					return $guard;
				}
				list( $from, $to ) = $this->dateRange( $request );
				$service = Container::resolve( AnalyticsService::class );
				return ApiResponse::success( $service->appointments( $from, $to ) )->send();
			}
		);
	}

	/**
	 * Employee performance endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 */
	public function employees( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$guard = $this->requirePro();
				if ( $guard ) {
					return $guard;
				}
				list( $from, $to ) = $this->dateRange( $request );
				$service = Container::resolve( AnalyticsService::class );
				return ApiResponse::success( $service->employees( $from, $to ) )->send();
			}
		);
	}

	/**
	 * Service analytics endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 */
	public function services( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$guard = $this->requirePro();
				if ( $guard ) {
					return $guard;
				}
				list( $from, $to ) = $this->dateRange( $request );
				$service = Container::resolve( AnalyticsService::class );
				return ApiResponse::success( $service->services( $from, $to ) )->send();
			}
		);
	}

	/**
	 * Customer analytics endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 */
	public function customers( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$guard = $this->requirePro();
				if ( $guard ) {
					return $guard;
				}
				list( $from, $to ) = $this->dateRange( $request );
				$service = Container::resolve( AnalyticsService::class );
				return ApiResponse::success( $service->customers( $from, $to ) )->send();
			}
		);
	}
}
