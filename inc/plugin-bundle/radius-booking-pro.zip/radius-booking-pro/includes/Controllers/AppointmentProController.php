<?php

namespace RadiusTheme\RadiusBookingPro\Controllers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Controllers\AppointmentController;
use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBooking\Services\AppointmentService;
use RadiusTheme\RadiusBookingPro\Integrations\WooCommerce\WooCommerceOrderManager;
use WP_REST_Request;

/**
 * Pro appointment controller — payment intent endpoints.
 */
class AppointmentProController extends AppointmentController {

	/**
	 * Add a held booking to the WooCommerce cart and return the checkout URL.
	 *
	 * Called by the public booking form right after the appointment is created
	 * when the customer chose "Pay with WooCommerce". The browser then redirects
	 * to the returned WooCommerce checkout URL.
	 *
	 * @param WP_REST_Request $request The request (appointment id path param).
	 *
	 * @return mixed
	 */
	public function createWooOrder( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$appointment_id = (int) $request->get_param( 'id' );
				if ( ! $appointment_id ) {
					return ApiResponse::error( __( 'Appointment ID is required', 'radius-booking-pro' ) )->send();
				}

				$result = ( new WooCommerceOrderManager() )->add_to_cart_for_appointment( $appointment_id );

				if ( is_wp_error( $result ) ) {
					return ApiResponse::error( $result->get_error_message() )->send();
				}

				return ApiResponse::success( $result, __( 'Booking added to WooCommerce cart', 'radius-booking-pro' ) )->send();
			}
		);
	}

	/**
	 * Create Payment Intent.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return mixed
	 */
	public function createIntend( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$service    = Container::resolve( AppointmentService::class );
				$intendData = $service->createPaymentIntend( $request->get_params() );
				if ( isset( $intendData['error'] ) && $intendData['error'] ) {
					return ApiResponse::error( $intendData['message'] ?? __( 'Failed to create payment intend', 'radius-booking-pro' ) )->send();
				}
				$intendData = apply_filters( 'radius_booking_create_payment_intend_response', $intendData, $request->get_params() );
				return ApiResponse::success(
					$intendData,
					__( 'Payment intend created successfully', 'radius-booking-pro' )
				)->send();
			}
		);
	}

	/**
	 * Verify Payment Intent after frontend confirmation.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return mixed
	 */
	public function verifyIntent( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$service = Container::resolve( AppointmentService::class );
				$params  = $request->get_params();

				if ( empty( $params['paymentIntentId'] ) ) {
					return ApiResponse::error( __( 'Payment Intent ID is required', 'radius-booking-pro' ) )->send();
				}

				$verificationResult = $service->verifyPaymentIntent( $params['paymentIntentId'] );

				if ( isset( $verificationResult['error'] ) && $verificationResult['error'] ) {
					return ApiResponse::error( $verificationResult['message'] ?? __( 'Payment verification failed', 'radius-booking-pro' ) )->send();
				}

				return ApiResponse::success(
					$verificationResult,
					__( 'Payment verified successfully', 'radius-booking-pro' )
				)->send();
			}
		);
	}
}