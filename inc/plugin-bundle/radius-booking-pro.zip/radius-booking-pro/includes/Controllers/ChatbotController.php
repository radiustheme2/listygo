<?php

namespace RadiusTheme\RadiusBookingPro\Controllers;

use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBooking\Core\Api\Middleware\RateLimitMiddleware;
use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBooking\Helpers\SettingsHelper;
use RadiusTheme\RadiusBookingPro\Services\ChatbotService;
use WP_REST_Request;
use WP_REST_Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ChatbotController
 *
 * Standalone controller (not CRUD-based) for chatbot endpoints.
 */
class ChatbotController {

	/**
	 * @var ChatbotService
	 */
	private $chatbot_service;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->chatbot_service = Container::resolve( ChatbotService::class );
	}

	/**
	 * POST /chatbot/message - Process a chat message.
	 * Public endpoint with rate limiting.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response
	 */
	public function sendMessage( WP_REST_Request $request ) {
		// Rate limit: 20 requests per minute per IP.
		$rate_limit = new RateLimitMiddleware( 20, 60 );
		$check      = $rate_limit->handle(
			$request,
			function ( $req ) {
				return true;
			}
		);

		if ( $check !== true ) {
			return ApiResponse::error( __( 'Too many requests. Please slow down.', 'radius-booking-pro' ), 429 )->send();
		}

		$message         = sanitize_text_field( $request->get_param( 'message' ) ?? '' );
		$history         = $request->get_param( 'history' ) ?? array();
		$completed_steps = $request->get_param( 'completed_steps' ) ?? array();

		if ( empty( $message ) ) {
			return ApiResponse::validationError(
				array( 'message' => __( 'Message is required.', 'radius-booking-pro' ) )
			)->send();
		}

		// Sanitize history.
		$sanitized_history = array();
		if ( is_array( $history ) ) {
			foreach ( $history as $msg ) {
				$sanitized_history[] = array(
					'role'    => sanitize_text_field( $msg['role'] ?? 'user' ),
					'content' => wp_kses_post( $msg['content'] ?? '' ),
				);
			}
		}

		// Sanitize completed steps.
		$sanitized_steps = array();
		if ( is_array( $completed_steps ) ) {
			$allowed_steps = array( 'service_shown', 'staff_shown', 'dates_shown', 'timeslots_shown', 'booking_created' );
			foreach ( $completed_steps as $step ) {
				$step = sanitize_text_field( $step );
				if ( in_array( $step, $allowed_steps, true ) ) {
					$sanitized_steps[] = $step;
				}
			}
		}

		try {
			$result = $this->chatbot_service->processMessage( $message, $sanitized_history, $sanitized_steps );
			return ApiResponse::success( $result, __( 'Message processed.', 'radius-booking-pro' ) )->send();
		} catch ( \Exception $e ) {
			/* translators: %s: exception message */
			return ApiResponse::error( sprintf( __( 'Failed to process message: %s', 'radius-booking-pro' ), $e->getMessage() ), 500 )->send();
		}
	}

	/**
	 * GET /chatbot/config - Get public chatbot config (no API key).
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response
	 */
	public function getConfig( WP_REST_Request $request ) {
		$settings = SettingsHelper::get_setting( 'chatbot' );

		$config = array(
			'enabled'        => $settings['enabled'] ?? false,
			'botName'        => $settings['botName'] ?? 'Booking Assistant',
			'welcomeMessage' => $settings['welcomeMessage'] ?? '',
			'primaryColor'   => $settings['primaryColor'] ?? '#0040ff',
			'position'       => $settings['position'] ?? 'bottom-right',
		);

		return ApiResponse::success( $config )->send();
	}

}
