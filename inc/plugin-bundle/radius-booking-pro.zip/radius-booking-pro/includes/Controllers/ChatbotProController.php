<?php

namespace RadiusTheme\RadiusBookingPro\Controllers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBookingPro\Services\ChatbotKnowledgeService;
use WP_REST_Request;

/**
 * Pro chatbot controller — knowledge base CRUD endpoints.
 */
class ChatbotProController {

	/**
	 * @var ChatbotKnowledgeService
	 */
	private $knowledge_service;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->knowledge_service = Container::resolve( ChatbotKnowledgeService::class );
	}

	/**
	 * GET /chatbot/knowledge - List all knowledge entries (admin only).
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return mixed
	 */
	public function getKnowledge( WP_REST_Request $request ) {
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'rtrb_manage_settings' ) ) {
			return ApiResponse::forbidden()->send();
		}

		$entries = $this->knowledge_service->getAll();
		return ApiResponse::success( $entries )->send();
	}

	/**
	 * POST /chatbot/knowledge - Create a knowledge entry (admin only).
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return mixed
	 */
	public function createKnowledge( WP_REST_Request $request ) {
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'rtrb_manage_settings' ) ) {
			return ApiResponse::forbidden()->send();
		}

		$data = array(
			'question' => $request->get_param( 'question' ) ?? '',
			'answer'   => $request->get_param( 'answer' ) ?? '',
			'category' => $request->get_param( 'category' ) ?? 'general',
		);

		if ( empty( $data['question'] ) || empty( $data['answer'] ) ) {
			return ApiResponse::validationError(
				array( 'question' => __( 'Question and answer are required.', 'radius-booking-pro' ) )
			)->send();
		}

		$entry = $this->knowledge_service->create( $data );
		return ApiResponse::created( $entry, __( 'Knowledge entry created.', 'radius-booking-pro' ) )->send();
	}

	/**
	 * PUT /chatbot/knowledge/{id} - Update a knowledge entry (admin only).
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return mixed
	 */
	public function updateKnowledge( WP_REST_Request $request ) {
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'rtrb_manage_settings' ) ) {
			return ApiResponse::forbidden()->send();
		}

		$id   = sanitize_text_field( $request->get_param( 'id' ) ?? '' );
		$data = array(
			'question' => $request->get_param( 'question' ),
			'answer'   => $request->get_param( 'answer' ),
			'category' => $request->get_param( 'category' ),
		);

		$entry = $this->knowledge_service->update( $id, array_filter( $data ) );

		if ( ! $entry ) {
			return ApiResponse::notFound()->send();
		}

		return ApiResponse::success( $entry, __( 'Knowledge entry updated.', 'radius-booking-pro' ) )->send();
	}

	/**
	 * DELETE /chatbot/knowledge/{id} - Delete a knowledge entry (admin only).
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return mixed
	 */
	public function deleteKnowledge( WP_REST_Request $request ) {
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'rtrb_manage_settings' ) ) {
			return ApiResponse::forbidden()->send();
		}

		$id      = sanitize_text_field( $request->get_param( 'id' ) ?? '' );
		$deleted = $this->knowledge_service->delete( $id );

		if ( ! $deleted ) {
			return ApiResponse::notFound()->send();
		}

		return ApiResponse::success( null, __( 'Knowledge entry deleted.', 'radius-booking-pro' ) )->send();
	}
}