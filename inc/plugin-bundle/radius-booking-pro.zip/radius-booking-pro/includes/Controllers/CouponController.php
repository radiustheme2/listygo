<?php
/**
 * Class CouponController
 *
 * Handles API requests related to coupon management.
 */

namespace RadiusTheme\RadiusBookingPro\Controllers;

use RadiusTheme\RadiusBooking\Abstracts\BaseController;
use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBookingPro\Repositories\CouponRepository;
use RadiusTheme\RadiusBookingPro\Resources\CouponResource;
use RadiusTheme\RadiusBookingPro\Services\CouponService;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Coupon API controller
 */
class CouponController extends BaseController {

	/**
	 * Constructor for initializing the controller with a CouponRepository instance.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct( new CouponRepository() );
	}

	/**
	 * Transforms the given item into an array representation.
	 *
	 * @param mixed $item The item to be transformed.
	 *
	 * @return array The transformed array representation.
	 */
	protected function transformItem( $item ): array {
		return ( new CouponResource() )->transform( $item );
	}

	/**
	 * Transforms a collection of items.
	 *
	 * @param array $items The array of items to be transformed.
	 *
	 * @return array The transformed collection.
	 */
	protected function transformCollection( array $items ): array {
		return CouponResource::collection( $items );
	}

	/**
	 * Retrieves the validation rules.
	 *
	 * @param mixed  $request The incoming request.
	 * @param string $context The context ('create' or 'update').
	 *
	 * @return array Validation rules.
	 */
	protected function getValidationRules( $request, string $context = 'create' ): array {
		return array();
	}

	/**
	 * Retrieves the resource type for this controller.
	 *
	 * @return string The resource type.
	 */
	protected function getResourceType(): string {
		return 'coupon';
	}

	/**
	 * GET /coupons — List paginated coupons with search.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function index( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$page    = $request->get_param( 'page' ) ? (int) $request->get_param( 'page' ) : 1;
				$perPage = $request->get_param( 'per_page' ) ? (int) $request->get_param( 'per_page' ) : 15;
				$orderBy = $request->get_param( 'order_by' ) ? $request->get_param( 'order_by' ) : 'created_at';
				$order   = $request->get_param( 'order' ) ? $request->get_param( 'order' ) : 'desc';
				$search  = $request->get_param( 'search' ) ? sanitize_text_field( $request->get_param( 'search' ) ) : null;
				$status  = $request->get_param( 'status' ) ? sanitize_text_field( $request->get_param( 'status' ) ) : null;

				$result = $this->repository->paginateWithSearch( $perPage, $page, $order, $orderBy, $search, $status );

				$items = apply_filters( 'radius_booking_index_items_coupon', $result->items, $this );

				return ApiResponse::success(
					$this->transformCollection( $items ),
					null,
					array(
						'pagination' => array(
							'current_page'   => $result->currentPage,
							'last_page'      => $result->lastPage,
							'per_page'       => $result->perPage,
							'total'          => $result->total,
							'has_more_pages' => $result->hasMorePages,
						),
					)
				)->send();
			}
		);
	}

	/**
	 * Store a new coupon — ensure code is uppercased and services JSON-encoded.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function store( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$data = $request->get_params();

				// Uppercase the code
				if ( ! empty( $data['code'] ) ) {
					$data['code'] = strtoupper( sanitize_text_field( $data['code'] ) );
				}

				// JSON-encode applicable services if array
				if ( isset( $data['applicable_services'] ) && is_array( $data['applicable_services'] ) ) {
					$data['applicable_services'] = wp_json_encode( $data['applicable_services'] );
				}

				// Normalize empty dates to null
				$data['start_date'] = ! empty( $data['start_date'] ) ? $data['start_date'] : null;
				$data['end_date']   = ! empty( $data['end_date'] ) ? $data['end_date'] : null;

				// Set created_by to current user
				$data['created_by'] = get_current_user_id();

				// Check for duplicate code
				$existing = $this->repository->findByCode( $data['code'] ?? '' );
				if ( $existing ) {
					return ApiResponse::error( __( 'A coupon with this code already exists.', 'radius-booking-pro' ), 422 )->send();
				}

				$coupon = $this->repository->create( $data );

				return ApiResponse::created( $this->transformItem( $coupon ) )->send();
			}
		);
	}

	/**
	 * Update an existing coupon.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function update( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$id   = $request->get_param( 'id' );
				$data = $request->get_params();

				// Uppercase the code
				if ( ! empty( $data['code'] ) ) {
					$data['code'] = strtoupper( sanitize_text_field( $data['code'] ) );
				}

				// JSON-encode applicable services if array
				if ( isset( $data['applicable_services'] ) && is_array( $data['applicable_services'] ) ) {
					$data['applicable_services'] = wp_json_encode( $data['applicable_services'] );
				}

				// Normalize empty dates to null
				$data['start_date'] = ! empty( $data['start_date'] ) ? $data['start_date'] : null;
				$data['end_date']   = ! empty( $data['end_date'] ) ? $data['end_date'] : null;

				// Check for duplicate code (excluding current coupon)
				if ( ! empty( $data['code'] ) ) {
					$existing = $this->repository->findByCode( $data['code'] );
					if ( $existing && (int) $existing->id !== (int) $id ) {
						return ApiResponse::error( __( 'A coupon with this code already exists.', 'radius-booking-pro' ), 422 )->send();
					}
				}

				$coupon = $this->repository->update( $id, $data );

				if ( ! $coupon ) {
					return ApiResponse::notFound()->send();
				}

				$coupon = $this->repository->find( $id );

				return ApiResponse::success( $this->transformItem( $coupon ) )->send();
			}
		);
	}

	/**
	 * Bulk delete coupons.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function bulkDelete( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$ids = $request->get_param( 'ids' );
				if ( empty( $ids ) || ! is_array( $ids ) ) {
					return ApiResponse::error( __( 'Invalid IDs', 'radius-booking-pro' ) )->send();
				}

				$deletedCount = 0;
				foreach ( $ids as $id ) {
					if ( $this->repository->delete( (int) $id ) ) {
						++$deletedCount;
					}
				}

				return ApiResponse::success( array( 'deleted_count' => $deletedCount ) )->send();
			}
		);
	}

	/**
	 * Validate a coupon code — public endpoint for booking form.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function validateCouponCode( WP_REST_Request $request ) {
		return $this->applyBypass(
			$request,
			function ( $request ) {
				$code      = sanitize_text_field( $request->get_param( 'code' ) ?? '' );
				$serviceId = (int) ( $request->get_param( 'service_id' ) ?? 0 );
				$amount    = (float) ( $request->get_param( 'amount' ) ?? 0 );

				if ( empty( $code ) ) {
					return ApiResponse::error( __( 'Coupon code is required.', 'radius-booking-pro' ) )->send();
				}

				$couponService = Container::resolve( CouponService::class );
				$result        = $couponService->validateCoupon( $code, $serviceId, $amount );

				if ( $result['valid'] ) {
					return ApiResponse::success( $result )->send();
				}

				return ApiResponse::error( $result['message'], 422 )->send();
			}
		);
	}

	/**
	 * Get auto-apply coupons for a service — public endpoint.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function getAutoApply( WP_REST_Request $request ) {
		return $this->applyBypass(
			$request,
			function ( $request ) {
				$serviceId = (int) $request->get_param( 'service_id' );
				$amount    = (float) ( $request->get_param( 'amount' ) ?? 0 );

				$couponService = Container::resolve( CouponService::class );
				$result        = $couponService->getAutoApplyCoupons( $serviceId, $amount );

				return ApiResponse::success( $result ?? array() )->send();
			}
		);
	}
}
