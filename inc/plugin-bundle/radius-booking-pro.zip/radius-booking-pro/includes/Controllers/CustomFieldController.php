<?php
/**
 * Api/Controllers/CustomFieldController.php
 * Handles API operations related to custom fields.
 * Manages resource transformation, validation, and data retrieval for custom field entities.
 */

namespace RadiusTheme\RadiusBookingPro\Controllers;

use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBooking\Core\Api\Middleware\AuthMiddleware;
use RadiusTheme\RadiusBooking\Core\Api\Middleware\PermissionMiddleware;
use WP_REST_Request;
use RadiusTheme\RadiusBooking\Abstracts\BaseController;
use RadiusTheme\RadiusBooking\Core\Api\Validation\Rules\RequiredRule;
use RadiusTheme\RadiusBookingPro\Models\CustomField;
use RadiusTheme\RadiusBookingPro\Repositories\CustomFieldRepository;
use RadiusTheme\RadiusBookingPro\Resources\CustomFieldResource;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Api/Controllers/CustomFieldController.php
 * CustomField API controller
 */
class CustomFieldController extends BaseController {

	/**
	 * CustomFieldController constructor.
	 */
	public function __construct() {
		parent::__construct( new CustomFieldRepository() );
		$this->middleware[] = new AuthMiddleware();
		$this->middleware[] = new PermissionMiddleware( 'rtrb_manage_custom_fields' );
	}

	/**
	 * Transforms the given item into an array representation.
	 *
	 * @param mixed $item The item to be transformed.
	 *
	 * @return array The transformed representation of the item.
	 */
	protected function transformItem( $item ): array {
		return ( new CustomFieldResource() )->transform( $item );
	}

	/**
	 * Transforms a collection of items into a formatted resource collection.
	 *
	 * @param array $items The collection of items to be transformed.
	 *
	 * @return array The transformed resource collection.
	 */
	protected function transformCollection( array $items ): array {
		return CustomFieldResource::collection( $items );
	}

	/**
	 * Retrieves the validation rules based on the provided request and context.
	 *
	 * @param mixed $request The incoming request containing data to be validated.
	 * @param string $context The context in which validation is applied (e.g., 'create', 'update').
	 *
	 * @return array An array of validation rules to be applied.
	 */
	protected function getValidationRules( $request, string $context = 'create' ): array {
		$rules = array(
			'label' => array( new RequiredRule() ),
		);

		return $rules;
	}

	/**
	 * Retrieves the resource type for this controller.
	 *
	 * @return string The resource type.
	 */
	protected function getResourceType(): string {
		return 'custom_field';
	}

	/**
	 * Prepare data for storage, mapping frontend fields to model fields.
	 *
	 * Normalizes the targeting fields (`applies_to`, `services`,
	 * `meeting_types`, `events`) to canonical shapes so the JSON casts on
	 * the model write predictable values regardless of which client posted
	 * them. Unknown values are dropped so a client cannot inject arbitrary
	 * resource type strings into `applies_to`.
	 *
	 * @param WP_REST_Request $request The current request.
	 * @param string          $context The operation context.
	 *
	 * @return array
	 */
	protected function prepareDataForStorage( WP_REST_Request $request, string $context ): array {
		$data = parent::prepareDataForStorage( $request, $context );

		if ( isset( $data['status'] ) ) {
			$data['is_active'] = 'active' === $data['status'] ? 1 : 0;
			unset( $data['status'] );
		}

		if ( array_key_exists( 'applies_to', $data ) ) {
			$data['applies_to'] = $this->sanitizeAppliesTo( $data['applies_to'] );
		}

		if ( array_key_exists( 'services', $data ) ) {
			$data['services'] = $this->sanitizeIdList( $data['services'] );
		}

		if ( array_key_exists( 'meeting_types', $data ) ) {
			$data['meeting_types'] = $this->sanitizeIdList( $data['meeting_types'] );
		}

		if ( array_key_exists( 'events', $data ) ) {
			$data['events'] = $this->sanitizeIdList( $data['events'] );
		}

		return $data;
	}

	/**
	 * Normalize the `applies_to` payload to a unique, ordered list drawn
	 * from the supported resource types.
	 *
	 * Accepts an array or a single scalar; unknown values are dropped.
	 * Returns null when nothing valid was supplied so the column stays NULL
	 * rather than storing an empty array (which would otherwise be
	 * indistinguishable from "applies to nothing" at the read layer).
	 *
	 * @param mixed $value Raw payload value.
	 *
	 * @return array|null
	 */
	private function sanitizeAppliesTo( $value ) {
		$allowed = array( 'service', 'meeting_type', 'event' );

		if ( ! is_array( $value ) ) {
			$value = array( $value );
		}

		$cleaned = array();
		foreach ( $value as $item ) {
			$item = is_string( $item ) ? sanitize_key( $item ) : '';
			if ( in_array( $item, $allowed, true ) && ! in_array( $item, $cleaned, true ) ) {
				$cleaned[] = $item;
			}
		}

		return empty( $cleaned ) ? null : $cleaned;
	}

	/**
	 * Normalize an ID-list payload to a unique array of positive integers.
	 *
	 * Used for the `services`, `meeting_types`, and `events` columns where
	 * an empty selection conveys "applies to all of that resource type"
	 * (subject to `applies_to`). Returns null when nothing valid was
	 * supplied so the column stays NULL.
	 *
	 * @param mixed $value Raw payload value.
	 *
	 * @return array|null
	 */
	private function sanitizeIdList( $value ) {
		if ( ! is_array( $value ) ) {
			return null;
		}

		$cleaned = array();
		foreach ( $value as $item ) {
			$id = (int) $item;
			if ( $id > 0 && ! in_array( $id, $cleaned, true ) ) {
				$cleaned[] = $id;
			}
		}

		return empty( $cleaned ) ? null : $cleaned;
	}

	/**
	 * Retrieves active custom fields that apply to a specific service.
	 *
	 * Returns fields where the services JSON column contains the given service_id,
	 * or where services is empty/null (meaning the field applies to all services).
	 *
	 * @param WP_REST_Request $request The REST request instance containing the service_id parameter.
	 *
	 * @return mixed The response after processing the middleware and retrieving custom fields.
	 */
	/**
	 * Handles the bulk deletion of custom fields based on provided IDs in the request.
	 *
	 * @param WP_REST_Request $request The REST request instance containing the parameters,
	 *                                 including an array of IDs to delete.
	 *
	 * @return mixed The response from the middleware, which can include success or error messages.
	 */
	public function bulkDelete( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$ids = $request->get_param( 'ids' );
				if ( empty( $ids ) || ! is_array( $ids ) || ! array_filter( $ids, 'is_numeric' ) ) {
					return ApiResponse::notFound( __( 'Invalid IDs', 'radius-booking-pro' ) )->send();
				}
				$deletedCount = CustomField::deleteMany( $ids );

				return ApiResponse::success( array( 'deleted_count' => $deletedCount ) )->send();
			}
		);
	}

	public function getFieldsByService( WP_REST_Request $request ) {
		return $this->applyBypass(
			$request,
			function () use ( $request ) {
				$service_id = absint( $request->get_param( 'service_id' ) );

				$fields = CustomField::where( 'is_active', 1 )
					->whereRaw(
						'(services IS NULL OR services = \'null\' OR services = \'[]\' OR JSON_CONTAINS(services, %s))',
						array( wp_json_encode( $service_id ) )
					)
					->orderBy( 'sort_order', 'ASC' )
					->get();

				return ApiResponse::success( CustomFieldResource::collection( $fields ) )->send();
			}
		);
	}
}
