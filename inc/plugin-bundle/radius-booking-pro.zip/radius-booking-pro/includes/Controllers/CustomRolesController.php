<?php
/**
 * Custom booking roles CRUD (Pro).
 *
 * @package RadiusTheme\RadiusBookingPro\Controllers
 */

namespace RadiusTheme\RadiusBookingPro\Controllers;

use RadiusTheme\RadiusBooking\Abstracts\BaseController;
use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBooking\Core\Api\Middleware\AuthMiddleware;
use RadiusTheme\RadiusBooking\Core\Api\Middleware\PermissionMiddleware;
use RadiusTheme\RadiusBooking\Core\Permissions\Capabilities;
use RadiusTheme\RadiusBooking\Setup\PermissionsInstaller;
use RadiusTheme\RadiusBookingPro\Hooks\PermissionsHook;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Lets admins create, rename, re-scope and delete custom booking roles. Roles
 * are stored in the CUSTOM_ROLES_OPTION and provisioned through the free
 * PermissionsInstaller::sync(). Gated by rtrb_manage_settings.
 */
class CustomRolesController extends BaseController {

	/**
	 * Constructor — wire middleware.
	 */
	public function __construct() {
		$this->middleware[] = new AuthMiddleware();
		$this->middleware[] = new PermissionMiddleware( Capabilities::MANAGE_SETTINGS );
	}

	/**
	 * GET the custom roles.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function index( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function () {
				return ApiResponse::success( array( 'roles' => $this->listRoles() ) )->send();
			}
		);
	}

	/**
	 * POST create a custom role.
	 *
	 * Body: { "label": "Reception Lead", "caps": ["rtrb_view_dashboard", ...] }
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function store( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$label = trim( sanitize_text_field( (string) $request->get_param( 'label' ) ) );
				if ( '' === $label ) {
					return ApiResponse::error( __( 'A role name is required.', 'radius-booking-pro' ), 400 )->send();
				}

				$roles = PermissionsHook::custom_roles();
				$slug  = $this->uniqueSlug( $label, $roles );

				$roles[ $slug ] = array(
					'label' => $label,
					'caps'  => $this->sanitizeCaps( $request->get_param( 'caps' ) ),
				);

				update_option( PermissionsHook::CUSTOM_ROLES_OPTION, $roles );
				PermissionsInstaller::sync();

				return ApiResponse::created(
					array( 'roles' => $this->listRoles() ),
					__( 'Custom role created.', 'radius-booking-pro' )
				)->send();
			}
		);
	}

	/**
	 * PUT update a custom role's label and/or caps.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function update( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$slug  = sanitize_text_field( (string) $request->get_param( 'slug' ) );
				$roles = PermissionsHook::custom_roles();

				if ( ! isset( $roles[ $slug ] ) ) {
					return ApiResponse::notFound( __( 'Custom role not found.', 'radius-booking-pro' ) )->send();
				}

				$label = $request->get_param( 'label' );
				if ( null !== $label && '' !== trim( (string) $label ) ) {
					$roles[ $slug ]['label'] = trim( sanitize_text_field( (string) $label ) );
				}
				if ( null !== $request->get_param( 'caps' ) ) {
					$roles[ $slug ]['caps'] = $this->sanitizeCaps( $request->get_param( 'caps' ) );
				}

				update_option( PermissionsHook::CUSTOM_ROLES_OPTION, $roles );
				// Clear any stale matrix overlay so the definition caps take effect.
				$this->clearMatrixOverlay( $slug );
				PermissionsInstaller::sync();

				return ApiResponse::success(
					array( 'roles' => $this->listRoles() ),
					__( 'Custom role updated.', 'radius-booking-pro' )
				)->send();
			}
		);
	}

	/**
	 * DELETE a custom role — removes the WP role, the option entry and any
	 * users' assignment of it.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function destroy( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$slug  = sanitize_text_field( (string) $request->get_param( 'slug' ) );
				$roles = PermissionsHook::custom_roles();

				if ( ! isset( $roles[ $slug ] ) ) {
					return ApiResponse::notFound( __( 'Custom role not found.', 'radius-booking-pro' ) )->send();
				}

				// Strip the role from any users holding it.
				foreach ( get_users( array( 'role' => $slug, 'number' => 1000 ) ) as $user ) {
					$user->remove_role( $slug );
				}

				unset( $roles[ $slug ] );
				update_option( PermissionsHook::CUSTOM_ROLES_OPTION, $roles );
				$this->clearMatrixOverlay( $slug );

				// The role is no longer in the map, so sync() won't touch it —
				// remove the WP role explicitly.
				remove_role( $slug );
				PermissionsInstaller::sync();

				return ApiResponse::success(
					array( 'roles' => $this->listRoles() ),
					__( 'Custom role deleted.', 'radius-booking-pro' )
				)->send();
			}
		);
	}

	/**
	 * List custom roles with their effective caps (matrix overlay applied).
	 *
	 * @return array
	 */
	private function listRoles(): array {
		$effective = Capabilities::roleMap();
		$labels    = Capabilities::roleLabels();
		$out       = array();
		foreach ( PermissionsHook::custom_roles() as $slug => $data ) {
			$out[] = array(
				'slug'  => $slug,
				'label' => $labels[ $slug ] ?? ( $data['label'] ?? $slug ),
				'caps'  => array_values( $effective[ $slug ] ?? ( $data['caps'] ?? array() ) ),
			);
		}
		return $out;
	}

	/**
	 * Keep only recognised capabilities from the request.
	 *
	 * @param mixed $caps Raw caps.
	 * @return string[]
	 */
	private function sanitizeCaps( $caps ): array {
		if ( ! is_array( $caps ) ) {
			return array();
		}
		return array_values( array_intersect( Capabilities::all(), array_map( 'sanitize_text_field', $caps ) ) );
	}

	/**
	 * Build a unique `rtrb_custom_*` slug from a label.
	 *
	 * @param string $label Human label.
	 * @param array  $existing Existing custom roles.
	 * @return string
	 */
	private function uniqueSlug( string $label, array $existing ): string {
		$base = 'rtrb_custom_' . sanitize_key( $label );
		$base = substr( $base, 0, 60 );
		$slug = $base;
		$i    = 2;
		while ( isset( $existing[ $slug ] ) || get_role( $slug ) ) {
			$slug = $base . '_' . $i;
			++$i;
		}
		return $slug;
	}

	/**
	 * Drop a role's entry from the free CAPS_OPTION matrix overlay.
	 *
	 * @param string $slug Role slug.
	 * @return void
	 */
	private function clearMatrixOverlay( string $slug ): void {
		$stored = get_option( Capabilities::CAPS_OPTION, array() );
		if ( is_array( $stored ) && isset( $stored[ $slug ] ) ) {
			unset( $stored[ $slug ] );
			update_option( Capabilities::CAPS_OPTION, $stored );
		}
	}

	/**
	 * {@inheritDoc}
	 */
	protected function transformItem( $item ): array {
		return (array) $item;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function transformCollection( array $items ): array {
		return $items;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function getValidationRules( $request, string $context = 'create' ): array {
		return array();
	}

	/**
	 * {@inheritDoc}
	 */
	protected function getResourceType(): string {
		return 'custom-roles';
	}
}