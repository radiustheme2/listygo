<?php

namespace RadiusTheme\RadiusBookingPro\Controllers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Controllers\CustomerPanelController;
use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBooking\Services\AppointmentService;
use RadiusTheme\RadiusBooking\Services\CustomerService;
use WP_REST_Request;

/**
 * Pro customer panel controller — cancel & reschedule endpoints.
 */
class CustomerPanelProController extends CustomerPanelController {

	/**
	 * Cancel a customer's appointment.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return mixed
	 */
	public function customerAppointmentCancel( WP_REST_Request $request ) {
		return $this->applyMiddleware( $request, function ( $request ) {
			$appointment_id      = $request->get_param( 'appointment_id' );
			$customer_id         = $request->get_param( 'user_id' );
			$cancellation_reason = $request->get_param( 'cancellation_reason' );
			$customer_service    = Container::resolve( CustomerService::class );
			$result              = $customer_service->cancelAppointment( $appointment_id, $customer_id, $cancellation_reason );

			return ApiResponse::success( $result )->send();
		} );
	}

	/**
	 * Reschedule an appointment.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return mixed
	 */
	public function rescheduleAppointment( WP_REST_Request $request ) {
		return $this->applyMiddleware( $request, function ( $request ) {
			$appointment_id   = $request->get_param( 'appointment_id' );
			$new_date         = $request->get_param( 'new_date' );
			$new_time         = $request->get_param( 'new_time' );
			$customer_service = Container::resolve( AppointmentService::class );
			$result           = $customer_service->rescheduleAppointment( $appointment_id, $new_date, $new_time );

			return ApiResponse::success( $result )->send();
		} );
	}
}