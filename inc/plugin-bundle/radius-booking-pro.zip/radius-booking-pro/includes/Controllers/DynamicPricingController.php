<?php
/**
 * Class DynamicPricingController
 *
 * Handles API requests related to dynamic pricing rule management
 * and live price calculation.
 */

namespace RadiusTheme\RadiusBookingPro\Controllers;

use RadiusTheme\RadiusBooking\Abstracts\BaseController;
use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBooking\Core\Api\Middleware\AuthMiddleware;
use RadiusTheme\RadiusBooking\Core\Api\Middleware\PermissionMiddleware;
use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBookingPro\Repositories\DynamicPricingRepository;
use RadiusTheme\RadiusBookingPro\Resources\DynamicPricingRuleResource;
use RadiusTheme\RadiusBookingPro\Services\DynamicPricingService;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Dynamic Pricing API controller.
 */
class DynamicPricingController extends BaseController {

	/**
	 * Constructor.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct( new DynamicPricingRepository() );
		// CRUD is gated; the public calculatePrice() uses applyBypass() so it
		// stays reachable during the booking flow.
		$this->middleware[] = new AuthMiddleware();
		$this->middleware[] = new PermissionMiddleware( 'rtrb_manage_dynamic_pricing' );
	}

	/**
	 * Transforms the given item into an array representation.
	 *
	 * @param mixed $item The item to be transformed.
	 *
	 * @return array The transformed array representation.
	 */
	protected function transformItem( $item ): array {
		return ( new DynamicPricingRuleResource() )->transform( $item );
	}

	/**
	 * Transforms a collection of items.
	 *
	 * @param array $items The array of items to be transformed.
	 *
	 * @return array The transformed collection.
	 */
	protected function transformCollection( array $items ): array {
		return DynamicPricingRuleResource::collection( $items );
	}

	/**
	 * Retrieves the validation rules.
	 *
	 * @param mixed  $request The incoming request.
	 * @param string $context The context ('create' or 'update').
	 *
	 * @return array Validation rules.
	 */
	protected function getValidationRules( $request, string $context = 'create' ): array {
		return array();
	}

	/**
	 * Retrieves the resource type for this controller.
	 *
	 * @return string The resource type.
	 */
	protected function getResourceType(): string {
		return 'dynamic_pricing_rule';
	}

	/**
	 * GET /dynamic-pricing — List paginated rules with search.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function index( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$page     = $request->get_param( 'page' ) ? (int) $request->get_param( 'page' ) : 1;
				$perPage  = $request->get_param( 'per_page' ) ? (int) $request->get_param( 'per_page' ) : 15;
				$orderBy  = $request->get_param( 'order_by' ) ? $request->get_param( 'order_by' ) : 'priority';
				$order    = $request->get_param( 'order' ) ? $request->get_param( 'order' ) : 'asc';
				$search   = $request->get_param( 'search' ) ? sanitize_text_field( $request->get_param( 'search' ) ) : null;
				$ruleType = $request->get_param( 'rule_type' ) ? sanitize_text_field( $request->get_param( 'rule_type' ) ) : null;
				$status   = $request->get_param( 'status' ) ? sanitize_text_field( $request->get_param( 'status' ) ) : null;

				$result = $this->repository->paginateWithSearch( $perPage, $page, $order, $orderBy, $search, $ruleType, $status );

				$items = apply_filters( 'radius_booking_index_items_dynamic_pricing', $result->items, $this );

				return ApiResponse::success(
					$this->transformCollection( $items ),
					null,
					array(
						'pagination' => array(
							'current_page'   => $result->currentPage,
							'last_page'      => $result->lastPage,
							'per_page'       => $result->perPage,
							'total'          => $result->total,
							'has_more_pages' => $result->hasMorePages,
						),
					)
				)->send();
			}
		);
	}

	/**
	 * Store a new dynamic pricing rule.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function store( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$data = $request->get_params();

				$data['name'] = sanitize_text_field( $data['name'] ?? '' );

				if ( empty( $data['name'] ) ) {
					return ApiResponse::error( __( 'Rule name is required.', 'radius-booking-pro' ), 422 )->send();
				}

				// JSON-encode conditions if array.
				if ( isset( $data['conditions'] ) && is_array( $data['conditions'] ) ) {
					$data['conditions'] = wp_json_encode( $data['conditions'] );
				}

				// JSON-encode applicable services if array.
				if ( isset( $data['applicable_services'] ) && is_array( $data['applicable_services'] ) ) {
					$data['applicable_services'] = wp_json_encode( $data['applicable_services'] );
				}

				$data['created_by'] = get_current_user_id();

				$rule = $this->repository->create( $data );

				return ApiResponse::created( $this->transformItem( $rule ) )->send();
			}
		);
	}

	/**
	 * Update an existing dynamic pricing rule.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function update( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$id   = $request->get_param( 'id' );
				$data = $request->get_params();

				if ( isset( $data['name'] ) ) {
					$data['name'] = sanitize_text_field( $data['name'] );
				}

				// JSON-encode conditions if array.
				if ( isset( $data['conditions'] ) && is_array( $data['conditions'] ) ) {
					$data['conditions'] = wp_json_encode( $data['conditions'] );
				}

				// JSON-encode applicable services if array.
				if ( isset( $data['applicable_services'] ) && is_array( $data['applicable_services'] ) ) {
					$data['applicable_services'] = wp_json_encode( $data['applicable_services'] );
				}

				$rule = $this->repository->update( $id, $data );

				if ( ! $rule ) {
					return ApiResponse::notFound()->send();
				}

				$rule = $this->repository->find( $id );

				return ApiResponse::success( $this->transformItem( $rule ) )->send();
			}
		);
	}

	/**
	 * Bulk delete dynamic pricing rules.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function bulkDelete( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$ids = $request->get_param( 'ids' );
				if ( empty( $ids ) || ! is_array( $ids ) ) {
					return ApiResponse::error( __( 'Invalid IDs', 'radius-booking-pro' ) )->send();
				}

				$deletedCount = 0;
				foreach ( $ids as $id ) {
					if ( $this->repository->delete( (int) $id ) ) {
						++$deletedCount;
					}
				}

				return ApiResponse::success( array( 'deleted_count' => $deletedCount ) )->send();
			}
		);
	}

	/**
	 * POST /dynamic-pricing/calculate — Public endpoint for live price calculation.
	 *
	 * Returns the adjusted price when a user picks a date/time on the booking form.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function calculatePrice( WP_REST_Request $request ) {
		return $this->applyBypass(
			$request,
			function ( $request ) {
				$serviceId = (int) ( $request->get_param( 'service_id' ) ?? 0 );
				$basePrice = (float) ( $request->get_param( 'base_price' ) ?? 0 );
				$date      = sanitize_text_field( $request->get_param( 'date' ) ?? '' );
				$time      = sanitize_text_field( $request->get_param( 'time' ) ?? '' );

				if ( ! $serviceId || ! $date || ! $time ) {
					return ApiResponse::error(
						__( 'service_id, date, and time are required.', 'radius-booking-pro' ),
						422
					)->send();
				}

				$pricingService = Container::resolve( DynamicPricingService::class );
				$result         = $pricingService->calculatePrice( $basePrice, $serviceId, $date, $time );

				return ApiResponse::success( $result )->send();
			}
		);
	}
}
