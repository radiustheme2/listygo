<?php
/**
 * Class EmployeePayoutController
 *
 * Handles employee-facing payout API endpoints.
 */

namespace RadiusTheme\RadiusBookingPro\Controllers;

use RadiusTheme\RadiusBooking\Abstracts\BaseController;
use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBooking\Repositories\UserProfileRepository;
use RadiusTheme\RadiusBooking\Services\EmployeePanelService;
use RadiusTheme\RadiusBookingPro\Repositories\PayoutRepository;
use RadiusTheme\RadiusBookingPro\Resources\PayoutResource;
use RadiusTheme\RadiusBookingPro\Services\PayoutService;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Employee Payout API controller.
 */
class EmployeePayoutController extends BaseController {

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct( new PayoutRepository() );
	}

	/**
	 * Transform a single payout item.
	 *
	 * @param mixed $item The item to be transformed.
	 *
	 * @return array The transformed array.
	 */
	protected function transformItem( $item ): array {
		return ( new PayoutResource() )->transform( $item );
	}

	/**
	 * Transform a collection of payout items.
	 *
	 * @param array $items The array of items.
	 *
	 * @return array The transformed collection.
	 */
	protected function transformCollection( array $items ): array {
		return PayoutResource::collection( $items );
	}

	/**
	 * Get validation rules.
	 *
	 * @param mixed  $request The incoming request.
	 * @param string $context The context.
	 *
	 * @return array Validation rules.
	 */
	protected function getValidationRules( $request, string $context = 'create' ): array {
		return array();
	}

	/**
	 * Get the resource type.
	 *
	 * @return string The resource type.
	 */
	protected function getResourceType(): string {
		return 'employee_payout';
	}

	/**
	 * Check if the payout feature is enabled in settings.
	 *
	 * @return bool
	 */
	private function isPayoutEnabled() {
		if ( ! function_exists( 'rtcl' ) ) {
			return false;
		}
		$settings = \RadiusTheme\RadiusBooking\Helpers\SettingsHelper::get_setting( 'payout' );
		return ! empty( $settings['enabled'] );
	}

	/**
	 * GET /employee/dashboard/{eid}/payouts/balance — Balance summary.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function getBalance( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				if ( ! $this->isPayoutEnabled() ) {
					return ApiResponse::forbidden( __( 'Payout feature is not enabled.', 'radius-booking-pro' ) )->send();
				}

				$employeeId = (int) $request->get_param( 'eid' );

				// Ensure the current user is the employee.
				if ( ! current_user_can( 'manage_options' ) ) {
					$profile = Container::resolve( UserProfileRepository::class )->findProfileByWPId( get_current_user_id() );
					$currentBookingUserId = $profile ? (int) $profile->user_id : 0;
					if ( $currentBookingUserId !== $employeeId ) {
						return ApiResponse::forbidden( __( 'You can only view your own balance.', 'radius-booking-pro' ) )->send();
					}
				}

				$service = Container::resolve( PayoutService::class );
				$balance = $service->getAvailableBalance( $employeeId );

				// Get enabled payout methods.
				$settings        = $service->getPayoutSettings();
				$methods         = $settings['payoutMethods'] ?? array();
				$enabledMethods  = array();
				foreach ( $methods as $key => $method ) {
					if ( ! empty( $method['enabled'] ) ) {
						$enabledMethods[] = array(
							'value'       => $key,
							'label'       => $method['label'] ?? $key,
							'description' => $method['description'] ?? '',
							'fields'      => $method['fields'] ?? array(),
						);
					}
				}

				$balance['payout_methods']      = $enabledMethods;
				$balance['minimum_payout']       = (float) ( $settings['minimumPayoutAmount'] ?? 0 );

				return ApiResponse::success( $balance )->send();
			}
		);
	}

	/**
	 * GET /employee/dashboard/{eid}/payouts — Payout history for employee.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function listPayouts( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				if ( ! $this->isPayoutEnabled() ) {
					return ApiResponse::forbidden( __( 'Payout feature is not enabled.', 'radius-booking-pro' ) )->send();
				}

				$employeeId = (int) $request->get_param( 'eid' );

				// Ensure the current user is the employee.
				if ( ! current_user_can( 'manage_options' ) ) {
					$profile = Container::resolve( UserProfileRepository::class )->findProfileByWPId( get_current_user_id() );
					$currentBookingUserId = $profile ? (int) $profile->user_id : 0;
					if ( $currentBookingUserId !== $employeeId ) {
						return ApiResponse::forbidden( __( 'You can only view your own payouts.', 'radius-booking-pro' ) )->send();
					}
				}

				$page    = $request->get_param( 'page' ) ? (int) $request->get_param( 'page' ) : 1;
				$perPage = $request->get_param( 'per_page' ) ? (int) $request->get_param( 'per_page' ) : 10;

				// Aggregate payouts across every employee_id that belongs to
				// the same WP user so a CL listing-as-staff sees all of their
				// listings' payout history, not just one shard.
				$relatedIds = Container::resolve( EmployeePanelService::class )
					->getRelatedEmployeeIds( $employeeId );

				$result = $this->repository->getEmployeePayouts( $relatedIds, $perPage, $page );

				return ApiResponse::success(
					$this->transformCollection( $result->items ),
					null,
					array(
						'pagination' => array(
							'current_page'   => $result->currentPage,
							'last_page'      => $result->lastPage,
							'per_page'       => $result->perPage,
							'total'          => $result->total,
							'has_more_pages' => $result->hasMorePages,
						),
					)
				)->send();
			}
		);
	}

	/**
	 * GET /employee/dashboard/{eid}/payouts/details — Get payout details for employee.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function getPayoutDetails( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				if ( ! $this->isPayoutEnabled() ) {
					return ApiResponse::forbidden( __( 'Payout feature is not enabled.', 'radius-booking-pro' ) )->send();
				}

				$wpUserId = (int) $request->get_param( 'eid' );

				// Ensure the current user is the employee or an admin.
				$currentUserId = get_current_user_id();
				if ( $currentUserId !== $wpUserId && ! current_user_can( 'manage_options' ) ) {
					return ApiResponse::forbidden( __( 'You can only view your own payout details.', 'radius-booking-pro' ) )->send();
				}

				$raw  = get_user_meta( $wpUserId, '_rtrb_payout_details', true );
				$data = ! empty( $raw ) ? json_decode( $raw, true ) : array();

				return ApiResponse::success( $data )->send();
			}
		);
	}

	/**
	 * PUT /employee/dashboard/{eid}/payouts/details — Save payout details for employee.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function savePayoutDetails( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				if ( ! $this->isPayoutEnabled() ) {
					return ApiResponse::forbidden( __( 'Payout feature is not enabled.', 'radius-booking-pro' ) )->send();
				}

				$wpUserId = (int) $request->get_param( 'eid' );

				// Ensure the current user is the employee or an admin.
				$currentUserId = get_current_user_id();
				if ( $currentUserId !== $wpUserId && ! current_user_can( 'manage_options' ) ) {
					return ApiResponse::forbidden( __( 'You can only update your own payout details.', 'radius-booking-pro' ) )->send();
				}

				$details = $request->get_param( 'payout_details' );
				if ( ! is_array( $details ) ) {
					$details = array();
				}

				// Sanitize each value recursively.
				$sanitized = array();
				foreach ( $details as $methodKey => $fields ) {
					$methodKey = sanitize_text_field( $methodKey );
					if ( is_array( $fields ) ) {
						$sanitized[ $methodKey ] = array();
						foreach ( $fields as $fieldKey => $fieldValue ) {
							$sanitized[ $methodKey ][ sanitize_text_field( $fieldKey ) ] = sanitize_text_field( $fieldValue );
						}
					}
				}

				update_user_meta( $wpUserId, '_rtrb_payout_details', wp_json_encode( $sanitized ) );

				return ApiResponse::success( $sanitized, __( 'Payout details saved successfully.', 'radius-booking-pro' ) )->send();
			}
		);
	}

	/**
	 * POST /employee/dashboard/{eid}/payouts — Request a payout.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function requestPayout( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				if ( ! $this->isPayoutEnabled() ) {
					return ApiResponse::forbidden( __( 'Payout feature is not enabled.', 'radius-booking-pro' ) )->send();
				}

				$employeeId = (int) $request->get_param( 'eid' );

				// Ensure the current user is the employee.
				if ( ! current_user_can( 'manage_options' ) ) {
					$profile = Container::resolve( UserProfileRepository::class )->findProfileByWPId( get_current_user_id() );
					$currentBookingUserId = $profile ? (int) $profile->user_id : 0;
					if ( $currentBookingUserId !== $employeeId ) {
						return ApiResponse::forbidden( __( 'You can only request payouts for yourself.', 'radius-booking-pro' ) )->send();
					}
				}

				$amount = (float) ( $request->get_param( 'amount' ) ?? 0 );
				$method = sanitize_text_field( $request->get_param( 'payout_method' ) ?? 'cash' );
				$note   = sanitize_textarea_field( $request->get_param( 'employee_note' ) ?? '' );

				$service = Container::resolve( PayoutService::class );
				$result  = $service->requestPayout( $employeeId, $amount, $method, $note );

				if ( ! $result['success'] ) {
					return ApiResponse::error( $result['message'], 422 )->send();
				}

				return ApiResponse::created(
					$this->transformItem( $result['payout'] ),
					$result['message']
				)->send();
			}
		);
	}
}
