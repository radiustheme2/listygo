<?php

namespace RadiusTheme\RadiusBookingPro\Controllers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Controllers\PaymentController;
use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBookingPro\Helpers\InvoiceHelper;
use WP_Error;
use WP_REST_Request;

/**
 * Pro invoice controller — send invoice email with PDF attachment.
 */
class InvoiceProController extends PaymentController {

	/**
	 * Send invoice email with PDF attachment.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return mixed
	 */
	public function sendInvoiceEmail( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$invoice_data    = $request->get_param( 'invoice_data' );
				$recipient_email = $request->get_param( 'recipient_email' );
				// Use customer email if no recipient specified.
				if ( empty( $recipient_email ) ) {
					$customer        = (array) $invoice_data['customer'];
					$recipient_email = isset( $customer['email'] ) ? sanitize_email( $customer['email'] ) : '';
				}

				if ( empty( $recipient_email ) || ! is_email( $recipient_email ) ) {
					return new WP_Error(
						'invalid_email',
						__( 'Invalid recipient email address.', 'radius-booking-pro' ),
						array( 'status' => 400 )
					);
				}

				// Generate PDF.
				$pdf_path = InvoiceHelper::generate_pdf_from_html( $invoice_data );

				if ( is_wp_error( $pdf_path ) ) {
					return $pdf_path;
				}

				// Send email.
				$email_sent = InvoiceHelper::send_email_with_attachment(
					$recipient_email,
					$invoice_data,
					$pdf_path
				);

				// Clean up temporary file.
				if ( file_exists( $pdf_path ) ) {
					@unlink( $pdf_path );
				}

				if ( is_wp_error( $email_sent ) ) {
					return $email_sent;
				}

				return ApiResponse::success( array( 'message' => __( 'Invoice sent successfully.', 'radius-booking-pro' ) ) )->send();
			}
		);
	}
}
