<?php
/**
 * License Controller
 *
 * Handles license activation, deactivation, and status checks via REST API.
 */

namespace RadiusTheme\RadiusBookingPro\Controllers;

use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBookingPro\License\LicenseManager;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class LicenseController {

	/**
	 * Option key for storing the license key.
	 */
	const LICENSE_KEY_OPTION = 'rtrb_pro_license_key';

	/**
	 * Option key for storing the license status.
	 */
	const LICENSE_STATUS_OPTION = 'rtrb_pro_license_status';

	/**
	 * EDD item ID for the product.
	 */
	const ITEM_ID = RADIUS_BOOKING_PRO_ITEM_ID;

	/**
	 * License server URL.
	 */
	const SERVER_URL = RADIUS_BOOKING_PRO_SL_STORE_URL;

	/**
	 * Proxy server URL.
	 */
	const PROXY_URL = 'https://radiustheme.com/';

	/**
	 * Plugin name for license validation.
	 */
	const PLUGIN_NAME = 'Radius Booking Pro';

	/**
	 * Get the current license status.
	 *
	 * @param WP_REST_Request $request The REST request.
	 *
	 * @return \WP_REST_Response
	 */
	public function status( WP_REST_Request $request ) {
		$license_key = get_option( self::LICENSE_KEY_OPTION, '' );
		$status      = get_option( self::LICENSE_STATUS_OPTION, '' );

		$message = '';
		if ( 'valid' === $status ) {
			$message = __( 'Your license is active.', 'radius-booking-pro' );
		} elseif ( 'expired' === $status ) {
			$message = __( 'Your license has expired.', 'radius-booking-pro' );
		} elseif ( 'invalid' === $status ) {
			$message = __( 'Your license is invalid.', 'radius-booking-pro' );
		}

		return ApiResponse::success(
			array(
				'license_key' => $license_key ? $this->mask_key( $license_key ) : '',
				'status'      => $status ?: null,
				'message'     => $message,
			),
			__( 'License status retrieved.', 'radius-booking-pro' )
		)->send();
	}

	/**
	 * Activate a license key.
	 *
	 * @param WP_REST_Request $request The REST request.
	 *
	 * @return \WP_REST_Response
	 */
	public function activate( WP_REST_Request $request ) {
		$license_key = sanitize_text_field( $request->get_param( 'license_key' ) );

		if ( empty( $license_key ) ) {
			return ApiResponse::error( __( 'License key is required.', 'radius-booking-pro' ), 400 )->send();
		}

		$manager = new LicenseManager(
			'activate_license',
			self::ITEM_ID,
			$license_key,
			self::PLUGIN_NAME,
			self::SERVER_URL,
			self::PROXY_URL
		);

		$manager->validate_license();
		$response = $manager->get_response();

		if ( $response['success'] ) {
			update_option( self::LICENSE_KEY_OPTION, $license_key );
			update_option( self::LICENSE_STATUS_OPTION, 'valid' );
		} else {
			update_option( self::LICENSE_STATUS_OPTION, $response['license_status'] ?? 'invalid' );
		}

		return ApiResponse::success(
			array(
				'success' => $response['success'],
				'status'  => $response['success'] ? 'valid' : ( $response['license_status'] ?? 'invalid' ),
				'message' => $response['message'],
			),
			$response['message']
		)->send();
	}

	/**
	 * Deactivate the current license.
	 *
	 * @param WP_REST_Request $request The REST request.
	 *
	 * @return \WP_REST_Response
	 */
	public function deactivate( WP_REST_Request $request ) {
		$license_key = get_option( self::LICENSE_KEY_OPTION, '' );

		if ( empty( $license_key ) ) {
			return ApiResponse::error( __( 'No license key to deactivate.', 'radius-booking-pro' ), 400 )->send();
		}

		$manager = new LicenseManager(
			'deactivate_license',
			self::ITEM_ID,
			$license_key,
			self::PLUGIN_NAME,
			self::SERVER_URL,
			self::PROXY_URL
		);

		$manager->validate_license();
		$response = $manager->get_response();

		delete_option( self::LICENSE_KEY_OPTION );
		update_option( self::LICENSE_STATUS_OPTION, '' );

		return ApiResponse::success(
			array(
				'success' => true,
				'message' => $response['message'] ?? __( 'License deactivated successfully.', 'radius-booking-pro' ),
			),
			__( 'License deactivated.', 'radius-booking-pro' )
		)->send();
	}

	/**
	 * Mask the license key for display (show first 4 and last 4 chars).
	 *
	 * @param string $key The full license key.
	 *
	 * @return string Masked key.
	 */
	private function mask_key( $key ) {
		if ( strlen( $key ) <= 8 ) {
			return str_repeat( '*', strlen( $key ) );
		}
		return substr( $key, 0, 4 ) . str_repeat( '*', strlen( $key ) - 8 ) . substr( $key, -4 );
	}
}