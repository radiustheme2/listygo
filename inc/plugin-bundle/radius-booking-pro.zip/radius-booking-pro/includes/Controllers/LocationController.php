<?php
/**
 * Class LocationController
 * Handles actions related to the Location resource in the API.
 *
 * Extends BaseController and provides API endpoints for managing locations.
 * Includes middleware for authentication and handles business logic for
 * location-related operations such as fetching, validating, and deleting multiple locations.
 */

namespace RadiusTheme\RadiusBookingPro\Controllers;

use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBooking\Core\Api\Middleware\AuthMiddleware;
use RadiusTheme\RadiusBooking\Core\Api\Middleware\PermissionMiddleware;
use RadiusTheme\RadiusBooking\Models\Location;
use WP_REST_Request;
use RadiusTheme\RadiusBooking\Abstracts\BaseController;
use RadiusTheme\RadiusBooking\Core\Api\Validation\Rules\RequiredRule;
use RadiusTheme\RadiusBooking\Repositories\LocationRepository;
use RadiusTheme\RadiusBooking\Resources\LocationResource;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Api/Controllers/LocationController.php
 * Location API controller
 */
class LocationController extends BaseController {

	/**
	 * Constructs a new instance of the class, initializing the parent constructor
	 * with a LocationRepository and adding an AuthMiddleware to the middleware stack.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct( new LocationRepository() );
		$this->middleware[] = new AuthMiddleware();
		// Locations belong to the "Manage Services & Locations" capability (see
		// the free Capabilities catalog) and the Locations menu is gated on it.
		// Enforcing manage_options here locked out every non-admin role that the
		// UI told could manage locations.
		$this->middleware[] = new PermissionMiddleware( 'rtrb_manage_services' );
	}

	/**
	 * Transforms the given item into an array representation using the LocationResource.
	 *
	 * @param mixed $item The item to be transformed.
	 *
	 * @return array The transformed item as an array.
	 */
	protected function transformItem( $item ): array {
		return ( new LocationResource() )->transform( $item );
	}

	/**
	 * Transforms a collection of items into a resource collection.
	 *
	 * @param array $items The array of items to be transformed into a resource collection.
	 *
	 * @return array The transformed resource collection.
	 */
	protected function transformCollection( array $items ): array {
		return LocationResource::collection( $items );
	}

	/**
	 * Retrieves the validation rules for the given request and context.
	 *
	 * @param mixed $request The request object containing input data to be validated.
	 * @param string $context The context in which the validation rules are applied (e.g., 'create').
	 *
	 * @return array An array of validation rules based on the specified context.
	 */
	protected function getValidationRules( $request, string $context = 'create' ) {
		$rules = array(
			'name'    => array( new RequiredRule() ),
			'address' => array( new RequiredRule() ),
		);
		return $rules;
	}

	/**
	 * Retrieves the resource type for this controller.
	 *
	 * @return string The resource type, which is 'user' in this case.
	 */
	protected function getResourceType(): string {
		return 'location';
	}

	/**
	 * Retrieves all locations and applies middleware to process the request.
	 *
	 * @param WP_REST_Request $request The REST request containing necessary parameters.
	 *
	 * @return mixed The API response after processing the locations and applying middleware.
	 */
	public function getAllLocation( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function () {
				$item = Location::where( 'status', 'active' )->get();

				if ( ! $item ) {
					return ApiResponse::notFound()->send();
				}

				return ApiResponse::success( $item )->send();
			}
		);
	}

	/**
	 * Handles the bulk deletion of locations based on provided IDs in the request.
	 *
	 * @param WP_REST_Request $request The REST request instance containing the parameters,
	 *                                 including an array of IDs to delete.
	 *
	 * @return mixed The response from the middleware, which can include success or error messages.
	 */
	public function bulkDelete( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$ids = $request->get_param( 'ids' );
				if ( empty( $ids ) || ! is_array( $ids ) || ! array_filter( $ids, 'is_numeric' ) ) {
					return ApiResponse::notFound( __( 'Invalid IDs', 'radius-booking-pro' ) )->send();
				}
				$deletedCount = Location::deleteMany( $ids );

				return ApiResponse::success( array( 'deleted_count' => $deletedCount ) )->send();
			}
		);
	}
}
