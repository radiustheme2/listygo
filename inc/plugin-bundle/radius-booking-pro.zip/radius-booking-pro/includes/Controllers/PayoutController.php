<?php
/**
 * Class PayoutController
 *
 * Handles admin API requests for payout management.
 */

namespace RadiusTheme\RadiusBookingPro\Controllers;

use RadiusTheme\RadiusBooking\Abstracts\BaseController;
use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBookingPro\Repositories\PayoutRepository;
use RadiusTheme\RadiusBookingPro\Resources\PayoutResource;
use RadiusTheme\RadiusBookingPro\Services\PayoutService;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin Payout API controller.
 */
class PayoutController extends BaseController {

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct( new PayoutRepository() );
	}

	/**
	 * Transform a single payout item.
	 *
	 * @param mixed $item The item to be transformed.
	 *
	 * @return array The transformed array.
	 */
	protected function transformItem( $item ): array {
		return ( new PayoutResource() )->transform( $item );
	}

	/**
	 * Transform a collection of payout items.
	 *
	 * @param array $items The array of items.
	 *
	 * @return array The transformed collection.
	 */
	protected function transformCollection( array $items ): array {
		return PayoutResource::collection( $items );
	}

	/**
	 * Get validation rules.
	 *
	 * @param mixed  $request The incoming request.
	 * @param string $context The context.
	 *
	 * @return array Validation rules.
	 */
	protected function getValidationRules( $request, string $context = 'create' ): array {
		return array();
	}

	/**
	 * Get the resource type.
	 *
	 * @return string The resource type.
	 */
	protected function getResourceType(): string {
		return 'payout';
	}

	/**
	 * GET /payouts — List all payouts with pagination and filters.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function index( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$page       = $request->get_param( 'page' ) ? (int) $request->get_param( 'page' ) : 1;
				$perPage    = $request->get_param( 'per_page' ) ? (int) $request->get_param( 'per_page' ) : 15;
				$orderBy    = $request->get_param( 'order_by' ) ? $request->get_param( 'order_by' ) : 'created_at';
				$order      = $request->get_param( 'order' ) ? $request->get_param( 'order' ) : 'desc';
				$status     = $request->get_param( 'status' ) ? sanitize_text_field( $request->get_param( 'status' ) ) : null;
				$employeeId = $request->get_param( 'employee_id' ) ? (int) $request->get_param( 'employee_id' ) : null;

				$result = $this->repository->paginateWithFilters( $perPage, $page, $order, $orderBy, $status, $employeeId );

				$statusCounts = $this->repository->getStatusCounts();

				return ApiResponse::success(
					$this->transformCollection( $result->items ),
					null,
					array(
						'pagination'    => array(
							'current_page'   => $result->currentPage,
							'last_page'      => $result->lastPage,
							'per_page'       => $result->perPage,
							'total'          => $result->total,
							'has_more_pages' => $result->hasMorePages,
						),
						'status_counts' => $statusCounts,
					)
				)->send();
			}
		);
	}

	/**
	 * GET /payouts/{id} — Single payout detail.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function show( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$id     = (int) $request->get_param( 'id' );
				$payout = $this->repository->find( $id );

				if ( ! $payout ) {
					return ApiResponse::notFound( __( 'Payout not found.', 'radius-booking-pro' ) )->send();
				}

				return ApiResponse::success( $this->transformItem( $payout ) )->send();
			}
		);
	}

	/**
	 * POST /payouts/{id}/approve — Approve a pending payout.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function approve( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$id   = (int) $request->get_param( 'id' );
				$note = sanitize_textarea_field( $request->get_param( 'admin_note' ) ?? '' );

				$service = Container::resolve( PayoutService::class );
				$result  = $service->approvePayout( $id, $note );

				if ( ! $result['success'] ) {
					return ApiResponse::error( $result['message'], 422 )->send();
				}

				$payout = $this->repository->find( $id );

				return ApiResponse::success(
					$this->transformItem( $payout ),
					$result['message']
				)->send();
			}
		);
	}

	/**
	 * POST /payouts/{id}/complete — Mark payout as completed.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function complete( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$id   = (int) $request->get_param( 'id' );
				$note = sanitize_textarea_field( $request->get_param( 'admin_note' ) ?? '' );

				$service = Container::resolve( PayoutService::class );
				$result  = $service->completePayout( $id, $note );

				if ( ! $result['success'] ) {
					return ApiResponse::error( $result['message'], 422 )->send();
				}

				$payout = $this->repository->find( $id );

				return ApiResponse::success(
					$this->transformItem( $payout ),
					$result['message']
				)->send();
			}
		);
	}

	/**
	 * POST /payouts/{id}/hold — Move a payout to the on-hold state.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function hold( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$id   = (int) $request->get_param( 'id' );
				$note = sanitize_textarea_field( $request->get_param( 'admin_note' ) ?? '' );

				$service = Container::resolve( PayoutService::class );
				$result  = $service->holdPayout( $id, $note );

				if ( ! $result['success'] ) {
					return ApiResponse::error( $result['message'], 422 )->send();
				}

				$payout = $this->repository->find( $id );

				return ApiResponse::success(
					$this->transformItem( $payout ),
					$result['message']
				)->send();
			}
		);
	}

	/**
	 * POST /payouts/{id}/unhold — Resume an on-hold payout back to processing.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function unhold( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$id   = (int) $request->get_param( 'id' );
				$note = sanitize_textarea_field( $request->get_param( 'admin_note' ) ?? '' );

				$service = Container::resolve( PayoutService::class );
				$result  = $service->unholdPayout( $id, $note );

				if ( ! $result['success'] ) {
					return ApiResponse::error( $result['message'], 422 )->send();
				}

				$payout = $this->repository->find( $id );

				return ApiResponse::success(
					$this->transformItem( $payout ),
					$result['message']
				)->send();
			}
		);
	}

	/**
	 * POST /payouts/{id}/reject — Reject a payout.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function reject( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$id   = (int) $request->get_param( 'id' );
				$note = sanitize_textarea_field( $request->get_param( 'admin_note' ) ?? '' );

				$service = Container::resolve( PayoutService::class );
				$result  = $service->rejectPayout( $id, $note );

				if ( ! $result['success'] ) {
					return ApiResponse::error( $result['message'], 422 )->send();
				}

				$payout = $this->repository->find( $id );

				return ApiResponse::success(
					$this->transformItem( $payout ),
					$result['message']
				)->send();
			}
		);
	}

	/**
	 * GET /payouts/employee-summary/{employee_id} — Balance breakdown for an employee.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	/**
	 * GET /payouts/admin-income — Admin commission income based on appointments.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function adminIncome( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$page    = $request->get_param( 'page' ) ? (int) $request->get_param( 'page' ) : 1;
				$perPage = $request->get_param( 'per_page' ) ? (int) $request->get_param( 'per_page' ) : 15;

				$service      = Container::resolve( PayoutService::class );
				$summary      = $service->getAdminIncomeSummary();
				$appointments = $service->getCommissionAppointments( $page, $perPage );

				return ApiResponse::success(
					$appointments['items'],
					null,
					array(
						'summary'    => $summary,
						'pagination' => $appointments['pagination'],
						'currency'   => $appointments['currency'],
					)
				)->send();
			}
		);
	}

	public function employeeSummary( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$employeeId = (int) $request->get_param( 'employee_id' );

				$service = Container::resolve( PayoutService::class );
				$balance = $service->getAvailableBalance( $employeeId );

				return ApiResponse::success( $balance )->send();
			}
		);
	}
}
