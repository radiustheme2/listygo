<?php
/**
 * Roles & Permissions REST controller (Pro).
 *
 * @package RadiusTheme\RadiusBookingPro\Controllers
 */

namespace RadiusTheme\RadiusBookingPro\Controllers;

use RadiusTheme\RadiusBooking\Abstracts\BaseController;
use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBooking\Core\Api\Middleware\AuthMiddleware;
use RadiusTheme\RadiusBooking\Core\Api\Middleware\PermissionMiddleware;
use RadiusTheme\RadiusBooking\Core\Permissions\Capabilities;
use RadiusTheme\RadiusBooking\Setup\PermissionsInstaller;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Serves the Roles & Permissions matrix (capabilities × built-in roles) and
 * persists admin edits to the CAPS_OPTION, then reconciles the WordPress roles.
 * Gated to users who can manage settings (admins pass via the cap bypass).
 *
 * Pro-only: the management surface lives in the Pro plugin, while the
 * enforcement layer (Capabilities, PermissionMiddleware, PermissionsInstaller)
 * remains in the free plugin.
 */
class RolesController extends BaseController {

	/**
	 * Constructor — wire the middleware stack (no repository needed).
	 */
	public function __construct() {
		$this->middleware[] = new AuthMiddleware();
		$this->middleware[] = new PermissionMiddleware( Capabilities::MANAGE_SETTINGS );
	}

	/**
	 * GET the full matrix: capability catalog + each editable role's caps.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function index( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function () {
				return ApiResponse::success( $this->buildMatrix() )->send();
			}
		);
	}

	/**
	 * PUT the matrix: persist role → caps overrides and re-sync WP roles.
	 *
	 * Body: { "roles": { "rtrb_front_desk": ["rtrb_view_dashboard", ...], ... } }
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function update( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$input = $request->get_param( 'roles' );
				if ( ! is_array( $input ) ) {
					return ApiResponse::error( __( 'Invalid payload: "roles" must be an object.', 'radius-booking' ), 400 )->send();
				}

				$editable = Capabilities::manageableRoles();
				$all_caps = Capabilities::all();

				$stored = get_option( Capabilities::CAPS_OPTION, array() );
				if ( ! is_array( $stored ) ) {
					$stored = array();
				}

				foreach ( $input as $slug => $caps ) {
					// Only built-in roles are editable here; custom roles are Pro.
					if ( ! in_array( $slug, $editable, true ) || ! is_array( $caps ) ) {
						continue;
					}
					// Keep only recognised capabilities.
					$stored[ $slug ] = array_values( array_intersect( $all_caps, array_map( 'sanitize_text_field', $caps ) ) );
				}

				update_option( Capabilities::CAPS_OPTION, $stored );

				// Apply the new matrix to the actual WordPress roles.
				PermissionsInstaller::sync();

				return ApiResponse::success(
					$this->buildMatrix(),
					__( 'Roles & permissions updated successfully.', 'radius-booking' )
				)->send();
			}
		);
	}

	/**
	 * GET the team: WordPress users who currently hold a built-in booking role,
	 * plus the list of assignable roles.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function members( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function () {
				$booking_roles = Capabilities::manageableRoles();
				$labels        = Capabilities::roleLabels();

				$users   = get_users(
					array(
						'role__in' => $booking_roles,
						'number'   => 200,
						'orderby'  => 'display_name',
						'order'    => 'ASC',
					)
				);
				$members = array_map( array( $this, 'formatMember' ), $users );

				$assignable = array();
				foreach ( $booking_roles as $slug ) {
					$assignable[] = array(
						'slug'  => $slug,
						'label' => $labels[ $slug ] ?? $slug,
					);
				}

				return ApiResponse::success(
					array(
						'members'          => $members,
						'assignable_roles' => $assignable,
					)
				)->send();
			}
		);
	}

	/**
	 * GET a user search for the "add member" picker.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function searchUsers( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$q    = sanitize_text_field( (string) $request->get_param( 'search' ) );
				$args = array(
					'number'  => 20,
					'orderby' => 'display_name',
					'order'   => 'ASC',
				);
				if ( '' !== $q ) {
					$args['search']         = '*' . $q . '*';
					$args['search_columns'] = array( 'user_login', 'user_email', 'display_name' );
				}

				$users = get_users( $args );
				$out   = array();
				foreach ( $users as $u ) {
					$out[] = array(
						'id'    => $u->ID,
						'name'  => $u->display_name ? $u->display_name : $u->user_login,
						'email' => $u->user_email,
					);
				}

				return ApiResponse::success( array( 'users' => $out ) )->send();
			}
		);
	}

	/**
	 * POST assign (or clear) a booking role for a user. Booking roles are added
	 * as an ADDITIONAL WordPress role so the user's existing role is preserved;
	 * only one booking role is held at a time.
	 *
	 * Body: { "user_id": 12, "role": "rtrb_front_desk" }  (role "" = revoke)
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function assignMember( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$user_id = absint( $request->get_param( 'user_id' ) );
				$role    = sanitize_text_field( (string) $request->get_param( 'role' ) );
				$user    = $user_id ? get_user_by( 'id', $user_id ) : false;

				if ( ! $user ) {
					return ApiResponse::notFound( __( 'User not found.', 'radius-booking' ) )->send();
				}

				$booking_roles = Capabilities::manageableRoles();

				if ( '' !== $role && ! in_array( $role, $booking_roles, true ) ) {
					return ApiResponse::error( __( 'Invalid role.', 'radius-booking' ), 400 )->send();
				}

				// Clear any existing booking role, then add the new one (if any).
				foreach ( $booking_roles as $r ) {
					if ( in_array( $r, (array) $user->roles, true ) ) {
						$user->remove_role( $r );
					}
				}
				if ( '' !== $role ) {
					$user->add_role( $role );
				}

				$refreshed = get_user_by( 'id', $user_id );

				return ApiResponse::success(
					array( 'member' => $this->formatMember( $refreshed ) ),
					__( 'Role assignment updated.', 'radius-booking' )
				)->send();
			}
		);
	}

	/**
	 * Shape a WP_User into a team-member row: id, name, email, current booking
	 * role slug (or empty) and their other (non-booking) roles for context.
	 *
	 * @param \WP_User $user User.
	 * @return array
	 */
	private function formatMember( $user ): array {
		$booking_roles = Capabilities::manageableRoles();
		$roles         = (array) $user->roles;
		$booking       = array_values( array_intersect( $roles, $booking_roles ) );
		$other         = array_values( array_diff( $roles, $booking_roles ) );

		return array(
			'id'           => $user->ID,
			'name'         => $user->display_name ? $user->display_name : $user->user_login,
			'email'        => $user->user_email,
			'booking_role' => $booking[0] ?? '',
			'other_roles'  => $other,
		);
	}

	/**
	 * Build the matrix payload consumed by the admin UI.
	 *
	 * @return array
	 */
	private function buildMatrix(): array {
		$labels = Capabilities::roleLabels();
		$map    = Capabilities::roleMap();

		$roles = array();
		foreach ( $map as $slug => $caps ) {
			$roles[] = array(
				'slug'  => $slug,
				'label' => $labels[ $slug ] ?? $slug,
				'caps'  => array_values( $caps ),
			);
		}

		return array(
			'capabilities' => Capabilities::catalog(),
			'roles'        => $roles,
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function transformItem( $item ): array {
		return (array) $item;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function transformCollection( array $items ): array {
		return $items;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function getValidationRules( $request, string $context = 'create' ): array {
		return array();
	}

	/**
	 * {@inheritDoc}
	 */
	protected function getResourceType(): string {
		return 'roles';
	}
}
