<?php
/**
 * Class ServiceExtraController
 *
 * Handles API requests related to service extras management.
 *
 * @package RadiusTheme\RadiusBookingPro\Controllers
 */

namespace RadiusTheme\RadiusBookingPro\Controllers;

use RadiusTheme\RadiusBooking\Abstracts\BaseController;
use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBookingPro\Repositories\ServiceExtraRepository;
use RadiusTheme\RadiusBookingPro\Resources\ServiceExtraResource;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Service Extra API controller
 */
class ServiceExtraController extends BaseController {

	/**
	 * Constructor for initializing the controller.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct( new ServiceExtraRepository() );
	}

	/**
	 * Transforms the given item into an array representation.
	 *
	 * @param mixed $item The item to be transformed.
	 *
	 * @return array The transformed array representation.
	 */
	protected function transformItem( $item ): array {
		return ( new ServiceExtraResource() )->transform( $item );
	}

	/**
	 * Transforms a collection of items.
	 *
	 * @param array $items The array of items to be transformed.
	 *
	 * @return array The transformed collection.
	 */
	protected function transformCollection( array $items ): array {
		return ServiceExtraResource::collection( $items );
	}

	/**
	 * Retrieves the validation rules.
	 *
	 * @param mixed  $request The incoming request.
	 * @param string $context The context ('create' or 'update').
	 *
	 * @return array Validation rules.
	 */
	protected function getValidationRules( $request, string $context = 'create' ): array {
		return array();
	}

	/**
	 * Retrieves the resource type for this controller.
	 *
	 * @return string The resource type.
	 */
	protected function getResourceType(): string {
		return 'service_extra';
	}

	/**
	 * GET /services/{service_id}/extras — List all extras for a service.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function index( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$serviceId = (int) $request->get_param( 'service_id' );
				$status    = $request->get_param( 'status' ) ? sanitize_text_field( $request->get_param( 'status' ) ) : 'all';

				$extras = $this->repository->getByService( $serviceId, $status );

				return ApiResponse::success( $this->transformCollection( $extras ) )->send();
			}
		);
	}

	/**
	 * GET /services/{service_id}/extras/public — Public endpoint for booking flow.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function publicIndex( WP_REST_Request $request ) {
		return $this->applyBypass(
			$request,
			function ( $request ) {
				$serviceId = (int) $request->get_param( 'service_id' );

				$extras = $this->repository->getActiveByService( $serviceId );

				return ApiResponse::success( $this->transformCollection( $extras ) )->send();
			}
		);
	}

	/**
	 * GET /services/{service_id}/extras/{id} — Get a single extra.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function show( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$id        = (int) $request->get_param( 'id' );
				$serviceId = (int) $request->get_param( 'service_id' );

				$extra = $this->repository->find( $id );

				if ( ! $extra || (int) $extra->service_id !== $serviceId ) {
					return ApiResponse::notFound()->send();
				}

				return ApiResponse::success( $this->transformItem( $extra ) )->send();
			}
		);
	}

	/**
	 * POST /services/{service_id}/extras — Create a new extra.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function store( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$serviceId = (int) $request->get_param( 'service_id' );
				$data      = $request->get_params();

				// Validate required fields.
				if ( empty( $data['title'] ) ) {
					return ApiResponse::error( __( 'Title is required.', 'radius-booking-pro' ), 422 )->send();
				}

				// Sanitize input.
				$data['service_id']   = $serviceId;
				$data['title']        = sanitize_text_field( $data['title'] );
				$data['description']  = isset( $data['description'] ) ? sanitize_textarea_field( $data['description'] ) : '';
				$data['price']        = isset( $data['price'] ) ? (float) $data['price'] : 0;
				$data['duration']     = isset( $data['duration'] ) ? (int) $data['duration'] : 0;
				$data['min_quantity'] = isset( $data['min_quantity'] ) ? max( 1, (int) $data['min_quantity'] ) : 1;
				$data['max_quantity'] = isset( $data['max_quantity'] ) ? max( $data['min_quantity'], (int) $data['max_quantity'] ) : 1;
				$data['status']       = isset( $data['status'] ) && in_array( $data['status'], array( 'active', 'inactive' ), true ) ? $data['status'] : 'active';

				// Auto-set position.
				$data['position'] = $this->repository->getNextPosition( $serviceId );

				$extra = $this->repository->create( $data );

				return ApiResponse::created( $this->transformItem( $extra ) )->send();
			}
		);
	}

	/**
	 * PUT /services/{service_id}/extras/{id} — Update an extra.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function update( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$id        = (int) $request->get_param( 'id' );
				$serviceId = (int) $request->get_param( 'service_id' );
				$data      = $request->get_params();

				$extra = $this->repository->find( $id );

				if ( ! $extra || (int) $extra->service_id !== $serviceId ) {
					return ApiResponse::notFound()->send();
				}

				// Sanitize input.
				if ( isset( $data['title'] ) ) {
					$data['title'] = sanitize_text_field( $data['title'] );
				}
				if ( isset( $data['description'] ) ) {
					$data['description'] = sanitize_textarea_field( $data['description'] );
				}
				if ( isset( $data['price'] ) ) {
					$data['price'] = (float) $data['price'];
				}
				if ( isset( $data['duration'] ) ) {
					$data['duration'] = (int) $data['duration'];
				}
				if ( isset( $data['min_quantity'] ) ) {
					$data['min_quantity'] = max( 1, (int) $data['min_quantity'] );
				}
				if ( isset( $data['max_quantity'] ) ) {
					$minQty               = isset( $data['min_quantity'] ) ? $data['min_quantity'] : $extra->min_quantity;
					$data['max_quantity'] = max( $minQty, (int) $data['max_quantity'] );
				}
				if ( isset( $data['status'] ) && ! in_array( $data['status'], array( 'active', 'inactive' ), true ) ) {
					unset( $data['status'] );
				}

				// Remove non-updateable fields.
				unset( $data['id'], $data['service_id'] );

				$this->repository->update( $id, $data );

				$extra = $this->repository->find( $id );

				return ApiResponse::success( $this->transformItem( $extra ) )->send();
			}
		);
	}

	/**
	 * DELETE /services/{service_id}/extras/{id} — Delete an extra.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function destroy( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$id        = (int) $request->get_param( 'id' );
				$serviceId = (int) $request->get_param( 'service_id' );

				$extra = $this->repository->find( $id );

				if ( ! $extra || (int) $extra->service_id !== $serviceId ) {
					return ApiResponse::notFound()->send();
				}

				$this->repository->delete( $id );

				return ApiResponse::success( array( 'deleted' => true ) )->send();
			}
		);
	}

	/**
	 * POST /services/{service_id}/extras/reorder — Reorder extras.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function reorder( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$serviceId = (int) $request->get_param( 'service_id' );
				$order     = $request->get_param( 'order' );

				if ( empty( $order ) || ! is_array( $order ) ) {
					return ApiResponse::error( __( 'Order array is required.', 'radius-booking-pro' ), 422 )->send();
				}

				$this->repository->reorder( $serviceId, array_map( 'intval', $order ) );

				$extras = $this->repository->getByService( $serviceId );

				return ApiResponse::success( $this->transformCollection( $extras ) )->send();
			}
		);
	}

	/**
	 * DELETE /services/{service_id}/extras/bulk-delete — Bulk delete extras.
	 *
	 * @param WP_REST_Request $request The current REST request.
	 *
	 * @return mixed
	 */
	public function bulkDelete( WP_REST_Request $request ) {
		return $this->applyMiddleware(
			$request,
			function ( $request ) {
				$serviceId = (int) $request->get_param( 'service_id' );
				$ids       = $request->get_param( 'ids' );

				if ( empty( $ids ) || ! is_array( $ids ) ) {
					return ApiResponse::error( __( 'Invalid IDs', 'radius-booking-pro' ), 422 )->send();
				}

				// Verify all extras belong to this service before deleting.
				$validIds = array();
				foreach ( $ids as $id ) {
					$extra = $this->repository->find( (int) $id );
					if ( $extra && (int) $extra->service_id === $serviceId ) {
						$validIds[] = (int) $id;
					}
				}

				$deletedCount = $this->repository->bulkDelete( $validIds );

				return ApiResponse::success( array( 'deleted_count' => $deletedCount ) )->send();
			}
		);
	}
}
