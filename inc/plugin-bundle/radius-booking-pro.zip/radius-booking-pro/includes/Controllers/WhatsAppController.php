<?php
/**
 * WhatsApp Controller
 *
 * REST endpoints for managing WhatsApp notification settings, per-type
 * message templates, delivery logs, and test sends.
 *
 * @package RadiusTheme\RadiusBookingPro\Controllers
 */

namespace RadiusTheme\RadiusBookingPro\Controllers;

use RadiusTheme\RadiusBooking\Core\Api\ApiResponse;
use RadiusTheme\RadiusBookingPro\WhatsApp\Context\ContextResolver;
use RadiusTheme\RadiusBookingPro\WhatsApp\WhatsAppSender;
use RadiusTheme\RadiusBookingPro\WhatsApp\WhatsAppLogger;
use RadiusTheme\RadiusBookingPro\WhatsApp\WhatsAppManager;
use RadiusTheme\RadiusBookingPro\WhatsApp\WhatsAppSettings;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class WhatsAppController
 */
class WhatsAppController {

	/**
	 * Permission callback — admin only.
	 *
	 * @return bool
	 */
	public static function permission_check() {
		// Site admins always pass (mirrors the rtrb_* admin bypass every other
		// booking endpoint gets via Capabilities::userCan); otherwise require the
		// dedicated WhatsApp capability.
		return current_user_can( 'manage_options' ) || current_user_can( 'rtrb_manage_whatsapp' );
	}

	/**
	 * Manager factory.
	 *
	 * @return WhatsAppManager
	 */
	private function manager() {
		return new WhatsAppManager();
	}

	/**
	 * GET /whatsapp/notifications — list all notifications + settings + tags.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function index( WP_REST_Request $request ) {
		$notifications = array();

		foreach ( $this->manager()->get_notifications() as $notification ) {
			$notifications[] = $notification->to_array();
		}

		return ApiResponse::success(
			array(
				'notifications' => $notifications,
				'settings'      => WhatsAppSettings::get_public(),
				'merge_tags'    => $this->merge_tags(),
			)
		)->send();
	}

	/**
	 * GET /whatsapp/notifications/{id} — single notification.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function show( WP_REST_Request $request ) {
		$id           = sanitize_text_field( (string) $request->get_param( 'id' ) );
		$notification = $this->manager()->get_notification( $id );

		if ( ! $notification ) {
			return ApiResponse::error( __( 'Notification not found', 'radius-booking-pro' ), 404 )->send();
		}

		$data               = $notification->to_array();
		$data['merge_tags'] = $this->merge_tags();

		return ApiResponse::success( $data )->send();
	}

	/**
	 * PUT /whatsapp/notifications/{id} — update a notification's message/toggle.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function update( WP_REST_Request $request ) {
		$id           = sanitize_text_field( (string) $request->get_param( 'id' ) );
		$notification = $this->manager()->get_notification( $id );

		if ( ! $notification ) {
			return ApiResponse::error( __( 'Notification not found', 'radius-booking-pro' ), 404 )->send();
		}

		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $request->get_params();
		}

		$update = array();

		if ( array_key_exists( 'enabled', $params ) ) {
			$update['enabled'] = (bool) $params['enabled'];
		}
		if ( array_key_exists( 'message', $params ) ) {
			$update['message'] = sanitize_textarea_field( (string) $params['message'] );
		}
		if ( array_key_exists( 'content_sid', $params ) ) {
			$update['content_sid'] = sanitize_text_field( (string) $params['content_sid'] );
		}
		if ( array_key_exists( 'reminder_minutes', $params ) && $notification->is_reminder() ) {
			$update['reminder_minutes'] = max( 1, absint( $params['reminder_minutes'] ) );
		}

		$notification->update_settings( $update );

		return ApiResponse::success( $notification->to_array(), __( 'Notification updated', 'radius-booking-pro' ) )->send();
	}

	/**
	 * GET /whatsapp/settings — global provider settings (token masked).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function get_settings( WP_REST_Request $request ) {
		return ApiResponse::success( WhatsAppSettings::get_public() )->send();
	}

	/**
	 * PUT /whatsapp/settings — update global provider settings.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function update_settings( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $request->get_params();
		}

		$update = array();

		if ( array_key_exists( 'enabled', $params ) ) {
			$update['enabled'] = (bool) $params['enabled'];
		}
		if ( array_key_exists( 'provider', $params ) ) {
			$provider           = sanitize_text_field( (string) $params['provider'] );
			$update['provider'] = in_array( $provider, array( 'twilio', 'meta' ), true ) ? $provider : 'twilio';
		}
		if ( array_key_exists( 'default_country_code', $params ) ) {
			$update['default_country_code'] = sanitize_text_field( (string) $params['default_country_code'] );
		}
		if ( array_key_exists( 'admin_numbers', $params ) ) {
			$update['admin_numbers'] = $this->sanitize_numbers( $params['admin_numbers'] );
		}

		// --- Twilio fields. ---
		if ( array_key_exists( 'sandbox_mode', $params ) ) {
			$update['sandbox_mode'] = (bool) $params['sandbox_mode'];
		}
		if ( array_key_exists( 'account_sid', $params ) ) {
			$update['account_sid'] = sanitize_text_field( (string) $params['account_sid'] );
		}
		if ( array_key_exists( 'from_number', $params ) ) {
			$update['from_number'] = sanitize_text_field( (string) $params['from_number'] );
		}

		// --- Meta Cloud API fields. ---
		if ( array_key_exists( 'meta_phone_number_id', $params ) ) {
			$update['meta_phone_number_id'] = sanitize_text_field( (string) $params['meta_phone_number_id'] );
		}
		if ( array_key_exists( 'meta_business_id', $params ) ) {
			$update['meta_business_id'] = sanitize_text_field( (string) $params['meta_business_id'] );
		}
		if ( array_key_exists( 'meta_api_version', $params ) ) {
			$update['meta_api_version'] = sanitize_text_field( (string) $params['meta_api_version'] );
		}
		if ( array_key_exists( 'meta_template_language', $params ) ) {
			$update['meta_template_language'] = sanitize_text_field( (string) $params['meta_template_language'] );
		}

		// Only overwrite secret tokens when a real (non-masked, non-empty) value is provided.
		if ( array_key_exists( 'auth_token', $params ) ) {
			$token = trim( (string) $params['auth_token'] );
			if ( '' !== $token && false === strpos( $token, '•' ) ) {
				$update['auth_token'] = $token;
			}
		}
		if ( array_key_exists( 'meta_access_token', $params ) ) {
			$token = trim( (string) $params['meta_access_token'] );
			if ( '' !== $token && false === strpos( $token, '•' ) ) {
				$update['meta_access_token'] = $token;
			}
		}

		WhatsAppSettings::update( $update );

		return ApiResponse::success( WhatsAppSettings::get_public(), __( 'Settings saved', 'radius-booking-pro' ) )->send();
	}

	/**
	 * POST /whatsapp/test-connection — verify Twilio credentials.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function test_connection( WP_REST_Request $request ) {
		$result = WhatsAppSender::test_connection();

		if ( is_wp_error( $result ) ) {
			return ApiResponse::error( $result->get_error_message(), 400 )->send();
		}

		return ApiResponse::success( array(), __( 'Connection successful. Your Twilio credentials are valid.', 'radius-booking-pro' ) )->send();
	}

	/**
	 * POST /whatsapp/test — send a test message for a notification.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function send_test( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $request->get_params();
		}

		$id = isset( $params['notification_id'] ) ? sanitize_text_field( (string) $params['notification_id'] ) : '';
		$to = isset( $params['to'] ) ? sanitize_text_field( (string) $params['to'] ) : '';

		if ( '' === $to ) {
			return ApiResponse::error( __( 'Please provide a recipient phone number.', 'radius-booking-pro' ), 422 )->send();
		}

		$notification = $this->manager()->get_notification( $id );

		if ( ! $notification ) {
			return ApiResponse::error( __( 'Notification not found', 'radius-booking-pro' ), 404 )->send();
		}

		$result = $notification->send_test( $to );

		if ( is_wp_error( $result ) ) {
			return ApiResponse::error( $result->get_error_message(), 400 )->send();
		}

		return ApiResponse::success( array(), __( 'Test message sent successfully.', 'radius-booking-pro' ) )->send();
	}

	/**
	 * GET /whatsapp/logs — recent delivery log.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function logs( WP_REST_Request $request ) {
		return ApiResponse::success( WhatsAppLogger::get() )->send();
	}

	/**
	 * DELETE /whatsapp/logs — clear the delivery log.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return mixed
	 */
	public function clear_logs( WP_REST_Request $request ) {
		WhatsAppLogger::clear();

		return ApiResponse::success( array(), __( 'Log cleared', 'radius-booking-pro' ) )->send();
	}

	/**
	 * Available merge tags for the UI inserter, keyed by booking type.
	 *
	 * The UI picks the list matching each notification's booking_type so it
	 * never offers a tag that resolves to an empty string for that type.
	 *
	 * @return array
	 */
	private function merge_tags() {
		return array(
			'appointment' => ContextResolver::tag_catalogue( 'appointment' ),
			'meeting'     => ContextResolver::tag_catalogue( 'meeting' ),
			'event'       => ContextResolver::tag_catalogue( 'event' ),
		);
	}

	/**
	 * Sanitize an array of phone numbers.
	 *
	 * @param mixed $numbers Raw input.
	 * @return array
	 */
	private function sanitize_numbers( $numbers ) {
		if ( ! is_array( $numbers ) ) {
			return array();
		}

		return array_values(
			array_filter(
				array_map(
					function ( $n ) {
						return sanitize_text_field( (string) $n );
					},
					$numbers
				)
			)
		);
	}
}
