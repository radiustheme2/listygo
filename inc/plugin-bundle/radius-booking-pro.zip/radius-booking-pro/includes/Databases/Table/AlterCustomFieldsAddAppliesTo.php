<?php
/**
 * Migration: extend `custom_fields` to target Meeting Types and Events.
 *
 * Adds three JSON columns:
 *
 *   - applies_to    — which resource types the field is enabled for
 *                     (e.g. ["service","meeting_type","event"])
 *   - meeting_types — array of meeting type IDs (empty = all meetings)
 *   - events        — array of event IDs       (empty = all events)
 *
 * Backfills existing rows with applies_to = ["service"] so behavior on
 * upgrade is unchanged — a pre-existing field that targeted services will
 * not suddenly appear on meeting or event forms.
 *
 * Idempotent: each column is added only if missing, so the migration is
 * safe to re-run.
 *
 * @package RadiusTheme\RadiusBookingPro\Databases\Table
 */

namespace RadiusTheme\RadiusBookingPro\Databases\Table;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\Migration;

/**
 * Class AlterCustomFieldsAddAppliesTo
 *
 * Adds applies_to, meeting_types, and events JSON columns to the
 * radius_booking_custom_fields table and backfills existing rows.
 */
class AlterCustomFieldsAddAppliesTo extends Migration {

	/**
	 * Apply the migration.
	 *
	 * Adds the three JSON columns if they don't already exist, then
	 * backfills `applies_to` for rows still missing it.
	 *
	 * @return void
	 */
	public function up(): void {
		global $wpdb;

		$table = $wpdb->prefix . $this->tablePrefix . 'custom_fields';

		// If the base table doesn't exist yet, the CustomFieldsTable migration
		// will run first with the original schema; bail quietly so we don't
		// error on fresh installs where ordering varies.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( ! $exists ) {
			return;
		}

		// LONGTEXT (not JSON) because the framework's BaseModel "json" cast
		// writes values with PHP serialize() rather than json_encode(); a
		// strict JSON column rejects the resulting "a:1:{...}" string and
		// every save errors. The CustomFieldResource's decodeJsonField
		// already handles both serialize and JSON payloads on read, so
		// values backfilled below as JSON literals also remain readable.
		$this->addColumnIfMissing( $table, 'applies_to', 'LONGTEXT NULL DEFAULT NULL AFTER `services`' );
		$this->addColumnIfMissing( $table, 'meeting_types', 'LONGTEXT NULL DEFAULT NULL AFTER `applies_to`' );
		$this->addColumnIfMissing( $table, 'events', 'LONGTEXT NULL DEFAULT NULL AFTER `meeting_types`' );

		// Backfill existing rows so the upgrade is non-breaking: any field that
		// existed before this migration must continue to apply only to services.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"UPDATE {$table} SET applies_to = '[\"service\"]' WHERE applies_to IS NULL"
		);
	}

	/**
	 * Revert the migration by dropping the three columns.
	 *
	 * Drops are guarded by SHOW COLUMNS so the down migration is also
	 * idempotent and safe to re-run.
	 *
	 * @return void
	 */
	public function down(): void {
		global $wpdb;

		$table = $wpdb->prefix . $this->tablePrefix . 'custom_fields';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( ! $exists ) {
			return;
		}

		$this->dropColumnIfPresent( $table, 'events' );
		$this->dropColumnIfPresent( $table, 'meeting_types' );
		$this->dropColumnIfPresent( $table, 'applies_to' );
	}

	/**
	 * Add a column to the table if it does not already exist.
	 *
	 * Uses a SHOW COLUMNS guard so re-running the migration is safe and
	 * the call returns a no-op on installs where this migration has
	 * already been applied or where a fresh install schema added the
	 * column directly.
	 *
	 * @param string $table      Fully-qualified table name (with WP prefix).
	 * @param string $column     Column name to add.
	 * @param string $definition Column SQL definition (e.g. "JSON NULL DEFAULT NULL").
	 *
	 * @return void
	 */
	private function addColumnIfMissing( string $table, string $column, string $definition ): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$present = $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SHOW COLUMNS FROM {$table} LIKE %s",
				$column
			)
		);

		if ( $present ) {
			return;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( "ALTER TABLE {$table} ADD COLUMN `{$column}` {$definition}" );
	}

	/**
	 * Drop a column from the table if it exists.
	 *
	 * @param string $table  Fully-qualified table name (with WP prefix).
	 * @param string $column Column name to drop.
	 *
	 * @return void
	 */
	private function dropColumnIfPresent( string $table, string $column ): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$present = $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SHOW COLUMNS FROM {$table} LIKE %s",
				$column
			)
		);

		if ( ! $present ) {
			return;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( "ALTER TABLE {$table} DROP COLUMN `{$column}`" );
	}
}
