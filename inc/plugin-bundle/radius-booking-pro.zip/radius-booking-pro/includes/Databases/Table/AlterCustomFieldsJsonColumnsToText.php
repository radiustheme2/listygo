<?php
/**
 * Hotfix migration: change `custom_fields.applies_to`, `meeting_types`,
 * and `events` from MySQL JSON to LONGTEXT.
 *
 * Why: the framework's BaseModel "json" cast writes values via PHP
 * `serialize()` rather than `json_encode()` (see
 * `Abstracts/BaseModel.php` around the cast handler). A strict JSON
 * column rejects the resulting `a:1:{...}` payload, so every save to
 * these columns errors with:
 *
 *   "Invalid JSON text: 'Invalid value.' at position 0".
 *
 * LONGTEXT happily stores serialized PHP, and the
 * `CustomFieldResource::decodeJsonField` reader already understands
 * both serialize and JSON payloads — so previously-backfilled JSON
 * literals (e.g. `["service"]`) stay readable as text strings after
 * the conversion.
 *
 * Idempotent: per-column it inspects `information_schema.COLUMNS` and
 * only runs the ALTER when the column is still JSON. Safe to re-run.
 *
 * @package RadiusTheme\RadiusBookingPro\Databases\Table
 */

namespace RadiusTheme\RadiusBookingPro\Databases\Table;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\Migration;

/**
 * Class AlterCustomFieldsJsonColumnsToText
 *
 * Converts the JSON-typed targeting columns introduced by
 * AlterCustomFieldsAddAppliesTo over to LONGTEXT.
 */
class AlterCustomFieldsJsonColumnsToText extends Migration {

	/**
	 * Apply the migration.
	 *
	 * @return void
	 */
	public function up(): void {
		global $wpdb;

		$table = $wpdb->prefix . $this->tablePrefix . 'custom_fields';

		// Bail quietly if the table does not exist (fresh installs that haven't
		// yet run CustomFieldsTable).
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( ! $exists ) {
			return;
		}

		$this->convertJsonColumnToLongText( $table, 'applies_to', '`services`' );
		$this->convertJsonColumnToLongText( $table, 'meeting_types', '`applies_to`' );
		$this->convertJsonColumnToLongText( $table, 'events', '`meeting_types`' );
	}

	/**
	 * Revert the migration: change the columns back to JSON.
	 *
	 * Existing serialized PHP values would become invalid JSON after the
	 * revert, so this down() also clears any non-JSON content to NULL to
	 * keep the column usable. Use with care.
	 *
	 * @return void
	 */
	public function down(): void {
		global $wpdb;

		$table = $wpdb->prefix . $this->tablePrefix . 'custom_fields';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( ! $exists ) {
			return;
		}

		foreach ( array( 'applies_to', 'meeting_types', 'events' ) as $column ) {
			// Wipe values that aren't valid JSON to avoid the ALTER failing.
			$this->nullifyNonJsonValues( $table, $column );

			$current_type = $this->getColumnDataType( $table, $column );
			if ( null === $current_type || 'json' === strtolower( $current_type ) ) {
				continue;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->query( "ALTER TABLE {$table} MODIFY COLUMN `{$column}` JSON NULL DEFAULT NULL" );
		}
	}

	/**
	 * Convert a single column from JSON to LONGTEXT in place.
	 *
	 * Skips the ALTER when the column is already LONGTEXT (or absent), so
	 * the migration is safe to re-run.
	 *
	 * @param string $table  Fully-qualified table name (with WP prefix).
	 * @param string $column Column name to convert.
	 * @param string $after  Backtick-quoted column name to position after.
	 *
	 * @return void
	 */
	private function convertJsonColumnToLongText( string $table, string $column, string $after ): void {
		global $wpdb;

		$current_type = $this->getColumnDataType( $table, $column );
		if ( null === $current_type ) {
			// Column missing — the original AlterCustomFieldsAddAppliesTo
			// migration will (or already did) add it with the corrected
			// LONGTEXT type; nothing to do here.
			return;
		}

		if ( 'longtext' === strtolower( $current_type ) ) {
			return;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( "ALTER TABLE {$table} MODIFY COLUMN `{$column}` LONGTEXT NULL DEFAULT NULL AFTER {$after}" );
	}

	/**
	 * Look up the DATA_TYPE of a column from information_schema.
	 *
	 * Returns null when the column does not exist. Returns the lowercase
	 * data type (e.g. 'json', 'longtext', 'text') otherwise.
	 *
	 * @param string $table  Fully-qualified table name (with WP prefix).
	 * @param string $column Column name to inspect.
	 *
	 * @return string|null
	 */
	private function getColumnDataType( string $table, string $column ): ?string {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$type = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT DATA_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s',
				$table,
				$column
			)
		);

		return $type ? strtolower( (string) $type ) : null;
	}

	/**
	 * NULL out values in a column that aren't valid JSON.
	 *
	 * Used by down() so a revert to a strict JSON column type doesn't
	 * fail on rows that contain PHP-serialized data.
	 *
	 * @param string $table  Fully-qualified table name (with WP prefix).
	 * @param string $column Column to clean.
	 *
	 * @return void
	 */
	private function nullifyNonJsonValues( string $table, string $column ): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query(
			"UPDATE {$table} SET `{$column}` = NULL WHERE `{$column}` IS NOT NULL AND JSON_VALID(`{$column}`) = 0"
		);
	}
}
