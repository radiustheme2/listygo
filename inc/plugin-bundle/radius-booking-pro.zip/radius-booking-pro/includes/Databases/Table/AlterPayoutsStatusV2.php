<?php
/**
 * Migration: alter the `payouts` table status enum to the new vocabulary.
 *
 * Replaces the original `pending / approved / completed / rejected` enum
 * with `pending / processing / on_hold / paid / rejected` and remaps any
 * existing rows so they land in the closest equivalent state:
 *   approved  → processing
 *   completed → paid
 *
 * Runs once per install (tracked by MigrationRunner) for both fresh and
 * upgrade scenarios. Fresh installs already get the new enum from
 * PayoutsTable; this migration is a no-op for them because the data
 * remap finds nothing to change and the ALTER simply re-asserts the
 * same column definition.
 */

namespace RadiusTheme\RadiusBookingPro\Databases\Table;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\Migration;

class AlterPayoutsStatusV2 extends Migration {

	/**
	 * Apply the migration: remap legacy values then widen the enum.
	 */
	public function up(): void {
		global $wpdb;

		$table = $wpdb->prefix . $this->tablePrefix . 'payouts';

		// If the table doesn't exist yet (fresh installs run PayoutsTable
		// first, but order is not guaranteed across all flows), bail
		// quietly — the new schema already carries the new enum.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( ! $exists ) {
			return;
		}

		// Remap legacy values to the new vocabulary BEFORE altering the
		// enum, otherwise MySQL will coerce out-of-range values to ''.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( "UPDATE {$table} SET status = 'processing' WHERE status = 'approved'" );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( "UPDATE {$table} SET status = 'paid' WHERE status = 'completed'" );

		// Widen / replace the enum. Default stays `pending`.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			"ALTER TABLE {$table}
			 MODIFY COLUMN status ENUM('pending','processing','on_hold','paid','rejected')
			 NOT NULL DEFAULT 'pending'"
		);
	}

	/**
	 * Revert: re-map new values back to the legacy set and shrink the enum.
	 */
	public function down(): void {
		global $wpdb;

		$table = $wpdb->prefix . $this->tablePrefix . 'payouts';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( ! $exists ) {
			return;
		}

		// Map new values back to legacy ones. `on_hold` has no legacy
		// equivalent, so it falls back to `pending` to keep the row valid.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( "UPDATE {$table} SET status = 'approved' WHERE status = 'processing'" );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( "UPDATE {$table} SET status = 'completed' WHERE status = 'paid'" );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( "UPDATE {$table} SET status = 'pending' WHERE status = 'on_hold'" );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			"ALTER TABLE {$table}
			 MODIFY COLUMN status ENUM('pending','approved','completed','rejected')
			 NOT NULL DEFAULT 'pending'"
		);
	}
}