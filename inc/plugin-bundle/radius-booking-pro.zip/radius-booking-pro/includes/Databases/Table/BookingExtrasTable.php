<?php
/**
 * Migration class for the 'booking_extras' table.
 *
 * @package RadiusTheme\RadiusBookingPro\Databases\Table
 */

namespace RadiusTheme\RadiusBookingPro\Databases\Table;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Database\Schema\Blueprint;
use RadiusTheme\RadiusBooking\Abstracts\Migration;
use RadiusTheme\RadiusBooking\Core\Database\Schema\Schema;

/**
 * Class BookingExtrasTable
 *
 * Migration for creating the 'booking_extras' table.
 * Stores selected extras per booking as a snapshot to preserve
 * historical pricing even if extras are later modified.
 */
class BookingExtrasTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up(): void {
		Schema::create(
			$this->tablePrefix . 'booking_extras',
			function ( Blueprint $table ) {
				$table->id();
				$table->unsignedBigInteger( 'booking_id' );
				$table->unsignedBigInteger( 'extra_id' );
				$table->string( 'title' );
				$table->decimal( 'unit_price', 10, 2 );
				$table->unsignedInteger( 'duration' )->default( 0 );
				$table->unsignedInteger( 'quantity' )->default( 1 );
				$table->decimal( 'total_price', 10, 2 );
				$table->timestamps();
				$table->index( 'booking_id' );
				$table->index( 'extra_id' );
			}
		);
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down(): void {
		Schema::drop( $this->tablePrefix . 'booking_extras' );
	}
}
