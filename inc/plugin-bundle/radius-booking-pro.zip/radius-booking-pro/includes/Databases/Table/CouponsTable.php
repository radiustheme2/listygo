<?php
/**
 * Migration class for the 'coupons' table.
 */

namespace RadiusTheme\RadiusBookingPro\Databases\Table;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Database\Schema\Blueprint;
use RadiusTheme\RadiusBooking\Abstracts\Migration;
use RadiusTheme\RadiusBooking\Core\Database\Schema\Schema;

/**
 * Class CouponsTable
 *
 * Migration for creating the 'coupons' table.
 */
class CouponsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up(): void {
		Schema::create(
			$this->tablePrefix . 'coupons',
			function ( Blueprint $table ) {
				$table->id();
				$table->string( 'code' )->unique();
				$table->string( 'description' )->nullable();
				$table->enum( 'discount_type', array( 'fixed', 'percentage' ) )->default( 'fixed' );
				$table->double( 'discount_value' )->default( 0 );
				$table->integer( 'max_uses' )->nullable();
				$table->integer( 'usage_count' )->default( 0 );
				$table->date( 'start_date' )->nullable();
				$table->date( 'end_date' )->nullable();
				$table->double( 'min_amount' )->default( 0 );
				$table->double( 'max_discount' )->nullable();
				$table->text( 'applicable_services' )->nullable();
				$table->boolean( 'auto_apply' )->default( 0 );
				$table->enum( 'status', array( 'active', 'inactive' ) )->default( 'active' );
				$table->unsignedInteger( 'created_by' )->nullable();
				$table->timestamps();
			}
		);
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down(): void {
		Schema::drop( $this->tablePrefix . 'coupons' );
	}
}