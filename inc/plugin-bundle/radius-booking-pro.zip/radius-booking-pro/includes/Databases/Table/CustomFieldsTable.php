<?php
/**
 * Migration class for the 'custom_fields' table.
 */

namespace RadiusTheme\RadiusBookingPro\Databases\Table;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Database\Schema\Blueprint;
use RadiusTheme\RadiusBooking\Abstracts\Migration;
use RadiusTheme\RadiusBooking\Core\Database\Schema\Schema;

/**
 * Class CustomFieldsTable
 *
 * Migration for creating the 'custom_fields' table.
 */
class CustomFieldsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up(): void {
		Schema::create(
			$this->tablePrefix . 'custom_fields',
			function ( Blueprint $table ) {
				$table->id();
				$table->string( 'label' );
				$table->string( 'type' );
				$table->json( 'options' )->nullable()->default( null );
				$table->string( 'placeholder' )->nullable()->default( null );
				$table->boolean( 'required' )->default( 0 );
				$table->boolean( 'is_active' )->default( 1 );
				$table->integer( 'sort_order' )->default( 0 );
				$table->json( 'services' )->nullable()->default( null );
				$table->timestamps();
			}
		);
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down(): void {
		Schema::drop( $this->tablePrefix . 'custom_fields' );
	}
}