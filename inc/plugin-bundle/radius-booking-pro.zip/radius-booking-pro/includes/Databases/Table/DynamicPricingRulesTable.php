<?php
/**
 * Migration class for the 'dynamic_pricing_rules' table.
 */

namespace RadiusTheme\RadiusBookingPro\Databases\Table;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Database\Schema\Blueprint;
use RadiusTheme\RadiusBooking\Abstracts\Migration;
use RadiusTheme\RadiusBooking\Core\Database\Schema\Schema;

/**
 * Class DynamicPricingRulesTable
 *
 * Migration for creating the 'dynamic_pricing_rules' table.
 */
class DynamicPricingRulesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up(): void {
		Schema::create(
			$this->tablePrefix . 'dynamic_pricing_rules',
			function ( Blueprint $table ) {
				$table->id();
				$table->string( 'name' );
				$table->string( 'description' )->nullable();
				$table->enum( 'rule_type', array( 'time_of_day', 'day_of_week', 'date_range', 'season', 'slot_availability' ) );
				$table->enum( 'adjustment_type', array( 'percentage', 'fixed' ) )->default( 'percentage' );
				$table->double( 'adjustment_value' )->default( 0 );
				$table->text( 'conditions' )->nullable();
				$table->text( 'applicable_services' )->nullable();
				$table->integer( 'priority' )->default( 10 );
				$table->boolean( 'is_active' )->default( 1 );
				$table->unsignedInteger( 'created_by' )->nullable();
				$table->timestamps();
			}
		);
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down(): void {
		Schema::drop( $this->tablePrefix . 'dynamic_pricing_rules' );
	}
}
