<?php
/**
 * Migration class for the 'payouts' table.
 */

namespace RadiusTheme\RadiusBookingPro\Databases\Table;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Database\Schema\Blueprint;
use RadiusTheme\RadiusBooking\Abstracts\Migration;
use RadiusTheme\RadiusBooking\Core\Database\Schema\Schema;

/**
 * Class PayoutsTable
 *
 * Migration for creating the 'payouts' table.
 */
class PayoutsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up(): void {
		Schema::create(
			$this->tablePrefix . 'payouts',
			function ( Blueprint $table ) {
				$table->id();
				$table->unsignedInteger( 'employee_id' );
				$table->double( 'amount' )->default( 0 );
				$table->double( 'commission_amount' )->default( 0 );
				$table->double( 'net_amount' )->default( 0 );
				$table->enum( 'status', array( 'pending', 'processing', 'on_hold', 'paid', 'rejected' ) )->default( 'pending' );
				$table->string( 'payout_method' )->default( 'cash' );
				$table->text( 'employee_note' )->nullable();
				$table->text( 'admin_note' )->nullable();
				$table->unsignedInteger( 'processed_by' )->nullable();
				$table->timestamp( 'processed_at' )->nullable();
				$table->timestamp( 'completed_at' )->nullable();
				$table->timestamps();
			}
		);
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down(): void {
		Schema::drop( $this->tablePrefix . 'payouts' );
	}
}
