<?php
/**
 * Migration class for the 'service_extras' table.
 *
 * @package RadiusTheme\RadiusBookingPro\Databases\Table
 */

namespace RadiusTheme\RadiusBookingPro\Databases\Table;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Database\Schema\Blueprint;
use RadiusTheme\RadiusBooking\Abstracts\Migration;
use RadiusTheme\RadiusBooking\Core\Database\Schema\Schema;

/**
 * Class ServiceExtrasTable
 *
 * Migration for creating the 'service_extras' table.
 * Stores extras configuration per service.
 */
class ServiceExtrasTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up(): void {
		Schema::create(
			$this->tablePrefix . 'service_extras',
			function ( Blueprint $table ) {
				$table->id();
				$table->unsignedBigInteger( 'service_id' );
				$table->string( 'title' );
				$table->text( 'description' )->nullable();
				$table->decimal( 'price', 10, 2 )->default( 0 );
				$table->unsignedInteger( 'duration' )->default( 0 );
				$table->unsignedInteger( 'min_quantity' )->default( 1 );
				$table->unsignedInteger( 'max_quantity' )->default( 1 );
				$table->unsignedInteger( 'position' )->default( 0 );
				$table->enum( 'status', array( 'active', 'inactive' ) )->default( 'active' );
				$table->timestamps();
				$table->index( 'service_id' );
				$table->index( 'status' );
			}
		);
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down(): void {
		Schema::drop( $this->tablePrefix . 'service_extras' );
	}
}
