<?php

namespace RadiusTheme\RadiusBookingPro\ExportImport\Exporters;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\ExportImport\Contracts\ExporterInterface;
use RadiusTheme\RadiusBookingPro\Models\Coupon;

/**
 * Class CouponExporter
 *
 * @package RadiusTheme\RadiusBookingPro\ExportImport\Exporters
 */
class CouponExporter implements ExporterInterface {

	/**
	 * {@inheritDoc}
	 */
	public function getModuleName(): string {
		return 'coupon';
	}

	/**
	 * {@inheritDoc}
	 */
	public function count(): int {
		return Coupon::query()->count();
	}

	/**
	 * {@inheritDoc}
	 */
	public function export( int $offset = 0, int $limit = 500 ): array {
		$rows    = Coupon::query()->offset( $offset )->limit( $limit )->get();
		$records = array();

		foreach ( $rows as $row ) {
			$model     = Coupon::hydrate( $row );
			$records[] = $model->toArray();
		}

		return $records;
	}

	/**
	 * {@inheritDoc}
	 */
	public function getDependencies(): array {
		return array( 'service' );
	}
}
