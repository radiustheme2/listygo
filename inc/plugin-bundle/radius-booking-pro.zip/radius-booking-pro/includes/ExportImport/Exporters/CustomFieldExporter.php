<?php

namespace RadiusTheme\RadiusBookingPro\ExportImport\Exporters;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\ExportImport\Contracts\ExporterInterface;
use RadiusTheme\RadiusBookingPro\Models\CustomField;

/**
 * Class CustomFieldExporter
 *
 * @package RadiusTheme\RadiusBookingPro\ExportImport\Exporters
 */
class CustomFieldExporter implements ExporterInterface {

	/**
	 * {@inheritDoc}
	 */
	public function getModuleName(): string {
		return 'custom_field';
	}

	/**
	 * {@inheritDoc}
	 */
	public function count(): int {
		return CustomField::query()->count();
	}

	/**
	 * {@inheritDoc}
	 */
	public function export( int $offset = 0, int $limit = 500 ): array {
		$rows    = CustomField::query()->offset( $offset )->limit( $limit )->get();
		$records = array();

		foreach ( $rows as $row ) {
			$model     = CustomField::hydrate( $row );
			$records[] = $model->toArray();
		}

		return $records;
	}

	/**
	 * {@inheritDoc}
	 */
	public function getDependencies(): array {
		return array( 'service' );
	}
}
