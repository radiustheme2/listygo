<?php

namespace RadiusTheme\RadiusBookingPro\ExportImport\Exporters;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\ExportImport\Contracts\ExporterInterface;
use RadiusTheme\RadiusBookingPro\Models\DynamicPricingRule;

/**
 * Class DynamicPricingExporter
 *
 * @package RadiusTheme\RadiusBookingPro\ExportImport\Exporters
 */
class DynamicPricingExporter implements ExporterInterface {

	/**
	 * {@inheritDoc}
	 */
	public function getModuleName(): string {
		return 'dynamic_pricing';
	}

	/**
	 * {@inheritDoc}
	 */
	public function count(): int {
		return DynamicPricingRule::query()->count();
	}

	/**
	 * {@inheritDoc}
	 */
	public function export( int $offset = 0, int $limit = 500 ): array {
		$rows    = DynamicPricingRule::query()->offset( $offset )->limit( $limit )->get();
		$records = array();

		foreach ( $rows as $row ) {
			$model     = DynamicPricingRule::hydrate( $row );
			$records[] = $model->toArray();
		}

		return $records;
	}

	/**
	 * {@inheritDoc}
	 */
	public function getDependencies(): array {
		return array( 'service' );
	}
}
