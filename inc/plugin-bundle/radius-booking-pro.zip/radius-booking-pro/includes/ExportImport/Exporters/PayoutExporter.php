<?php

namespace RadiusTheme\RadiusBookingPro\ExportImport\Exporters;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\ExportImport\Contracts\ExporterInterface;
use RadiusTheme\RadiusBookingPro\Models\Payout;

/**
 * Class PayoutExporter
 *
 * @package RadiusTheme\RadiusBookingPro\ExportImport\Exporters
 */
class PayoutExporter implements ExporterInterface {

	/**
	 * {@inheritDoc}
	 */
	public function getModuleName(): string {
		return 'payout';
	}

	/**
	 * {@inheritDoc}
	 */
	public function count(): int {
		return Payout::query()->count();
	}

	/**
	 * {@inheritDoc}
	 */
	public function export( int $offset = 0, int $limit = 500 ): array {
		$rows    = Payout::query()->offset( $offset )->limit( $limit )->get();
		$records = array();

		foreach ( $rows as $row ) {
			$model     = Payout::hydrate( $row );
			$records[] = $model->toArray();
		}

		return $records;
	}

	/**
	 * {@inheritDoc}
	 */
	public function getDependencies(): array {
		return array( 'staff' );
	}
}
