<?php

namespace RadiusTheme\RadiusBookingPro\ExportImport\Importers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\ExportImport\Contracts\ImporterInterface;
use RadiusTheme\RadiusBooking\ExportImport\IdMapper;
use RadiusTheme\RadiusBookingPro\Models\DynamicPricingRule;

/**
 * Class DynamicPricingImporter
 *
 * @package RadiusTheme\RadiusBookingPro\ExportImport\Importers
 */
class DynamicPricingImporter implements ImporterInterface {

	/**
	 * {@inheritDoc}
	 */
	public function getModuleName(): string {
		return 'dynamic_pricing';
	}

	/**
	 * {@inheritDoc}
	 */
	public function import( array $records, IdMapper $id_mapper ): int {
		$imported = 0;

		foreach ( $records as $record ) {
			$old_id = (int) ( $record['id'] ?? 0 );
			unset( $record['id'], $record['created_at'], $record['updated_at'] );

			// Remap applicable_services IDs.
			if ( ! empty( $record['applicable_services'] ) ) {
				$services = $record['applicable_services'];
				if ( is_string( $services ) ) {
					$services = json_decode( $services, true );
				}
				if ( is_array( $services ) ) {
					$remapped = array();
					foreach ( $services as $svc_id ) {
						$new_id     = $id_mapper->getNewId( 'service', (int) $svc_id );
						$remapped[] = $new_id ? $new_id : (int) $svc_id;
					}
					$record['applicable_services'] = wp_json_encode( $remapped );
				}
			}

			$model = DynamicPricingRule::create( $record );

			if ( $model && $old_id ) {
				$id_mapper->addMapping( 'dynamic_pricing', $old_id, (int) $model->id );
				++$imported;
			}
		}

		return $imported;
	}

	/**
	 * {@inheritDoc}
	 */
	public function getDependencies(): array {
		return array( 'service' );
	}
}
