<?php

namespace RadiusTheme\RadiusBookingPro\ExportImport\Importers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\ExportImport\Contracts\ImporterInterface;
use RadiusTheme\RadiusBooking\ExportImport\IdMapper;
use RadiusTheme\RadiusBookingPro\Models\Payout;

/**
 * Class PayoutImporter
 *
 * @package RadiusTheme\RadiusBookingPro\ExportImport\Importers
 */
class PayoutImporter implements ImporterInterface {

	/**
	 * {@inheritDoc}
	 */
	public function getModuleName(): string {
		return 'payout';
	}

	/**
	 * {@inheritDoc}
	 */
	public function import( array $records, IdMapper $id_mapper ): int {
		$imported = 0;

		foreach ( $records as $record ) {
			$old_id = (int) ( $record['id'] ?? 0 );
			unset( $record['id'], $record['created_at'], $record['updated_at'] );

			// Remap employee_id.
			if ( ! empty( $record['employee_id'] ) ) {
				$new_emp_id = $id_mapper->getNewId( 'staff', (int) $record['employee_id'] );
				if ( $new_emp_id ) {
					$record['employee_id'] = $new_emp_id;
				}
			}

			$model = Payout::create( $record );

			if ( $model && $old_id ) {
				$id_mapper->addMapping( 'payout', $old_id, (int) $model->id );
				++$imported;
			}
		}

		return $imported;
	}

	/**
	 * {@inheritDoc}
	 */
	public function getDependencies(): array {
		return array( 'staff' );
	}
}
