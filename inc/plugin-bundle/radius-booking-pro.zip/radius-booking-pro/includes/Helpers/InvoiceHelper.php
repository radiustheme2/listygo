<?php

namespace RadiusTheme\RadiusBookingPro\Helpers;

use WP_Error;

class InvoiceHelper {

	/**
	 * Generate PDF from HTML using available libraries
	 *
	 * @param array $invoice_data Invoice data.
	 * @return string|WP_Error Path to generated PDF or error.
	 */
	public static function generate_pdf_from_html( $invoice_data ) {
		// Check if required libraries are available
		if ( ! class_exists( 'Dompdf\Dompdf' ) ) {
			return new WP_Error(
				'pdf_library_missing',
				__( 'PDF generation library not found. Please install Dompdf.', 'radius-booking-pro' )
			);
		}

		$html = self::generate_invoice_html( $invoice_data );
		$invoice_number = sanitize_file_name( $invoice_data['invoiceNumber'] );

		// Create temporary file
		$upload_dir = wp_upload_dir();
		$temp_dir = trailingslashit( $upload_dir['basedir'] ) . 'radius-booking-temp';

		if ( ! file_exists( $temp_dir ) ) {
			wp_mkdir_p( $temp_dir );
		}

		$pdf_path = $temp_dir . '/invoice-' . $invoice_number . '-' . time() . '.pdf';
		// Try Dompdf first
		if ( class_exists( 'Dompdf\Dompdf' ) ) {
			try {
				$dompdf = new \Dompdf\Dompdf();
				$dompdf->loadHtml( $html, 'UTF-8' );
				$dompdf->setPaper( 'A4', 'portrait' );
				$dompdf->render();

				file_put_contents( $pdf_path, $dompdf->output() );
				return $pdf_path;
			} catch ( \Exception $e ) {
				return new WP_Error(
					'pdf_generation_failed',
					/* translators: %s: exception message */
					sprintf( __( 'PDF generation failed: %s', 'radius-booking-pro' ), $e->getMessage() )
				);
			}
		}

		return new WP_Error(
			'pdf_generation_failed',
			__( 'Unable to generate PDF.', 'radius-booking-pro' )
		);
	}

	/**
	 * Generate HTML for invoice
	 *
	 * @param array $invoice_data Invoice data.
	 * @return string HTML content.
	 */
	public static function generate_invoice_html( $invoice_data ) {
		$invoice_data = (array) $invoice_data;
		$customer = (array) $invoice_data['customer'];
		$business = (array) $invoice_data['business'];
		$services = (array) $invoice_data['services'];
		$currency = isset( $invoice_data['currency']['currency']['symbol'] ) ? esc_html( $invoice_data['currency']['currency']['symbol'] ) : '$';
		$status_text = ucfirst( esc_html( $invoice_data['status'] ) );

		ob_start();
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="UTF-8">
			<style>
				body { font-family: Arial, sans-serif; font-size: 12px; color: #333; }
				.invoice-container { max-width: 800px; margin: 0 auto; padding: 20px; }
				.header { justify-content: space-between; margin-bottom: 30px; border-bottom: 2px solid #2563eb; padding-bottom: 20px; }
				.header h1 { color: #2563eb; margin: 0; font-size: 32px; }
				.company-info { text-align: right; }
				.bill-to { margin-bottom: 30px; }
				.invoice-details { margin-bottom: 20px; }
				table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
				th { background-color: #f3f4f6; padding: 10px; text-align: left; border-bottom: 2px solid #e5e7eb; }
				td { padding: 10px; border-bottom: 1px solid #e5e7eb; }
				.text-right { text-align: right; }
				.totals { float: right; width: 300px; }
				.totals table { margin-bottom: 0; }
				.total-row { font-weight: bold; font-size: 14px; background-color: #f3f4f6; }
				.status-badge { display: inline-block; padding: 5px 15px; border-radius: 20px; font-size: 11px; font-weight: bold; }
				.status-paid { background-color: #d1fae5; color: #065f46; }
				.status-pending { background-color: #fef3c7; color: #92400e; }
				.notes { margin-top: 30px; padding: 15px; background-color: #eff6ff; border-radius: 5px; }
				.footer { margin-top: 40px; text-align: center; color: #6b7280; font-size: 11px; border-top: 1px solid #e5e7eb; padding-top: 20px; }
				.clearfix::after {
					content: "";
					display: table;   /* or block */
					clear: both;
				}
			</style>
		</head>
		<body>
		<div class="invoice-container">
			<div class="header clearfix">
				<div style="width: 48%; float: left;">
					<h1>INVOICE</h1>
					<span class="status-badge status-<?php echo esc_attr( $invoice_data['status'] ); ?>">
							<?php echo $status_text; ?>
						</span>
					<div class="invoice-details">
						<p><strong>Invoice #:</strong> <?php echo esc_html( $invoice_data['invoiceNumber'] ); ?></p>
						<p><strong>Date:</strong> <?php echo esc_html( $invoice_data['invoiceDate'] ); ?></p>
						<p><strong>Due Date:</strong> <?php echo esc_html( $invoice_data['dueDate'] ); ?></p>
					</div>
				</div>
				<div class="company-info" style="width: 48%; float: right;">
					<h2><?php echo esc_html( $business['name'] ); ?></h2>
					<p><?php echo esc_html( $business['address'] ); ?></p>
					<p>Phone: <?php echo esc_html( $business['phone'] ); ?></p>
					<p>Email: <?php echo esc_html( $business['email'] ); ?></p>
					<?php if ( ! empty( $business['website'] ) ) : ?>
						<p>Web: <?php echo esc_html( $business['website'] ); ?></p>
					<?php endif; ?>
				</div>
			</div>

			<div class="bill-to">
				<h3>BILL TO:</h3>
				<p><strong><?php echo esc_html( $customer['name'] ); ?></strong></p>
				<?php if ( ! empty( $customer['email'] ) ) : ?>
					<p>Email: <?php echo esc_html( $customer['email'] ); ?></p>
				<?php endif; ?>
				<?php if ( ! empty( $customer['phone'] ) ) : ?>
					<p>Phone: <?php echo esc_html( $customer['phone'] ); ?></p>
				<?php endif; ?>
				<?php if ( ! empty( $customer['address'] ) ) : ?>
					<p><?php echo esc_html( $customer['address'] ); ?></p>
				<?php endif; ?>
			</div>

			<table>
				<thead>
				<tr>
					<th>Service</th>
					<th>Employee</th>
					<th>Date</th>
					<th>Duration</th>
					<th class="text-right">Persons</th>
					<th class="text-right">Price</th>
					<th class="text-right">Total</th>
				</tr>
				</thead>
				<tbody>
				<?php
				foreach ( $services as $service ) :
					$service = (array) $service;
					?>
					<tr>
						<td>
							<strong><?php echo esc_html( $service['name'] ); ?></strong>
							<?php if ( ! empty( $service['description'] ) ) : ?>
								<br><small><?php echo esc_html( $service['description'] ); ?></small>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( $service['employee'] ); ?></td>
						<td><?php echo esc_html( $service['date'] ); ?></td>
						<td><?php echo esc_html( $service['duration'] ); ?></td>
						<td class="text-right"><?php echo esc_html( $invoice_data['persons'] + 1 ); ?></td>
						<td class="text-right"><?php echo $currency . number_format( $service['price'], 2 ); ?></td>
						<td class="text-right"><?php echo $currency . number_format( $service['price'] * ($invoice_data['persons'] + 1), 2 ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<div class="totals">
				<table>
					<tr>
						<td>Subtotal:</td>
						<td class="text-right"><strong><?php echo $currency . number_format( $invoice_data['subtotal'], 2 ); ?></strong></td>
					</tr>
					<?php
					$dynamic_adjustment = isset( $invoice_data['dynamicAdjustment'] ) ? (float) $invoice_data['dynamicAdjustment'] : 0;
					$dynamic_rules      = isset( $invoice_data['dynamicRules'] ) && is_array( $invoice_data['dynamicRules'] )
						? $invoice_data['dynamicRules']
						: array();
					if ( 0.0 !== $dynamic_adjustment ) :
						$rule_names = array();
						foreach ( $dynamic_rules as $rule ) {
							$rule = (array) $rule;
							if ( ! empty( $rule['name'] ) ) {
								$rule_names[] = $rule['name'];
							}
						}
						?>
						<tr>
							<td>
								Dynamic Pricing<?php echo ! empty( $rule_names ) ? ' <small style="color:#6b7280;">(' . esc_html( implode( ', ', $rule_names ) ) . ')</small>' : ''; ?>:
							</td>
							<td class="text-right" style="color: <?php echo $dynamic_adjustment >= 0 ? '#dc2626' : '#059669'; ?>;">
								<strong><?php echo ( $dynamic_adjustment >= 0 ? '+' : '-' ) . $currency . number_format( abs( $dynamic_adjustment ), 2 ); ?></strong>
							</td>
						</tr>
					<?php endif; ?>
					<?php if ( $invoice_data['discount'] > 0 ) : ?>
						<tr>
							<td>Discount<?php echo ! empty( $invoice_data['couponCode'] ) ? ' (' . esc_html( $invoice_data['couponCode'] ) . ')' : ''; ?>:</td>
							<td class="text-right" style="color: #059669;"><strong>-<?php echo $currency . number_format( $invoice_data['discount'], 2 ); ?></strong></td>
						</tr>
					<?php endif; ?>
					<?php if ( $invoice_data['tax'] > 0 ) : ?>
						<tr>
							<td><?php echo esc_html( ! empty( $invoice_data['taxLabel'] ) ? $invoice_data['taxLabel'] : 'Tax' ); ?><?php echo ! empty( $invoice_data['taxInclusive'] ) ? ' (incl.)' : ' (excl.)'; ?>:</td>
							<td class="text-right"><strong><?php echo $currency . number_format( $invoice_data['tax'], 2 ); ?></strong></td>
						</tr>
					<?php endif; ?>
					<tr class="total-row">
						<td>Total:</td>
						<td class="text-right"><?php echo $currency . number_format( $invoice_data['total'], 2 ); ?></td>
					</tr>
					<tr style="color: #059669;">
						<td>Paid:</td>
						<td class="text-right"><strong><?php echo $currency . number_format( $invoice_data['paidAmount'], 2 ); ?></strong></td>
					</tr>
					<?php if ( $invoice_data['dueAmount'] > 0 ) : ?>
						<tr style="color: #dc2626;">
							<td>Due:</td>
							<td class="text-right"><strong><?php echo $currency . number_format( $invoice_data['dueAmount'], 2 ); ?></strong></td>
						</tr>
					<?php endif; ?>
				</table>
			</div>

			<div style="clear: both;"></div>

			<?php if ( ! empty( $invoice_data['notes'] ) ) : ?>
				<div class="notes">
					<h4>Notes:</h4>
					<p><?php echo esc_html( $invoice_data['notes'] ); ?></p>
				</div>
			<?php endif; ?>

			<div class="footer">
				<p>Thank you for choosing our services!</p>
				<p>For questions about this invoice, please contact us at <?php echo esc_html( $business['email'] ); ?></p>
			</div>
		</div>
		</body>
		</html>
		<?php
		return ob_get_clean();
	}

	/**
	 * Send email with PDF attachment
	 *
	 * @param string $recipient_email Recipient email address.
	 * @param array $invoice_data Invoice data.
	 * @param string $pdf_path Path to PDF file.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	public static function send_email_with_attachment( $recipient_email, $invoice_data, $pdf_path ) {
		$business = (array) $invoice_data['business'];
		$invoice_number = sanitize_text_field( $invoice_data['invoiceNumber'] );

		$subject = sprintf(
			/* translators: 1: invoice number, 2: business name */
			__( 'Invoice %1$s from %2$s', 'radius-booking-pro' ),
			$invoice_number,
			$business['name']
		);

		$message = self::get_email_message( $invoice_data, $business );

		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . $business['name'] . ' <' . $business['email'] . '>',
		);
		$attachments = array( $pdf_path );

		$sent = wp_mail( $recipient_email, $subject, $message, $headers, $attachments );

		if ( ! $sent ) {
			return new WP_Error(
				'email_send_failed',
				__( 'Failed to send email. Please check your email configuration.', 'radius-booking-pro' ),
				array( 'status' => 500 )
			);
		}

		return true;
	}

	/**
	 * Get email message HTML
	 *
	 * @param array $invoice_data Invoice data.
	 * @param array $business Business information.
	 * @return string HTML email message.
	 */
	public static function get_email_message( $invoice_data, $business ) {
		$customer = (array) $invoice_data['customer'];
		$currency = isset( $invoice_data['currency']['currency_symbol'] ) ? esc_html( $invoice_data['currency']['currency_symbol'] ) : '$';

		ob_start();
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="UTF-8">
			<style>
				body { font-family: DejaVu Sans, Arial, sans-serif; line-height: 1.6; color: #333; }
				.email-container { max-width: 600px; margin: 0 auto; padding: 20px; }
				.header { background-color: #2563eb; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
				.content { background-color: #f9fafb; padding: 30px; border-radius: 0 0 5px 5px; }
				.invoice-summary { background-color: white; padding: 20px; border-radius: 5px; margin: 20px 0; }
				.footer { text-align: center; color: #6b7280; font-size: 12px; margin-top: 30px; }
				.button { display: inline-block; padding: 12px 24px; background-color: #2563eb; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
			</style>
		</head>
		<body>
		<div class="email-container">
			<div class="header">
				<h1><?php echo esc_html( $business['name'] ); ?></h1>
				<p>Invoice for your recent booking</p>
			</div>
			<div class="content">
				<p>Dear <?php echo esc_html( $customer['name'] ); ?>,</p>

				<p>Thank you for choosing our services! Please find your invoice attached to this email.</p>

				<div class="invoice-summary">
					<h3>Invoice Summary</h3>
					<table style="width: 100%; border-collapse: collapse;">
						<tr>
							<td style="padding: 8px 0;"><strong>Invoice Number:</strong></td>
							<td style="text-align: right;"><?php echo esc_html( $invoice_data['invoiceNumber'] ); ?></td>
						</tr>
						<tr>
							<td style="padding: 8px 0;"><strong>Date:</strong></td>
							<td style="text-align: right;"><?php echo esc_html( $invoice_data['invoiceDate'] ); ?></td>
						</tr>
						<tr>
							<td style="padding: 8px 0;"><strong>Total Amount:</strong></td>
							<td style="text-align: right;"><strong><?php echo $currency . number_format( $invoice_data['total'], 2 ); ?></strong></td>
						</tr>
						<tr>
							<td style="padding: 8px 0;"><strong>Paid:</strong></td>
							<td style="text-align: right; color: #059669;"><?php echo $currency . number_format( $invoice_data['paidAmount'], 2 ); ?></td>
						</tr>
						<?php if ( $invoice_data['dueAmount'] > 0 ) : ?>
							<tr>
								<td style="padding: 8px 0;"><strong>Amount Due:</strong></td>
								<td style="text-align: right; color: #dc2626;"><strong><?php echo $currency . number_format( $invoice_data['dueAmount'], 2 ); ?></strong></td>
							</tr>
						<?php endif; ?>
						<tr>
							<td style="padding: 8px 0;"><strong>Status:</strong></td>
							<td style="text-align: right;"><?php echo ucfirst( esc_html( $invoice_data['status'] ) ); ?></td>
						</tr>
					</table>
				</div>

				<?php if ( $invoice_data['dueAmount'] > 0 ) : ?>
					<p><strong>Please note:</strong> You have an outstanding balance of <?php echo $currency . number_format( $invoice_data['dueAmount'], 2 ); ?>. Payment is due by <?php echo esc_html( $invoice_data['dueDate'] ); ?>.</p>
				<?php endif; ?>

				<p>If you have any questions about this invoice, please don't hesitate to contact us.</p>

				<div class="footer">
					<p>
						<?php echo esc_html( $business['name'] ); ?><br>
						<?php echo esc_html( $business['address'] ); ?><br>
						Email: <?php echo esc_html( $business['email'] ); ?> | Phone: <?php echo esc_html( $business['phone'] ); ?>
					</p>
				</div>
			</div>
		</div>
		</body>
		</html>
		<?php
		return ob_get_clean();
	}
}
