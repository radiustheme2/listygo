<?php
/**
 * Enables the Analytics pro feature and registers its DI bindings.
 */
namespace RadiusTheme\RadiusBookingPro\Hooks;

use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBookingPro\Repositories\AnalyticsRepository;
use RadiusTheme\RadiusBookingPro\Services\AnalyticsService;

class AnalyticsHook {

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		add_filter( 'rtrb_analytics_enabled', '__return_true' );
		$this->register_bindings();
	}

	/**
	 * Register DI container bindings for Analytics.
	 *
	 * @return void
	 */
	private function register_bindings() {
		Container::bind(
			AnalyticsRepository::class,
			fn() => new AnalyticsRepository()
		);
		Container::bind(
			AnalyticsService::class,
			fn() => new AnalyticsService(
				Container::resolve( AnalyticsRepository::class )
			)
		);
	}
}
