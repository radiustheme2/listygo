<?php

/**
 * This class hooks into the Radius Booking system to include Apple Calendar
 * and Outlook calendar links in confirmation emails.
 */

namespace RadiusTheme\RadiusBookingPro\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
use RadiusTheme\RadiusBooking\Helpers\SettingsHelper;
use RadiusTheme\RadiusBookingPro\Integrations\AppleCalendarIntegration;

/**
 * Handles integration with Apple Calendar and adding calendar links to emails.
 */
class AppleCalendarIntegrationHook {

	/**
	 * The calendar integration instance.
	 *
	 * @var AppleCalendarIntegration
	 */
	private $calendar_integration;

	/**
	 * Initializes the class by creating a calendar integration instance
	 * and setting up email calendar button functionality.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->calendar_integration = new AppleCalendarIntegration();

		add_action( 'rtrb_email_before_button', array( $this, 'add_apple_calendar_link_to_email' ), 10, 2 );
	}

	/**
	 * Appends an Apple Calendar link to an email based on booking details and settings.
	 *
	 * @param object $email The email object.
	 * @param array $booking The booking data.
	 *
	 * @return void
	 */
	public function add_apple_calendar_link_to_email( $email, $booking ) {
		$email_id = array( 'customer_appointment_confirmed', 'employee_appointment_confirmed', 'customer_meeting_confirmed', 'employee_meeting_confirmed' );
		if ( $email->id && ! in_array( $email->id, $email_id ) ) {
			return;
		}

		$setting           = SettingsHelper::get_setting( 'integrations' );
		$is_apple_calender = $setting['appleCalendar']['enabled'] ?? false;
		if ( ! $is_apple_calender ) {
			return;
		}

		if ( isset( $email->settings['include_calendar'] ) && ! $email->settings['include_calendar'] ) {
			return;
		}

		$event_id = $booking['id'] ?? null;
		if ( ! $event_id ) {
			return;
		}

		set_transient( 'rtrb_booking_' . $event_id, $booking, HOUR_IN_SECONDS );
		$nonce = wp_create_nonce( 'calendar_download_' . intval( $event_id ) );

		$download_url = add_query_arg(
			array(
				'calendar_download' => '1',
				'event_id'          => $event_id,
				'_wpnonce'          => $nonce,
			),
			home_url()
		);

		$outlook_url = $this->calendar_integration->get_outlook_calendar_url_from_booking( $booking );

		$service_name     = $booking['service_name'] ?? 'Appointment';
		$appointment_date = $booking['appointment_date'] ?? '';
		$start_time       = $booking['start_time'] ?? '';
		$end_time         = $booking['end_time'] ?? '';
		$location_name    = $booking['location_info']['name'] ?? '';

		$timezone_string = wp_timezone_string();

		if ( isset( $booking['customer']->utc_offset ) ) {
			$utc_offset_minutes = $booking['customer']->utc_offset;
			$utc_offset_hours   = $utc_offset_minutes / 60;

			$sign            = $utc_offset_hours >= 0 ? '+' : '-';
			$hours           = abs( floor( $utc_offset_hours ) );
			$minutes         = abs( ( $utc_offset_hours - floor( $utc_offset_hours ) ) * 60 );
			$timezone_string = sprintf( '%s%02d:%02d', $sign, $hours, $minutes );
		}

		$formatted_date = '';
		$formatted_time = '';
		$timezone_label = '';

		if ( $appointment_date && $start_time ) {
			try {
				$tz       = new \DateTimeZone( $timezone_string );
				$datetime = new \DateTime( $appointment_date . ' ' . $start_time, $tz );

				$formatted_date = $datetime->format( 'F j, Y' );
				$formatted_time = $datetime->format( 'g:i A' );

				if ( $end_time ) {
					$end_datetime    = new \DateTime( $appointment_date . ' ' . $end_time, $tz );
					$formatted_time .= ' - ' . $end_datetime->format( 'g:i A' );
				}

				if ( isset( $booking['customer']->utc_offset ) ) {
					$utc_offset_minutes = $booking['customer']->utc_offset;
					$utc_offset_hours   = $utc_offset_minutes / 60;
					$sign               = $utc_offset_hours >= 0 ? '+' : '-';
					$hours              = abs( floor( $utc_offset_hours ) );
					$mins               = abs( ( $utc_offset_hours - floor( $utc_offset_hours ) ) * 60 );
					$timezone_label     = 'UTC' . $sign . $hours . ( $mins > 0 ? ':' . sprintf( '%02d', $mins ) : '' );
				} else {
					$timezone_label = $datetime->format( 'T' );
				}
			} catch ( \Exception $e ) {
				$datetime       = strtotime( $appointment_date . ' ' . $start_time );
				$formatted_date = gmdate( 'F j, Y', $datetime );
				$formatted_time = gmdate( 'g:i A', $datetime );

				if ( $end_time ) {
					$end_datetime    = strtotime( $appointment_date . ' ' . $end_time );
					$formatted_time .= ' - ' . gmdate( 'g:i A', $end_datetime );
				}
			}
		}

		?>
		<table cellpadding="0" cellspacing="0" border="0" width="100%" style="margin: 25px 0; background: #f8f9fa; border-radius: 8px;">
			<tr>
				<td style="padding: 20px;">
					<h3 style="margin: 0 0 15px 0; color: #333; font-size: 16px; font-weight: 600;">📅 Add to Your Calendar</h3>

					<?php if ( $formatted_date && $formatted_time ) : ?>
						<table cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom: 15px;">
							<tr>
								<td style="color: #666; font-size: 14px; line-height: 1.6;">
									<strong style="color: #333;"><?php echo esc_html( $service_name ); ?></strong><br>
									📅 <?php echo esc_html( $formatted_date ); ?><br>
									🕐 <?php echo esc_html( $formatted_time ); ?>
									<?php if ( $timezone_label ) : ?>
										<span style="color: #999; font-size: 12px;">(<?php echo esc_html( $timezone_label ); ?>)</span>
									<?php endif; ?>
									<?php if ( $location_name ) : ?>
										<br>📍 <?php echo esc_html( $location_name ); ?>
									<?php endif; ?>
								</td>
							</tr>
						</table>
					<?php endif; ?>

					<table cellpadding="0" cellspacing="0" border="0">
						<tr>
							<td style="padding-right: 8px;">
								<a href="<?php echo esc_url( $download_url ); ?>" style="display: inline-block; background: #007aff; color: white; padding: 10px 16px; text-decoration: none; border-radius: 5px; font-weight: 600; font-size: 13px;">
									Add Apple Calender
								</a>
							</td>
							<td>
								<a href="<?php echo esc_url( $outlook_url ); ?>" target="_blank" style="display: inline-block; background: #0078d4; color: white; padding: 10px 16px; text-decoration: none; border-radius: 5px; font-weight: 600; font-size: 13px;">Outlook</a>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<?php
	}
}
