<?php
namespace RadiusTheme\RadiusBookingPro\Hooks;

use RadiusTheme\RadiusBookingPro\Services\AppointmentProService;
use RadiusTheme\RadiusBookingPro\Services\RecurringBookingService;

/**
 * Handles hooks related to appointments and booking processes.
 */
class AppointmentHook {

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		add_action( 'rtrb_after_process_appointment_booking', array( $this, 'after_process_appointment_booking' ), 10, 3 );
		add_action( 'rtrb_process_recurring_appointments', array( $this, 'process_recurring_appointments_job' ), 10, 2 );
		add_filter( 'rtrb_calculate_payment_amount', array( $this, 'calculate_recurring_payment' ), 10, 3 );
		add_filter( 'radius_booking_reschedule_appointment', array( $this, 'reschedule_appointment' ), 10, 4 );
		add_filter( 'rtrb_appointment_resource_data', array( $this, 'attach_dynamic_pricing_info' ), 10, 2 );
		add_filter( 'rtrb_my_booking_item_data', array( $this, 'attach_my_booking_dynamic_pricing' ), 10, 1 );
		add_filter( 'rtrb_reminder_times', array( $this, 'provide_multiple_reminder_times' ), 10, 4 );
	}

	/**
	 * Attach dynamic pricing information to the appointment resource data.
	 *
	 * Reads the snapshot stored on the customer_bookings row at booking time
	 * rather than recalculating. Recalculating against current rules would
	 * retroactively apply rules created/edited after the booking, and show
	 * dynamic pricing on appointments that never actually had it applied.
	 *
	 * @param array  $data        The appointment resource data.
	 * @param object $appointment The appointment model instance.
	 *
	 * @return array Modified appointment data with dynamic_pricing key.
	 */
	public function attach_dynamic_pricing_info( $data, $appointment ) {
		$customer = $data['customer'] ?? null;
		$snapshot = is_object( $customer ) ? ( $customer->dynamic_pricing ?? null ) : ( $customer['dynamic_pricing'] ?? null );

		if ( is_string( $snapshot ) && '' !== $snapshot ) {
			$decoded  = json_decode( $snapshot, true );
			$snapshot = is_array( $decoded ) ? $decoded : null;
		}

		$data['dynamic_pricing'] = ( is_array( $snapshot ) && ! empty( $snapshot['applied_rules'] ) ) ? $snapshot : null;

		return $data;
	}

	/**
	 * Attach dynamic pricing information to My Booking item data.
	 *
	 * Reads the snapshot stored at booking time (see attach_dynamic_pricing_info
	 * for rationale).
	 *
	 * @param object $booking The booking data object from My Booking queries.
	 *
	 * @return object Modified booking data with dynamic_pricing property.
	 */
	public function attach_my_booking_dynamic_pricing( $booking ) {
		$snapshot = $booking->dynamic_pricing ?? null;

		if ( is_string( $snapshot ) && '' !== $snapshot ) {
			$decoded  = json_decode( $snapshot, true );
			$snapshot = is_array( $decoded ) ? $decoded : null;
		}

		$booking->dynamic_pricing = ( is_array( $snapshot ) && ! empty( $snapshot['applied_rules'] ) ) ? $snapshot : null;

		return $booking;
	}

	/**
	 * Handle appointment rescheduling.
	 *
	 * @param mixed  $result   Default null from filter.
	 * @param int    $id       Appointment ID.
	 * @param string $new_date New appointment date (Y-m-d).
	 * @param string $new_time New start time (H:i:s).
	 *
	 * @return array Result with success status and message.
	 */
	public function reschedule_appointment( $result, $id, $new_date, $new_time ) {
		$service = new AppointmentProService();
		return $service->rescheduleAppointment( $id, $new_date, $new_time );
	}

	/**
	 * Create recurring appointments after the main booking is processed.
	 *
	 * @param array $data Appointment data.
	 * @param int $appointment_id The appointment ID.
	 * @param object $appointment The appointment service instance.
	 *
	 * @return void
	 */
	public function after_process_appointment_booking( $data, $appointment_id, $appointment ) {
		// Nothing to do when the booking isn't recurring.
		if ( empty( $data['cart_items'] ) || ! is_array( $data['cart_items'] ) ) {
			return;
		}

		// Each recurring child replays the ENTIRE booking pipeline (customer
		// resolution, payment record, gateway verification, and every
		// notification) via BookingService::createBookingsForAppointment. With
		// up to 51 children that is ~52x the per-booking work, all of it inline
		// on the booking POST — the main reason the request exceeded the PHP
		// max_execution_time while the parent slot was already reserved.
		//
		// Defer the whole loop to a single background job so the POST returns as
		// soon as the parent appointment is created. Fall back to inline only
		// when Action Scheduler is unavailable, to preserve behaviour.
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action(
				'rtrb_process_recurring_appointments',
				array(
					'data'      => $data,
					'parent_id' => (int) $appointment_id,
				),
				'booking-recurring'
			);
			return;
		}

		( new RecurringBookingService() )->createRecurringAppointments( $data, $appointment_id );
	}

	/**
	 * Background handler that creates the recurring child appointments.
	 *
	 * Runs off-request via Action Scheduler (see after_process_appointment_booking).
	 *
	 * @param array $data      The original appointment data (carries cart_items).
	 * @param int   $parent_id The parent appointment ID.
	 *
	 * @return void
	 */
	public function process_recurring_appointments_job( $data, $parent_id ) {
		( new RecurringBookingService() )->createRecurringAppointments( (array) $data, (int) $parent_id );
	}

	/**
	 * Provide multiple reminder times for pro users.
	 *
	 * Replaces the single free reminder time with multiple times
	 * from the `reminder_times` email setting (array of minutes).
	 *
	 * @param array  $reminder_times   Default single reminder time from free plugin.
	 * @param string $email_id         The email template ID.
	 * @param array  $settings         The email settings.
	 * @param int    $appointment_id   The appointment ID.
	 *
	 * @return array Array of minutes before appointment.
	 */
	public function provide_multiple_reminder_times( $reminder_times, $email_id, $settings, $appointment_id ) {
		if ( ! empty( $settings['reminder_times'] ) && is_array( $settings['reminder_times'] ) ) {
			return array_map( 'absint', $settings['reminder_times'] );
		}

		return $reminder_times;
	}

	/**
	 * Calculate recurring payment amount.
	 *
	 * @param float $amount The default payment amount.
	 * @param array $appointment_data The appointment data.
	 * @param float $total_amount The total order amount.
	 *
	 * @return float
	 */
	public function calculate_recurring_payment( $amount, $appointment_data, $total_amount ) {
		$service_id = $appointment_data['service_id'] ?? 0;
		if ( ! $service_id ) {
			return $amount;
		}

		$service = \RadiusTheme\RadiusBooking\Models\Service::find( $service_id );
		if ( ! $service ) {
			return $amount;
		}

		$recurring_payment = $appointment_data['recurring_payment'] ?? $service->recurring_payment();
		$cart_items        = $appointment_data['cart_items'] ?? array();
		$has_recurring     = ! empty( $cart_items );

		// CASE 1: recurring_payment = TRUE and has recurring appointments → split equally
		if ( $has_recurring && $recurring_payment ) {
			$total_appointments = 1 + count( $cart_items );
			return $total_appointments > 0 ? ( $total_amount / $total_appointments ) : $total_amount;
		}

		// CASE 2: Recurring child with recurring_payment disabled → no payment
		$is_recurring_child = ! empty( $appointment_data['parent_payment_id'] );
		if ( $is_recurring_child && ! $recurring_payment ) {
			return 0;
		}

		return $amount;
	}
}
