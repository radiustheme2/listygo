<?php

namespace RadiusTheme\RadiusBookingPro\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBooking\Repositories\AppointmentRepository;
use RadiusTheme\RadiusBooking\Repositories\ServiceRepository;
use RadiusTheme\RadiusBooking\Repositories\UserRepository;
use RadiusTheme\RadiusBooking\Services\AppointmentService;
use RadiusTheme\RadiusBookingPro\Services\ChatbotKnowledgeService;
use RadiusTheme\RadiusBookingPro\Services\ChatbotService;

/**
 * Handles chatbot-related hooks and DI bindings for the Pro plugin.
 */
class ChatbotHook {

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		$this->register_bindings();
	}

	/**
	 * Register chatbot DI container bindings.
	 *
	 * @return void
	 */
	private function register_bindings() {
		Container::bind(
			ChatbotKnowledgeService::class,
			fn() => new ChatbotKnowledgeService()
		);

		Container::bind(
			ChatbotService::class,
			fn() => new ChatbotService(
				Container::resolve( AppointmentService::class ),
				Container::resolve( ServiceRepository::class ),
				Container::resolve( UserRepository::class ),
				Container::resolve( AppointmentRepository::class )
			)
		);
	}
}
