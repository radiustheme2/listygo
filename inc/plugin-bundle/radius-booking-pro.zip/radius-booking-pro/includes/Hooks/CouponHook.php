<?php

namespace RadiusTheme\RadiusBookingPro\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBookingPro\Repositories\CouponRepository;
use RadiusTheme\RadiusBookingPro\Services\CouponService;

/**
 * Handles coupon-related hooks and DI bindings for the Pro plugin.
 */
class CouponHook {

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		$this->register_bindings();
		add_filter( 'radius_booking_apply_coupon', array( $this, 'apply_coupon' ), 10, 4 );
	}

	/**
	 * Register coupon DI container bindings.
	 *
	 * @return void
	 */
	private function register_bindings() {
		Container::bind(
			CouponRepository::class,
			fn() => new CouponRepository()
		);

		Container::bind(
			CouponService::class,
			fn() => new CouponService(
				Container::resolve( CouponRepository::class )
			)
		);
	}

	/**
	 * Apply a coupon code during appointment creation.
	 *
	 * @param mixed    $result     Default null from filter.
	 * @param string   $code       The coupon code.
	 * @param int      $service_id The service ID.
	 * @param float    $amount     The order amount.
	 *
	 * @return array|null Coupon result or null.
	 */
	public function apply_coupon( $result, $code, $service_id, $amount ) {
		$coupon_service = Container::resolve( CouponService::class );
		return $coupon_service->applyCoupon( $code, $service_id, $amount );
	}
}
