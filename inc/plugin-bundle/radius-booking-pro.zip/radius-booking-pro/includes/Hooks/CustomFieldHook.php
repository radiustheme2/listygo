<?php
/**
 * Provides custom fields data for the frontend.
 */
namespace RadiusTheme\RadiusBookingPro\Hooks;

use RadiusTheme\RadiusBookingPro\Models\CustomField;
use RadiusTheme\RadiusBookingPro\Resources\CustomFieldResource;

class CustomFieldHook {

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		add_filter( 'rtrb_custom_fields_data', array( $this, 'get_custom_fields' ) );
	}

	/**
	 * Retrieve active custom fields for frontend localization.
	 *
	 * @param array $fields Default empty array.
	 *
	 * @return array
	 */
	public function get_custom_fields( $fields ) {
		return array_values(
			CustomFieldResource::collection(
				(array) CustomField::where( 'is_active', 1 )
					->orderBy( 'sort_order', 'ASC' )
					->get()
			)
		);
	}
}
