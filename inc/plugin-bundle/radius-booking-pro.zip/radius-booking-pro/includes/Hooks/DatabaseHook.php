<?php

namespace RadiusTheme\RadiusBookingPro\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Databases\DatabaseManager;
use RadiusTheme\RadiusBookingPro\Databases\Table\AlterCustomFieldsAddAppliesTo;
use RadiusTheme\RadiusBookingPro\Databases\Table\AlterCustomFieldsJsonColumnsToText;
use RadiusTheme\RadiusBookingPro\Databases\Table\AlterPayoutsStatusV2;
use RadiusTheme\RadiusBookingPro\Databases\Table\BookingExtrasTable;
use RadiusTheme\RadiusBookingPro\Databases\Table\CouponsTable;
use RadiusTheme\RadiusBookingPro\Databases\Table\CustomFieldsTable;
use RadiusTheme\RadiusBookingPro\Databases\Table\DynamicPricingRulesTable;
use RadiusTheme\RadiusBookingPro\Databases\Table\PayoutsTable;
use RadiusTheme\RadiusBookingPro\Databases\Table\ServiceExtrasTable;
use RadiusTheme\RadiusBookingPro\Setup\Installer;

/**
 * Registers pro database migrations and triggers version-based updates.
 */
class DatabaseHook {

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		add_filter( 'rtrb_booking_migration_classes', array( $this, 'register_pro_migrations' ) );

		// Versioned migration: Installer compares stored DB version
		// against RADIUS_BOOKING_PRO_DB_VERSION and only runs when behind.
		Installer::init();

		// Backwards-compat: handle the one-time activation flag for
		// existing installs that activated before the versioned approach.
		add_action( 'admin_init', array( $this, 'maybe_run_pro_migrations' ), 4 );
	}

	/**
	 * Run pro migrations after activation (legacy flag).
	 *
	 * @return void
	 */
	public function maybe_run_pro_migrations() {
		if ( ! get_option( 'rtrb_pro_needs_migration' ) ) {
			return;
		}

		delete_option( 'rtrb_pro_needs_migration' );
		DatabaseManager::migrate();
	}

	/**
	 * Add pro migration table classes to the migration list.
	 *
	 * @param array $migrations Existing migration classes.
	 *
	 * @return array Modified migration classes.
	 */
	public function register_pro_migrations( $migrations ) {
		$migrations[] = CustomFieldsTable::class;
		$migrations[] = CouponsTable::class;
		$migrations[] = PayoutsTable::class;
		$migrations[] = DynamicPricingRulesTable::class;
		// Upgrades the `payouts.status` enum from
		// pending/approved/completed/rejected to the new
		// pending/processing/on_hold/paid/rejected vocabulary and
		// remaps existing rows. Tracked by MigrationRunner, so it
		// runs exactly once per install.
		$migrations[] = AlterPayoutsStatusV2::class;
		// Extends the `custom_fields` table with applies_to,
		// meeting_types, and events columns so custom fields can target
		// Meeting Types and Events in addition to Services. Backfills
		// existing rows with applies_to=["service"] so behavior is
		// unchanged on upgrade.
		$migrations[] = AlterCustomFieldsAddAppliesTo::class;
		// Hotfix: the original AlterCustomFieldsAddAppliesTo created
		// the three new columns as JSON, but the framework's BaseModel
		// "json" cast writes PHP serialize() output, which a strict
		// JSON column rejects ("Invalid JSON text"). This converts the
		// columns to LONGTEXT for installs that already ran the
		// original; fresh installs now get LONGTEXT directly.
		$migrations[] = AlterCustomFieldsJsonColumnsToText::class;

		// Service Extras feature: stores extras per service and
		// booking extras snapshots for historical pricing.
		// Note: Extras settings are stored in the service's `settings` JSON
		// column under the `extrasSettings` key (no separate columns needed).
		$migrations[] = ServiceExtrasTable::class;
		$migrations[] = BookingExtrasTable::class;

		return $migrations;
	}
}