<?php

namespace RadiusTheme\RadiusBookingPro\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBookingPro\Repositories\DynamicPricingRepository;
use RadiusTheme\RadiusBookingPro\Services\DynamicPricingService;

/**
 * Handles dynamic pricing DI bindings and hooks.
 */
class DynamicPricingHook {

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		$this->register_bindings();
		add_filter( 'rtrb_calculate_service_price', array( $this, 'apply_dynamic_pricing' ), 10, 4 );
	}

	/**
	 * Register dynamic pricing DI container bindings.
	 *
	 * @return void
	 */
	private function register_bindings() {
		Container::bind(
			DynamicPricingRepository::class,
			fn() => new DynamicPricingRepository()
		);

		Container::bind(
			DynamicPricingService::class,
			fn() => new DynamicPricingService(
				Container::resolve( DynamicPricingRepository::class )
			)
		);
	}

	/**
	 * Apply dynamic pricing adjustments to service price.
	 *
	 * Hooked into 'rtrb_calculate_service_price' so any code that
	 * calculates the service price can get the dynamically adjusted value.
	 *
	 * @param float  $price     The current service price.
	 * @param int    $serviceId The service ID.
	 * @param string $date      The appointment date (Y-m-d).
	 * @param string $time      The appointment start time (H:i or H:i:s).
	 *
	 * @return float The adjusted price.
	 */
	public function apply_dynamic_pricing( $price, $serviceId, $date, $time ) {
		$service = Container::resolve( DynamicPricingService::class );
		$result  = $service->calculatePrice( $price, $serviceId, $date, $time );

		return $result['final_price'];
	}
}
