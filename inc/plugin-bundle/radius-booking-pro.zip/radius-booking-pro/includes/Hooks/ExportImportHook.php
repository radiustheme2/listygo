<?php

namespace RadiusTheme\RadiusBookingPro\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Helpers\SettingsHelper;
use RadiusTheme\RadiusBookingPro\ExportImport\Exporters\CouponExporter;
use RadiusTheme\RadiusBookingPro\ExportImport\Exporters\CustomFieldExporter;
use RadiusTheme\RadiusBookingPro\ExportImport\Exporters\DynamicPricingExporter;
use RadiusTheme\RadiusBookingPro\ExportImport\Exporters\PayoutExporter;
use RadiusTheme\RadiusBookingPro\ExportImport\Importers\CouponImporter;
use RadiusTheme\RadiusBookingPro\ExportImport\Importers\CustomFieldImporter;
use RadiusTheme\RadiusBookingPro\ExportImport\Importers\DynamicPricingImporter;
use RadiusTheme\RadiusBookingPro\ExportImport\Importers\PayoutImporter;

/**
 * Registers pro export/import modules with the free plugin's export/import system.
 */
class ExportImportHook {

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		add_filter( 'rtrb_export_import_exporters', array( $this, 'register_exporters' ) );
		add_filter( 'rtrb_export_import_importers', array( $this, 'register_importers' ) );
	}

	/**
	 * Register pro exporters.
	 *
	 * @param array $exporters Existing exporters.
	 *
	 * @return array Modified exporters.
	 */
	public function register_exporters( $exporters ) {
		$exporters[] = new CouponExporter();
		$exporters[] = new CustomFieldExporter();
		$exporters[] = new DynamicPricingExporter();

		if ( $this->is_payout_active() ) {
			$exporters[] = new PayoutExporter();
		}

		return $exporters;
	}

	/**
	 * Register pro importers.
	 *
	 * @param array $importers Existing importers.
	 *
	 * @return array Modified importers.
	 */
	public function register_importers( $importers ) {
		$importers[] = new CouponImporter();
		$importers[] = new CustomFieldImporter();
		$importers[] = new DynamicPricingImporter();

		if ( $this->is_payout_active() ) {
			$importers[] = new PayoutImporter();
		}

		return $importers;
	}

	/**
	 * Check if Classified Listing plugin is active and payout is enabled.
	 *
	 * @return bool
	 */
	private function is_payout_active(): bool {
		if ( ! function_exists( 'rtcl' ) ) {
			return false;
		}

		$payout = SettingsHelper::get_setting( 'payout' );

		return ! empty( $payout['enabled'] );
	}
}