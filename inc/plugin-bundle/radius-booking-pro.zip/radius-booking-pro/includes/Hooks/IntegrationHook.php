<?php
/**
 * Registers pro-only third-party integrations (Zoom, Apple Calendar, WooCommerce).
 */
namespace RadiusTheme\RadiusBookingPro\Hooks;

use RadiusTheme\RadiusBookingPro\Integrations\WooCommerce\WooCommerceIntegration;

class IntegrationHook {

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		// Register for the free plugin's integration action (for Zoom, Apple Calendar).
		add_action( 'rtrb_register_pro_integrations', array( $this, 'register_integrations' ) );

		// WooCommerceIntegration must be instantiated unconditionally (not via the
		// action) because of a race condition: both plugins use `init` at priority 10,
		// so the free plugin may fire `rtrb_register_pro_integrations` before the pro
		// plugin registers its handler. WooCommerceIntegration guards itself with
		// `class_exists('WooCommerce')` so it's safe to instantiate it always.
		// This ensures WC cart hooks are registered on the checkout page, not just
		// during REST API requests.
		new WooCommerceIntegration();
	}

	/**
	 * Register pro integrations that depend on the free plugin's action timing.
	 *
	 * @return void
	 */
	public function register_integrations() {
		new ZoomIntegrationHook();
		new AppleCalendarIntegrationHook();
	}
}