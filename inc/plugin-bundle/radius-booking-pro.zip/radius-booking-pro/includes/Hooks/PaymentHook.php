<?php

namespace RadiusTheme\RadiusBookingPro\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Models\Payment;
use RadiusTheme\RadiusBooking\PaymentGateway\PaymentService;
use RadiusTheme\RadiusBooking\Repositories\PaymentRepository;
use RadiusTheme\RadiusBooking\Services\TransactionService;
use RadiusTheme\RadiusBookingPro\PaymentGateway\StripePaymentGateway;

/**
 * Handles Stripe payment processing for the Pro plugin.
 */
class PaymentHook {

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		add_filter( 'radius_booking_process_stripe_payment', array( $this, 'process_stripe_payment' ), 10, 6 );
		add_filter( 'rtrb_booking_custom_payment_gateway', array( $this, 'register_stripe_gateway' ), 10, 3 );
		add_filter( 'radius_booking_process_custom_gateway', array( $this, 'process_woocommerce_payment' ), 10, 7 );
	}

	/**
	 * Hold the payment as pending for WooCommerce bookings.
	 *
	 * The WooCommerce order (and actual payment) is created separately by the
	 * WooCommerce order endpoint; here we just record the booking as awaiting
	 * WooCommerce payment so it is not treated as an offline booking.
	 *
	 * @param mixed  $result           Current filter result (null if unhandled).
	 * @param string $gateway          The gateway name.
	 * @param int    $payment_id       The payment row ID.
	 * @param int    $booking_id       The booking ID.
	 * @param int    $customer_id      The customer ID.
	 * @param array  $appointment_data The appointment data.
	 * @param array  $payment_data     The payment data.
	 *
	 * @return mixed
	 */
	public function process_woocommerce_payment( $result, $gateway, $payment_id, $booking_id, $customer_id, $appointment_data, $payment_data ) {
		if ( 'woocommerce' !== $gateway ) {
			return $result;
		}

		Payment::find( $payment_id )->update(
			array(
				'status' => 'pending',
				'notes'  => 'Awaiting WooCommerce payment',
			)
		);

		return array(
			'success'    => true,
			'message'    => 'Booking held — awaiting WooCommerce payment',
			'payment_id' => $payment_id,
			'booking_id' => $booking_id,
			'status'     => 'pending',
		);
	}

	/**
	 * Register the Stripe payment gateway via filter.
	 *
	 * @param mixed  $gateway     Current gateway instance (null if not yet created).
	 * @param string $gateway_name The name of the gateway being requested.
	 * @param array  $config      Gateway configuration.
	 *
	 * @return mixed The gateway instance or null.
	 */
	public function register_stripe_gateway( $gateway, $gateway_name, $config ) {
		if ( 'stripe' === $gateway_name ) {
			return new StripePaymentGateway( $config );
		}

		return $gateway;
	}

	/**
	 * Process Stripe payment.
	 *
	 * @param mixed $result      Default null from filter.
	 * @param int   $payment_id  ID of the payment to process.
	 * @param int   $booking_id  ID of the associated booking.
	 * @param int   $customer_id ID of the customer making the payment.
	 * @param array $appointment_data Data related to the appointment.
	 * @param array $payment_data Payment data passed from the frontend.
	 *
	 * @return array Result of the payment process.
	 */
	public function process_stripe_payment( $result, $payment_id, $booking_id, $customer_id, $appointment_data, $payment_data ) {
		// Action before Stripe processing.
		do_action( 'radius_booking_before_stripe_payment', $payment_id, $booking_id, $payment_data );

		$customer_email = $appointment_data['bookings'][0]['customer_info']['email'] ?? '';

		// Check if payment was already confirmed on frontend.
		if ( ! empty( $payment_data['payment_intent_id'] ) ) {
			$verify_result = $this->verify_stripe_payment(
				$payment_id,
				$booking_id,
				$payment_data['payment_intent_id']
			);

			// Action after Stripe verification.
			do_action( 'radius_booking_after_stripe_verification', $verify_result, $payment_id, $booking_id );

			return $verify_result;
		}

		// Legacy backend payment processing.
		if ( ! empty( $payment_data['payment_method_id'] ) ) {
			$payment_amount  = $appointment_data['total'];
			$backend_result = $this->process_stripe_backend_payment(
				$payment_id,
				$booking_id,
				$customer_id,
				$customer_email,
				$payment_amount,
				$payment_data
			);

			// Action after Stripe backend processing.
			do_action( 'radius_booking_after_stripe_backend_payment', $backend_result, $payment_id, $booking_id );

			return $backend_result;
		}

		// No payment method provided.
		do_action( 'radius_booking_stripe_payment_method_missing', $payment_id, $booking_id, $payment_data );

		return array(
			'success'    => false,
			'message'    => __( 'Payment method required. Please complete payment on the frontend.', 'radius-booking-pro' ),
			'payment_id' => $payment_id,
			'booking_id' => $booking_id,
		);
	}

	/**
	 * Verify a Stripe payment.
	 *
	 * @param int    $payment_id        The ID of the payment to verify.
	 * @param int    $booking_id        The ID of the associated booking.
	 * @param string $payment_intent_id The payment intent ID provided by Stripe.
	 *
	 * @return array Result of the verification.
	 */
	private function verify_stripe_payment( $payment_id, $booking_id, $payment_intent_id ) {
		// Action before verification.
		do_action( 'radius_booking_before_stripe_verify', $payment_id, $booking_id, $payment_intent_id );

		// Verify payment through Stripe gateway.
		$gateway_result = PaymentService::verifyPayment( 'stripe', $payment_intent_id );

		if ( $gateway_result['success'] ) {
			$status = $gateway_result['status'] ?? 'paid';

			// Map 'completed' to 'paid' for consistency.
			if ( 'completed' === $status ) {
				$status = ( new PaymentRepository() )->getPaymentStatusByAmount( $payment_id );
			}

			// Filter status before update.
			$status = apply_filters( 'radius_booking_stripe_payment_status', $status, $gateway_result, $payment_id );

			// Update payment record with verified transaction.
			Payment::find( $payment_id )->update(
				array(
					'transaction_id' => $payment_intent_id,
					'status'         => $status,
				)
			);

			// Record the Stripe charge in the transaction ledger. Guarded so an
			// older free plugin (updated after pro) can't fatal here.
			if ( class_exists( TransactionService::class ) ) {
				TransactionService::record(
					$payment_id,
					array(
						'gateway'          => 'stripe',
						'transaction_id'   => $payment_intent_id,
						'status'           => 'completed',
						'gateway_response' => $gateway_result,
						'notes'            => 'Stripe payment',
					)
				);
			}

			// Action after successful verification.
			do_action( 'radius_booking_stripe_payment_verified', $payment_id, $booking_id, $payment_intent_id, $status, $gateway_result );

			return array(
				'success'        => true,
				'message'        => __( 'Payment verified successfully', 'radius-booking-pro' ),
				'payment_id'     => $payment_id,
				'booking_id'     => $booking_id,
				'transaction_id' => $payment_intent_id,
				'status'         => $status,
				'gateway_result' => $gateway_result,
			);
		}

		// Verification failed.
		Payment::find( $payment_id )->update(
			array(
				'status' => 'failed',
				'notes'  => $gateway_result['message'] ?? __( 'Payment verification failed', 'radius-booking-pro' ),
			)
		);

		// Action after failed verification.
		do_action( 'radius_booking_stripe_payment_verification_failed', $payment_id, $booking_id, $payment_intent_id, $gateway_result );

		return array(
			'success'    => false,
			'message'    => $gateway_result['message'] ?? __( 'Payment verification failed', 'radius-booking-pro' ),
			'payment_id' => $payment_id,
			'booking_id' => $booking_id,
			'error'      => $gateway_result,
		);
	}

	/**
	 * Process Stripe payment from the backend.
	 *
	 * @param int    $payment_id      The ID of the payment record.
	 * @param int    $booking_id      The ID of the booking record.
	 * @param int    $customer_id     The ID of the customer.
	 * @param string $customer_email  The email address of the customer.
	 * @param float  $payment_amount  The total payment amount.
	 * @param array  $payment_data    Additional payment-related data.
	 *
	 * @return array Contains the result of the payment processing.
	 */
	private function process_stripe_backend_payment(
		$payment_id,
		$booking_id,
		$customer_id,
		$customer_email,
		$payment_amount,
		$payment_data
	) {
		$gateway_payment_data = array(
			'booking_id'        => $booking_id,
			'customer_id'       => $customer_id,
			'customer_email'    => $customer_email,
			'amount'            => $payment_amount,
			'currency'          => $payment_data['currency'] ?? 'USD',
			'payment_method_id' => $payment_data['payment_method_id'],
			'description'       => sprintf(
				/* translators: %d: booking ID */
				__( 'Booking #%d', 'radius-booking-pro' ),
				$booking_id
			),
		);

		// Filter gateway payment data.
		$gateway_payment_data = apply_filters( 'radius_booking_stripe_gateway_payment_data', $gateway_payment_data, $payment_id, $booking_id );

		// Action before Stripe processing.
		do_action( 'radius_booking_before_stripe_process', $gateway_payment_data, $payment_id, $booking_id );

		// Process payment through Stripe.
		$gateway_result = PaymentService::processPayment( 'stripe', $gateway_payment_data );

		if ( $gateway_result['success'] ) {
			// Update payment record with successful transaction.
			Payment::find( $payment_id )->update(
				array(
					'transaction_id' => $gateway_result['transaction_id'] ?? '',
					'status'         => $gateway_result['status'] ?? 'paid',
				)
			);

			// Record the Stripe charge in the transaction ledger. Guarded so an
			// older free plugin (updated after pro) can't fatal here.
			if ( class_exists( TransactionService::class ) ) {
				TransactionService::record(
					$payment_id,
					array(
						'gateway'          => 'stripe',
						'transaction_id'   => $gateway_result['transaction_id'] ?? null,
						'status'           => 'completed',
						'gateway_response' => $gateway_result,
						'notes'            => 'Stripe payment (backend)',
					)
				);
			}

			// Action after successful Stripe payment.
			do_action( 'radius_booking_stripe_payment_success', $payment_id, $booking_id, $gateway_result );

			return array(
				'success'        => true,
				'message'        => __( 'Stripe payment processed successfully', 'radius-booking-pro' ),
				'payment_id'     => $payment_id,
				'booking_id'     => $booking_id,
				'gateway_result' => $gateway_result,
			);
		}

		// Payment failed - update status.
		Payment::find( $payment_id )->update(
			array(
				'status' => 'failed',
				'notes'  => $gateway_result['message'] ?? __( 'Payment processing failed', 'radius-booking-pro' ),
			)
		);

		// Action after failed Stripe payment.
		do_action( 'radius_booking_stripe_payment_failed', $payment_id, $booking_id, $gateway_result );

		return array(
			'success'    => false,
			'message'    => $gateway_result['message'] ?? __( 'Stripe payment processing failed', 'radius-booking-pro' ),
			'payment_id' => $payment_id,
			'booking_id' => $booking_id,
			'error'      => $gateway_result,
		);
	}
}
