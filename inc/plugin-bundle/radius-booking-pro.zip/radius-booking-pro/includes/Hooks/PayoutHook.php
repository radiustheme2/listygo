<?php

namespace RadiusTheme\RadiusBookingPro\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBooking\Repositories\EmployeeRepository;
use RadiusTheme\RadiusBookingPro\Repositories\PayoutRepository;
use RadiusTheme\RadiusBookingPro\Services\PayoutService;

/**
 * Handles payout-related hooks and DI bindings for the Pro plugin.
 */
class PayoutHook {

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		$this->register_bindings();
	}

	/**
	 * Register payout DI container bindings.
	 *
	 * @return void
	 */
	private function register_bindings() {
		Container::bind(
			PayoutRepository::class,
			fn() => new PayoutRepository()
		);

		Container::bind(
			PayoutService::class,
			fn() => new PayoutService(
				Container::resolve( PayoutRepository::class ),
				Container::resolve( EmployeeRepository::class )
			)
		);
	}
}