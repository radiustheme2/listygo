<?php
/**
 * Registers Pro capabilities and custom roles into the free permission layer.
 *
 * @package RadiusTheme\RadiusBookingPro\Hooks
 */

namespace RadiusTheme\RadiusBookingPro\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Feeds the free plugin's Capabilities registry (via its filters) with the
 * advanced Pro capabilities and any admin-created custom roles stored in the
 * `rtrb_custom_roles` option. The free PermissionsInstaller::sync() then
 * provisions those roles automatically.
 */
class PermissionsHook {

	/**
	 * Option holding admin-created custom roles: [ slug => { label, caps[] } ].
	 */
	const CUSTOM_ROLES_OPTION = 'rtrb_custom_roles';

	/**
	 * Register the filter hooks into the free permission layer.
	 *
	 * @return void
	 */
	public function init_hooks() {
		add_filter( 'rtrb_capabilities', array( $this, 'add_capabilities' ) );
		add_filter( 'rtrb_capabilities', array( $this, 'filter_cl_dependent_caps' ), 20 );
		add_filter( 'rtrb_capability_catalog_meta', array( $this, 'add_capability_meta' ) );
		add_filter( 'rtrb_role_capabilities_map', array( $this, 'add_custom_roles' ) );
		add_filter( 'rtrb_manageable_roles', array( $this, 'add_custom_role_slugs' ) );
		add_filter( 'rtrb_role_labels', array( $this, 'add_custom_role_labels' ) );
	}

	/**
	 * Advanced Pro capabilities: cap => [ label, group ].
	 *
	 * @return array<string,array{0:string,1:string}>
	 */
	public static function advanced_caps(): array {
		return array(
			'rtrb_manage_dynamic_pricing' => array( __( 'Manage Dynamic Pricing', 'radius-booking-pro' ), __( 'Finance', 'radius-booking-pro' ) ),
			'rtrb_manage_custom_fields'   => array( __( 'Manage Custom Fields', 'radius-booking-pro' ), __( 'System', 'radius-booking-pro' ) ),
			'rtrb_manage_whatsapp'        => array( __( 'Manage WhatsApp', 'radius-booking-pro' ), __( 'System', 'radius-booking-pro' ) ),
		);
	}

	/**
	 * Read the custom roles option, normalised.
	 *
	 * @return array<string,array{label:string,caps:string[]}>
	 */
	public static function custom_roles(): array {
		$roles = get_option( self::CUSTOM_ROLES_OPTION, array() );
		return is_array( $roles ) ? $roles : array();
	}

	/**
	 * Add advanced caps to Capabilities::all().
	 *
	 * @param string[] $caps Existing caps.
	 * @return string[]
	 */
	public function add_capabilities( $caps ) {
		return array_merge( (array) $caps, array_keys( self::advanced_caps() ) );
	}

	/**
	 * Filter out capabilities that depend on Classified Listing integration.
	 *
	 * The "Manage Payouts" capability is only relevant when Classified Listing
	 * plugin is active AND the integration is enabled in settings.
	 *
	 * @param string[] $caps Existing caps.
	 * @return string[]
	 */
	public function filter_cl_dependent_caps( $caps ) {
		if ( ! self::is_cl_integration_active() ) {
			$caps = array_diff( (array) $caps, array( 'rtrb_manage_payouts' ) );
		}
		return array_values( $caps );
	}

	/**
	 * Check if Classified Listing plugin is active and integration is enabled.
	 *
	 * @return bool
	 */
	public static function is_cl_integration_active(): bool {
		if ( ! function_exists( 'rtcl' ) ) {
			return false;
		}
		$settings = \RadiusTheme\RadiusBooking\Helpers\SettingsHelper::get_setting( 'integrations' );
		return ! empty( $settings['classifiedListing']['enabled'] );
	}

	/**
	 * Add label/group meta for advanced caps.
	 *
	 * @param array $meta Existing meta map.
	 * @return array
	 */
	public function add_capability_meta( $meta ) {
		foreach ( self::advanced_caps() as $cap => $info ) {
			$meta[ $cap ] = $info;
		}
		return $meta;
	}

	/**
	 * Inject custom roles into the role → cap map. Their effective caps come
	 * from the free CAPS_OPTION overlay (unified matrix); we seed each with the
	 * role's stored caps so it isn't empty before any matrix edit.
	 *
	 * @param array $map Role => caps map.
	 * @return array
	 */
	public function add_custom_roles( $map ) {
		foreach ( self::custom_roles() as $slug => $data ) {
			$map[ $slug ] = ( isset( $data['caps'] ) && is_array( $data['caps'] ) ) ? array_values( $data['caps'] ) : array();
		}
		return $map;
	}

	/**
	 * Make custom roles editable/assignable.
	 *
	 * @param string[] $roles Manageable role slugs.
	 * @return string[]
	 */
	public function add_custom_role_slugs( $roles ) {
		return array_merge( (array) $roles, array_keys( self::custom_roles() ) );
	}

	/**
	 * Provide labels for custom roles.
	 *
	 * @param array $labels Role slug => label.
	 * @return array
	 */
	public function add_custom_role_labels( $labels ) {
		foreach ( self::custom_roles() as $slug => $data ) {
			$labels[ $slug ] = $data['label'] ?? $slug;
		}
		return $labels;
	}
}
