<?php
/**
 * Registers pro-only API routes.
 */
namespace RadiusTheme\RadiusBookingPro\Hooks;

use RadiusTheme\RadiusBooking\Controllers\AppointmentController;
use RadiusTheme\RadiusBooking\Controllers\CustomerPanelController;
use RadiusTheme\RadiusBooking\Controllers\EmployeePanelController;
use RadiusTheme\RadiusBookingPro\Controllers\AnalyticsController;
use RadiusTheme\RadiusBookingPro\Controllers\CouponController;
use RadiusTheme\RadiusBookingPro\Controllers\CustomFieldController;
use RadiusTheme\RadiusBookingPro\Controllers\LocationController;

class RouteHook {

	/**
	 * Initialize route hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		add_filter( 'radius_booking_api_route_paths', array($this,'radius_booking_pro_register_route_paths') );
	}


	public function radius_booking_pro_register_route_paths( $paths ) {
		$paths[] = RADIUS_BOOKING_PRO_INCLUDES . '/Routes/pro-routes.php';
		return $paths;
	}
}
