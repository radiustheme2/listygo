<?php
/**
 * ServiceExtraHook
 *
 * Handles service extras hooks, DI bindings, and integration with booking flow.
 *
 * @package RadiusTheme\RadiusBookingPro\Hooks
 */

namespace RadiusTheme\RadiusBookingPro\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBooking\Models\Service;
use RadiusTheme\RadiusBookingPro\Repositories\ServiceExtraRepository;
use RadiusTheme\RadiusBookingPro\Repositories\BookingExtraRepository;
use RadiusTheme\RadiusBookingPro\Resources\BookingExtraResource;
use RadiusTheme\RadiusBookingPro\Services\ServiceExtraService;

/**
 * Handles service extras related hooks and DI bindings for the Pro plugin.
 */
class ServiceExtraHook {

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		$this->register_bindings();

		// NOTE: Extras settings are now stored in the service's `settings` JSON column
		// under the `extrasSettings` key. The free plugin handles saving this automatically
		// when the service is updated, so no separate save hooks are needed.

		// Booking data preparation - attach extras to booking.
		add_filter( 'radius_booking_prepare_booking_data', array( $this, 'attach_extras_to_booking' ), 10, 5 );

		// After booking created - create extras snapshot.
		add_action( 'radius_booking_created', array( $this, 'create_booking_extras_snapshot' ), 10, 4 );

		// Appointment resource - attach booking extras data.
		add_filter( 'rtrb_appointment_resource_data', array( $this, 'attach_booking_extras_to_appointment' ), 10, 2 );

		// My booking item data - attach extras.
		add_filter( 'rtrb_my_booking_item_data', array( $this, 'attach_my_booking_extras' ), 10, 1 );

		// Service resource - attach extras data.
		add_filter( 'rtrb_service_resource_data', array( $this, 'attach_service_extras' ), 10, 2 );
	}

	/**
	 * Register service extras DI container bindings.
	 *
	 * @return void
	 */
	private function register_bindings() {
		Container::bind(
			ServiceExtraRepository::class,
			fn() => new ServiceExtraRepository()
		);

		Container::bind(
			BookingExtraRepository::class,
			fn() => new BookingExtraRepository()
		);

		Container::bind(
			ServiceExtraService::class,
			fn() => new ServiceExtraService(
				Container::resolve( ServiceExtraRepository::class ),
				Container::resolve( BookingExtraRepository::class )
			)
		);
	}

	/**
	 * Get extras settings from service model.
	 *
	 * Reads extras settings from the service's `settings` JSON column
	 * under the `extrasSettings` key.
	 *
	 * @param object $service The service model.
	 *
	 * @return array Extras settings array with defaults.
	 */
	private function get_extras_settings( $service ) {
		$settings       = $service->settings ?? array();
		$extrasSettings = $settings['extrasSettings'] ?? array();

		return array(
			'enabled'                   => ! empty( $extrasSettings['enabled'] ),
			'selectionType'             => $extrasSettings['selectionType'] ?? 'single',
			'minSelected'               => (int) ( $extrasSettings['minSelected'] ?? 0 ),
			'maxSelected'               => (int) ( $extrasSettings['maxSelected'] ?? 3 ),
			'adjustWithDynamicPricing'  => ! empty( $extrasSettings['adjustWithDynamicPricing'] ),
		);
	}

	/**
	 * Attach extras data to booking data before saving.
	 *
	 * Validates selected extras server-side and calculates price/duration.
	 *
	 * @param array $bookingData        The prepared booking data.
	 * @param array $booking            The original booking array.
	 * @param array $appointmentData    The appointment data.
	 * @param int   $appointmentId      The appointment ID.
	 * @param int   $customerId         The customer ID.
	 *
	 * @return array Modified booking data with extras information.
	 */
	public function attach_extras_to_booking( $bookingData, $booking, $appointmentData, $appointmentId, $customerId ) {
		$serviceId      = $appointmentData['service_id'] ?? 0;
		$selectedExtras = $appointmentData['selected_extras'] ?? array();

		if ( ! $serviceId || empty( $selectedExtras ) ) {
			return $bookingData;
		}

		$service = Service::find( $serviceId );
		if ( ! $service ) {
			return $bookingData;
		}

		// Get service extras settings from settings.extrasSettings.
		$extrasSettings = $this->get_extras_settings( $service );

		// If extras not enabled, skip processing.
		if ( empty( $extrasSettings['enabled'] ) ) {
			return $bookingData;
		}

		// Map to the format expected by validateSelection.
		$serviceSettings = array(
			'extras_enabled'        => $extrasSettings['enabled'],
			'extras_selection_type' => $extrasSettings['selectionType'],
			'mandatory_extra'       => $extrasSettings['minSelected'] > 0,
			'min_selected_extras'   => $extrasSettings['minSelected'],
			'max_selected_extras'   => $extrasSettings['maxSelected'],
		);

		$extraService = Container::resolve( ServiceExtraService::class );

		// Validate selection.
		$validation = $extraService->validateSelection( $serviceId, $selectedExtras, $serviceSettings );

		if ( ! $validation['valid'] ) {
			// Log validation failure but don't block booking.
			// The booking will proceed without extras.
			return $bookingData;
		}

		// Calculate extras price and duration server-side for validation/snapshot.
		$extrasPrice    = $extraService->calculateExtrasPrice( $selectedExtras );
		$extrasDuration = $extraService->calculateExtrasDuration( $selectedExtras );

		// NOTE: Do NOT add extras to booking price here.
		// The frontend already includes extras in grand_total when submitting the booking.
		// Adding extras here would result in double-addition (price already contains extras).
		// The server-side calculation is used for validation and snapshot purposes only.

		// Store extras data in booking for later snapshot creation.
		$bookingData['selected_extras']       = $selectedExtras;
		$bookingData['extras_total_price']    = $extrasPrice;
		$bookingData['extras_total_duration'] = $extrasDuration;

		return $bookingData;
	}

	/**
	 * Create booking extras snapshot after booking is created.
	 *
	 * @param object $customerBooking The created customer booking.
	 * @param array  $bookingData     The booking data.
	 * @param int    $appointmentId   The appointment ID.
	 * @param int    $customerId      The customer ID.
	 *
	 * @return void
	 */
	public function create_booking_extras_snapshot( $customerBooking, $bookingData, $appointmentId, $customerId ) {
		$selectedExtras = $bookingData['selected_extras'] ?? array();

		if ( empty( $selectedExtras ) ) {
			return;
		}

		$bookingId = $customerBooking->get_id();

		$extraService = Container::resolve( ServiceExtraService::class );
		$extraService->createBookingExtrasSnapshot( $bookingId, $selectedExtras );
	}

	/**
	 * Attach booking extras to appointment resource data.
	 *
	 * Reads the snapshot stored at booking time.
	 *
	 * @param array  $data        The appointment resource data.
	 * @param object $appointment The appointment model instance.
	 *
	 * @return array Modified appointment data with extras key.
	 */
	public function attach_booking_extras_to_appointment( $data, $appointment ) {
		$customer  = $data['customer'] ?? null;
		$bookingId = is_object( $customer ) ? ( $customer->id ?? 0 ) : ( $customer['id'] ?? 0 );

		if ( ! $bookingId ) {
			$data['extras'] = array();
			return $data;
		}

		$bookingExtraRepo = Container::resolve( BookingExtraRepository::class );
		$extras           = $bookingExtraRepo->getByBooking( (int) $bookingId );

		$data['extras'] = BookingExtraResource::collection( $extras );

		// Calculate totals.
		$data['extras_total_price']    = $bookingExtraRepo->getTotalPriceByBooking( (int) $bookingId );
		$data['extras_total_duration'] = $bookingExtraRepo->getTotalDurationByBooking( (int) $bookingId );

		return $data;
	}

	/**
	 * Attach extras to My Booking item data.
	 *
	 * @param object $booking The booking data object from My Booking queries.
	 *
	 * @return object Modified booking data with extras property.
	 */
	public function attach_my_booking_extras( $booking ) {
		$bookingId = $booking->id ?? 0;

		if ( ! $bookingId ) {
			$booking->extras                = array();
			$booking->extras_total_price    = 0;
			$booking->extras_total_duration = 0;
			return $booking;
		}

		$bookingExtraRepo = Container::resolve( BookingExtraRepository::class );
		$extras           = $bookingExtraRepo->getByBooking( (int) $bookingId );

		$booking->extras                = BookingExtraResource::collection( $extras );
		$booking->extras_total_price    = $bookingExtraRepo->getTotalPriceByBooking( (int) $bookingId );
		$booking->extras_total_duration = $bookingExtraRepo->getTotalDurationByBooking( (int) $bookingId );

		return $booking;
	}

	/**
	 * Attach service extras data to service resource.
	 *
	 * @param array  $data    The service resource data.
	 * @param object $service The service model instance.
	 *
	 * @return array Modified service data with extras configuration.
	 */
	public function attach_service_extras( $data, $service ) {
		$serviceId = $service->id ?? 0;

		// Get extras settings from settings.extrasSettings.
		$extrasSettings = $this->get_extras_settings( $service );

		// Add extras settings to resource data (flat keys for API compatibility).
		$data['extras_enabled']                       = $extrasSettings['enabled'];
		$data['extras_selection_type']                = $extrasSettings['selectionType'];
		$data['min_selected_extras']                  = $extrasSettings['minSelected'];
		$data['max_selected_extras']                  = $extrasSettings['maxSelected'];
		$data['adjust_extras_with_dynamic_pricing']   = $extrasSettings['adjustWithDynamicPricing'];

		// Add extras list if enabled.
		if ( $serviceId && $extrasSettings['enabled'] ) {
			$extraRepo      = Container::resolve( ServiceExtraRepository::class );
			$extras         = $extraRepo->getActiveByService( (int) $serviceId );
			$data['extras'] = \RadiusTheme\RadiusBookingPro\Resources\ServiceExtraResource::collection( $extras );
		} else {
			$data['extras'] = array();
		}

		return $data;
	}
}
