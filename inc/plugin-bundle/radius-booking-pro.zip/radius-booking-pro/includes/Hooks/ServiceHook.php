<?php
/**
 * Handles pro per-service setting overrides.
 */
namespace RadiusTheme\RadiusBookingPro\Hooks;

use RadiusTheme\RadiusBooking\Models\Service;

class ServiceHook {

	/**
	 * Initialize service override hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		add_filter( 'rtrb_service_appointment_status', array( $this, 'override_appointment_status' ), 10, 2 );
		add_filter( 'rtrb_service_min_booking_time', array( $this, 'override_min_booking_time' ), 10, 2 );
		add_filter( 'rtrb_service_min_cancel_time', array( $this, 'override_min_cancel_time' ), 10, 2 );
		add_filter( 'rtrb_service_min_reschedule_time', array( $this, 'override_min_reschedule_time' ), 10, 2 );
		add_filter( 'rtrb_service_booking_advance_period', array( $this, 'override_booking_advance_period' ), 10, 2 );
	}

	/**
	 * Override appointment status with per-service value.
	 *
	 * @param string  $default The global default status.
	 * @param Service $service The service model instance.
	 *
	 * @return string
	 */
	public function override_appointment_status( $default, $service ) {
		$general       = $service->get_general_setting();
		$service_value = $general['defaultStatus'] ?? '';

		if ( ! empty( $service_value ) && 'global' !== $service_value ) {
			return $service_value;
		}

		return $default;
	}

	/**
	 * Override min booking time with per-service value.
	 *
	 * @param mixed   $default The global default value.
	 * @param Service $service The service model instance.
	 *
	 * @return mixed
	 */
	public function override_min_booking_time( $default, $service ) {
		$general       = $service->get_general_setting();
		$service_value = $general['minBookingTime'] ?? 'disabled';

		if ( 'disabled' !== $service_value && ! empty( $service_value ) ) {
			return $service_value;
		}

		return $default;
	}

	/**
	 * Override min cancel time with per-service value.
	 *
	 * @param mixed   $default The global default value.
	 * @param Service $service The service model instance.
	 *
	 * @return mixed
	 */
	public function override_min_cancel_time( $default, $service ) {
		$general       = $service->get_general_setting();
		$service_value = $general['minCancelTime'] ?? 'disabled';

		if ( 'disabled' !== $service_value && ! empty( $service_value ) ) {
			return $service_value;
		}

		return $default;
	}

	/**
	 * Override min reschedule time with per-service value.
	 *
	 * @param mixed   $default The global default value.
	 * @param Service $service The service model instance.
	 *
	 * @return mixed
	 */
	public function override_min_reschedule_time( $default, $service ) {
		$general       = $service->get_general_setting();
		$service_value = $general['minRescheduleTime'] ?? 'disabled';

		if ( 'disabled' !== $service_value && ! empty( $service_value ) ) {
			return $service_value;
		}

		return $default;
	}

	/**
	 * Override booking advance period with per-service value.
	 *
	 * @param int     $default The global default value in days.
	 * @param Service $service The service model instance.
	 *
	 * @return int
	 */
	public function override_booking_advance_period( $default, $service ) {
		$general       = $service->get_general_setting();
		$service_value = $general['bookingAdvancePeriod'] ?? null;

		if ( null !== $service_value && '' !== $service_value ) {
			return (int) $service_value;
		}

		return $default;
	}
}
