<?php
/**
 * Class responsible for handling settings-related hooks for Radius Booking Pro plugin.
 */
namespace RadiusTheme\RadiusBookingPro\Hooks;

/**
 * Class SettingsHook
 *
 * Handles the initialization of hooks for integrating payment methods and third-party service integrations.
 */
class SettingsHook {

	/**
	 * Initializes WordPress hooks for payment methods and integrations.
	 *
	 * @return void
	 */
	public function init_hooks(  ) {
		add_filter('rtrb_payment_methods', array( $this, 'add_payment_method' ));
		add_filter('rtrb_integrations', array( $this, 'add_integrations' ));
		add_action('rtrb_settings', array( $this, 'add_customer_schedule' ));
		add_action('rtrb_settings', array( $this, 'add_tax' ));
		add_action('rtrb_settings', array( $this, 'add_chatbot_settings' ));
		add_action('rtrb_settings', array( $this, 'add_knowledge_base' ));
		add_action('rtrb_settings', array( $this, 'add_payout_settings' ));
	}

	/**
	 * Adds new payment methods to the existing list of payment methods.
	 *
	 * @param array $payment_methods An array of existing payment methods.
	 *
	 * @return array The updated array of payment methods, including the new payment methods.
	 */
	public function add_payment_method( $payment_methods ) {
		$new_payment_methods = [
			'stripe'  => array(
				'enabled'            => false,
				'testMode'           => true,
				'livePublishableKey' => '',
				'liveSecretKey'      => '',
				'testPublishableKey' => '',
				'testSecretKey'      => '',
			),
		];
		return  array_merge( $payment_methods, $new_payment_methods );
	}

	/**
	 * Adds new integrations to the existing list of integrations.
	 *
	 * @param array $integrations An array of existing integrations.
	 *
	 * @return array The updated array of integrations, including the new integrations.
	 */
	public function add_integrations( $integrations ) {
		$add_integrations = [
			'zoom'            => array(
				'enabled'           => false,
				'accountId'         => '',
				'clientId'          => '',
				'clientSecret'      => '',
				'autoCreateMeeting' => true,
				'requirePassword'   => true,
				'enableWaitingRoom' => true,
				'sendInviteEmail'   => true,
				'defaultDuration'   => 60,
			),
			'appleCalendar'   => array(
				'enabled'            => false,
				'showDownloadLink'   => true,
				'enableCalendarFeed' => false,
				'includeLocation'    => true,
				'includeDescription' => true,
				'addReminders'       => true,
				'reminderMinutes'    => 60,
				'calendarName'       => __( 'My Business Appointments', 'radius-booking-pro' ),
				'organizerEmail'     => '',
			),
			'woocommerce'     => array(
				'enabled'           => false,
				// When the WC order reaches this status the appointment is confirmed.
				// 'processing' = confirm on payment (processing OR completed); 'completed' = only when completed.
				'confirmOn'         => 'processing',
				'cancelOnRefund'    => true,   // Cancel the appointment when the WC order is refunded.
				'cancelOnCancel'    => true,   // Cancel when the WC order is cancelled/failed.
				'newOrderStatus'    => 'pending', // Status new booking orders start in ('pending' | 'on-hold').
				'holdUnpaidMinutes' => 30,     // Release the held slot after N minutes unpaid (0 = never).
				'redirectTo'        => 'checkout', // Where to send the customer ('checkout' | 'cart').
				'createCustomer'    => true,   // Create/link a WooCommerce customer for the booker.
			),
		];
		return array_merge( $integrations, $add_integrations );
	}

	public function add_customer_schedule( $settings ) {
		$settings['customer'] = array(
			'allowReschedule' => false,
			'allowCancel'     => false,
		);
		return $settings;

	}

    public function add_tax( $settings )
    {
        $settings['tax'] =  array(
            'enabled'   => false,
            'rate'      => 0,
            'inclusive' => false,
            'label'     => __( 'Tax', 'radius-booking-pro' ),
        );
        return $settings;

    }

	public function add_chatbot_settings( $settings ) {
		$settings['chatbot'] = array(
			'enabled'        => false,
			'showFormToggle' => false,
			'provider'       => 'openai',
			'apiKey'         => '',
			'geminiApiKey'   => '',
			'model'          => 'gpt-4o-mini',
			'geminiModel'    => 'gemini-3-flash-preview',
			'maxTokens'      => 1024,
			'temperature'    => 0.7,
			'displayMode'    => 'all_pages',
			'specificPages'  => array(),
			'welcomeMessage' => __( "Hi! I'm your booking assistant. How can I help you today?", 'radius-booking-pro' ),
			'botName'        => __( 'Booking Assistant', 'radius-booking-pro' ),
			'primaryColor'   => '#0040ff',
			'position'       => 'bottom-right',
			'responseStyle'  => 'text',
			'bubbleIcon'     => 'chat',
			'bubbleImage'    => '',
			'poweredBy'      => __( 'Powered by Radius Booking', 'radius-booking-pro' ),
		);
		return $settings;
	}

	/**
	 * Add payout settings defaults.
	 *
	 * @param array $settings Existing settings.
	 *
	 * @return array Modified settings.
	 */
	public function add_payout_settings( $settings ) {
		$settings['payout'] = array(
			'enabled'             => false,
			'commissionType'      => 'percentage',
			'commissionRate'      => 0,
			'minimumPayoutAmount' => 50,
			'payoutMethods'       => array(
				'cash'          => array(
					'enabled'     => true,
					'label'       => __( 'Cash', 'radius-booking-pro' ),
					'description' => __( 'Receive payout in cash at the office.', 'radius-booking-pro' ),
					'fields'      => array(),
				),
				'bank_transfer' => array(
					'enabled'     => true,
					'label'       => __( 'Bank Transfer', 'radius-booking-pro' ),
					'description' => __( 'Direct bank transfer to your account.', 'radius-booking-pro' ),
					'fields'      => array(
						array( 'key' => 'bank_name', 'label' => __( 'Bank Name', 'radius-booking-pro' ), 'type' => 'text' ),
						array( 'key' => 'account_name', 'label' => __( 'Account Holder Name', 'radius-booking-pro' ), 'type' => 'text' ),
						array( 'key' => 'account_number', 'label' => __( 'Account Number', 'radius-booking-pro' ), 'type' => 'text' ),
						array( 'key' => 'routing_number', 'label' => __( 'Routing / SWIFT', 'radius-booking-pro' ), 'type' => 'text' ),
					),
				),
			),
		);
		return $settings;
	}

	public function add_knowledge_base( $settings ) {
		$settings['chatbotKnowledge'] = array(
			array(
				'id'       => 'default-cancellation',
				'question' => __( 'What is your cancellation policy?', 'radius-booking-pro' ),
				'answer'   => __( 'You can cancel your appointment up to 24 hours before the scheduled time. Please contact us or use the My Bookings page to cancel.', 'radius-booking-pro' ),
				'category' => 'policy',
			),
			array(
				'id'       => 'default-reschedule',
				'question' => __( 'Can I reschedule my appointment?', 'radius-booking-pro' ),
				'answer'   => __( 'Yes, you can reschedule your appointment up to 12 hours before the scheduled time through the My Bookings page.', 'radius-booking-pro' ),
				'category' => 'policy',
			),
			array(
				'id'       => 'default-payment',
				'question' => __( 'What payment methods do you accept?', 'radius-booking-pro' ),
				'answer'   => __( 'We accept various payment methods including online payments and pay-at-venue options. Check the booking form for available methods.', 'radius-booking-pro' ),
				'category' => 'payment',
			),
		);
		return $settings;

	}


}