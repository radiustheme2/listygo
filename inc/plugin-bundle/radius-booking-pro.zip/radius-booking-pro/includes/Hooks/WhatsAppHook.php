<?php
/**
 * WhatsApp Hook
 *
 * Boots the WhatsApp notification manager so each notification wires itself
 * to its trigger action. Runs on `init` so it is active for both normal page
 * loads and REST requests (which is when bookings are created).
 *
 * @package RadiusTheme\RadiusBookingPro\Hooks
 */

namespace RadiusTheme\RadiusBookingPro\Hooks;

use RadiusTheme\RadiusBookingPro\WhatsApp\WhatsAppManager;
use RadiusTheme\RadiusBookingPro\WhatsApp\WhatsAppReminderService;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class WhatsAppHook
 */
class WhatsAppHook {

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init_hooks() {
		add_action( 'init', array( $this, 'boot_manager' ), 20 );
	}

	/**
	 * Instantiate and initialize the WhatsApp manager + reminder scheduler.
	 *
	 * @return void
	 */
	public function boot_manager() {
		( new WhatsAppManager() )->init();
		( new WhatsAppReminderService() )->register_hooks();
	}
}
