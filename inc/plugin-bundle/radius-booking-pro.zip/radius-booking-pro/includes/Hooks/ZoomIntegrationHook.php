<?php
/**
 * Handles the integration of Zoom meetings with the Radius Booking system.
 */
namespace RadiusTheme\RadiusBookingPro\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
use DateTime;
use DateTimeZone;
use Exception;
use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBooking\Helpers\SettingsHelper;
use RadiusTheme\RadiusBookingPro\Integrations\ZoomIntegration;
use RadiusTheme\RadiusBooking\Models\MeetingType;
use RadiusTheme\RadiusBooking\Models\Service;
use RadiusTheme\RadiusBooking\Models\User;
use RadiusTheme\RadiusBooking\Services\AppointmentIntegrationService;

/**
 * Class ZoomIntegrationHook
 *
 * Handles Zoom integration for automated meeting creation during booking events.
 */
class ZoomIntegrationHook {

	/**
	 * Initializes the class and sets up the necessary hook to integrate Zoom functionality
	 * after creating bookings.
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'radius_booking_after_create_bookings', array( $this, 'integrate_zoom' ), 10, 3 );
		add_action( 'radius_booking_after_create_meeting_bookings', array( $this, 'integrate_zoom_for_meeting' ), 10, 4 );
	}

	/**
	 * Integrates Zoom meeting creation for an appointment and stores the meeting details
	 * if Zoom integration is enabled and all required data is valid.
	 *
	 * @param array $bookings An array containing booking details, including customer information.
	 * @param array $data An array containing appointment data such as service ID, employee ID, appointment date, and start time.
	 * @param int $appointment_id The ID of the appointment for which the Zoom meeting is being created.
	 *
	 * @return void
	 */
	public function integrate_zoom( $bookings, $data, $appointment_id ) {

		$settings = SettingsHelper::get_setting( 'integrations' );

		$is_zoom_enabled = $settings['zoom']['enabled'] ?? false;
		if ( ! $is_zoom_enabled ) {
			return;
		}

		if ( empty( $data['service_id'] ) || empty( $data['employee_id'] ) || empty( $bookings[0]['customer_info']['email'] ) ) {
			return;
		}
		$service_id  = $data['service_id'];
		$employee_id = $data['employee_id'];

		$service = Service::find( $service_id );
		if ( ! $service ) {
			return;
		}

		$service_settings = $service->integrations();
		$is_zoom_active   = ! empty( $service_settings['zoom'] );
		if ( ! $is_zoom_active ) {
			return;
		}

		$employee = User::find( $employee_id );
		if ( ! $employee ) {
			return;
		}

		$employee_email = $employee->get_email() ?? '';
		$customer       = $bookings[0]['customer_info'] ?? array();
		$customer_email = $customer['email'] ?? '';

		if ( empty( $employee_email ) || empty( $customer_email ) ) {
			return;
		}

		$profile            = $employee->profile()->get();
		$employee_full_name = trim( ( $profile->first_name ?? '' ) . ' ' . ( $profile->last_name ?? '' ) );
		$customer_full_name = trim( ( $customer['first_name'] ?? '' ) . ' ' . ( $customer['last_name'] ?? '' ) );
		$duration           = $service->get_duration() / 60;

		try {
			$local_datetime = "{$data['appointment_date']} {$data['start_time']}";
			$tz             = new DateTimeZone( wp_timezone_string() );
			$dt             = new DateTime( $local_datetime, $tz );
			$dt->setTimezone( new DateTimeZone( 'UTC' ) );
			$start_time_utc = $dt->format( 'Y-m-d\TH:i:s\Z' );
		} catch ( Exception $e ) {
			error_log( 'Zoom integration time parse failed: ' . $e->getMessage() ); //phpcs:ignore
			return;
		}

		$title = sprintf( '%s Appointment #%d', $service->get_name(), $appointment_id );

		$description = sprintf(
			"Appointment Details:\nService: %s\nEmployee: %s\nCustomer: %s\nDate: %s\nDuration: %s minutes\n\nBooked via Radius Booking.",
			$service->get_name(),
			$employee_full_name,
			$customer_full_name,
			wp_date( 'F j, Y g:i A', strtotime( $local_datetime ) ),
			$duration
		);

		$invitees = array_unique( array_filter( array( $customer_email, $employee_email ) ) );

		$site_timezone  = wp_timezone_string();
		$staff_timezone = $profile->time_zone ?? '';

		$appointment_context = array(
			'appointment_id'   => $appointment_id,
			'service_name'     => $service->get_name(),
			'employee_name'    => $employee_full_name,
			'customer_name'    => $customer_full_name,
			'customer_email'   => $customer_email,
			'employee_email'   => $employee_email,
			'appointment_date' => $data['appointment_date'] ?? '',
			'start_time'       => $data['start_time'] ?? '',
			'duration'         => (int) $duration,
			'location'         => $data['location_name'] ?? '',
			'site_timezone'    => $site_timezone,
			'staff_timezone'   => $staff_timezone,
		);

		$zoom = new ZoomIntegration();
		try {
			$meeting = $zoom->create_meeting(
				'me',
				$title,
				$start_time_utc,
				$settings['zoom'],
				(int) $duration,
				$invitees,
				$description,
				$appointment_context
			);
			if ( $meeting && ! isset( $meeting['error'] ) ) {
				$integrateService = Container::resolve( AppointmentIntegrationService::class );
				$payload          = array(
					'provider'             => 'zoom',
					'external_event_id'    => $meeting['id'] ?? null,
					'external_calendar_id' => 'zoom',
					'meeting_url'          => $meeting['join_url'] ?? null,
					'join_url'             => $meeting['join_url'] ?? null,
					'start_url'            => $meeting['start_url'] ?? null,
					'meta'                 => maybe_serialize( $meeting ?? array() ),
					'status'               => 'created',
				);

				$integrateService->storeOrUpdate( $appointment_id, 'zoom', $payload );
			} else {
				error_log( 'Zoom meeting creation failed: ' . print_r( $meeting, true ) ); //phpcs:ignore
			}
		} catch ( Exception $e ) {
			error_log( 'Zoom meeting creation exception: ' . $e->getMessage() );
		}
	}

	/**
	 * Integrate Zoom meeting creation for meeting bookings.
	 *
	 * @param array  $bookings       Bookings array with customer info.
	 * @param array  $booking_data   Booking data with dates/times.
	 * @param int    $appointment_id Appointment ID.
	 * @param object $meeting_type   MeetingType model.
	 *
	 * @return void
	 */
	public function integrate_zoom_for_meeting( $bookings, $booking_data, $appointment_id, $meeting_type ) {
		// Check global Zoom enabled.
		$settings        = SettingsHelper::get_setting( 'integrations' );
		$is_zoom_enabled = $settings['zoom']['enabled'] ?? false;
		if ( ! $is_zoom_enabled ) {
			return;
		}

		// Check meeting type Zoom enabled.
		$mt_settings    = $this->getMeetingTypeIntegrations( $meeting_type );
		$is_zoom_active = ! empty( $mt_settings['zoom'] );
		if ( ! $is_zoom_active ) {
			return;
		}

		$employee_id = $meeting_type->employee_id;
		if ( empty( $employee_id ) || empty( $bookings[0]['customer_info']['email'] ) ) {
			return;
		}

		$employee = User::find( $employee_id );
		if ( ! $employee ) {
			return;
		}

		$employee_email = $employee->get_email() ?? '';
		$customer       = $bookings[0]['customer_info'] ?? array();
		$customer_email = $customer['email'] ?? '';

		if ( empty( $employee_email ) || empty( $customer_email ) ) {
			return;
		}

		$profile            = $employee->profile()->get();
		$employee_full_name = trim( ( $profile->first_name ?? '' ) . ' ' . ( $profile->last_name ?? '' ) );
		$customer_full_name = trim( ( $customer['first_name'] ?? '' ) . ' ' . ( $customer['last_name'] ?? '' ) );
		$duration           = (int) $meeting_type->duration;

		try {
			$local_datetime = "{$booking_data['appointment_date']} {$booking_data['start_time']}";
			$tz             = new DateTimeZone( wp_timezone_string() );
			$dt             = new DateTime( $local_datetime, $tz );
			$dt->setTimezone( new DateTimeZone( 'UTC' ) );
			$start_time_utc = $dt->format( 'Y-m-d\TH:i:s\Z' );
		} catch ( Exception $e ) {
			error_log( 'Zoom meeting integration time parse failed: ' . $e->getMessage() ); //phpcs:ignore
			return;
		}

		$title       = sprintf( '%s Meeting #%d', $meeting_type->get_name(), $appointment_id );
		$description = sprintf(
			"Meeting Details:\nMeeting Type: %s\nHost: %s\nGuest: %s\nDate: %s\nDuration: %s minutes\n\nBooked via Radius Booking.",
			$meeting_type->get_name(),
			$employee_full_name,
			$customer_full_name,
			wp_date( 'F j, Y g:i A', strtotime( $local_datetime ) ),
			$duration
		);

		$invitees       = array_unique( array_filter( array( $customer_email, $employee_email ) ) );
		$site_timezone  = wp_timezone_string();
		$staff_timezone = $profile->time_zone ?? '';

		$appointment_context = array(
			'appointment_id'   => $appointment_id,
			'service_name'     => $meeting_type->get_name(),
			'employee_name'    => $employee_full_name,
			'customer_name'    => $customer_full_name,
			'customer_email'   => $customer_email,
			'employee_email'   => $employee_email,
			'appointment_date' => $booking_data['appointment_date'] ?? '',
			'start_time'       => $booking_data['start_time'] ?? '',
			'duration'         => $duration,
			'location'         => '',
			'site_timezone'    => $site_timezone,
			'staff_timezone'   => $staff_timezone,
		);

		$zoom = new ZoomIntegration();
		try {
			$meeting = $zoom->create_meeting(
				'me',
				$title,
				$start_time_utc,
				$settings['zoom'],
				$duration,
				$invitees,
				$description,
				$appointment_context
			);

			if ( $meeting && ! isset( $meeting['error'] ) ) {
				$integrateService = Container::resolve( AppointmentIntegrationService::class );
				$payload          = array(
					'provider'             => 'zoom',
					'external_event_id'    => $meeting['id'] ?? null,
					'external_calendar_id' => 'zoom',
					'meeting_url'          => $meeting['join_url'] ?? null,
					'join_url'             => $meeting['join_url'] ?? null,
					'start_url'            => $meeting['start_url'] ?? null,
					'meta'                 => maybe_serialize( $meeting ?? array() ),
					'status'               => 'created',
				);
				$integrateService->storeOrUpdate( $appointment_id, 'zoom', $payload );
			} else {
				error_log( 'Zoom meeting creation failed for meeting: ' . print_r( $meeting, true ) ); //phpcs:ignore
			}
		} catch ( Exception $e ) {
			error_log( 'Zoom meeting creation exception: ' . $e->getMessage() );
		}
	}

	/**
	 * Safely get integration settings from a MeetingType model or stdClass.
	 *
	 * @param object $meeting_type Model or stdClass.
	 *
	 * @return array
	 */
	private function getMeetingTypeIntegrations( $meeting_type ): array {
		if ( method_exists( $meeting_type, 'integrations' ) ) {
			return $meeting_type->integrations();
		}

		// Fallback for stdClass: decode settings manually.
		$raw = $meeting_type->settings ?? null;
		if ( is_string( $raw ) && ! empty( $raw ) ) {
			$decoded = json_decode( $raw, true );
			if ( is_array( $decoded ) ) {
				return $decoded['integrations'] ?? array();
			}
			$unserialized = maybe_unserialize( $raw );
			if ( is_array( $unserialized ) ) {
				return $unserialized['integrations'] ?? array();
			}
		}
		if ( is_array( $raw ) ) {
			return $raw['integrations'] ?? array();
		}

		return array();
	}
}
