<?php

/**
 * Class AppleCalendarIntegration
 *
 * Handles integration of Apple Calendar functionality, including
 * download endpoints, feed generation, and shortcode implementation.
 */

namespace RadiusTheme\RadiusBookingPro\Integrations;

use RadiusTheme\RadiusBooking\Helpers\SettingsHelper;


if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

/**
 * Class AppleCalendarIntegration
 *
 * Handles Apple Calendar integration to manage downloading calendar files, generating calendar feeds,
 * and supporting shortcodes for event calendar functionalities.
 */
class AppleCalendarIntegration {

	/**
	 * Constructor for initializing the calendar functionality.
	 *
	 * @return void
	 */
	public function __construct() {
		// Register download endpoint
		add_action( 'init', array( $this, 'register_download_endpoint' ) );
		add_action( 'template_redirect', array( $this, 'handle_calendar_download' ) );

		// REST API endpoint
		add_action( 'rest_api_init', array( $this, 'register_rest_endpoint' ) );

		// Calendar feed endpoint
		add_action( 'init', array( $this, 'register_feed_endpoint' ) );
	}

	/**
	 * Registers a custom download endpoint for calendar events.
	 *
	 * @return void
	 */
	public function register_download_endpoint() {
		add_rewrite_rule(
			'^calendar/download/([0-9]+)/?$',
			'index.php?calendar_download=1&event_id=$matches[1]',
			'top'
		);
		add_rewrite_tag( '%calendar_download%', '([0-9]+)' );
		add_rewrite_tag( '%event_id%', '([0-9]+)' );
	}

	/**
	 * Registers a custom feed endpoint for calendar feeds.
	 *
	 * @return void
	 */
	public function register_feed_endpoint() {
		add_rewrite_rule(
			'^calendar/feed/([a-zA-Z0-9]+)/?$',
			'index.php?calendar_feed=1&feed_token=$matches[1]',
			'top'
		);
		add_rewrite_tag( '%calendar_feed%', '([0-9]+)' );
		add_rewrite_tag( '%feed_token%', '([a-zA-Z0-9]+)' );
	}

	/**
	 * Retrieve or generate the feed token for the Apple Calendar integration.
	 *
	 * @return string The feed token for the Apple Calendar integration.
	 */
	private function get_feed_token() {
		$token = get_option( 'apple_calendar_feed_token' );
		if ( ! $token ) {
			$token = bin2hex( random_bytes( 16 ) );
			update_option( 'rtrb_apple_calendar_feed_token', $token );
		}

		return $token;
	}

	/**
	 * Handles calendar download requests for a specified event by generating an ICS file.
	 *
	 * @return void
	 */
	public function handle_calendar_download() {

		// Run only for explicit download requests
		if ( ! isset( $_GET['calendar_download'], $_GET['event_id'], $_GET['_wpnonce'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'radius-booking-pro' ) );
		}
		$event_id = absint( wp_unslash( $_GET['event_id'] ) );
		$nonce    = sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) );

		if ( ! $event_id ) {
			wp_die( esc_html__( 'Invalid event ID.', 'radius-booking-pro' ) );
		}

		if ( ! wp_verify_nonce( $nonce, 'calendar_download_' . $event_id ) ) {
			wp_die( esc_html__( 'Invalid security token.', 'radius-booking-pro' ) );
		}

		if ( ! get_option( 'apple_calendar_show_download_link', true ) ) {
			wp_die( esc_html__( 'Calendar download is disabled.', 'radius-booking-pro' ) );
		}

		$booking = get_transient( 'rtrb_booking_' . $event_id );

		if ( $booking ) {
			$ics_content = $this->generate_calendar_from_booking( $booking );

			if ( $ics_content ) {
				header( 'Content-Type: text/calendar; charset=utf-8' );
				header( 'Content-Disposition: attachment; filename="appointment-' . $event_id . '.ics"' );
				header( 'Content-Length: ' . strlen( $ics_content ) );
				header( 'Cache-Control: no-cache' );

				echo wp_kses_post( $ics_content );
				exit;
			}
		}

		$this->download_calendar_file_by_id( $event_id );
		exit;
	}


	/**
	 * Converts a booking array into an event representation.
	 *
	 * @param array $booking The booking data.
	 *
	 * @return array The event data created from the booking.
	 */
	private function convert_booking_to_event( $booking ) {
		$appointment_datetime = $booking['appointment_date'] . ' ' . $booking['start_time'];
		$start_timestamp      = strtotime( $appointment_datetime );

		$end_datetime  = $booking['appointment_date'] . ' ' . $booking['end_time'];
		$end_timestamp = strtotime( $end_datetime );

		$title = $booking['service_name'] ?? __( 'Appointment', 'radius-booking-pro' );

		$customer_name = '';
		if ( isset( $booking['customer']->customer_info['name'] ) ) {
			$customer_name = $booking['customer']->customer_info['name'];
		} elseif ( isset( $booking['customer']->customer_info['first_name'] ) ) {
			$customer_name = $booking['customer']->customer_info['first_name'];
			if ( isset( $booking['customer']->customer_info['last_name'] ) ) {
				$customer_name .= ' ' . $booking['customer']->customer_info['last_name'];
			}
		}

		if ( $customer_name ) {
			$title .= ' - ' . $customer_name;
		}

		$na           = __( 'N/A', 'radius-booking-pro' );
		$description  = __( 'Service:', 'radius-booking-pro' ) . ' ' . ( $booking['service_name'] ?? $na ) . "\n";
		$description .= __( 'Employee:', 'radius-booking-pro' ) . ' ' . ( $booking['employee_name'] ?? $na ) . "\n";

		if ( isset( $booking['customer']->customer_info['phone'] ) ) {
			$description .= __( 'Phone:', 'radius-booking-pro' ) . ' ' . $booking['customer']->customer_info['phone'] . "\n";
		}

		if ( isset( $booking['customer']->customer_info['email'] ) ) {
			$description .= __( 'Email:', 'radius-booking-pro' ) . ' ' . $booking['customer']->customer_info['email'] . "\n";
		}

		if ( ! empty( $booking['notes'] ) ) {
			$description .= "\n" . __( 'Notes:', 'radius-booking-pro' ) . ' ' . $booking['notes'];
		}

		$location = '';
		if ( ! empty( $booking['location_info'] ) && is_array( $booking['location_info'] ) ) {
			$location = $booking['location_info']['name'] ?? '';
			if ( ! empty( $booking['location_info']['address'] ) ) {
				$location .= ', ' . $booking['location_info']['address'];
			}
		}

		$attendees = array();

		if ( ! empty( $booking['employee_email'] ) ) {
			$attendees[] = array(
				'email' => $booking['employee_email'],
				'name'  => $booking['employee_name'] ?? $booking['employee_email'],
			);
		}

		if ( isset( $booking['customer']->customer_info['email'] ) ) {
			$attendees[] = array(
				'email' => $booking['customer']->customer_info['email'],
				'name'  => $customer_name ?? $booking['customer']->customer_info['email'],
			);
		}

		return array(
			'id'          => $booking['id'],
			'title'       => $title,
			'description' => $description,
			'location'    => $location,
			'start_time'  => $start_timestamp,
			'end_time'    => $end_timestamp,
			'attendees'   => $attendees,
			'status'      => $booking['status'] ?? 'confirmed',
		);
	}

	/**
	 * Generates an iCalendar (ICS) format string from a booking.
	 *
	 * @param array $booking An array containing booking details.
	 *
	 * @return string|false A string in iCalendar format, or false if the booking could not be converted.
	 */
	public function generate_calendar_from_booking( $booking ) {
		$event = $this->convert_booking_to_event( $booking );

		if ( ! $event ) {
			return false;
		}

		$ics   = array();
		$ics[] = 'BEGIN:VCALENDAR';
		$ics[] = 'VERSION:2.0';
		$ics[] = 'PRODID:-//' . get_bloginfo( 'name' ) . '//NONSGML Events//EN';
		$ics[] = 'CALSCALE:GREGORIAN';
		$ics[] = 'METHOD:PUBLISH';
		$ics[] = $this->generate_vevent( $event );
		$ics[] = 'END:VCALENDAR';

		return implode( "\r\n", $ics );
	}

	/**
	 * Generates a VEVENT string in iCalendar (ICS) format.
	 *
	 * @param array $event An associative array containing the event details.
	 *
	 * @return string Returns the generated VEVENT string in iCalendar format.
	 */
	private function generate_vevent( $event ) {
		$setting           = SettingsHelper::get_setting( 'integrations' );
		$apple_cal_setting = $setting['appleCalendar'] ?? array();
		$lines             = array();
		$lines[]           = 'BEGIN:VEVENT';
		$lines[]           = 'UID:' . $this->generate_uid( $event['id'] );
		$lines[]           = 'DTSTAMP:' . $this->format_ics_datetime( current_time( 'timestamp' ) );
		$lines[]           = 'DTSTART:' . $this->format_ics_datetime( $event['start_time'] );
		$lines[]           = 'DTEND:' . $this->format_ics_datetime( $event['end_time'] );
		$lines[]           = 'SUMMARY:' . $this->escape_ics_string( $event['title'] );

		if ( $apple_cal_setting['includeDescription'] && ! empty( $event['description'] ) ) {
			$lines[] = 'DESCRIPTION:' . $this->escape_ics_string( $event['description'] );
		}

		if ( $apple_cal_setting['includeLocation'] && ! empty( $event['location'] ) ) {
			$lines[] = 'LOCATION:' . $this->escape_ics_string( $event['location'] );
		}

		$lines[] = 'STATUS:CONFIRMED';

		$organizer_email = $apple_cal_setting['organizerEmail'] ?? get_option( 'admin_email' );
		$organizer_name  = $apple_cal_setting['calendarName'] ?? get_bloginfo( 'name' );
		$lines[]         = 'ORGANIZER;CN=' . $this->escape_ics_string( $organizer_name ) . ':MAILTO:' . $organizer_email;

		if ( ! empty( $event['attendees'] ) ) {
			foreach ( $event['attendees'] as $attendee ) {
				$email   = is_array( $attendee ) ? $attendee['email'] : $attendee;
				$name    = is_array( $attendee ) && isset( $attendee['name'] ) ? $attendee['name'] : $email;
				$lines[] = 'ATTENDEE;CN=' . $this->escape_ics_string( $name ) . ';RSVP=TRUE:MAILTO:' . $email;
			}
		}

		if ( ! empty( $event['url'] ) ) {
			$lines[] = 'URL:' . $event['url'];
		}

		if ( $apple_cal_setting['addReminders'] ) {
			$reminder_time = $apple_cal_setting['reminderMinutes'] ?? 60;
			$lines[]       = 'BEGIN:VALARM';
			$lines[]       = 'TRIGGER:-PT' . $reminder_time . 'M';
			$lines[]       = 'ACTION:DISPLAY';
			$lines[]       = 'DESCRIPTION:Reminder';
			$lines[]       = 'END:VALARM';
		}

		$lines[] = 'END:VEVENT';

		return implode( "\r\n", $lines );
	}

	/**
	 * Downloads an iCalendar (ICS) file for a specific booking based on its ID.
	 *
	 * @param int $booking_id The ID of the booking.
	 *
	 * @return void
	 */
	public function download_calendar_file_by_id( $booking_id ) {
		global $wpdb;

		$booking = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$wpdb->prefix}rtrb_appointments` WHERE id = %d",
				$booking_id
			),
			ARRAY_A
		);

		if ( ! $booking ) {
			wp_die( esc_html__( 'Event not found', 'radius-booking-pro' ) );
		}

		$customer = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM `{$wpdb->prefix}rtrb_customers` WHERE appointment_id = %d",
				$booking_id
			),
			ARRAY_A
		);

		if ( $customer ) {
			$customer_info = maybe_unserialize( $customer['customer_info'] );
			if ( ! is_array( $customer_info ) ) {
				$customer_info = json_decode( $customer['customer_info'], true ) ?? array();
			}
			$booking['customer'] = (object) array_merge( $customer, array( 'customer_info' => $customer_info ) );
		}

		if ( ! empty( $booking['location_info'] ) ) {
			$location_info            = maybe_unserialize( $booking['location_info'] );
			$booking['location_info'] = is_array( $location_info ) ? $location_info : array();
		}

		$ics_content = $this->generate_calendar_from_booking( $booking );

		if ( ! $ics_content ) {
			wp_die( esc_html__( 'Failed to generate calendar', 'radius-booking-pro' ) );
		}

		header( 'Content-Type: text/calendar; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="appointment-' . $booking_id . '.ics"' );
		header( 'Content-Length: ' . strlen( $ics_content ) );
		header( 'Cache-Control: no-cache' );

		echo wp_kses_post( $ics_content );
	}

	/**
	 * Formats a timestamp into an ICS-compliant datetime string.
	 *
	 * @param int|string $timestamp The timestamp to format.
	 *
	 * @return string The formatted ICS datetime string.
	 */
	private function format_ics_datetime( $timestamp ) {
		if ( is_string( $timestamp ) ) {
			$timestamp = strtotime( $timestamp );
		}

		return gmdate( 'Ymd\THis\Z', $timestamp );
	}

	/**
	 * Generates a unique identifier (UID) for an event.
	 *
	 * @param int|string $event_id The ID of the event.
	 *
	 * @return string The generated UID.
	 */
	private function generate_uid( $event_id ) {
		return 'booking-' . $event_id . '-' . md5( $event_id . get_site_url() ) . '@' . wp_parse_url( get_site_url(), PHP_URL_HOST );
	}

	/**
	 * Escapes a string for use in an ICS file.
	 *
	 * @param string $string The input string to be escaped.
	 *
	 * @return string The escaped and formatted string.
	 */
	private function escape_ics_string( $string ) {
		$string = str_replace( array( '\\', ',', ';', "\n", "\r" ), array( '\\\\', '\\,', '\\;', '\\n', '' ), $string );

		return wordwrap( $string, 75, "\r\n ", true );
	}

	/**
	 * Generates an HTML download button for adding a calendar event.
	 *
	 * @param int $booking_id The ID of the booking.
	 * @param string $text Optional. The text to display. Default is 'Add to Calendar' (translated).
	 * @param string $style Optional. The style: 'button', 'link', or 'icon'. Default is 'button'.
	 *
	 * @return string The HTML markup. Returns an empty string if download is disabled.
	 */
	public function get_download_button( $booking_id, $text = '', $style = 'button' ) {
		if ( ! get_option( 'apple_calendar_show_download_link', true ) ) {
			return '';
		}

		if ( '' === $text ) {
			$text = __( 'Add to Calendar', 'radius-booking-pro' );
		}

		$url = home_url( '/calendar/download/' . $booking_id );

		$html = '';

		if ( $style === 'button' ) {
			$html = '<a href="' . esc_url( $url ) . '" class="rtrb-calendar-download-btn" style="display:inline-block;background:#007aff;color:white;padding:12px 24px;text-decoration:none;border-radius:6px;font-weight:600;font-size:14px;">📅 ' . esc_html( $text ) . '</a>';
		} elseif ( $style === 'link' ) {
			$html = '<a href="' . esc_url( $url ) . '" class="rtrb-calendar-download-link" style="color:#007aff;text-decoration:none;">📅 ' . esc_html( $text ) . '</a>';
		} elseif ( $style === 'icon' ) {
			$html = '<a href="' . esc_url( $url ) . '" class="rtrb-calendar-download-icon" style="display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;background:#007aff;color:white;border-radius:50%;text-decoration:none;font-size:20px;">📅</a>';
		}

		return $html;
	}

	/**
	 * Generates a Google Calendar event URL from booking details.
	 *
	 * @param array $booking Booking details.
	 *
	 * @return string The Google Calendar URL, or '#' if required fields are missing.
	 */
	public function get_google_calendar_url_from_booking( $booking ) {
		$title = $booking['service_name'] ?? __( 'Appointment', 'radius-booking-pro' );
		$date  = $booking['appointment_date'] ?? '';
		$start = $booking['start_time'] ?? '';
		$end   = $booking['end_time'] ?? '';

		if ( ! $date || ! $start || ! $end ) {
			return '#';
		}

		$start_dt = strtotime( $date . ' ' . $start );
		$end_dt   = strtotime( $date . ' ' . $end );

		$description = __( 'Service:', 'radius-booking-pro' ) . ' ' . ( $booking['service_name'] ?? '' ) . "\n";
		if ( isset( $booking['employee_name'] ) ) {
			$description .= __( 'Employee:', 'radius-booking-pro' ) . ' ' . $booking['employee_name'] . "\n";
		}
		if ( isset( $booking['notes'] ) ) {
			$description .= __( 'Notes:', 'radius-booking-pro' ) . ' ' . $booking['notes'];
		}

		$location = '';
		if ( isset( $booking['location_info']['name'] ) ) {
			$location = $booking['location_info']['name'];
			if ( isset( $booking['location_info']['address'] ) ) {
				$location .= ', ' . $booking['location_info']['address'];
			}
		}

		$params = array(
			'action'   => 'TEMPLATE',
			'text'     => $title,
			'dates'    => gmdate( 'Ymd\THis\Z', $start_dt ) . '/' . gmdate( 'Ymd\THis\Z', $end_dt ),
			'details'  => $description,
			'location' => $location,
		);

		return 'https://calendar.google.com/calendar/render?' . http_build_query( $params );
	}

	/**
	 * Generate an Outlook calendar event URL for the given booking details.
	 *
	 * @param array $booking Booking details.
	 *
	 * @return string The Outlook calendar URL, or '#' if required fields are missing.
	 */
	public function get_outlook_calendar_url_from_booking( $booking ) {
		$title = $booking['service_name'] ?? __( 'Appointment', 'radius-booking-pro' );
		$date  = $booking['appointment_date'] ?? '';
		$start = $booking['start_time'] ?? '';
		$end   = $booking['end_time'] ?? '';

		if ( ! $date || ! $start || ! $end ) {
			return '#';
		}

		$start_dt = strtotime( $date . ' ' . $start );
		$end_dt   = strtotime( $date . ' ' . $end );

		$description = __( 'Service:', 'radius-booking-pro' ) . ' ' . ( $booking['service_name'] ?? '' ) . "\n";
		if ( isset( $booking['employee_name'] ) ) {
			$description .= __( 'Employee:', 'radius-booking-pro' ) . ' ' . $booking['employee_name'];
		}

		$location = '';
		if ( isset( $booking['location_info']['name'] ) ) {
			$location = $booking['location_info']['name'];
		}

		$params = array(
			'path'     => '/calendar/action/compose',
			'rru'      => 'addevent',
			'subject'  => $title,
			'startdt'  => gmdate( 'Y-m-d\TH:i:s', $start_dt ),
			'enddt'    => gmdate( 'Y-m-d\TH:i:s', $end_dt ),
			'body'     => $description,
			'location' => $location,
		);

		return 'https://outlook.live.com/calendar/0/deeplink/compose?' . http_build_query( $params );
	}

	/**
	 * Registers a REST API endpoint for downloading calendar data.
	 *
	 * @return void
	 */
	public function register_rest_endpoint() {
		register_rest_route(
			'radius-booking/calendar/v1',
			'/download/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'rest_download_calendar' ),
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
			)
		);
	}

	/**
	 * Handles the REST request to download a calendar file by ID.
	 *
	 * @param WP_REST_Request $request The REST API request.
	 *
	 * @return void
	 */
	public function rest_download_calendar( $request ) {
		$this->download_calendar_file_by_id( $request['id'] );
	}
}
