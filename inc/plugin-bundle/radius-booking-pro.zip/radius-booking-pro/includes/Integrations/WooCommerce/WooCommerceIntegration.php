<?php
/**
 * WooCommerce order lifecycle → booking status sync.
 */

namespace RadiusTheme\RadiusBookingPro\Integrations\WooCommerce;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBooking\Models\Appointment;
use RadiusTheme\RadiusBooking\Models\Payment;
use RadiusTheme\RadiusBooking\Services\AppointmentService;
use RadiusTheme\RadiusBooking\Services\EventRegistrationService;
use RadiusTheme\RadiusBooking\Services\TransactionService;

/**
 * Confirms / cancels the booking when its linked WooCommerce order changes
 * status. Only acts on orders created by Radius Booking (identified by the
 * `_rtrb_appointment_id` order meta).
 */
class WooCommerceIntegration {

	/**
	 * Constructor — wires the WooCommerce order hooks when WooCommerce is active.
	 */
	public function __construct() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		$this->register_hooks();
	}

	/**
	 * Register the WooCommerce order lifecycle hooks.
	 *
	 * @return void
	 */
	private function register_hooks() {
		// Order lifecycle → booking status.
		add_action( 'woocommerce_payment_complete', array( $this, 'on_payment_complete' ), 10, 1 );
		add_action( 'woocommerce_order_status_processing', array( $this, 'on_processing' ), 10, 1 );
		add_action( 'woocommerce_order_status_completed', array( $this, 'on_completed' ), 10, 1 );
		add_action( 'woocommerce_order_status_cancelled', array( $this, 'on_cancelled' ), 10, 1 );
		add_action( 'woocommerce_order_status_failed', array( $this, 'on_failed' ), 10, 1 );
		add_action( 'woocommerce_order_status_refunded', array( $this, 'on_refunded' ), 10, 1 );

		// Cart → order bridge for the dynamic booking line item.
		add_filter( 'woocommerce_get_cart_item_from_session', array( $this, 'restore_cart_item_data' ), 10, 3 );
		add_action( 'woocommerce_before_calculate_totals', array( $this, 'set_cart_item_price' ), 20, 1 );

		add_filter( 'woocommerce_cart_item_name', array( $this, 'cart_item_name' ), 10, 3 );
		add_filter( 'woocommerce_get_item_data', array( $this, 'cart_item_display_meta' ), 10, 2 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'add_order_line_item_meta' ), 10, 4 );
		add_action( 'woocommerce_checkout_create_order', array( $this, 'link_order_to_appointment' ), 10, 2 );
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'on_order_processed' ), 10, 3 );
		// Block (Store API) checkout counterpart — the classic order-processed hook
		// above does not fire for the block checkout (the modern WC default).
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'on_store_api_order_processed' ), 10, 1 );

		// Honor the "New booking order status" setting. Offline gateways force the
		// order to on-hold during process_payment (which is why a "pending" choice
		// would otherwise never stick); these filters let a booking order start in
		// the configured status instead. Online gateways already leave the order at
		// pending until payment completes, so they need no filter here.
		add_filter( 'woocommerce_bacs_process_payment_order_status', array( $this, 'filter_new_order_status' ), 10, 2 );
		add_filter( 'woocommerce_cheque_process_payment_order_status', array( $this, 'filter_new_order_status' ), 10, 2 );
		add_filter( 'woocommerce_cod_process_payment_order_status', array( $this, 'filter_new_order_status' ), 10, 2 );

		// Pre-fill checkout fields with booking customer info (classic checkout).
		add_filter( 'woocommerce_checkout_get_value', array( $this, 'prefill_checkout_fields' ), 10, 2 );

		// Pre-fill customer data for both classic and block checkout.
		add_action( 'woocommerce_before_checkout_form', array( $this, 'prefill_customer_data' ), 5 );
		add_action( 'woocommerce_blocks_checkout_enqueue_data', array( $this, 'prefill_customer_data' ) );
	}

	/**
	 * Force a Radius Booking order into the configured "New booking order status"
	 * ('pending' | 'on-hold') when an offline gateway would otherwise pick its own
	 * status. Leaves non-booking orders untouched.
	 *
	 * @param string    $status The status the gateway is about to set.
	 * @param \WC_Order $order  The order being processed.
	 *
	 * @return string
	 */
	public function filter_new_order_status( $status, $order ) {
		if ( ! $order || ! (int) $order->get_meta( WooCommerceOrderManager::META_APPOINTMENT_ID ) ) {
			return $status;
		}
		$configured = $this->settings()['newOrderStatus'] ?? 'pending';
		return in_array( $configured, array( 'pending', 'on-hold' ), true ) ? $configured : $status;
	}

	/**
	 * Pre-fill WooCommerce customer data from booking info.
	 *
	 * This works for both classic and block checkout by setting data directly
	 * on the WC_Customer object.
	 *
	 * @return void
	 */
	public function prefill_customer_data() {
		// Skip if no cart or no session.
		if ( ! WC()->cart || ! WC()->session || ! WC()->customer ) {
			return;
		}

		// Check if we already pre-filled to avoid overwriting user edits.
		if ( WC()->session->get( 'rtrb_checkout_prefilled' ) ) {
			return;
		}

		// Get customer info from session.
		$customer_info = WC()->session->get( 'rtrb_checkout_customer' );

		// Fallback: try to get from cart item data.
		if ( empty( $customer_info ) ) {
			foreach ( WC()->cart->get_cart() as $item ) {
				if ( isset( $item[ WooCommerceOrderManager::CART_CUSTOMER_INFO ] ) ) {
					$customer_info = $item[ WooCommerceOrderManager::CART_CUSTOMER_INFO ];
					break;
				}
			}
		}

		if ( empty( $customer_info ) ) {
			return;
		}

		// Ensure customer_info is an array (may be PHP serialized or JSON).
		if ( is_string( $customer_info ) ) {
			$unserialized = maybe_unserialize( $customer_info );
			if ( is_array( $unserialized ) ) {
				$customer_info = $unserialized;
			} else {
				$customer_info = json_decode( $customer_info, true ) ?: array();
			}
		}

		$customer = WC()->customer;

		// Only set if customer doesn't already have data.
		if ( ! empty( $customer_info['first_name'] ) && ! $customer->get_billing_first_name() ) {
			$customer->set_billing_first_name( sanitize_text_field( $customer_info['first_name'] ) );
		}
		if ( ! empty( $customer_info['last_name'] ) && ! $customer->get_billing_last_name() ) {
			$customer->set_billing_last_name( sanitize_text_field( $customer_info['last_name'] ) );
		}
		if ( ! empty( $customer_info['email'] ) && ! $customer->get_billing_email() ) {
			$customer->set_billing_email( sanitize_email( $customer_info['email'] ) );
		}
		if ( ! empty( $customer_info['phone'] ) && ! $customer->get_billing_phone() ) {
			$customer->set_billing_phone( sanitize_text_field( $customer_info['phone'] ) );
		}

		// Mark as pre-filled so we don't overwrite user edits on subsequent loads.
		WC()->session->set( 'rtrb_checkout_prefilled', true );
	}

	/**
	 * Pre-fill WooCommerce checkout fields with booking customer info.
	 *
	 * This prevents customers from having to enter their details twice — once in
	 * the booking form and again at WooCommerce checkout.
	 *
	 * @param mixed  $value The current field value.
	 * @param string $input The field key (e.g. 'billing_first_name').
	 *
	 * @return mixed The pre-filled value or original value.
	 */
	public function prefill_checkout_fields( $value, $input ) {
		// Only pre-fill if user hasn't already entered data.
		if ( ! empty( $value ) ) {
			return $value;
		}

		// Skip if no session.
		if ( ! WC()->session ) {
			return $value;
		}

		// Get customer info from cart item data (this persists across sessions).
		$customer_info = null;
		$booking_notes = '';

		if ( WC()->cart ) {
			foreach ( WC()->cart->get_cart() as $item ) {
				if ( isset( $item[ WooCommerceOrderManager::CART_CUSTOMER_INFO ] ) ) {
					$customer_info = $item[ WooCommerceOrderManager::CART_CUSTOMER_INFO ];
					$booking_notes = $item[ WooCommerceOrderManager::CART_BOOKING_NOTES ] ?? '';
					break;
				}
			}
		}

		// Fallback: check the rtrb_checkout_customer session value.
		if ( empty( $customer_info ) ) {
			$customer_info = WC()->session->get( 'rtrb_checkout_customer' );
			$booking_notes = WC()->session->get( 'rtrb_checkout_notes' );
		}

		if ( empty( $customer_info ) ) {
			return $value;
		}

		// Ensure customer_info is an array (may be PHP serialized or JSON).
		if ( is_string( $customer_info ) ) {
			$unserialized = maybe_unserialize( $customer_info );
			if ( is_array( $unserialized ) ) {
				$customer_info = $unserialized;
			} else {
				$customer_info = json_decode( $customer_info, true ) ?: array();
			}
		}

		// Map booking fields to WooCommerce checkout fields.
		$field_mapping = array(
			'billing_first_name' => $customer_info['first_name'] ?? '',
			'billing_last_name'  => $customer_info['last_name'] ?? '',
			'billing_email'      => $customer_info['email'] ?? '',
			'billing_phone'      => $customer_info['phone'] ?? '',
			'order_comments'     => $booking_notes,
		);

		// Return the mapped value if this field has a mapping.
		if ( isset( $field_mapping[ $input ] ) && ! empty( $field_mapping[ $input ] ) ) {
			return $field_mapping[ $input ];
		}

		return $value;
	}

	/**
	 * Restore custom cart item data (rtrb_price, rtrb_label, etc.) from session.
	 *
	 * WooCommerce stores cart item data in the session, but when restoring, it
	 * doesn't automatically include custom data. This filter merges the session
	 * data back into the cart item so our dynamic price is preserved.
	 *
	 * @param array $cart_item    The cart item being restored.
	 * @param array $session_data The session data for this cart item.
	 * @param string $key         The cart item key.
	 *
	 * @return array The cart item with custom data restored.
	 */
	public function restore_cart_item_data( $cart_item, $session_data, $key ) {
		// Restore our custom cart item data keys from session.
		// WooCommerce merges session values into the cart item, but our custom keys
		// may not be included automatically.
		$custom_keys = array(
			WooCommerceOrderManager::CART_APPOINTMENT_ID,
			WooCommerceOrderManager::CART_PAYMENT_ID,
			WooCommerceOrderManager::CART_BOOKING_ID,
			WooCommerceOrderManager::CART_PRICE,
			WooCommerceOrderManager::CART_LABEL,
			WooCommerceOrderManager::CART_CUSTOMER_INFO,
			WooCommerceOrderManager::CART_BOOKING_NOTES,
			'rtrb_unique',
		);

		foreach ( $custom_keys as $custom_key ) {
			if ( isset( $session_data[ $custom_key ] ) ) {
				$cart_item[ $custom_key ] = $session_data[ $custom_key ];
			}
		}

		// Pre-fill customer data when cart is restored (works for both classic and block checkout).
		if ( isset( $session_data[ WooCommerceOrderManager::CART_CUSTOMER_INFO ] ) ) {
			$this->set_customer_billing_data( $session_data[ WooCommerceOrderManager::CART_CUSTOMER_INFO ] );
		}

		return $cart_item;
	}

	/**
	 * Set customer billing data from booking info.
	 *
	 * @param array|string $customer_info The customer info from booking.
	 *
	 * @return void
	 */
	private function set_customer_billing_data( $customer_info ) {
		if ( ! WC()->customer ) {
			return;
		}

		// Ensure customer_info is an array (may be PHP serialized or JSON).
		if ( is_string( $customer_info ) ) {
			$unserialized = maybe_unserialize( $customer_info );
			if ( is_array( $unserialized ) ) {
				$customer_info = $unserialized;
			} else {
				$customer_info = json_decode( $customer_info, true ) ?: array();
			}
		}

		if ( empty( $customer_info ) ) {
			return;
		}

		$customer = WC()->customer;

		// Only set if customer doesn't already have data (avoid overwriting logged-in user data).
		if ( ! empty( $customer_info['first_name'] ) && ! $customer->get_billing_first_name() ) {
			$customer->set_billing_first_name( sanitize_text_field( $customer_info['first_name'] ) );
		}
		if ( ! empty( $customer_info['last_name'] ) && ! $customer->get_billing_last_name() ) {
			$customer->set_billing_last_name( sanitize_text_field( $customer_info['last_name'] ) );
		}
		if ( ! empty( $customer_info['email'] ) && ! $customer->get_billing_email() ) {
			$customer->set_billing_email( sanitize_email( $customer_info['email'] ) );
		}
		if ( ! empty( $customer_info['phone'] ) && ! $customer->get_billing_phone() ) {
			$customer->set_billing_phone( sanitize_text_field( $customer_info['phone'] ) );
		}
	}

	/**
	 * Apply the booking's dynamic price to its cart line (the shared product is
	 * priced at 0). Runs on every cart totals calculation on cart/checkout.
	 *
	 * @param \WC_Cart $cart The cart being calculated.
	 *
	 * @return void
	 */
	public function set_cart_item_price( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return;
		}
		foreach ( $cart->get_cart() as $item ) {
			if ( isset( $item['data'] ) ) {
				$price = 0;

				// Try to get price from cart item data first.
				if ( isset( $item[ WooCommerceOrderManager::CART_PRICE ] ) ) {
					$price = (float) $item[ WooCommerceOrderManager::CART_PRICE ];
				}

				// Fallback: try to get price from transient using appointment ID.
				if ( $price <= 0 && isset( $item[ WooCommerceOrderManager::CART_APPOINTMENT_ID ] ) ) {
					$transient_price = get_transient( 'rtrb_wc_price_' . $item[ WooCommerceOrderManager::CART_APPOINTMENT_ID ] );
					if ( $transient_price !== false ) {
						$price = (float) $transient_price;
					}
				}

				if ( $price > 0 ) {
					$item['data']->set_price( $price );
				}
			}
		}
	}

	/**
	 * Show the service/date/time label as the cart & checkout line name instead
	 * of the generic hidden product title.
	 *
	 * @param string $name          The current line item name (HTML).
	 * @param array  $cart_item     The cart item.
	 * @param string $cart_item_key The cart item key.
	 *
	 * @return string
	 */
	public function cart_item_name( $name, $cart_item, $cart_item_key ) {
		if ( ! empty( $cart_item[ WooCommerceOrderManager::CART_LABEL ] ) ) {
			return esc_html( $cart_item[ WooCommerceOrderManager::CART_LABEL ] );
		}
		return $name;
	}

	/**
	 * Surface the booking label as a cart/checkout meta line. Works for both the
	 * classic (shortcode) and block (Store API) checkout, which the
	 * `woocommerce_cart_item_name` filter does not cover.
	 *
	 * @param array $item_data The existing item data rows.
	 * @param array $cart_item The cart item.
	 *
	 * @return array
	 */
	public function cart_item_display_meta( $item_data, $cart_item ) {
		if ( ! empty( $cart_item[ WooCommerceOrderManager::CART_LABEL ] ) ) {
			$item_data[] = array(
				'key'   => __( 'Appointment', 'radius-booking-pro' ),
				'value' => wc_clean( $cart_item[ WooCommerceOrderManager::CART_LABEL ] ),
			);
		}
		return $item_data;
	}

	/**
	 * Carry the booking link + label from the cart item onto the order line item
	 * when the order is created at checkout.
	 *
	 * @param \WC_Order_Item_Product $item          The order line item.
	 * @param string                 $cart_item_key The cart item key.
	 * @param array                  $values        The cart item values.
	 * @param \WC_Order              $order         The order.
	 *
	 * @return void
	 */
	public function add_order_line_item_meta( $item, $cart_item_key, $values, $order ) {
		if ( empty( $values[ WooCommerceOrderManager::CART_APPOINTMENT_ID ] ) ) {
			return;
		}
		$item->add_meta_data( WooCommerceOrderManager::META_APPOINTMENT_ID, (int) $values[ WooCommerceOrderManager::CART_APPOINTMENT_ID ], true );
		if ( ! empty( $values[ WooCommerceOrderManager::CART_LABEL ] ) ) {
			$item->set_name( $values[ WooCommerceOrderManager::CART_LABEL ] );
		}

		// Set the order meta here too — this hook fires for BOTH the classic and
		// block (Store API) checkout, whereas woocommerce_checkout_create_order
		// does not fire for the block checkout.
		$order->update_meta_data( WooCommerceOrderManager::META_APPOINTMENT_ID, (int) $values[ WooCommerceOrderManager::CART_APPOINTMENT_ID ] );
		$order->update_meta_data( WooCommerceOrderManager::META_PAYMENT_ID, (int) ( $values[ WooCommerceOrderManager::CART_PAYMENT_ID ] ?? 0 ) );
		$order->update_meta_data( WooCommerceOrderManager::META_BOOKING_ID, (int) ( $values[ WooCommerceOrderManager::CART_BOOKING_ID ] ?? 0 ) );
	}

	/**
	 * Copy the booking linkage from the cart onto the order meta so the lifecycle
	 * hooks (on_payment_complete etc.) can resolve the appointment.
	 *
	 * @param \WC_Order $order The order being created at checkout.
	 * @param array     $data  The posted checkout data.
	 *
	 * @return void
	 */
	public function link_order_to_appointment( $order, $data ) {
		if ( is_null( WC()->cart ) ) {
			return;
		}
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( empty( $item[ WooCommerceOrderManager::CART_APPOINTMENT_ID ] ) ) {
				continue;
			}
			$order->update_meta_data( WooCommerceOrderManager::META_APPOINTMENT_ID, (int) $item[ WooCommerceOrderManager::CART_APPOINTMENT_ID ] );
			$order->update_meta_data( WooCommerceOrderManager::META_PAYMENT_ID, (int) ( $item[ WooCommerceOrderManager::CART_PAYMENT_ID ] ?? 0 ) );
			$order->update_meta_data( WooCommerceOrderManager::META_BOOKING_ID, (int) ( $item[ WooCommerceOrderManager::CART_BOOKING_ID ] ?? 0 ) );
			break; // One booking per order.
		}
	}

	/**
	 * Once the order is saved at checkout, stamp the order id on the payment row
	 * and note the appointment on the order.
	 *
	 * @param int       $order_id The new order ID.
	 * @param array     $data     The posted checkout data.
	 * @param \WC_Order $order    The order.
	 *
	 * @return void
	 */
	public function on_order_processed( $order_id, $data, $order ) {
		$appointment_id = (int) $order->get_meta( WooCommerceOrderManager::META_APPOINTMENT_ID );
		if ( ! $appointment_id ) {
			return;
		}
		$payment_id = (int) $order->get_meta( WooCommerceOrderManager::META_PAYMENT_ID );
		if ( $payment_id ) {
			$payment = Payment::find( $payment_id );
			if ( $payment ) {
				$payment->update( array( 'transaction_id' => 'wc_order_' . $order_id ) );
			}
		}
		$order->add_order_note(
			sprintf(
				/* translators: %d is the appointment ID. */
				__( 'Radius Booking appointment #%d — awaiting payment.', 'radius-booking-pro' ),
				$appointment_id
			)
		);

		$this->maybe_create_customer( $order );
	}

	/**
	 * Block (Store API) checkout counterpart of on_order_processed. Only the
	 * customer-account creation is needed here — the appointment linkage is
	 * already written by add_order_line_item_meta (which fires for block too).
	 *
	 * @param \WC_Order $order The order just created via the Store API.
	 *
	 * @return void
	 */
	public function on_store_api_order_processed( $order ) {
		$this->maybe_create_customer( $order );
	}

	/**
	 * Create (or link) a WooCommerce customer account for the booker when the
	 * "create customer account" setting is enabled and the order was placed as a
	 * guest. Applies to every booking type — service, meeting and event all place
	 * their order through this same checkout. If an account already exists for the
	 * billing email, the order is linked to it instead of creating a duplicate.
	 *
	 * @param \WC_Order $order The Radius Booking order.
	 *
	 * @return void
	 */
	private function maybe_create_customer( $order ) {
		if ( ! $order || empty( $this->settings()['createCustomer'] ) ) {
			return;
		}
		// Only act on Radius Booking orders (identified by the appointment meta).
		if ( ! (int) $order->get_meta( WooCommerceOrderManager::META_APPOINTMENT_ID ) ) {
			return;
		}
		// Already tied to a user (logged-in booker or a previous link).
		if ( $order->get_customer_id() ) {
			return;
		}
		$email = $order->get_billing_email();
		if ( ! $email || ! is_email( $email ) || ! function_exists( 'wc_create_new_customer' ) ) {
			return;
		}

		$user_id = email_exists( $email );
		if ( ! $user_id ) {
			// Empty username/password → WooCommerce generates them and (per its
			// account settings) emails the customer a set-password link. This fires
			// `woocommerce_created_customer`, which merges any existing guest
			// analytics row into the new account.
			$user_id = wc_create_new_customer(
				$email,
				'',
				'',
				array(
					'first_name' => $order->get_billing_first_name(),
					'last_name'  => $order->get_billing_last_name(),
				)
			);
		}
		if ( is_wp_error( $user_id ) || ! $user_id ) {
			return;
		}

		// Attach this guest order (and any other guest orders for the same email)
		// to the account using WooCommerce's own guest→account routine. It sets the
		// order's customer, saves it, and fires the customer/analytics sync so the
		// buyer appears under WooCommerce → Customers (the analytics lookup table) —
		// not only in Users. A bare set_customer_id()/save() does not populate that
		// lookup. Must run while the order is still a guest order (customer_id 0),
		// so do NOT pre-assign the customer before calling this.
		if ( function_exists( 'wc_update_new_customer_past_orders' ) ) {
			wc_update_new_customer_past_orders( (int) $user_id );
		} else {
			$order->set_customer_id( (int) $user_id );
			$order->save();
		}
	}

	/**
	 * The WooCommerce integration settings.
	 *
	 * @return array
	 */
	private function settings(): array {
		return WooCommerceOrderManager::settings();
	}

	/**
	 * Resolve the booking context for a WooCommerce order.
	 *
	 * @param int $order_id The WooCommerce order ID.
	 *
	 * @return array|null { order, appointment_id, payment_id } or null.
	 */
	private function context( $order_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return null;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return null;
		}
		$appointment_id = (int) $order->get_meta( WooCommerceOrderManager::META_APPOINTMENT_ID );
		if ( ! $appointment_id ) {
			return null;
		}
		return array(
			'order'          => $order,
			'appointment_id' => $appointment_id,
			'payment_id'     => (int) $order->get_meta( WooCommerceOrderManager::META_PAYMENT_ID ),
		);
	}

	/**
	 * Payment received — confirm the booking when configured to confirm on payment.
	 *
	 * @param int $order_id The WooCommerce order ID.
	 *
	 * @return void
	 */
	public function on_payment_complete( $order_id ) {
		if ( 'processing' === ( $this->settings()['confirmOn'] ?? 'processing' ) ) {
			$this->confirm( $order_id );
		}
	}

	/**
	 * Order reached "processing" — confirm when configured to confirm on payment.
	 *
	 * Covers gateways (e.g. Cash on Delivery) that move the order straight to
	 * "processing" without firing `woocommerce_payment_complete`. Idempotent, so
	 * it is harmless when `payment_complete` already confirmed the booking.
	 *
	 * @param int $order_id The WooCommerce order ID.
	 *
	 * @return void
	 */
	public function on_processing( $order_id ) {
		if ( 'processing' === ( $this->settings()['confirmOn'] ?? 'processing' ) ) {
			$this->confirm( $order_id );
		}
	}

	/**
	 * Order completed — always confirm the booking.
	 *
	 * @param int $order_id The WooCommerce order ID.
	 *
	 * @return void
	 */
	public function on_completed( $order_id ) {
		$this->confirm( $order_id );
	}

	/**
	 * Order cancelled — cancel the booking (if enabled).
	 *
	 * @param int $order_id The WooCommerce order ID.
	 *
	 * @return void
	 */
	public function on_cancelled( $order_id ) {
		if ( ! empty( $this->settings()['cancelOnCancel'] ) ) {
			$this->cancel( $order_id, __( 'WooCommerce order cancelled.', 'radius-booking-pro' ), 'failed' );
		}
	}

	/**
	 * Order failed — cancel the booking (if enabled).
	 *
	 * @param int $order_id The WooCommerce order ID.
	 *
	 * @return void
	 */
	public function on_failed( $order_id ) {
		if ( ! empty( $this->settings()['cancelOnCancel'] ) ) {
			$this->cancel( $order_id, __( 'WooCommerce payment failed.', 'radius-booking-pro' ), 'failed' );
		}
	}

	/**
	 * Order refunded — cancel the booking (if enabled).
	 *
	 * @param int $order_id The WooCommerce order ID.
	 *
	 * @return void
	 */
	public function on_refunded( $order_id ) {
		if ( ! empty( $this->settings()['cancelOnRefund'] ) ) {
			$this->cancel( $order_id, __( 'WooCommerce order refunded.', 'radius-booking-pro' ), 'refunded' );
		}
	}

	/**
	 * Mark the payment paid, confirm the appointment and fire confirmation emails.
	 *
	 * @param int $order_id The WooCommerce order ID.
	 *
	 * @return void
	 */
	private function confirm( $order_id ) {
		$ctx = $this->context( $order_id );
		if ( ! $ctx ) {
			return;
		}
		$appointment = Appointment::find( $ctx['appointment_id'] );
		if ( ! $appointment || ! $appointment->get_id() ) {
			return;
		}
		if ( 'confirmed' === $appointment->get_status() ) {
			return; // Idempotent — avoid re-sending confirmation emails.
		}

		if ( $ctx['payment_id'] ) {
			$payment = Payment::find( $ctx['payment_id'] );
			if ( $payment ) {
				$total = (float) ( $payment->total_amount ?? 0 );
				$payment->update(
					array(
						'status'         => 'paid',
						'amount'         => $total,
						'due_amount'     => 0,
						'paid_at'        => current_time( 'mysql' ),
						'transaction_id' => $ctx['order']->get_transaction_id() ? $ctx['order']->get_transaction_id() : ( 'wc_order_' . $order_id ),
					)
				);

				// Record the WooCommerce payment in the transaction ledger.
				// Guarded so an older free plugin can't fatal here.
				if ( class_exists( TransactionService::class ) ) {
					TransactionService::record(
						$payment,
						array(
							'gateway'        => 'woocommerce',
							'type'           => 'payment',
							'transaction_id' => $ctx['order']->get_transaction_id() ? $ctx['order']->get_transaction_id() : ( 'wc_order_' . $order_id ),
							'amount'         => $total,
							'status'         => 'completed',
							'notes'          => 'WooCommerce order paid',
						)
					);
				}
			}
		}

		Container::resolve( AppointmentService::class )->confirmAppointment( $ctx['appointment_id'] );
		$this->fire_status_action( $appointment, 'confirmed' );
	}

	/**
	 * Fire the confirm/cancel status action that matches the booking type, so a
	 * meeting or event triggers its own emails/reminders rather than the
	 * service-booking ones. Service bookings keep the original appointment hook.
	 *
	 * @param Appointment $appointment The appointment.
	 * @param string      $state       'confirmed' | 'cancelled'.
	 *
	 * @return void
	 */
	private function fire_status_action( $appointment, $state ) {
		$id   = $appointment->get_id();
		$type = $appointment->booking_type ?? '';

		if ( 'meeting' === $type ) {
			do_action( "radius_booking_meeting_status_{$state}", $id );
			return;
		}
		if ( 'event' === $type ) {
			// A cancel must run the full event-registration lifecycle (release
			// ticket capacity, promote the waitlist, fire the cancellation
			// emails/reminders) — flipping the appointment row alone would leak
			// ticket inventory and skip the emails. On confirm we only signal that
			// the WC payment settled (registration emails already fired at
			// registration time), so we don't double-send them.
			if ( 'cancelled' === $state ) {
				Container::resolve( EventRegistrationService::class )->cancelRegistrationsByAppointment( $id );
			} else {
				do_action( "radius_booking_event_payment_{$state}", $id );
			}
			return;
		}
		do_action( "radius_booking_appointment_status_{$state}", $id );
	}

	/**
	 * Cancel the appointment and mark the payment failed/refunded.
	 *
	 * @param int    $order_id       The WooCommerce order ID.
	 * @param string $reason         Cancellation reason.
	 * @param string $payment_status The payment status to set ('failed' | 'refunded').
	 *
	 * @return void
	 */
	private function cancel( $order_id, $reason, $payment_status ) {
		$ctx = $this->context( $order_id );
		if ( ! $ctx ) {
			return;
		}
		$appointment = Appointment::find( $ctx['appointment_id'] );
		if ( ! $appointment || ! $appointment->get_id() ) {
			return;
		}
		if ( 'cancelled' === $appointment->get_status() ) {
			return; // Idempotent.
		}

		if ( $ctx['payment_id'] ) {
			$payment = Payment::find( $ctx['payment_id'] );
			if ( $payment ) {
				$payment->update(
					array(
						'status'       => $payment_status,
						'cancelled_at' => current_time( 'mysql' ),
					)
				);

				// A genuine refund is a money movement — ledger it. A plain
				// cancellation of an unpaid order ('failed') moves no money.
				if ( 'refunded' === $payment_status && class_exists( TransactionService::class ) ) {
					TransactionService::record(
						$payment,
						array(
							'gateway'        => 'woocommerce',
							'type'           => 'refund',
							'transaction_id' => $ctx['order']->get_transaction_id() ? $ctx['order']->get_transaction_id() : ( 'wc_order_' . $order_id ),
							'amount'         => (float) ( $payment->amount ?? 0 ),
							'status'         => 'refunded',
							'notes'          => 'WooCommerce order refunded',
						)
					);
				}
			}
		}

		Container::resolve( AppointmentService::class )->cancelAppointment( $ctx['appointment_id'], $reason );
		$this->fire_status_action( $appointment, 'cancelled' );
	}
}
