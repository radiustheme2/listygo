<?php
/**
 * Adds a held (pending) booking to the WooCommerce cart and hands the customer
 * off to the standard WooCommerce checkout page.
 */

namespace RadiusTheme\RadiusBookingPro\Integrations\WooCommerce;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Helpers\SettingsHelper;
use RadiusTheme\RadiusBooking\Models\Appointment;
use RadiusTheme\RadiusBooking\Models\CustomerBooking;
use RadiusTheme\RadiusBooking\Models\Payment;
use RadiusTheme\RadiusBooking\Resources\AppointmentResource;
use WP_Error;

/**
 * Puts the booking into the WooCommerce cart (as a line item on a shared hidden
 * "Appointment Booking" product) and returns the checkout URL. WooCommerce owns
 * the checkout form + payment; the WC order is created only when the customer
 * places it, then linked back to the appointment by WooCommerceIntegration.
 */
class WooCommerceOrderManager {

	const PRODUCT_OPTION      = 'rtrb_wc_booking_product_id';

	// Order meta keys — read by WooCommerceIntegration lifecycle hooks.
	const META_APPOINTMENT_ID = '_rtrb_appointment_id';
	const META_PAYMENT_ID     = '_rtrb_payment_id';
	const META_BOOKING_ID     = '_rtrb_booking_id';

	// Cart item data keys (internal, carried from cart → order at checkout).
	const CART_APPOINTMENT_ID  = 'rtrb_appointment_id';
	const CART_PAYMENT_ID      = 'rtrb_payment_id';
	const CART_BOOKING_ID      = 'rtrb_booking_id';
	const CART_PRICE           = 'rtrb_price';
	const CART_LABEL           = 'rtrb_label';
	const CART_CUSTOMER_INFO   = 'rtrb_customer_info';
	const CART_BOOKING_NOTES   = 'rtrb_booking_notes';

	/**
	 * The WooCommerce integration settings block.
	 *
	 * @return array
	 */
	public static function settings(): array {
		$integrations = SettingsHelper::get_setting( 'integrations' );
		return $integrations['woocommerce'] ?? array();
	}

	/**
	 * Add a held appointment to the WooCommerce cart and return the checkout URL.
	 *
	 * @param int $appointment_id The appointment ID.
	 *
	 * @return array|WP_Error { redirect_url, appointment_id } or an error.
	 */
	public function add_to_cart_for_appointment( $appointment_id ) {
		if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_load_cart' ) ) {
			return new WP_Error( 'wc_inactive', __( 'WooCommerce is not active.', 'radius-booking-pro' ) );
		}

		$appointment = Appointment::find( $appointment_id );
		if ( ! $appointment || ! $appointment->get_id() ) {
			return new WP_Error( 'not_found', __( 'Appointment not found.', 'radius-booking-pro' ) );
		}

		$booking          = ( new AppointmentResource() )->transform( $appointment );
		$customer_booking = CustomerBooking::where( 'appointment_id', $appointment_id )->first();
		if ( ! $customer_booking ) {
			return new WP_Error( 'no_booking', __( 'Booking not found for this appointment.', 'radius-booking-pro' ) );
		}
		$payment = Payment::where( 'booking_id', $customer_booking->id )->first();

		// Get the booking amount from the payment record first, then fallback to
		// the customer booking price. Handle null payment gracefully.
		$amount = 0;
		if ( $payment ) {
			$amount = (float) ( $payment->total_amount ?? 0 );
		}
		if ( $amount <= 0 ) {
			$amount = (float) ( $customer_booking->price ?? 0 );
		}

		// Boot the WooCommerce session + cart in this REST context.
		wc_load_cart();
		if ( is_null( WC()->cart ) ) {
			return new WP_Error( 'no_cart', __( 'Unable to initialise the WooCommerce cart.', 'radius-booking-pro' ) );
		}

		// Retry-safe: drop any existing line for this same appointment.
		foreach ( WC()->cart->get_cart() as $key => $item ) {
			if ( isset( $item[ self::CART_APPOINTMENT_ID ] ) && (int) $item[ self::CART_APPOINTMENT_ID ] === (int) $appointment_id ) {
				WC()->cart->remove_cart_item( $key );
			}
		}

		// Line label uses the right name for the booking type (service / meeting / event).
		$booking_type = $booking['booking_type'] ?? '';
		if ( 'meeting' === $booking_type ) {
			$name = $booking['meeting_type_name'] ?? '';
		} elseif ( 'event' === $booking_type ) {
			$name = $booking['event_name'] ?? '';
		} else {
			$name = $booking['service_name'] ?? '';
		}
		if ( empty( $name ) ) {
			$name = __( 'Booking', 'radius-booking-pro' );
		}

		$label = sprintf(
			/* translators: 1: booking name, 2: date, 3: time. */
			__( '%1$s — %2$s at %3$s', 'radius-booking-pro' ),
			$name,
			$booking['appointment_date'] ?? '',
			! empty( $booking['start_time'] ) ? gmdate( 'g:i A', strtotime( $booking['start_time'] ) ) : ''
		);

		// Extract customer info for pre-filling WooCommerce checkout.
		// Note: customer_info may be stored as PHP serialized string or JSON.
		$customer_info = $customer_booking->customer_info ?? array();

		if ( is_string( $customer_info ) ) {
			// Try PHP unserialization first (WordPress often uses this).
			$unserialized = maybe_unserialize( $customer_info );
			if ( is_array( $unserialized ) ) {
				$customer_info = $unserialized;
			} else {
				// Fallback to JSON decode.
				$customer_info = json_decode( $customer_info, true ) ?: array();
			}
		}

		// Get booking notes from the appointment.
		$booking_notes = $appointment->notes ?? '';

		$cart_item_data = array(
			self::CART_APPOINTMENT_ID => (int) $appointment_id,
			self::CART_PAYMENT_ID     => $payment ? (int) $payment->id : 0,
			self::CART_BOOKING_ID     => (int) $customer_booking->id,
			self::CART_PRICE          => $amount,
			self::CART_LABEL          => $label,
			self::CART_CUSTOMER_INFO  => $customer_info,
			self::CART_BOOKING_NOTES  => $booking_notes,
			// Force a unique cart line so WooCommerce never merges two bookings.
			'rtrb_unique'             => $appointment_id . '_' . uniqid(),
		);

		// Also store customer info in WooCommerce session for checkout pre-fill.
		// This ensures the data is available even if cart item data isn't restored.
		if ( WC()->session && ! empty( $customer_info ) ) {
			WC()->session->set( 'rtrb_checkout_customer', $customer_info );
			WC()->session->set( 'rtrb_checkout_notes', $booking_notes );
		}

		// Pre-fill WooCommerce customer billing data directly in session.
		// This persists across the REST API → checkout page redirect.
		if ( WC()->session && ! empty( $customer_info ) ) {
			// Set billing fields directly in session (WooCommerce reads these on checkout).
			if ( ! empty( $customer_info['first_name'] ) ) {
				WC()->session->set( 'billing_first_name', sanitize_text_field( $customer_info['first_name'] ) );
			}
			if ( ! empty( $customer_info['last_name'] ) ) {
				WC()->session->set( 'billing_last_name', sanitize_text_field( $customer_info['last_name'] ) );
			}
			if ( ! empty( $customer_info['email'] ) ) {
				WC()->session->set( 'billing_email', sanitize_email( $customer_info['email'] ) );
			}
			if ( ! empty( $customer_info['phone'] ) ) {
				WC()->session->set( 'billing_phone', sanitize_text_field( $customer_info['phone'] ) );
			}
		}

		// Also set on WC()->customer object for Store API / Block Checkout.
		if ( WC()->customer && ! empty( $customer_info ) ) {
			$wc_customer = WC()->customer;

			if ( ! empty( $customer_info['first_name'] ) ) {
				$wc_customer->set_billing_first_name( sanitize_text_field( $customer_info['first_name'] ) );
			}
			if ( ! empty( $customer_info['last_name'] ) ) {
				$wc_customer->set_billing_last_name( sanitize_text_field( $customer_info['last_name'] ) );
			}
			if ( ! empty( $customer_info['email'] ) ) {
				$wc_customer->set_billing_email( sanitize_email( $customer_info['email'] ) );
			}
			if ( ! empty( $customer_info['phone'] ) ) {
				$wc_customer->set_billing_phone( sanitize_text_field( $customer_info['phone'] ) );
			}

			// Save customer data to persist in session.
			$wc_customer->save();
		}

		// Store price in transient as backup (in case WC session doesn't persist custom
		// cart item data across the REST API → checkout page redirect).
		set_transient( 'rtrb_wc_price_' . $appointment_id, $amount, HOUR_IN_SECONDS );

		$added = WC()->cart->add_to_cart( $this->get_booking_product_id(), 1, 0, array(), $cart_item_data );
		if ( ! $added ) {
			return new WP_Error( 'cart_failed', __( 'Could not add the booking to the cart.', 'radius-booking-pro' ) );
		}

		WC()->cart->calculate_totals();
		WC()->cart->set_session();
		if ( WC()->session ) {
			// Emit the session cookie on this REST response so /checkout/ sees the cart.
			WC()->session->set_customer_session_cookie( true );
		}

		// Honor the "Redirect customer to" setting: checkout (default) or cart.
		$redirect_to  = self::settings()['redirectTo'] ?? 'checkout';
		$redirect_url = ( 'cart' === $redirect_to ) ? wc_get_cart_url() : wc_get_checkout_url();

		return array(
			'redirect_url'   => $redirect_url,
			'appointment_id' => $appointment_id,
		);
	}

	/**
	 * Get (or lazily create) the shared hidden "Appointment Booking" product used
	 * to carry the dynamic booking line item. Must be published so WooCommerce
	 * treats it as purchasable, but hidden from the shop/search catalog.
	 *
	 * @return int The product ID.
	 */
	private function get_booking_product_id(): int {
		$product_id = (int) get_option( self::PRODUCT_OPTION );
		if ( $product_id ) {
			$product = wc_get_product( $product_id );
			if ( $product ) {
				// Coerce legacy 'private' products to a purchasable published state.
				if ( 'publish' !== $product->get_status() || 'hidden' !== $product->get_catalog_visibility() ) {
					$product->set_status( 'publish' );
					$product->set_catalog_visibility( 'hidden' );
					$product->save();
				}
				return $product_id;
			}
		}

		$product = new \WC_Product_Simple();
		$product->set_name( __( 'Appointment Booking', 'radius-booking-pro' ) );
		$product->set_status( 'publish' );
		$product->set_catalog_visibility( 'hidden' );
		$product->set_virtual( true );
		$product->set_sold_individually( true );
		$product->set_regular_price( 0 );
		$product->set_price( 0 );
		$product->save();

		update_option( self::PRODUCT_OPTION, $product->get_id() );
		return $product->get_id();
	}
}
