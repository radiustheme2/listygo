<?php
/**
 * Class ZoomIntegration
 *
 * Handles integration with the Zoom API for creating meetings, retrieving user details, and managing
 * authentication tokens.
 */
namespace RadiusTheme\RadiusBookingPro\Integrations;

use RadiusTheme\RadiusBooking\Models\Settings;
use RadiusTheme\RadiusBooking\Emails\EmailSender;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
/**
 * Class ZoomIntegration
 *
 * Handles the integration with the Zoom API, allowing for the retrieval of user information, creation
 * of meetings, and management of OAuth access tokens. Provides functionality to interact with Zoom's
 * REST API efficiently while ensuring proper authentication and error handling.
 */
class ZoomIntegration {

	/**
	 * Zoom API account credentials and configuration.
	 *
	 * @var array
	 */
	private $account_id;

	/**
	 * The Zoom client ID associated with the OAuth app.
	 *
	 * @var string
	 */
	private $client_id;

	/**
	 * The Zoom client secret associated with the OAuth app.
	 *
	 * @var string
	 */
	private $client_secret;

	/**
	 * The OAuth access token used to authenticate API requests.
	 *
	 * @var string|null
	 */
	private $access_token;

	/**
	 * The base URL for Zoom API requests.
	 *
	 * @var string
	 */
	private $base_url = 'https://api.zoom.us/v2';


	/**
	 * Constructor method for initializing the class.
	 *
	 * Sets up integrations and credentials required for Zoom API interaction.
	 * Registers a webhook endpoint with WordPress REST API if the integration is enabled.
	 *
	 * @return void|false Returns false if Zoom integration is not enabled.
	 */
	public function __construct() {
		$settings     = new Settings();
		$integrations = $settings->getNestedKey( 'integrations.zoom', false );
		if ( ! $integrations['enabled'] ) {
			return false;
		}
		// Get credentials from options
		$this->account_id    = $integrations['accountId'];
		$this->client_id     = $integrations['clientId'];
		$this->client_secret = $integrations['clientSecret'];
		$this->access_token  = get_option( 'rtrb_zoom_access_token' );

		// Hooks
		add_action( 'rest_api_init', array( $this, 'register_webhook_endpoint' ) );
	}

	/**
	 * Retrieve or generate a new access token for Zoom API requests.
	 *
	 * @return string|false The Zoom access token if successfully retrieved or generated, false on failure.
	 */
	private function get_access_token() {
		// Check if token is still valid

		$token_expires = get_option( 'rtrb_zoom_token_expires', 0 );
		if ( $this->access_token && time() < ( $token_expires - 300 ) ) {
			return $this->access_token;
		}

		// Generate new token
		$auth_string = base64_encode( $this->client_id . ':' . $this->client_secret );

		$response = wp_remote_post(
			'https://zoom.us/oauth/token',
			array(
				'headers' => array(
					'Authorization' => 'Basic ' . $auth_string,
					'Content-Type'  => 'application/x-www-form-urlencoded',
				),
				'body'    => http_build_query(
					array(
						'grant_type' => 'account_credentials',
						'account_id' => $this->account_id,
					)
				),
				'timeout' => 10,
			)
		);
		if ( is_wp_error( $response ) ) {
			error_log( 'Zoom OAuth Error: ' . $response->get_error_message() );
			return false;
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		$body        = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $status_code !== 200 ) {
			error_log( 'Zoom OAuth Failed - Status: ' . $status_code . ' - Response: ' . print_r( $body, true ) ); //phpcs:ignore
		}

		if ( isset( $body['access_token'] ) ) {
			$this->access_token = $body['access_token'];
			update_option( 'rtrb_zoom_access_token', $body['access_token'] );
			update_option( 'rtrb_zoom_token_expires', time() + $body['expires_in'] );
			return $this->access_token;
		}

		return false;
	}

	/**
	 * Makes a request to the specified API endpoint.
	 *
	 * @param string $endpoint The API endpoint to request.
	 * @param string $method The HTTP method to use for the request. Defaults to 'GET'.
	 * @param array $data Optional. The data to send with the request for applicable methods (e.g., POST, PATCH, PUT). Defaults to an empty array.
	 *
	 * @return array The response from the API, including the status code and response data. Returns an error array if the request fails.
	 */
	private function make_request( $endpoint, $method = 'GET', $data = array() ) {
		$token = $this->get_access_token();

		if ( ! $token ) {
			return array( 'error' => __( 'Failed to get access token', 'radius-booking-pro' ) );
		}

		$url = $this->base_url . $endpoint;

		$args = array(
			'method'  => $method,
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => 'application/json',
			),
			'timeout' => 10,
		);

		if ( ( $method === 'POST' || $method === 'PATCH' || $method === 'PUT' ) && ! empty( $data ) ) {
			$args['body'] = json_encode( $data, JSON_UNESCAPED_SLASHES );
		}

		$response = wp_remote_request( $url, $args );
		if ( is_wp_error( $response ) ) {
			error_log( 'Zoom API Error: ' . $response->get_error_message() );
			return array( 'error' => $response->get_error_message() );
		}

		$body        = wp_remote_retrieve_body( $response );
		$status_code = wp_remote_retrieve_response_code( $response );

		if ( $status_code >= 400 ) {
			error_log( 'Zoom API Error - Status: ' . $status_code . ' - Response: ' . $body );
		}

		if ( $status_code === 204 ) {
			return array(
				'status_code' => $status_code,
				'data'        => array( 'success' => true ),
			);
		}

		return array(
			'status_code' => $status_code,
			'data'        => json_decode( $body, true ),
		);
	}

	/**
	 * Retrieve user details.
	 *
	 * @param string $user_id The ID of the user to retrieve. Defaults to 'me'.
	 *
	 * @return mixed Returns the user's data if the request is successful, or false on failure.
	 */
	public function get_user( $user_id = 'me' ) {
		$response = $this->make_request( '/users/' . $user_id, 'GET' );

		if ( $response['status_code'] === 200 ) {
			return $response['data'];
		}

		return false;
	}

	/**
	 * Create a new meeting for a specified user with given configurations.
	 *
	 * @param string $user_id The unique identifier of the user who will host the meeting.
	 * @param string $topic The title or subject of the meeting.
	 * @param string $start_time_utc The start time of the meeting in UTC ISO 8601 format.
	 * @param array $service_settings An array of service settings.
	 * @param int $duration Optional. The duration of the meeting in minutes, with a default value of 60.
	 * @param array $invitees Optional. A list of email addresses to be invited as participants.
	 * @param string $description Optional. A textual description or agenda for the meeting.
	 *
	 * @return array|false Returns an array containing the meeting details if creation is successful, otherwise an error array.
	 */
	public function create_meeting( $user_id, $topic, $start_time_utc, $service_settings, $duration = 60, $invitees = array(), $description = '', $appointment_context = array() ) {
		if ( empty( $topic ) ) {
			return array( 'error' => __( 'Meeting topic is required', 'radius-booking-pro' ) );
		}

		if ( empty( $start_time_utc ) ) {
			return array( 'error' => __( 'Start time is required', 'radius-booking-pro' ) );
		}

		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/', $start_time_utc ) ) {
			$timestamp = strtotime( $start_time_utc );
			if ( $timestamp ) {
				$start_time_utc = gmdate( 'Y-m-d\TH:i:s\Z', $timestamp );
			} else {
				return array( 'error' => __( 'Invalid start time format', 'radius-booking-pro' ) );
			}
		}

		$duration = (int) max( 15, $duration );

		$settings = array(
			'host_video'        => true,
			'participant_video' => true,
			'join_before_host'  => true,
			'mute_upon_entry'   => false,
			'approval_type'     => 2,
			'audio'             => 'both',
			'auto_recording'    => 'none',
			'waiting_room'      => (bool) $service_settings['enableWaitingRoom'],
		);

		if ( $service_settings['requirePassword'] ) {
			$settings['password'] = $this->generate_meeting_password();
		}

		$meeting_data = array(
			'topic'      => sanitize_text_field( $topic ),
			'type'       => 2,
			'start_time' => $start_time_utc,
			'duration'   => $duration,
			'timezone'   => 'UTC',
			'agenda'     => sanitize_textarea_field( $description ?? __( 'Appointment via Radius Booking', 'radius-booking-pro' ) ),
			'settings'   => $settings,
		);

		$response = $this->make_request( '/users/' . urlencode( $user_id ) . '/meetings', 'POST', $meeting_data );

		if ( $response['status_code'] === 201 && isset( $response['data']['id'] ) ) {
			$meeting    = $response['data'];
			$meeting_id = $meeting['id'];

			if ( ! empty( $invitees ) ) {
				foreach ( $invitees as $email ) {
					try {
						$this->make_request(
							"/meetings/{$meeting_id}/registrants",
							'POST',
							array(
								'email'      => sanitize_email( $email ),
								'first_name' => '',
								'last_name'  => '',
							)
						);
					} catch ( Exception $e ) {
						error_log( 'Zoom registrant add failed: ' . $e->getMessage() );
					}
				}
			}

			if ( $service_settings['sendInviteEmail'] && ! empty( $invitees ) ) {
				$this->send_meeting_invites( $meeting, $invitees, $appointment_context );
			}

			return $meeting;
		}

		return array(
			'error'       => __( 'Failed to create meeting', 'radius-booking-pro' ),
			'status_code' => $response['status_code'] ?? 0,
			'data'        => $response['data'] ?? array(),
		);
	}

	/**
	 * Retrieves the details of a meeting by its ID.
	 *
	 * @param int|string $meeting_id The ID of the meeting to retrieve.
	 *
	 * @return array|false Returns an array containing the meeting data if the request is successful, or false otherwise.
	 */
	public function get_meeting( $meeting_id ) {
		$response = $this->make_request( '/meetings/' . $meeting_id, 'GET' );
		return ( $response['status_code'] === 200 ) ? $response['data'] : false;
	}

	/**
	 * Updates the details of a meeting by its ID.
	 *
	 * @param int|string $meeting_id The ID of the meeting to update.
	 * @param array $data An associative array containing the meeting data to be updated.
	 *
	 * @return bool Returns true if the update request is successful, or false otherwise.
	 */
	public function update_meeting( $meeting_id, $data ) {
		$response = $this->make_request( '/meetings/' . $meeting_id, 'PATCH', $data );
		return ( $response['status_code'] === 204 );
	}

	/**
	 * Lists meetings for a specific user and type.
	 *
	 * @param int|string $user_id The ID of the user whose meetings are being listed.
	 * @param string $type The type of meetings to retrieve. Default is 'scheduled'.
	 *
	 * @return array Returns an array of meetings if the request is successful, or an empty array otherwise.
	 */
	public function list_meetings( $user_id, $type = 'scheduled' ) {
		$response = $this->make_request( '/users/' . $user_id . '/meetings?type=' . $type, 'GET' );
		return ( $response['status_code'] === 200 ) ? $response['data']['meetings'] : array();
	}

	/**
	 * Generates a random password for a meeting.
	 *
	 * @param int $length The desired length of the generated password. Defaults to 10.
	 *
	 * @return string Returns a randomly generated password string with the specified length.
	 */
	private function generate_meeting_password( $length = 10 ) {
		return substr( str_shuffle( '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ' ), 0, $length );
	}

	/**
	 * Sends meeting invites to a list of invitees via email.
	 *
	 * @param array $meeting_data An associative array containing meeting details.
	 * @param string|array $invitees A single email address or an array of email addresses.
	 *
	 * @return void
	 */
	private function send_meeting_invites( $meeting_data, $invitees, $appointment_context = array() ) {
		if ( empty( $invitees ) ) {
			return;
		}

		$invitees = is_array( $invitees ) ? $invitees : array( $invitees );

		foreach ( $invitees as $email ) {
			if ( ! is_email( $email ) ) {
				continue;
			}

			$subject = '[Zoom Meeting] ' . $meeting_data['topic'];
			$message = $this->get_invite_email_html( $meeting_data, $appointment_context );

			EmailSender::send( $email, $subject, $message );
		}
	}

	/**
	 * Generates an HTML-formatted email invitation for a Zoom meeting
	 * including full appointment details.
	 *
	 * @param array $meeting            Zoom meeting details from API response.
	 * @param array $appointment_context Appointment context with keys:
	 *   appointment_id, service_name, employee_name, customer_name,
	 *   customer_email, appointment_date, start_time, duration, location.
	 *
	 * @return string HTML content for the email invitation.
	 */
	private function get_invite_email_html( $meeting, $appointment_context = array() ) {
		$site_tz_string = $appointment_context['site_timezone'] ?? wp_timezone_string();
		$staff_tz_string = $appointment_context['staff_timezone'] ?? '';

		$html = '<html><body style="font-family: Arial, sans-serif; color: #333; max-width: 600px; margin: 0 auto;">';

		// ── Appointment Details ──
		if ( ! empty( $appointment_context ) ) {
			$html .= '<h2 style="color: #1a1a2e; margin-bottom: 5px;">Appointment Confirmation</h2>';
			$html .= '<p style="color: #666; margin-top: 0;">A Zoom meeting has been created for your upcoming appointment.</p>';

			$html .= '<table style="width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 14px;">';

			$rows = array();

			if ( ! empty( $appointment_context['appointment_id'] ) ) {
				$rows[] = array( 'Appointment ID', '#' . $appointment_context['appointment_id'] );
			}

			if ( ! empty( $appointment_context['service_name'] ) ) {
				$rows[] = array( 'Service', $appointment_context['service_name'] );
			}

			if ( ! empty( $appointment_context['employee_name'] ) ) {
				$staff_label = $appointment_context['employee_name'];
				if ( ! empty( $appointment_context['employee_email'] ) ) {
					$staff_label .= ' (' . $appointment_context['employee_email'] . ')';
				}
				$rows[] = array( 'Staff', $staff_label );
			}

			if ( ! empty( $appointment_context['customer_name'] ) ) {
				$customer_label = $appointment_context['customer_name'];
				if ( ! empty( $appointment_context['customer_email'] ) ) {
					$customer_label .= ' (' . $appointment_context['customer_email'] . ')';
				}
				$rows[] = array( 'Customer', $customer_label );
			}

			// Date & Time — always in site timezone with label.
			if ( ! empty( $appointment_context['appointment_date'] ) ) {
				$local_datetime = $appointment_context['appointment_date'];
				if ( ! empty( $appointment_context['start_time'] ) ) {
					$local_datetime .= ' ' . $appointment_context['start_time'];
				}

				$timestamp = strtotime( $local_datetime );
				if ( $timestamp ) {
					try {
						$site_tz   = new \DateTimeZone( $site_tz_string );
						$dt        = new \DateTime( $local_datetime, $site_tz );
						$tz_abbrev = $dt->format( 'T' ); // e.g. "EST", "PST"

						$formatted = wp_date( 'F j, Y \a\t g:i A', $timestamp ) . ' (' . $tz_abbrev . ')';
						$rows[]    = array( 'Date & Time', $formatted );

						// If staff has a different timezone, show their local time too.
						if ( $staff_tz_string && $staff_tz_string !== $site_tz_string ) {
							$staff_tz   = new \DateTimeZone( $staff_tz_string );
							$staff_dt   = clone $dt;
							$staff_dt->setTimezone( $staff_tz );
							$staff_time = $staff_dt->format( 'F j, Y \a\t g:i A' ) . ' (' . $staff_dt->format( 'T' ) . ')';
							$rows[]     = array( 'Staff Local Time', $staff_time );
						}
					} catch ( \Exception $e ) {
						// Fallback: show without timezone label.
						$rows[] = array( 'Date & Time', wp_date( 'F j, Y \a\t g:i A', $timestamp ) );
					}
				}
			}

			if ( ! empty( $appointment_context['duration'] ) ) {
				$rows[] = array( 'Duration', $appointment_context['duration'] . ' ' . __( 'minutes', 'radius-booking-pro' ) );
			}

			if ( ! empty( $appointment_context['location'] ) ) {
				$rows[] = array( 'Location', $appointment_context['location'] );
			}

			foreach ( $rows as $row ) {
				$html .= '<tr>';
				$html .= '<td style="padding: 8px 12px; border-bottom: 1px solid #eee; color: #666; width: 150px;"><strong>' . esc_html( $row[0] ) . '</strong></td>';
				$html .= '<td style="padding: 8px 12px; border-bottom: 1px solid #eee;">' . esc_html( $row[1] ) . '</td>';
				$html .= '</tr>';
			}

			$html .= '</table>';
			$html .= '<hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;">';
		}

		// ── Zoom Meeting Details ──
		$html .= '<h3 style="color: #2D8CFF; margin-bottom: 10px;">Zoom Meeting Details</h3>';
		$html .= '<table style="width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 14px;">';

		// Convert Zoom UTC time to the site timezone — same time as appointment.
		if ( isset( $meeting['start_time'] ) ) {
			try {
				$utc_dt = new \DateTime( $meeting['start_time'], new \DateTimeZone( 'UTC' ) );
				$utc_dt->setTimezone( new \DateTimeZone( $site_tz_string ) );
				$meeting_time = $utc_dt->format( 'F j, Y \a\t g:i A' ) . ' (' . $utc_dt->format( 'T' ) . ')';
			} catch ( \Exception $e ) {
				$meeting_time = gmdate( 'F j, Y \a\t g:i A', strtotime( $meeting['start_time'] ) ) . ' (UTC)';
			}
			$html .= '<tr><td style="padding: 6px 12px; color: #666; width: 150px;"><strong>Meeting Time</strong></td>';
			$html .= '<td style="padding: 6px 12px;">' . esc_html( $meeting_time ) . '</td></tr>';
		}

		$html .= '<tr><td style="padding: 6px 12px; color: #666;"><strong>Meeting ID</strong></td>';
		$html .= '<td style="padding: 6px 12px;">' . esc_html( $meeting['id'] ) . '</td></tr>';

		if ( isset( $meeting['password'] ) ) {
			$html .= '<tr><td style="padding: 6px 12px; color: #666;"><strong>Password</strong></td>';
			$html .= '<td style="padding: 6px 12px;">' . esc_html( $meeting['password'] ) . '</td></tr>';
		}

		$html .= '</table>';

		$html .= '<p style="margin-top: 16px;"><a href="' . esc_url( $meeting['join_url'] ) . '" style="background:#2D8CFF;color:white;padding:12px 24px;text-decoration:none;border-radius:4px;display:inline-block;font-weight:600;">Join Zoom Meeting</a></p>';
		$html .= '<p style="color:#888;font-size:12px;margin-top:16px;">Or copy this link: ' . esc_url( $meeting['join_url'] ) . '</p>';
		$html .= '</body></html>';

		return $html;
	}

	/**
	 * Registers the REST API endpoint for handling webhook events.
	 *
	 * @return void
	 */
	public function register_webhook_endpoint() {
		register_rest_route(
			'radius-booking/zoom/v1',
			'/webhook',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_webhook' ),
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
			)
		);
	}

	/**
	 * Handles incoming webhook requests and processes the event accordingly.
	 *
	 * @param WP_REST_Request $request The incoming webhook request containing event data.
	 *
	 * @return WP_REST_Response Returns a response object indicating the status of the webhook handling.
	 */
	public function handle_webhook( $request ) {
		$body       = $request->get_json_params();
		$event_type = $body['event'] ?? '';

		switch ( $event_type ) {
			case 'meeting.started':
			case 'meeting.ended':
				global $wpdb;
				$status = ( $event_type === 'meeting.started' ) ? 'started' : 'ended';
				$wpdb->update(
					$wpdb->prefix . 'zoom_meetings',
					array( 'status' => $status ),
					array( 'meeting_id' => $body['payload']['object']['id'] )
				);
				do_action( 'rtrb_zoom_' . str_replace( '.', '_', $event_type ), $body['payload'] );
				break;
		}

		return new \WP_REST_Response( array( 'status' => 'success' ), 200 );
	}
}
