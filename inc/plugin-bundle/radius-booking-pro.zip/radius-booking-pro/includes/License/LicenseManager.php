<?php
namespace  RadiusTheme\RadiusBookingPro\License;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Manages license validation for a plugin using the Easy Digital Downloads (EDD) licensing system.
 *
 * @since 1.0.0
 */
class LicenseManager
{

	/**
	 * @var string The action to perform (e.g., activate, deactivate, check).
	 *
	 * @since 1.0.0
	 */
	protected $action;

	/**
	 * @var int The ID of the item in RadiusTheme.
	 *
	 * @since 1.0.0
	 */
	protected $item_id;

	/**
	 * @var string The license key.
	 *
	 * @since 1.0.0
	 */
	protected $license;

	/**
	 * @var string The URL of the Licensing server.
	 *
	 * @since 1.0.0
	 */
	protected $request_server;

	/**
	 * @var string The URL of the Licensing proxy server.
	 *
	 * @since 1.0.0
	 */
	protected $proxy_server;

	/**
	 * @var string The name of the plugin.
	 *
	 * @since 1.0.0
	 */
	protected $plugin_name;

	/**
	 * @var array Error messages for different license validation outcomes.
	 *
	 * @since 1.0.0
	 */
	protected $error_messages;

	/**
	 * @var mixed The response data received after license validation.
	 *
	 * @since 1.0.0
	 */
	protected $response_data;


	/**
	 * Constructs a new LicenseManager instance.
	 *
	 * Initializes the LicenseManager object with provided parameters.
	 *
	 * @param string $action         The action to perform (e.g., activate, deactivate, check).
	 * @param int    $item_id        The ID of the item in RadiusTheme.
	 * @param string $license        The license key.
	 * @param string $plugin_name    The name of the plugin.
	 * @param string $request_server The URL of the custom API server.
	 * @param string $proxy_server The URL of the custom API server.
	 *
	 * @since 1.0.0
	 */
	public function __construct( $action, $item_id, $license, $plugin_name, $request_server, $proxy_server = null )
	{
		$this->action         = $action;
		$this->item_id        = $item_id;
		$this->license        = $license;
		$this->plugin_name    = $plugin_name;
		$this->request_server = esc_url( $request_server );
		$this->proxy_server   = esc_url( $proxy_server );
	}
	/**
	 * Validates the license by making a request to the EDD licensing API.
	 *
	 * This method constructs API parameters and sends a POST request to the EDD licensing API endpoint.
	 * It sets the response data property with the result of the API call.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function validate_license() {
		$api_params = [
			'edd_action' => $this->action,
			'license'    => $this->license,
			'item_id'    => $this->item_id, // The ID of the item in RadiusTheme
			'url'        => home_url()
		];

		$license_url = $this->request_server;

		//check if license url is working
		$server_status = wp_remote_get( $license_url );

		if( is_wp_error( $server_status ) || empty( $server_status['response']['code'] ) || 200 != $server_status['response']['code'] ) {
			$license_url = $this->proxy_server;
		}

		// Call the custom API.
		$this->response_data = wp_remote_post(
			$license_url,
			[
				'body'      => $api_params,
				'timeout'   => 15,
				'sslverify' => false,
			]
		);
	}

	/**
	 * Retrieves the response data after license validation.
	 *
	 * This method checks the response data received from the license validation request.
	 * It sets the success status and message based on the response.
	 *
	 * @since 1.0.0
	 *
	 * @return array The response data containing success status, license status, message, and response data.
	 */
	public function get_response()
	{
		$success  = false;
		$message = '';

		$this->load_response_messages();

		if (is_wp_error($this->response_data) || 200 !== wp_remote_retrieve_response_code($this->response_data)) {
			$message = (is_wp_error($this->response_data) && !empty($this->response_data->get_error_message())) ? $this->response_data->get_error_message() : $this->error_messages[ 'default' ];
		}
		else {
			$license_data = json_decode(wp_remote_retrieve_body($this->response_data));
			if ( !empty( $license_data->success ) ) {
				$success = true;
			}
			else {
				$message = $this->error_messages[$license_data->error] ?? $this->error_messages['default'];
			}
		}

		if ( empty( $message ) ) {
			$message = $this->error_messages[ $this->action ] ?? $this->error_messages[ 'default' ];
		}

		return [
			'success'        => $success,
			'license_status' => $license_data->license ?? 'invalid',
			'message'        => $message,
			'response_data'  => $license_data ?? []
		];
	}

	protected function load_response_messages()
	{
		$this->error_messages = [
			'activate'            => __( 'Your license has been successfully activated.', 'radius-booking-pro' ),
			'deactivate'          => __( 'Your license has been successfully deactivated.', 'radius-booking-pro' ),
			'check'               => __( 'Your license has been successfully validated.', 'radius-booking-pro' ),
			'revoked'             => __( 'Your license key has been disabled.', 'radius-booking-pro' ),
			'missing'             => __( 'Your license key has been disabled.', 'radius-booking-pro' ),
			'invalid'             => __( 'Your license is not active for this URL.', 'radius-booking-pro' ),
			'site_inactive'       => __( 'Your license is not active for this URL.', 'radius-booking-pro' ),
			/* translators: %s: plugin name */
			'item_name_mismatch'  => sprintf( __( 'This appears to be an invalid license key for %s.', 'radius-booking-pro' ), $this->plugin_name ),
			'no_activations_left' => __( 'Your license key has reached its activation limit.', 'radius-booking-pro' ),
			'deactivated'         => __( 'Your license successfully deactivate.', 'radius-booking-pro' ),
			'failed'              => __( 'Your license deactivation failed.', 'radius-booking-pro' ),
			'default'             => __( 'An unknown error occurred, please try again.', 'radius-booking-pro' ),
		];

		if ( !empty( $this->response_data->expires ) ) {
			$this->error_messages[ 'expired' ] = sprintf(
				/* translators: %s: license expiry date */
				__( 'Your license key expired on %s.', 'radius-booking-pro' ),
				date_i18n(
					get_option('date_format'),
					strtotime( $this->response_data->expires, current_time('timestamp'))
				)
			);
		}
	}
}
