<?php
/**
 * BookingExtra Model
 *
 * @package RadiusTheme\RadiusBookingPro\Models
 */

namespace RadiusTheme\RadiusBookingPro\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseModel;

/**
 * Class BookingExtra
 *
 * Stores a snapshot of selected extras for a booking.
 * This preserves historical pricing even if extras are later modified.
 *
 * @package RadiusTheme\RadiusBookingPro\Models
 *
 * @property int    $id
 * @property int    $booking_id
 * @property int    $extra_id
 * @property string $title
 * @property float  $unit_price
 * @property int    $duration
 * @property int    $quantity
 * @property float  $total_price
 * @property string $created_at
 * @property string $updated_at
 */
class BookingExtra extends BaseModel {

	/**
	 * The database table associated with the model.
	 *
	 * @var string
	 */
	protected string $table = 'radius_booking_booking_extras';

	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected array $fillable = array(
		'booking_id',
		'extra_id',
		'title',
		'unit_price',
		'duration',
		'quantity',
		'total_price',
	);

	/**
	 * The attributes that should be cast.
	 *
	 * @var array
	 */
	protected array $casts = array(
		'booking_id'  => 'integer',
		'extra_id'    => 'integer',
		'unit_price'  => 'float',
		'duration'    => 'integer',
		'quantity'    => 'integer',
		'total_price' => 'float',
	);

	/**
	 * Get the total duration for this booking extra.
	 *
	 * @return int Total duration in minutes (unit duration * quantity).
	 */
	public function getTotalDuration(): int {
		return (int) $this->duration * (int) $this->quantity;
	}
}
