<?php
/**
 * Coupon Model
 */

namespace RadiusTheme\RadiusBookingPro\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseModel;

/**
 * Class Coupon
 *
 * @package RadiusTheme\RadiusBookingPro\Models
 *
 * @property int    $id
 * @property string $code
 * @property string $description
 * @property string $discount_type
 * @property float  $discount_value
 * @property int    $max_uses
 * @property int    $usage_count
 * @property string $start_date
 * @property string $end_date
 * @property float  $min_amount
 * @property float  $max_discount
 * @property string $applicable_services
 * @property bool   $auto_apply
 * @property string $status
 * @property int    $created_by
 */
class Coupon extends BaseModel {

	/**
	 * The database table associated with the model.
	 *
	 * @var string
	 */
	protected string $table = 'radius_booking_coupons';

	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected array $fillable = array(
		'code',
		'description',
		'discount_type',
		'discount_value',
		'max_uses',
		'usage_count',
		'start_date',
		'end_date',
		'min_amount',
		'max_discount',
		'applicable_services',
		'auto_apply',
		'status',
		'created_by',
	);

	/**
	 * The attributes that should be cast.
	 *
	 * @var array
	 */
	protected array $casts = array(
		'discount_value' => 'float',
		'max_uses'       => 'integer',
		'usage_count'    => 'integer',
		'min_amount'     => 'float',
		'max_discount'   => 'float',
		'auto_apply'     => 'boolean',
	);

	/**
	 * Check if the coupon is valid for the given service and amount.
	 *
	 * @param int|null $serviceId The service ID to check against.
	 * @param float    $amount    The order amount to validate.
	 *
	 * @return array{valid: bool, message: string}
	 */
	public function isValid( $serviceId = null, $amount = 0 ) {
		if ( 'active' !== $this->status ) {
			return array(
				'valid'   => false,
				'message' => __( 'This coupon is inactive.', 'radius-booking-pro' ),
			);
		}

		$today     = gmdate( 'Y-m-d' );
		$startDate = $this->start_date && '0000-00-00' !== $this->start_date ? $this->start_date : null;
		$endDate   = $this->end_date && '0000-00-00' !== $this->end_date ? $this->end_date : null;

		if ( $startDate && $today < $startDate ) {
			return array(
				'valid'   => false,
				'message' => __( 'This coupon is not yet active.', 'radius-booking-pro' ),
			);
		}

		if ( $endDate && $today > $endDate ) {
			return array(
				'valid'   => false,
				'message' => __( 'This coupon has expired.', 'radius-booking-pro' ),
			);
		}

		if ( $this->max_uses && $this->usage_count >= $this->max_uses ) {
			return array(
				'valid'   => false,
				'message' => __( 'This coupon has reached its usage limit.', 'radius-booking-pro' ),
			);
		}

		if ( $this->min_amount > 0 && $amount < $this->min_amount ) {
			return array(
				'valid'   => false,
				'message' => sprintf(
					/* translators: %s: minimum amount */
					__( 'Minimum order amount of %s required.', 'radius-booking-pro' ),
					$this->min_amount
				),
			);
		}

		if ( $serviceId && $this->applicable_services ) {
			$services = json_decode( $this->applicable_services, true );
			if ( is_array( $services ) && ! empty( $services ) && ! in_array( (int) $serviceId, array_map( 'intval', $services ), true ) ) {
				return array(
					'valid'   => false,
					'message' => __( 'This coupon is not applicable for the selected service.', 'radius-booking-pro' ),
				);
			}
		}

		return array(
			'valid'   => true,
			'message' => __( 'Coupon is valid.', 'radius-booking-pro' ),
		);
	}
}