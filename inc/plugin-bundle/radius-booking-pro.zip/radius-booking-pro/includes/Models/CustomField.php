<?php

namespace RadiusTheme\RadiusBookingPro\Models;

use RadiusTheme\RadiusBooking\Abstracts\BaseModel;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
/**
 * Class CustomField
 *
 * @package RadiusTheme\RadiusBookingPro\Models
 *
 * @property int    $id
 * @property string $label
 * @property string $type
 * @property array  $options
 * @property string $placeholder
 * @property bool   $required
 * @property bool   $is_active
 * @property int    $sort_order
 * @property array  $services       Array of service IDs (empty/null = applies to all services
 *                                  when 'service' is in applies_to).
 * @property array  $applies_to     Which resource types this field applies to. Subset of
 *                                  ['service','meeting_type','event']. Existing rows upgraded
 *                                  via migration default to ['service'].
 * @property array  $meeting_types  Array of meeting type IDs (empty/null = all meetings when
 *                                  'meeting_type' is in applies_to).
 * @property array  $events         Array of event IDs (empty/null = all events when 'event'
 *                                  is in applies_to).
 */
class CustomField extends BaseModel {

	/**
	 * The database table associated with the model.
	 *
	 * @var string
	 */
	protected string $table = 'radius_booking_custom_fields';

	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected array $fillable = array(
		'label',
		'type',
		'options',
		'placeholder',
		'required',
		'is_active',
		'sort_order',
		'services',
		'applies_to',
		'meeting_types',
		'events',
	);

	/**
	 * The validation rules.
	 *
	 * @var array
	 */
	protected array $rules = array(
		'label' => 'required|string|max:255',
	);

	/**
	 * The attributes that should be cast to native types.
	 *
	 * @var array|string[]
	 */
	protected array $casts = array(
		'options'       => 'json',
		'services'      => 'json',
		'applies_to'    => 'json',
		'meeting_types' => 'json',
		'events'        => 'json',
		'required'      => 'boolean',
		'is_active'     => 'boolean',
	);
}
