<?php
/**
 * DynamicPricingRule Model
 */

namespace RadiusTheme\RadiusBookingPro\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseModel;

/**
 * Class DynamicPricingRule
 *
 * @package RadiusTheme\RadiusBookingPro\Models
 *
 * @property int    $id
 * @property string $name
 * @property string $description
 * @property string $rule_type
 * @property string $adjustment_type
 * @property float  $adjustment_value
 * @property string $conditions
 * @property string $applicable_services
 * @property int    $priority
 * @property bool   $is_active
 * @property int    $created_by
 * @property string $created_at
 * @property string $updated_at
 */
class DynamicPricingRule extends BaseModel {

	/**
	 * The database table associated with the model.
	 *
	 * @var string
	 */
	protected string $table = 'radius_booking_dynamic_pricing_rules';

	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected array $fillable = array(
		'name',
		'description',
		'rule_type',
		'adjustment_type',
		'adjustment_value',
		'conditions',
		'applicable_services',
		'priority',
		'is_active',
		'created_by',
	);

	/**
	 * The attributes that should be cast.
	 *
	 * @var array
	 */
	protected array $casts = array(
		'adjustment_value' => 'float',
		'priority'         => 'integer',
		'is_active'        => 'boolean',
	);

	/**
	 * Get parsed conditions array.
	 *
	 * @return array
	 */
	public function getConditions() {
		$conditions = $this->conditions;
		if ( is_string( $conditions ) ) {
			$conditions = json_decode( $conditions, true );
		}
		return is_array( $conditions ) ? $conditions : array();
	}

	/**
	 * Get applicable service IDs.
	 *
	 * @return array
	 */
	public function getApplicableServices() {
		$services = $this->applicable_services;
		if ( is_string( $services ) ) {
			$services = json_decode( $services, true );
		}
		return is_array( $services ) ? $services : array();
	}

	/**
	 * Check if this rule applies to a given service.
	 *
	 * @param int $serviceId The service ID.
	 *
	 * @return bool
	 */
	public function appliesToService( $serviceId ) {
		$services = $this->getApplicableServices();
		if ( empty( $services ) ) {
			return true; // Empty means applies to all services.
		}
		return in_array( (int) $serviceId, array_map( 'intval', $services ), true );
	}
}
