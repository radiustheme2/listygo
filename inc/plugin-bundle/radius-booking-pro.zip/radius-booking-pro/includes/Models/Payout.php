<?php
/**
 * Payout Model
 */

namespace RadiusTheme\RadiusBookingPro\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseModel;

/**
 * Class Payout
 *
 * @package RadiusTheme\RadiusBookingPro\Models
 *
 * @property int    $id
 * @property int    $employee_id
 * @property float  $amount
 * @property float  $commission_amount
 * @property float  $net_amount
 * @property string $status
 * @property string $payout_method
 * @property string $employee_note
 * @property string $admin_note
 * @property int    $processed_by
 * @property string $processed_at
 * @property string $completed_at
 * @property string $created_at
 * @property string $updated_at
 */
class Payout extends BaseModel {

	/**
	 * The database table associated with the model.
	 *
	 * @var string
	 */
	protected string $table = 'radius_booking_payouts';

	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected array $fillable = array(
		'employee_id',
		'amount',
		'commission_amount',
		'net_amount',
		'status',
		'payout_method',
		'employee_note',
		'admin_note',
		'processed_by',
		'processed_at',
		'completed_at',
	);

	/**
	 * The attributes that should be cast.
	 *
	 * @var array
	 */
	protected array $casts = array(
		'employee_id'       => 'integer',
		'amount'            => 'float',
		'commission_amount' => 'float',
		'net_amount'        => 'float',
		'processed_by'      => 'integer',
	);

	/**
	 * Get the employee user associated with this payout.
	 *
	 * @return \WP_User|false
	 */
	public function employee() {
		return get_userdata( $this->employee_id );
	}
}
