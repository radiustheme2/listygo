<?php
/**
 * ServiceExtra Model
 *
 * @package RadiusTheme\RadiusBookingPro\Models
 */

namespace RadiusTheme\RadiusBookingPro\Models;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseModel;

/**
 * Class ServiceExtra
 *
 * @package RadiusTheme\RadiusBookingPro\Models
 *
 * @property int    $id
 * @property int    $service_id
 * @property string $title
 * @property string $description
 * @property float  $price
 * @property int    $duration
 * @property int    $min_quantity
 * @property int    $max_quantity
 * @property int    $position
 * @property string $status
 * @property string $created_at
 * @property string $updated_at
 */
class ServiceExtra extends BaseModel {

	/**
	 * The database table associated with the model.
	 *
	 * @var string
	 */
	protected string $table = 'radius_booking_service_extras';

	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected array $fillable = array(
		'service_id',
		'title',
		'description',
		'price',
		'duration',
		'min_quantity',
		'max_quantity',
		'position',
		'status',
	);

	/**
	 * The attributes that should be cast.
	 *
	 * @var array
	 */
	protected array $casts = array(
		'service_id'   => 'integer',
		'price'        => 'float',
		'duration'     => 'integer',
		'min_quantity' => 'integer',
		'max_quantity' => 'integer',
		'position'     => 'integer',
	);

	/**
	 * Check if this extra is valid (active and properly configured).
	 *
	 * @return bool True if the extra is valid and can be used.
	 */
	public function isValid(): bool {
		return 'active' === $this->status;
	}

	/**
	 * Calculate the total price for a given quantity.
	 *
	 * @param int $quantity The quantity to calculate price for.
	 *
	 * @return float The total price (unit price * quantity).
	 */
	public function calculatePrice( int $quantity = 1 ): float {
		$qty = max( $this->min_quantity, min( $quantity, $this->max_quantity ) );
		return (float) $this->price * $qty;
	}

	/**
	 * Calculate the total duration for a given quantity.
	 *
	 * @param int $quantity The quantity to calculate duration for.
	 *
	 * @return int The total duration in minutes (unit duration * quantity).
	 */
	public function calculateDuration( int $quantity = 1 ): int {
		$qty = max( $this->min_quantity, min( $quantity, $this->max_quantity ) );
		return (int) $this->duration * $qty;
	}

	/**
	 * Validate that a requested quantity is within allowed limits.
	 *
	 * @param int $quantity The requested quantity.
	 *
	 * @return array{valid: bool, message: string, adjusted_quantity: int}
	 */
	public function validateQuantity( int $quantity ): array {
		if ( $quantity < $this->min_quantity ) {
			return array(
				'valid'             => false,
				'message'           => sprintf(
					/* translators: 1: extra title, 2: minimum quantity */
					__( '%1$s requires a minimum quantity of %2$d.', 'radius-booking-pro' ),
					$this->title,
					$this->min_quantity
				),
				'adjusted_quantity' => $this->min_quantity,
			);
		}

		if ( $quantity > $this->max_quantity ) {
			return array(
				'valid'             => false,
				'message'           => sprintf(
					/* translators: 1: extra title, 2: maximum quantity */
					__( '%1$s allows a maximum quantity of %2$d.', 'radius-booking-pro' ),
					$this->title,
					$this->max_quantity
				),
				'adjusted_quantity' => $this->max_quantity,
			);
		}

		return array(
			'valid'             => true,
			'message'           => '',
			'adjusted_quantity' => $quantity,
		);
	}
}
