<?php
namespace RadiusTheme\RadiusBookingPro\PaymentGateway;

use RadiusTheme\RadiusBooking\Abstracts\AbstractPaymentGateway;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
/**
 * Stripe Payment Gateway
 *
 * Handles Stripe payment processing with test/live mode support
 */
class StripePaymentGateway extends AbstractPaymentGateway {

	/**
	 * Stripe API Client
	 *
	 * @var \Stripe\StripeClient
	 */
	private $stripeClient;

	/**
	 * Test mode status
	 *
	 * @var mixed
	 */
	private $isTestMode;

	/**
	 * Constructor
	 *
	 * @param array $config Configuration array
	 */
	public function __construct( array $config = array() ) {
		parent::__construct( $config );
		$this->isTestMode = $this->getConfig( 'test_mode', true );
		$this->initializeStripe();
	}

	/**
	 * Initialize Stripe client
	 */
	private function initializeStripe() {
		if ( ! $this->isConfigured() ) {
			return;
		}

		// Initialize Stripe library
		if ( class_exists( '\Stripe\Stripe' ) ) {
			\Stripe\Stripe::setApiKey( $this->getConfig( 'secret_key' ) );

			// Bound the network cost of the synchronous verify call made during
			// the booking POST. The SDK defaults to an 80s request timeout with
			// no retries, so a single slow/hung Stripe call could stall the
			// booking request (and, under recurring, once per child). Cap it and
			// allow one automatic retry for transient failures.
			if ( method_exists( '\Stripe\Stripe', 'setMaxNetworkRetries' ) ) {
				\Stripe\Stripe::setMaxNetworkRetries( 1 );
			}
			if ( class_exists( '\Stripe\HttpClient\CurlClient' ) ) {
				$curl = new \Stripe\HttpClient\CurlClient(
					array(
						CURLOPT_CONNECTTIMEOUT => 10,
						CURLOPT_TIMEOUT        => 15,
					)
				);
				\Stripe\ApiRequestor::setHttpClient( $curl );
			}

			$this->stripeClient = new \Stripe\StripeClient( $this->getConfig( 'secret_key' ) );
		}
	}

	/**
	 * Create a payment intent for processing a payment.
	 *
	 * @param array $intentData An associative array containing the payment intent data.
	 *                          Required fields:
	 *                          - amount (float): The payment amount in the provided currency.
	 *                          - currency (string): The currency code for the payment, e.g., 'USD'.
	 *                          Optional fields:
	 *                          - description (string): A description for the payment.
	 *                          - customer_email (string): The email address of the customer.
	 *                          - metadata (array): Additional metadata to attach to the payment intent.
	 *
	 * @return array An associative array representing the result of the payment intent creation.
	 *               The array contains:
	 *               - success (bool): Whether the operation succeeded or failed.
	 *               - message (string): A status message.
	 *               - data (array): Additional details including client secret, intent ID, amount, currency, and status, or error details if the operation failed.
	 */
	public function createPaymentIntent( array $intentData ): array {
		try {
			// Validate required fields
			$validation = $this->validatePaymentData(
				$intentData,
				array(
					'amount',
					'currency',
				)
			);

			if ( ! $validation['valid'] ) {
				return $this->createResponse(
					false,
					__( 'Validation failed', 'radius-booking-pro' ),
					array(
						'errors' => $validation['errors'],
					)
				);
			}

			if ( ! $this->isConfigured() ) {
				return $this->createResponse( false, __( 'Stripe is not configured', 'radius-booking-pro' ) );
			}

			// Convert amount to cents for Stripe
			$amountInCents = (int) ( $intentData['amount'] * 100 );

			// Prepare Stripe payment intent data
			$stripeIntentData = array(
				'amount'                    => $amountInCents,
				'currency'                  => strtolower( $intentData['currency'] ?? 'usd' ),
				'description'               => $intentData['description'] ?? 'Radius Booking Payment',
				'automatic_payment_methods' => array(
					'enabled'         => true,
					'allow_redirects' => 'never', // Disable redirect-based payment methods
				),
				'metadata'                  => array(
					'mode' => $this->isTestMode ? 'test' : 'live',
				),
			);

			// Add customer email if provided
			if ( ! empty( $intentData['customer_email'] ) ) {
				$stripeIntentData['receipt_email'] = $intentData['customer_email'];
			}

			// Add metadata
			if ( ! empty( $intentData['metadata'] ) && is_array( $intentData['metadata'] ) ) {
				$stripeIntentData['metadata'] = array_merge(
					$stripeIntentData['metadata'],
					$intentData['metadata']
				);
			}

			// Create payment intent (not confirmed yet)
			$intent = $this->stripeClient->paymentIntents->create( $stripeIntentData );

			$this->log(
				'info',
				'Stripe payment intent created',
				array(
					'intent_id' => $intent->id,
					'amount'    => $intentData['amount'],
					'mode'      => $this->isTestMode ? 'test' : 'live',
				)
			);

			return $this->createResponse(
				true,
				__( 'Payment intent created successfully', 'radius-booking-pro' ),
				array(
					'client_secret' => $intent->client_secret,
					'intent_id'     => $intent->id,
					'amount'        => $intent->amount / 100,
					'currency'      => strtoupper( $intent->currency ),
					'status'        => $intent->status,
					'test_mode'     => $this->isTestMode,
				)
			);

		} catch ( \Exception $e ) {
			$this->log(
				'error',
				'Stripe payment intent creation error',
				array(
					'error' => $e->getMessage(),
					'mode'  => $this->isTestMode ? 'test' : 'live',
				)
			);

			/* translators: %s: exception message */
			return $this->createResponse( false, sprintf( __( 'Payment intent creation failed: %s', 'radius-booking-pro' ), $e->getMessage() ) );
		}
	}

	/**
	 * Confirm a Stripe payment intent
	 *
	 * @param string $paymentIntentId The ID of the payment intent to confirm.
	 *
	 * @return array An array containing the confirmation status, message, and other relevant details.
	 */
	public function confirmPaymentIntent( string $paymentIntentId ): array {
		try {
			if ( ! $this->isConfigured() ) {
				return $this->createResponse( false, __( 'Stripe is not configured', 'radius-booking-pro' ) );
			}

			// Retrieve the payment intent
			$intent = $this->stripeClient->paymentIntents->retrieve( $paymentIntentId );

			$this->log(
				'info',
				'Stripe payment intent retrieved',
				array(
					'intent_id' => $intent->id,
					'status'    => $intent->status,
					'mode'      => $this->isTestMode ? 'test' : 'live',
				)
			);

			$status = $this->mapStripeStatus( $intent->status );

			return $this->createResponse(
				true,
				__( 'Payment confirmed', 'radius-booking-pro' ),
				array(
					'transaction_id' => $intent->id,
					'status'         => $status,
					'amount'         => $intent->amount / 100,
					'currency'       => strtoupper( $intent->currency ),
					'payment_method' => $intent->payment_method ?? null,
					'test_mode'      => $this->isTestMode,
					'payment_intent' => $intent->toArray(),
				)
			);

		} catch ( \Exception $e ) {
			$this->log(
				'error',
				'Stripe payment confirmation error',
				array(
					'error'     => $e->getMessage(),
					'intent_id' => $paymentIntentId,
					'mode'      => $this->isTestMode ? 'test' : 'live',
				)
			);

			/* translators: %s: exception message */
			return $this->createResponse( false, sprintf( __( 'Payment confirmation failed: %s', 'radius-booking-pro' ), $e->getMessage() ) );
		}
	}

	/**
	 * Process the payment using provided payment data
	 *
	 * @param array $paymentData Array containing payment information such as amount, currency, customer_email, and others.
	 *
	 * @return array Response indicating the success or failure of the payment processing. Includes details like transaction ID, status, and any errors if applicable.
	 */
	public function processPayment( array $paymentData ): array {
		try {
			// Validate required fields
			$validation = $this->validatePaymentData(
				$paymentData,
				array(
					'amount',
					'currency',
					'customer_email',
				)
			);

			if ( ! $validation['valid'] ) {
				return $this->createResponse(
					false,
					__( 'Validation failed', 'radius-booking-pro' ),
					array(
						'errors' => $validation['errors'],
					)
				);
			}

			if ( ! $this->isConfigured() ) {
				return $this->createResponse( false, __( 'Stripe is not configured', 'radius-booking-pro' ) );
			}

			// Convert amount to cents for Stripe
			$amountInCents = (int) ( $paymentData['amount'] * 100 );

			// Prepare Stripe payment intent data
			$intentData = array(
				'amount'        => $amountInCents,
				'currency'      => strtolower( $paymentData['currency'] ?? 'usd' ),
				'description'   => $paymentData['description'] ?? __( 'Booking Payment', 'radius-booking-pro' ),
				'receipt_email' => $paymentData['customer_email'],
				'metadata'      => array(
					'booking_id'  => $paymentData['booking_id'] ?? '',
					'customer_id' => $paymentData['customer_id'] ?? '',
					'mode'        => $this->isTestMode ? 'test' : 'live',
				),
			);

			// CRITICAL: Check if payment_method_id is provided
			if ( ! empty( $paymentData['payment_method_id'] ) ) {
				// Use provided payment method (from frontend)
				$intentData['payment_method']            = $paymentData['payment_method_id'];
				$intentData['confirm']                   = true;
				$intentData['automatic_payment_methods'] = array(
					'enabled'         => false,
					'allow_redirects' => 'never',
				);
			} elseif ( ! empty( $paymentData['payment_intent_id'] ) ) {
				// Payment already confirmed on frontend, just retrieve it
				return $this->confirmPaymentIntent( $paymentData['payment_intent_id'] );
			} else {
				// No payment method provided - return error
				return $this->createResponse(
					false,
					__( 'Payment method required. Please use createPaymentIntent for frontend payment collection.', 'radius-booking-pro' )
				);
			}

			// Create and confirm payment intent
			$intent = $this->stripeClient->paymentIntents->create( $intentData );

			$this->log(
				'info',
				'Stripe payment processed',
				array(
					'intent_id'  => $intent->id,
					'booking_id' => $paymentData['booking_id'] ?? '',
					'mode'       => $this->isTestMode ? 'test' : 'live',
				)
			);
			// Determine status
			$status = $this->mapStripeStatus( $intent->status ) === 'completed'
				? 'paid'
				: $this->mapStripeStatus( $intent->status );

			return $this->createResponse(
				true,
				__( 'Payment processed successfully', 'radius-booking-pro' ),
				array(
					'transaction_id' => $intent->id,
					'status'         => $status,
					'client_secret'  => $intent->client_secret,
					'test_mode'      => $this->isTestMode,
					'payment_intent' => $intent->toArray(),
				)
			);

		} catch ( \Stripe\Exception\CardException $e ) {
			$this->log(
				'error',
				'Stripe card error',
				array(
					'error'      => $e->getMessage(),
					'booking_id' => $paymentData['booking_id'] ?? '',
					'mode'       => $this->isTestMode ? 'test' : 'live',
				)
			);

			return $this->createResponse(
				false,
				$e->getMessage(),
				array(
					'error_type' => 'card_error',
				)
			);

		} catch ( \Exception $e ) {
			$this->log(
				'error',
				'Stripe payment error',
				array(
					'error'      => $e->getMessage(),
					'booking_id' => $paymentData['booking_id'] ?? '',
					'mode'       => $this->isTestMode ? 'test' : 'live',
				)
			);

			/* translators: %s: exception message */
			return $this->createResponse( false, sprintf( __( 'Payment processing failed: %s', 'radius-booking-pro' ), $e->getMessage() ) );
		}
	}

	/**
	 * Verify the payment status using the specified transaction ID
	 *
	 * @param string $transactionId The unique identifier of the transaction to be verified
	 *
	 * @return array An array containing the verification status, payment details, and response message
	 */
	public function verifyPayment( string $transactionId ): array {
		try {
			if ( ! $this->isConfigured() ) {
				return $this->createResponse( false, __( 'Stripe is not configured', 'radius-booking-pro' ) );
			}

			$intent = $this->stripeClient->paymentIntents->retrieve( $transactionId );

			$status = $this->mapStripeStatus( $intent->status );
			return $this->createResponse(
				true,
				__( 'Payment verified', 'radius-booking-pro' ),
				array(
					'transaction_id' => $intent->id,
					'status'         => $status,
					'amount'         => $intent->amount / 100,
					'currency'       => strtoupper( $intent->currency ),
					'test_mode'      => $this->isTestMode,
					'payment_intent' => $intent->toArray(),
				)
			);

		} catch ( \Exception $e ) {
			$this->log(
				'error',
				'Stripe verification error',
				array(
					'error'          => $e->getMessage(),
					'transaction_id' => $transactionId,
					'mode'           => $this->isTestMode ? 'test' : 'live',
				)
			);

			/* translators: %s: exception message */
			return $this->createResponse( false, sprintf( __( 'Payment verification failed: %s', 'radius-booking-pro' ), $e->getMessage() ) );
		}
	}

	/**
	 * Process a refund for a payment.
	 *
	 * @param string $transactionId The transaction ID of the payment to refund.
	 * @param float $amount The amount to refund. Defaults to 0, which implies a full refund.
	 *
	 * @return array Response data containing the status, message, and refund details upon success or failure.
	 */
	public function refundPayment( string $transactionId, float $amount = 0 ): array {
		try {
			if ( ! $this->isConfigured() ) {
				return $this->createResponse( false, __( 'Stripe is not configured', 'radius-booking-pro' ) );
			}

			$refundData = array(
				'payment_intent' => $transactionId,
			);

			// Add amount if partial refund
			if ( $amount > 0 ) {
				$refundData['amount'] = (int) ( $amount * 100 );
			}

			$refund = $this->stripeClient->refunds->create( $refundData );

			$this->log(
				'info',
				'Stripe refund created',
				array(
					'refund_id'      => $refund->id,
					'transaction_id' => $transactionId,
					'amount'         => $amount,
					'mode'           => $this->isTestMode ? 'test' : 'live',
				)
			);

			return $this->createResponse(
				true,
				__( 'Refund processed successfully', 'radius-booking-pro' ),
				array(
					'refund_id'      => $refund->id,
					'transaction_id' => $transactionId,
					'amount'         => $refund->amount / 100,
					'status'         => $refund->status,
					'test_mode'      => $this->isTestMode,
				)
			);

		} catch ( \Exception $e ) {
			$this->log(
				'error',
				'Stripe refund error',
				array(
					'error'          => $e->getMessage(),
					'transaction_id' => $transactionId,
					'mode'           => $this->isTestMode ? 'test' : 'live',
				)
			);

			/* translators: %s: exception message */
			return $this->createResponse( false, sprintf( __( 'Refund failed: %s', 'radius-booking-pro' ), $e->getMessage() ) );
		}
	}

	/**
	 * Map the given Stripe payment status to a corresponding custom status.
	 *
	 * @param string $stripeStatus The payment status received from Stripe.
	 *
	 * @return string The mapped custom status.
	 */
	private function mapStripeStatus( string $stripeStatus ): string {
		$statusMap = array(
			'succeeded'               => 'completed',
			'requires_payment_method' => 'pending',
			'requires_confirmation'   => 'pending',
			'requires_action'         => 'pending',
			'processing'              => 'processing',
			'requires_capture'        => 'authorized',
			'canceled'                => 'canceled',
			'failed'                  => 'failed',
		);

		return $statusMap[ $stripeStatus ] ?? 'pending';
	}

	/**
	 * Get test mode status
	 *
	 * @return bool
	 */
	public function isTestMode(): bool {
		return $this->isTestMode;
	}

	/**
	 * Retrieve the gateway name
	 *
	 * @return string
	 */
	public function getGatewayName(): string {
		return 'stripe';
	}

	/**
	 * Determine if the configuration is properly set up
	 *
	 * @return bool
	 */
	public function isConfigured(): bool {
		return ! empty( $this->getConfig( 'secret_key' ) ) &&
				class_exists( '\Stripe\Stripe' );
	}
}
