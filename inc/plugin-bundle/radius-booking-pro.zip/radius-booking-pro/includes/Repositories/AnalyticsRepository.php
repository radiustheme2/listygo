<?php
namespace RadiusTheme\RadiusBookingPro\Repositories;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseRepository;
use RadiusTheme\RadiusBooking\Models\Appointment;
use RadiusTheme\RadiusBooking\Models\Payment;
use RadiusTheme\RadiusBooking\Models\User;

/**
 * Handles data queries for the Analytics module.
 */
class AnalyticsRepository extends BaseRepository {

	/**
	 * @var string
	 */
	protected string $model = Appointment::class;

	/**
	 * Total revenue in a date range.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return float
	 */
	public function totalRevenue( string $from, string $to ): float {
		global $wpdb;
		$prefix = radius_table_prefix();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COALESCE(SUM(p.amount),0)
				FROM {$prefix}payments p
				LEFT JOIN {$prefix}customer_bookings cb ON cb.id = p.booking_id
				LEFT JOIN {$prefix}appointments a ON a.id = cb.appointment_id
				WHERE p.status IN ('paid','completed','partial_payment')
				AND p.booking_date_time BETWEEN %s AND %s
				AND a.deleted_at IS NULL",
				$from . ' 00:00:00',
				$to . ' 23:59:59'
			)
		);

		return (float) ( $total ?? 0 );
	}

	/**
	 * Total appointments in a date range.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return int
	 */
	public function totalAppointments( string $from, string $to ): int {
		$row = Appointment::query()
			->selectRaw( 'COUNT(*) as total' )
			->whereBetween( 'appointment_date', array( $from, $to ) )
			->first();

		return (int) ( $row->total ?? 0 );
	}

	/**
	 * New customers in a date range.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return int
	 */
	public function newCustomers( string $from, string $to ): int {
		$row = User::query()
			->selectRaw( 'COUNT(*) as total' )
			->where( 'user_type', 'customer' )
			->whereBetween( 'created_at', array( $from . ' 00:00:00', $to . ' 23:59:59' ) )
			->first();

		return (int) ( $row->total ?? 0 );
	}

	/**
	 * Cancelled appointments in a date range.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return int
	 */
	public function cancelledAppointments( string $from, string $to ): int {
		$row = Appointment::query()
			->selectRaw( 'COUNT(*) as total' )
			->where( 'status', 'cancelled' )
			->whereBetween( 'appointment_date', array( $from, $to ) )
			->first();

		return (int) ( $row->total ?? 0 );
	}

	/**
	 * Revenue trend grouped by day.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function revenueTrend( string $from, string $to ): array {
		global $wpdb;
		$prefix = radius_table_prefix();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE(p.booking_date_time) as date_label, SUM(p.amount) as total
				FROM {$prefix}payments p
				LEFT JOIN {$prefix}customer_bookings cb ON cb.id = p.booking_id
				LEFT JOIN {$prefix}appointments a ON a.id = cb.appointment_id
				WHERE p.status IN ('paid','completed','partial_payment')
				AND p.booking_date_time BETWEEN %s AND %s
				AND a.deleted_at IS NULL
				GROUP BY DATE(p.booking_date_time)
				ORDER BY date_label ASC",
				$from . ' 00:00:00',
				$to . ' 23:59:59'
			)
		);

		return is_array( $results ) ? $results : array();
	}

	/**
	 * Revenue grouped by service.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function revenueByService( string $from, string $to ): array {
		global $wpdb;
		$prefix = radius_table_prefix();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT s.id as service_id, s.name as service_name, COALESCE(SUM(p.amount),0) as revenue
				FROM {$prefix}payments p
				LEFT JOIN {$prefix}customer_bookings cb ON cb.id = p.booking_id
				LEFT JOIN {$prefix}appointments a ON a.id = cb.appointment_id
				LEFT JOIN {$prefix}services s ON s.id = a.service_id
				WHERE p.status IN ('paid','completed','partial_payment')
				AND p.booking_date_time BETWEEN %s AND %s
				AND s.id IS NOT NULL
				AND a.deleted_at IS NULL
				GROUP BY s.id, s.name
				ORDER BY revenue DESC
				LIMIT 10",
				$from . ' 00:00:00',
				$to . ' 23:59:59'
			)
		);
	}

	/**
	 * Revenue grouped by employee.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function revenueByEmployee( string $from, string $to ): array {
		global $wpdb;
		$prefix = radius_table_prefix();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.employee_id, u.first_name as employee_name, COALESCE(SUM(p.amount),0) as revenue
				FROM {$prefix}payments p
				LEFT JOIN {$prefix}customer_bookings cb ON cb.id = p.booking_id
				LEFT JOIN {$prefix}appointments a ON a.id = cb.appointment_id
				LEFT JOIN {$prefix}user_profiles u ON u.user_id = a.employee_id
				WHERE p.status IN ('paid','completed','partial_payment')
				AND p.booking_date_time BETWEEN %s AND %s
				AND a.employee_id IS NOT NULL
				AND a.deleted_at IS NULL
				GROUP BY a.employee_id, u.first_name
				ORDER BY revenue DESC
				LIMIT 10",
				$from . ' 00:00:00',
				$to . ' 23:59:59'
			)
		);
	}

	/**
	 * Appointments grouped by status.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function appointmentsByStatus( string $from, string $to ): array {
		return (array) Appointment::query()
			->selectRaw( 'status, COUNT(*) as total' )
			->whereBetween( 'appointment_date', array( $from, $to ) )
			->groupByRaw( 'status' )
			->get();
	}

	/**
	 * Appointments over time grouped by day.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function appointmentsOverTime( string $from, string $to ): array {
		return (array) Appointment::query()
			->selectRaw( 'DATE(appointment_date) as date_label, COUNT(*) as total' )
			->whereBetween( 'appointment_date', array( $from, $to ) )
			->groupByRaw( 'DATE(appointment_date)' )
			->orderBy( 'date_label', 'ASC' )
			->get();
	}

	/**
	 * Peak booking hours.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function peakHours( string $from, string $to ): array {
		return (array) Appointment::query()
			->selectRaw( 'HOUR(start_time) as hour, COUNT(*) as total' )
			->whereBetween( 'appointment_date', array( $from, $to ) )
			->groupByRaw( 'HOUR(start_time)' )
			->orderBy( 'hour', 'ASC' )
			->get();
	}

	/**
	 * Busiest days of the week.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function busiestDays( string $from, string $to ): array {
		return (array) Appointment::query()
			->selectRaw( 'DAYOFWEEK(appointment_date) as weekday, COUNT(*) as total' )
			->whereBetween( 'appointment_date', array( $from, $to ) )
			->groupByRaw( 'DAYOFWEEK(appointment_date)' )
			->orderBy( 'weekday', 'ASC' )
			->get();
	}

	/**
	 * Employee performance data.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function employeePerformance( string $from, string $to ): array {
		global $wpdb;
		$prefix = radius_table_prefix();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT
					a.employee_id,
					u.first_name as employee_name,
					COUNT(*) as total_appointments,
					SUM(CASE WHEN a.status = 'completed' THEN 1 ELSE 0 END) as completed,
					SUM(CASE WHEN a.status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
					COALESCE(rev.revenue, 0) as revenue
				FROM {$prefix}appointments a
				LEFT JOIN {$prefix}user_profiles u ON u.user_id = a.employee_id
				LEFT JOIN (
					SELECT a2.employee_id, SUM(p.amount) as revenue
					FROM {$prefix}payments p
					LEFT JOIN {$prefix}customer_bookings cb ON cb.id = p.booking_id
					LEFT JOIN {$prefix}appointments a2 ON a2.id = cb.appointment_id
					WHERE p.status IN ('paid','completed','partial_payment')
					AND p.booking_date_time BETWEEN %s AND %s
					AND a2.deleted_at IS NULL
					GROUP BY a2.employee_id
				) rev ON rev.employee_id = a.employee_id
				WHERE a.appointment_date BETWEEN %s AND %s
				AND a.employee_id IS NOT NULL
				AND a.deleted_at IS NULL
				GROUP BY a.employee_id, u.first_name, rev.revenue
				ORDER BY total_appointments DESC",
				$from . ' 00:00:00',
				$to . ' 23:59:59',
				$from,
				$to
			)
		);
	}

	/**
	 * Popular services by appointment count.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function popularServices( string $from, string $to ): array {
		global $wpdb;
		$prefix = radius_table_prefix();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT s.id as service_id, s.name as service_name, COUNT(*) as appointment_count
				FROM {$prefix}appointments a
				LEFT JOIN {$prefix}services s ON s.id = a.service_id
				WHERE a.appointment_date BETWEEN %s AND %s
				AND s.id IS NOT NULL
				AND a.deleted_at IS NULL
				GROUP BY s.id, s.name
				ORDER BY appointment_count DESC
				LIMIT 10",
				$from,
				$to
			)
		);
	}

	/**
	 * Top customers by revenue.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function topCustomersByRevenue( string $from, string $to ): array {
		global $wpdb;
		$prefix = radius_table_prefix();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.customer_id, u.first_name as customer_name, SUM(p.amount) as total_revenue, COUNT(*) as appointment_count
				FROM {$prefix}payments p
				LEFT JOIN {$prefix}customer_bookings cb ON cb.id = p.booking_id
				LEFT JOIN {$prefix}appointments a ON a.id = cb.appointment_id
				LEFT JOIN {$prefix}user_profiles u ON u.user_id = p.customer_id
				WHERE p.status IN ('paid','completed','partial_payment')
				AND p.booking_date_time BETWEEN %s AND %s
				AND p.customer_id IS NOT NULL
				AND a.deleted_at IS NULL
				GROUP BY p.customer_id, u.first_name
				ORDER BY total_revenue DESC
				LIMIT 10",
				$from . ' 00:00:00',
				$to . ' 23:59:59'
			)
		);
	}

	/**
	 * New vs returning customers over time.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function newVsReturningCustomers( string $from, string $to ): array {
		global $wpdb;
		$prefix = radius_table_prefix();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT
					DATE(cb.created_at) as date_label,
					SUM(CASE WHEN u.created_at >= %s THEN 1 ELSE 0 END) as new_customers,
					SUM(CASE WHEN u.created_at < %s THEN 1 ELSE 0 END) as returning_customers
				FROM {$prefix}customer_bookings cb
				LEFT JOIN {$prefix}appointments a ON a.id = cb.appointment_id
				LEFT JOIN {$prefix}users u ON u.id = cb.customer_id
				WHERE a.appointment_date BETWEEN %s AND %s
				AND a.deleted_at IS NULL
				GROUP BY DATE(cb.created_at)
				ORDER BY date_label ASC",
				$from . ' 00:00:00',
				$from . ' 00:00:00',
				$from,
				$to
			)
		);

		return is_array( $results ) ? $results : array();
	}

	/**
	 * Customer retention rate.
	 *
	 * @param string $from     Current period start.
	 * @param string $to       Current period end.
	 * @param string $prev_from Previous period start.
	 * @param string $prev_to   Previous period end.
	 *
	 * @return float
	 */
	public function customerRetentionRate( string $from, string $to, string $prev_from, string $prev_to ): float {
		global $wpdb;
		$prefix = radius_table_prefix();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$prev_customers = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT cb.customer_id)
				FROM {$prefix}customer_bookings cb
				LEFT JOIN {$prefix}appointments a ON a.id = cb.appointment_id
				WHERE a.appointment_date BETWEEN %s AND %s
				AND a.deleted_at IS NULL",
				$prev_from,
				$prev_to
			)
		);

		if ( 0 === $prev_customers ) {
			return 0;
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$retained = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT curr.customer_id)
				FROM {$prefix}customer_bookings curr
				LEFT JOIN {$prefix}appointments a1 ON a1.id = curr.appointment_id
				WHERE a1.appointment_date BETWEEN %s AND %s
				AND a1.deleted_at IS NULL
				AND curr.customer_id IN (
					SELECT DISTINCT prev.customer_id
					FROM {$prefix}customer_bookings prev
					LEFT JOIN {$prefix}appointments a2 ON a2.id = prev.appointment_id
					WHERE a2.appointment_date BETWEEN %s AND %s
					AND a2.deleted_at IS NULL
				)",
				$from,
				$to,
				$prev_from,
				$prev_to
			)
		);

		return round( ( $retained / $prev_customers ) * 100, 1 );
	}
}
