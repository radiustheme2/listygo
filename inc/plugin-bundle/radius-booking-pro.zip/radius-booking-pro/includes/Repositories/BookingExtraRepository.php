<?php
/**
 * BookingExtraRepository
 *
 * @package RadiusTheme\RadiusBookingPro\Repositories
 */

namespace RadiusTheme\RadiusBookingPro\Repositories;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseRepository;
use RadiusTheme\RadiusBookingPro\Models\BookingExtra;
use RadiusTheme\RadiusBookingPro\Models\ServiceExtra;

/**
 * Class BookingExtraRepository
 *
 * Handles data operations for the BookingExtra model.
 */
class BookingExtraRepository extends BaseRepository {

	/**
	 * The model class managed by this repository.
	 *
	 * @var string
	 */
	protected string $model = BookingExtra::class;

	/**
	 * Get all extras for a specific booking.
	 *
	 * @param int $bookingId The booking ID.
	 *
	 * @return array Array of BookingExtra models.
	 */
	public function getByBooking( int $bookingId ): array {
		$results = $this->model::where( 'booking_id', $bookingId )->get();

		return array_map(
			function ( $item ) {
				return $this->model::hydrate( $item );
			},
			$results
		);
	}

	/**
	 * Create a snapshot of selected extras for a booking.
	 *
	 * @param int   $bookingId      The booking ID.
	 * @param array $selectedExtras Array of selected extras with format:
	 *                              [['id' => int, 'quantity' => int], ...].
	 *
	 * @return array Array of created BookingExtra models.
	 */
	public function createSnapshot( int $bookingId, array $selectedExtras ): array {
		$created = array();

		foreach ( $selectedExtras as $selection ) {
			$extraId  = isset( $selection['id'] ) ? (int) $selection['id'] : 0;
			$quantity = isset( $selection['quantity'] ) ? (int) $selection['quantity'] : 1;

			if ( ! $extraId ) {
				continue;
			}

			// Fetch the current extra data for snapshot.
			$extra = ServiceExtra::find( $extraId );
			if ( ! $extra ) {
				continue;
			}

			// Validate and adjust quantity within limits.
			$quantity = max( $extra->min_quantity, min( $quantity, $extra->max_quantity ) );

			// Calculate total price.
			$totalPrice = (float) $extra->price * $quantity;

			// Create the snapshot record.
			$bookingExtra = $this->create(
				array(
					'booking_id'  => $bookingId,
					'extra_id'    => $extraId,
					'title'       => $extra->title,
					'unit_price'  => (float) $extra->price,
					'duration'    => (int) $extra->duration,
					'quantity'    => $quantity,
					'total_price' => $totalPrice,
				)
			);

			if ( $bookingExtra ) {
				$created[] = $bookingExtra;
			}
		}

		return $created;
	}

	/**
	 * Delete all extras for a booking.
	 *
	 * @param int $bookingId The booking ID.
	 *
	 * @return int Number of deleted records.
	 */
	public function deleteByBooking( int $bookingId ): int {
		$extras       = $this->getByBooking( $bookingId );
		$deletedCount = 0;

		foreach ( $extras as $extra ) {
			if ( $this->delete( $extra->id ) ) {
				++$deletedCount;
			}
		}

		return $deletedCount;
	}

	/**
	 * Calculate the total price of all extras for a booking.
	 *
	 * @param int $bookingId The booking ID.
	 *
	 * @return float Total extras price.
	 */
	public function getTotalPriceByBooking( int $bookingId ): float {
		$extras = $this->getByBooking( $bookingId );
		$total  = 0.0;

		foreach ( $extras as $extra ) {
			$total += (float) $extra->total_price;
		}

		return $total;
	}

	/**
	 * Calculate the total duration of all extras for a booking.
	 *
	 * @param int $bookingId The booking ID.
	 *
	 * @return int Total extras duration in minutes.
	 */
	public function getTotalDurationByBooking( int $bookingId ): int {
		$extras   = $this->getByBooking( $bookingId );
		$duration = 0;

		foreach ( $extras as $extra ) {
			$duration += $extra->getTotalDuration();
		}

		return $duration;
	}
}
