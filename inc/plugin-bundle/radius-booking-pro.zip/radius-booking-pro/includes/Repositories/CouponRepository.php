<?php

namespace RadiusTheme\RadiusBookingPro\Repositories;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseRepository;
use RadiusTheme\RadiusBookingPro\Models\Coupon;

/**
 * Class CouponRepository
 *
 * Handles data operations for the Coupon model.
 */
class CouponRepository extends BaseRepository {

	/**
	 * The model class managed by this repository.
	 *
	 * @var string
	 */
	protected string $model = Coupon::class;

	/**
	 * Find a coupon by its code.
	 *
	 * @param string $code The coupon code.
	 *
	 * @return object|null
	 */
	public function findByCode( string $code ) {
		$result = $this->model::where( 'code', strtoupper( $code ) )->first();

		return $result ? $this->model::hydrate( $result ) : null;
	}

	/**
	 * Increment the usage count for a coupon.
	 *
	 * @param int $id The coupon ID.
	 *
	 * @return void
	 */
	public function incrementUsage( int $id ) {
		$coupon = $this->model::find( $id );
		if ( $coupon ) {
			$coupon->update( array( 'usage_count' => ( $coupon->usage_count ?? 0 ) + 1 ) );
		}
	}

	/**
	 * Get auto-apply coupons applicable for a given service.
	 *
	 * @param int|null $serviceId The service ID to filter by.
	 *
	 * @return array
	 */
	public function getAutoApplyCoupons( $serviceId = null ) {
		$results = $this->model::where( 'auto_apply', 1 )
			->where( 'status', 'active' )
			->get();

		$coupons = array_map(
			function ( $item ) {
				return $this->model::hydrate( $item );
			},
			$results
		);

		if ( ! $serviceId ) {
			return $coupons;
		}

		return array_filter(
			$coupons,
			function ( $coupon ) use ( $serviceId ) {
				$result = $coupon->isValid( $serviceId, 0 );
				return $result['valid'];
			}
		);
	}

	/**
	 * Paginate coupons with search support.
	 *
	 * @param int         $perPage Number of items per page.
	 * @param int         $page    Current page number.
	 * @param string      $order   Order direction.
	 * @param string      $orderBy Column to order by.
	 * @param string|null $search  Search term.
	 * @param string|null $status  Coupon status filter.
	 *
	 * @return mixed Paginated results.
	 */
	public function paginateWithSearch( $perPage, $page, $order, $orderBy, $search = null, $status = null ) {
		$query = $this->model::query();

		if ( $status && 'all' !== $status ) {
			$query->where( 'status', $status );
		}

		if ( $search ) {
			$query->where(
				function ( $q ) use ( $search ) {
					$q->where( 'code', 'LIKE', '%' . $search . '%' );
					$q->orWhere( 'description', 'LIKE', '%' . $search . '%' );
				}
			);
		}

		return $query->paginate( $perPage, $page, $order, $orderBy );
	}
}