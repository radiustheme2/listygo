<?php
namespace RadiusTheme\RadiusBookingPro\Repositories;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
use RadiusTheme\RadiusBooking\Abstracts\BaseRepository;
use RadiusTheme\RadiusBookingPro\Models\CustomField;

/**
 * Class CustomFieldRepository
 *
 * Handles data operations for the CustomField model.
 */
class CustomFieldRepository extends BaseRepository {

	/**
	 * The model class managed by this repository.
	 *
	 * @var string
	 */
	protected string $model = CustomField::class;

	// You can add custom repository methods here
}
