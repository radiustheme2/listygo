<?php

namespace RadiusTheme\RadiusBookingPro\Repositories;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseRepository;
use RadiusTheme\RadiusBookingPro\Models\DynamicPricingRule;

/**
 * Class DynamicPricingRepository
 *
 * Handles data operations for the DynamicPricingRule model.
 */
class DynamicPricingRepository extends BaseRepository {

	/**
	 * The model class managed by this repository.
	 *
	 * @var string
	 */
	protected string $model = DynamicPricingRule::class;

	/**
	 * Get all active rules for a service, ordered by priority then creation time.
	 *
	 * Convention: lower priority number = higher priority (priority 1 wins
	 * over priority 10). When two rules have the same priority, the older
	 * rule wins — this gives admins deterministic behavior and avoids "I
	 * just added a rule and prices changed unexpectedly" surprises.
	 *
	 * @param int|null $serviceId The service ID to filter by.
	 *
	 * @return array Array of DynamicPricingRule instances.
	 */
	public function getActiveRulesForService( $serviceId = null ) {
		$results = $this->model::where( 'is_active', 1 )
			->orderBy( 'priority', 'ASC' )
			->orderBy( 'created_at', 'ASC' )
			->get();

		$rules = array_map(
			function ( $item ) {
				return $this->model::hydrate( $item );
			},
			$results
		);

		if ( ! $serviceId ) {
			return $rules;
		}

		return array_values(
			array_filter(
				$rules,
				function ( $rule ) use ( $serviceId ) {
					return $rule->appliesToService( $serviceId );
				}
			)
		);
	}

	/**
	 * Get rules by type.
	 *
	 * @param string $ruleType The rule type to filter by.
	 *
	 * @return array
	 */
	public function getByType( string $ruleType ) {
		$results = $this->model::where( 'rule_type', $ruleType )
			->where( 'is_active', 1 )
			->orderBy( 'priority', 'ASC' )
			->get();

		return array_map(
			function ( $item ) {
				return $this->model::hydrate( $item );
			},
			$results
		);
	}

	/**
	 * Paginate rules with search and filtering.
	 *
	 * @param int         $perPage  Number of items per page.
	 * @param int         $page     Current page number.
	 * @param string      $order    Order direction.
	 * @param string      $orderBy  Column to order by.
	 * @param string|null $search   Search term.
	 * @param string|null $ruleType Rule type filter.
	 * @param string|null $status   Active status filter.
	 *
	 * @return mixed Paginated results.
	 */
	public function paginateWithSearch( $perPage, $page, $order, $orderBy, $search = null, $ruleType = null, $status = null ) {
		$query = $this->model::query();

		if ( $ruleType && 'all' !== $ruleType ) {
			$query->where( 'rule_type', $ruleType );
		}

		if ( null !== $status && 'all' !== $status ) {
			$query->where( 'is_active', 'active' === $status ? 1 : 0 );
		}

		if ( $search ) {
			$query->where(
				function ( $q ) use ( $search ) {
					$q->where( 'name', 'LIKE', '%' . $search . '%' );
					$q->orWhere( 'description', 'LIKE', '%' . $search . '%' );
				}
			);
		}

		return $query->paginate( $perPage, $page, $order, $orderBy );
	}
}
