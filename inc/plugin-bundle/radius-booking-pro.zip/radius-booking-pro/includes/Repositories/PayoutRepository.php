<?php

namespace RadiusTheme\RadiusBookingPro\Repositories;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseRepository;
use RadiusTheme\RadiusBookingPro\Models\Payout;

/**
 * Class PayoutRepository
 *
 * Handles data operations for the Payout model.
 */
class PayoutRepository extends BaseRepository {

	/**
	 * The model class managed by this repository.
	 *
	 * @var string
	 */
	protected string $model = Payout::class;

	/**
	 * Paginate payouts with filters.
	 *
	 * @param int         $perPage    Number of items per page.
	 * @param int         $page       Current page number.
	 * @param string      $order      Order direction.
	 * @param string      $orderBy    Column to order by.
	 * @param string|null $status     Status filter.
	 * @param int|null    $employeeId Employee ID filter.
	 *
	 * @return mixed Paginated results.
	 */
	public function paginateWithFilters( $perPage, $page, $order, $orderBy, $status = null, $employeeId = null ) {
		$query = $this->model::query();

		if ( $status && 'all' !== $status ) {
			$query->where( 'status', $status );
		}

		if ( $employeeId ) {
			$query->where( 'employee_id', (int) $employeeId );
		}

		return $query->paginate( $perPage, $page, $order, $orderBy );
	}

	/**
	 * Normalize a single id or an array of ids into a clean int[] for whereIn.
	 *
	 * Lets every aggregate accept either the legacy single id (used by
	 * non-CL flows) or the full set of related employee ids the my-booking
	 * dashboard resolves for a Classified Listing user that owns multiple
	 * listing-tied employee profiles.
	 *
	 * @param int|int[] $employeeId
	 *
	 * @return int[]
	 */
	private function normalizeEmployeeIds( $employeeId ): array {
		$ids = is_array( $employeeId ) ? $employeeId : array( $employeeId );
		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );
		return array_values( array_unique( $ids ) );
	}

	/**
	 * Get total paid out for an employee (completed payouts).
	 *
	 * @param int|int[] $employeeId Employee ID, or array of related ids.
	 *
	 * @return float Total paid out amount.
	 */
	public function getTotalPaidOut( $employeeId ) {
		$ids = $this->normalizeEmployeeIds( $employeeId );
		if ( empty( $ids ) ) {
			return 0.0;
		}

		$result = $this->model::whereIn( 'employee_id', $ids )
			->where( 'status', 'paid' )
			->sum( 'net_amount' );

		return (float) $result;
	}

	/**
	 * Get total pending payouts for an employee (pending + processing + on_hold).
	 *
	 * @param int|int[] $employeeId Employee ID, or array of related ids.
	 *
	 * @return float Total pending amount.
	 */
	public function getTotalPending( $employeeId ) {
		$ids = $this->normalizeEmployeeIds( $employeeId );
		if ( empty( $ids ) ) {
			return 0.0;
		}

		$result = $this->model::whereIn( 'employee_id', $ids )
			->whereIn( 'status', array( 'pending', 'processing', 'on_hold' ) )
			->sum( 'net_amount' );

		return (float) $result;
	}

	/**
	 * Get payouts for a specific employee with pagination.
	 *
	 * @param int|int[] $employeeId Employee ID, or array of related ids.
	 * @param int       $perPage    Number of items per page.
	 * @param int       $page       Current page number.
	 * @param string    $order      Order direction.
	 * @param string    $orderBy    Column to order by.
	 *
	 * @return mixed Paginated results.
	 */
	public function getEmployeePayouts( $employeeId, $perPage, $page, $order = 'desc', $orderBy = 'created_at' ) {
		$ids = $this->normalizeEmployeeIds( $employeeId );
		if ( empty( $ids ) ) {
			return $this->model::query()->whereRaw( '1 = 0' )->paginate( $perPage, $page, $order, $orderBy );
		}

		return $this->model::whereIn( 'employee_id', $ids )
			->paginate( $perPage, $page, $order, $orderBy );
	}

	/**
	 * Get admin income summary (commission earned from payouts).
	 *
	 * @return array Summary with totals.
	 */
	public function getAdminIncomeSummary() {
		global $wpdb;

		$table = $wpdb->prefix . 'radius_booking_payouts';

		$row = $wpdb->get_row(
			"SELECT
				COALESCE(SUM(CASE WHEN status = 'paid' THEN commission_amount ELSE 0 END), 0) AS total_commission_earned,
				COALESCE(SUM(CASE WHEN status = 'paid' THEN net_amount ELSE 0 END), 0) AS total_paid_to_employees,
				COALESCE(SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END), 0) AS total_gross_payouts,
				COALESCE(SUM(CASE WHEN status IN ('pending', 'processing', 'on_hold') THEN net_amount ELSE 0 END), 0) AS total_pending_payouts
			FROM {$table}",
			ARRAY_A
		);

		return array(
			'total_commission_earned'  => (float) ( $row['total_commission_earned'] ?? 0 ),
			'total_paid_to_employees'  => (float) ( $row['total_paid_to_employees'] ?? 0 ),
			'total_gross_payouts'      => (float) ( $row['total_gross_payouts'] ?? 0 ),
			'total_pending_payouts'    => (float) ( $row['total_pending_payouts'] ?? 0 ),
		);
	}

	/**
	 * Get status counts for admin overview.
	 *
	 * @return array Associative array of status => count.
	 */
	public function getStatusCounts() {
		global $wpdb;

		$table = $wpdb->prefix . 'radius_booking_payouts';

		$results = $wpdb->get_results(
			"SELECT status, COUNT(*) as count FROM {$table} GROUP BY status",
			ARRAY_A
		);

		$counts = array(
			'pending'    => 0,
			'processing' => 0,
			'on_hold'    => 0,
			'paid'       => 0,
			'rejected'   => 0,
		);

		foreach ( $results as $row ) {
			$counts[ $row['status'] ] = (int) $row['count'];
		}

		$counts['all'] = array_sum( $counts );

		return $counts;
	}
}
