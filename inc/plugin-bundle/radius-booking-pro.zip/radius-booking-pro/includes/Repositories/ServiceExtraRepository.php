<?php
/**
 * ServiceExtraRepository
 *
 * @package RadiusTheme\RadiusBookingPro\Repositories
 */

namespace RadiusTheme\RadiusBookingPro\Repositories;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseRepository;
use RadiusTheme\RadiusBookingPro\Models\ServiceExtra;

/**
 * Class ServiceExtraRepository
 *
 * Handles data operations for the ServiceExtra model.
 */
class ServiceExtraRepository extends BaseRepository {

	/**
	 * The model class managed by this repository.
	 *
	 * @var string
	 */
	protected string $model = ServiceExtra::class;

	/**
	 * Get all extras for a specific service.
	 *
	 * @param int    $serviceId The service ID.
	 * @param string $status    Optional status filter ('active', 'inactive', or 'all').
	 *
	 * @return array Array of ServiceExtra models.
	 */
	public function getByService( int $serviceId, string $status = 'all' ): array {
		$query = $this->model::where( 'service_id', $serviceId );

		if ( 'all' !== $status ) {
			$query->where( 'status', $status );
		}

		$results = $query->orderBy( 'position', 'ASC' )->get();

		return array_map(
			function ( $item ) {
				return $this->model::hydrate( $item );
			},
			$results
		);
	}

	/**
	 * Get active extras for a service (for booking flow).
	 *
	 * @param int $serviceId The service ID.
	 *
	 * @return array Array of active ServiceExtra models.
	 */
	public function getActiveByService( int $serviceId ): array {
		return $this->getByService( $serviceId, 'active' );
	}

	/**
	 * Reorder extras for a service.
	 *
	 * @param int   $serviceId The service ID.
	 * @param array $order     Array of extra IDs in the desired order.
	 *
	 * @return bool True on success.
	 */
	public function reorder( int $serviceId, array $order ): bool {
		foreach ( $order as $position => $extraId ) {
			$extra = $this->model::find( (int) $extraId );
			if ( $extra && (int) $extra->service_id === $serviceId ) {
				$extra->update( array( 'position' => $position ) );
			}
		}
		return true;
	}

	/**
	 * Bulk delete extras by IDs.
	 *
	 * @param array $ids Array of extra IDs to delete.
	 *
	 * @return int Number of deleted items.
	 */
	public function bulkDelete( array $ids ): int {
		$deletedCount = 0;
		foreach ( $ids as $id ) {
			if ( $this->delete( (int) $id ) ) {
				++$deletedCount;
			}
		}
		return $deletedCount;
	}

	/**
	 * Get the next position value for a service.
	 *
	 * @param int $serviceId The service ID.
	 *
	 * @return int The next position value.
	 */
	public function getNextPosition( int $serviceId ): int {
		global $wpdb;

		$table = $wpdb->prefix . 'radius_booking_service_extras';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$maxPosition = $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT MAX(position) FROM {$table} WHERE service_id = %d",
				$serviceId
			)
		);

		return null === $maxPosition ? 0 : ( (int) $maxPosition + 1 );
	}

	/**
	 * Paginate extras for a service with search support.
	 *
	 * @param int         $serviceId The service ID.
	 * @param int         $perPage   Number of items per page.
	 * @param int         $page      Current page number.
	 * @param string      $order     Order direction.
	 * @param string      $orderBy   Column to order by.
	 * @param string|null $search    Search term.
	 * @param string|null $status    Status filter.
	 *
	 * @return mixed Paginated results.
	 */
	public function paginateByService( int $serviceId, int $perPage, int $page, string $order, string $orderBy, ?string $search = null, ?string $status = null ) {
		$query = $this->model::where( 'service_id', $serviceId );

		if ( $status && 'all' !== $status ) {
			$query->where( 'status', $status );
		}

		if ( $search ) {
			$query->where(
				function ( $q ) use ( $search ) {
					$q->where( 'title', 'LIKE', '%' . $search . '%' );
					$q->orWhere( 'description', 'LIKE', '%' . $search . '%' );
				}
			);
		}

		return $query->paginate( $perPage, $page, $order, $orderBy );
	}
}
