<?php
/**
 * BookingExtraResource
 *
 * @package RadiusTheme\RadiusBookingPro\Resources
 */

namespace RadiusTheme\RadiusBookingPro\Resources;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseResource;

/**
 * BookingExtraResource
 * Booking extra resource transformer
 */
class BookingExtraResource extends BaseResource {

	/**
	 * Transform a BookingExtra model into an API-friendly array.
	 *
	 * @param object $extra The BookingExtra model instance.
	 *
	 * @return array Transformed data.
	 */
	public function transform( $extra ): array {
		return array(
			'id'          => (int) $extra->id,
			'booking_id'  => (int) $extra->booking_id,
			'extra_id'    => (int) $extra->extra_id,
			'title'       => $extra->title,
			'unit_price'  => (float) $extra->unit_price,
			'duration'    => (int) $extra->duration,
			'quantity'    => (int) $extra->quantity,
			'total_price' => (float) $extra->total_price,
			'created_at'  => $extra->created_at,
			'updated_at'  => $extra->updated_at,
		);
	}
}
