<?php

namespace RadiusTheme\RadiusBookingPro\Resources;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseResource;

/**
 * CouponResource
 * Coupon resource transformer
 */
class CouponResource extends BaseResource {

	/**
	 * Transform a Coupon model into an API-friendly array.
	 *
	 * @param object $coupon The Coupon model instance.
	 *
	 * @return array Transformed data.
	 */
	public function transform( $coupon ): array {
		$applicable_services = $coupon->applicable_services;
		if ( is_string( $applicable_services ) ) {
			$applicable_services = json_decode( $applicable_services, true );
		}
		if ( ! is_array( $applicable_services ) ) {
			$applicable_services = array();
		}

		return array(
			'id'                  => $coupon->id,
			'code'                => $coupon->code,
			'description'         => $coupon->description,
			'discount_type'       => $coupon->discount_type,
			'discount_value'      => (float) $coupon->discount_value,
			'max_uses'            => $coupon->max_uses,
			'usage_count'         => (int) $coupon->usage_count,
			'start_date'          => $coupon->start_date,
			'end_date'            => $coupon->end_date,
			'min_amount'          => (float) $coupon->min_amount,
			'max_discount'        => $coupon->max_discount ? (float) $coupon->max_discount : null,
			'applicable_services' => $applicable_services,
			'auto_apply'          => (bool) $coupon->auto_apply,
			'status'              => $coupon->status,
			'created_by'          => $coupon->created_by,
			'created_at'          => $coupon->created_at,
			'updated_at'          => $coupon->updated_at,
		);
	}
}