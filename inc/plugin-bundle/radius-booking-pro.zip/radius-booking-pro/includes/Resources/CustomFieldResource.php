<?php
namespace RadiusTheme\RadiusBookingPro\Resources;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
use RadiusTheme\RadiusBooking\Abstracts\BaseResource;

/**
 * Api/Resources/CustomFieldResource.php
 * CustomField resource transformer
 *
 * @package RadiusTheme\RadiusBookingPro\Resources
 */
class CustomFieldResource extends BaseResource {

	/**
	 * Transform a CustomField model into an API-friendly array.
	 *
	 * Decodes the JSON columns into arrays and returns the targeting fields
	 * (`applies_to`, `meeting_types`, `events`) alongside the existing
	 * `services` array so frontends can filter which fields to render on a
	 * given resource type.
	 *
	 * @param object $custom_field The CustomField model instance.
	 * @return array Transformed data.
	 */
	public function transform( $custom_field ): array {
		$options       = $this->decodeJsonField( $custom_field->options );
		$services      = $this->decodeJsonField( $custom_field->services );
		$applies_to    = $this->decodeJsonField( $custom_field->applies_to ?? null );
		$meeting_types = $this->decodeJsonField( $custom_field->meeting_types ?? null );
		$events        = $this->decodeJsonField( $custom_field->events ?? null );

		// Default existing rows / unmigrated data to the historic behavior
		// (services-only) so older clients keep working.
		if ( ! is_array( $applies_to ) || empty( $applies_to ) ) {
			$applies_to = array( 'service' );
		}

		return array(
			'id'            => $custom_field->id,
			'label'         => $custom_field->label,
			'type'          => $custom_field->type,
			'options'       => is_array( $options ) ? array_values( $options ) : $options,
			'placeholder'   => $custom_field->placeholder,
			'required'      => (bool) $custom_field->required,
			'is_active'     => (bool) $custom_field->is_active,
			'status'        => $custom_field->is_active ? 'active' : 'inactive',
			'sort_order'    => $custom_field->sort_order,
			'services'      => is_array( $services ) ? array_values( $services ) : $services,
			'applies_to'    => array_values( $applies_to ),
			'meeting_types' => is_array( $meeting_types ) ? array_values( $meeting_types ) : $meeting_types,
			'events'        => is_array( $events ) ? array_values( $events ) : $events,
			'created_at'    => $custom_field->created_at,
			'updated_at'    => $custom_field->updated_at,
		);
	}

	/**
	 * Decode a field that may be a raw serialized/JSON string or already decoded.
	 *
	 * @param mixed $value The field value.
	 * @return mixed Decoded value.
	 */
	private function decodeJsonField( $value ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}
		if ( is_serialized( $value ) ) {
			return maybe_unserialize( $value );
		}
		$decoded = json_decode( $value, true );
		return ( null !== $decoded ) ? $decoded : $value;
	}
}
