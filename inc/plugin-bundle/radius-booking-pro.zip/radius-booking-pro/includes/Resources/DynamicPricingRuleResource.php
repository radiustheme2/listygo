<?php

namespace RadiusTheme\RadiusBookingPro\Resources;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseResource;

/**
 * DynamicPricingRuleResource
 *
 * Transforms a DynamicPricingRule model into an API-friendly array.
 */
class DynamicPricingRuleResource extends BaseResource {

	/**
	 * Transform a DynamicPricingRule model into an API-friendly array.
	 *
	 * @param object $rule The DynamicPricingRule model instance.
	 *
	 * @return array Transformed data.
	 */
	public function transform( $rule ): array {
		$conditions = $rule->conditions;
		if ( is_string( $conditions ) ) {
			$conditions = json_decode( $conditions, true );
		}
		if ( ! is_array( $conditions ) ) {
			$conditions = array();
		}

		$applicable_services = $rule->applicable_services;
		if ( is_string( $applicable_services ) ) {
			$applicable_services = json_decode( $applicable_services, true );
		}
		if ( ! is_array( $applicable_services ) ) {
			$applicable_services = array();
		}

		return array(
			'id'                  => $rule->id,
			'name'                => $rule->name,
			'description'         => $rule->description,
			'rule_type'           => $rule->rule_type,
			'adjustment_type'     => $rule->adjustment_type,
			'adjustment_value'    => (float) $rule->adjustment_value,
			'conditions'          => $conditions,
			'applicable_services' => $applicable_services,
			'priority'            => (int) $rule->priority,
			'is_active'           => (bool) $rule->is_active,
			'created_by'          => $rule->created_by,
			'created_at'          => $rule->created_at,
			'updated_at'          => $rule->updated_at,
		);
	}
}
