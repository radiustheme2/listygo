<?php

namespace RadiusTheme\RadiusBookingPro\Resources;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseResource;
use RadiusTheme\RadiusBooking\Helpers\SettingsHelper;
use RadiusTheme\RadiusBooking\Models\UserProfile;

/**
 * PayoutResource
 * Payout resource transformer
 */
class PayoutResource extends BaseResource {

	/**
	 * Transform a Payout model into an API-friendly array.
	 *
	 * @param object $payout The Payout model instance.
	 *
	 * @return array Transformed data.
	 */
	public function transform( $payout ): array {
		// payout->employee_id is a Radius Booking user ID. Resolve via UserProfile
		// to get the display name and the linked WP user ID for meta lookups.
		$profile       = UserProfile::where( 'user_id', (int) $payout->employee_id )->first();
		$wp_user_id    = $profile ? (int) $profile->wp_user_id : 0;
		$employee_name = self::resolveEmployeeName( $profile, $wp_user_id );

		$processed_by_name = '';
		if ( $payout->processed_by ) {
			$admin             = get_userdata( $payout->processed_by );
			$processed_by_name = $admin ? $admin->display_name : '';
		}

		// Resolve payout method label and field definitions from settings.
		$payout_settings = SettingsHelper::get_setting( 'payout' );
		$methods         = $payout_settings['payoutMethods'] ?? array();
		$method_key      = $payout->payout_method;
		$method_config   = $methods[ $method_key ] ?? array();
		$method_label    = $method_config['label'] ?? ucwords( str_replace( '_', ' ', $method_key ) );
		$method_fields   = $method_config['fields'] ?? array();

		// Get employee's saved payout details for this method (keyed by WP user ID).
		$raw_details      = $wp_user_id ? get_user_meta( $wp_user_id, '_rtrb_payout_details', true ) : '';
		$all_details      = ! empty( $raw_details ) ? json_decode( $raw_details, true ) : array();
		$method_details   = $all_details[ $method_key ] ?? array();

		// Build a readable array: [ { label: "Bank Name", value: "ABC Bank" }, ... ]
		$payment_info = array();
		if ( ! empty( $method_fields ) && ! empty( $method_details ) ) {
			foreach ( $method_fields as $field ) {
				$field_key = $field['key'] ?? '';
				if ( $field_key && isset( $method_details[ $field_key ] ) && '' !== $method_details[ $field_key ] ) {
					$payment_info[] = array(
						'label' => $field['label'] ?? $field_key,
						'value' => $method_details[ $field_key ],
					);
				}
			}
		}

		return array(
			'id'                  => $payout->id,
			'employee_id'         => (int) $payout->employee_id,
			'employee_name'       => $employee_name,
			'amount'              => (float) $payout->amount,
			'commission_amount'   => (float) $payout->commission_amount,
			'net_amount'          => (float) $payout->net_amount,
			'status'              => $payout->status,
			'payout_method'       => $payout->payout_method,
			'payout_method_label' => $method_label,
			'payment_info'        => $payment_info,
			'employee_note'       => $payout->employee_note,
			'admin_note'        => $payout->admin_note,
			'processed_by'      => $payout->processed_by ? (int) $payout->processed_by : null,
			'processed_by_name' => $processed_by_name,
			'processed_at'      => $payout->processed_at,
			'completed_at'      => $payout->completed_at,
			'created_at'        => $payout->created_at,
			'updated_at'        => $payout->updated_at,
			'currency'          => array(
				'currency_symbol' => get_rtrb_currency_symbol(),
				'currency'        => get_rtrb_currency(),
			),
		);
	}

	/**
	 * Resolve a human-readable employee name.
	 *
	 * Employees are WordPress users, so prefer the WP user's first_name +
	 * last_name (user_meta). Fall back to display_name, then to the
	 * UserProfile's name, then to "Unknown".
	 *
	 * @param UserProfile|null $profile    The Radius Booking user profile.
	 * @param int              $wp_user_id The linked WordPress user ID, or 0.
	 *
	 * @return string
	 */
	public static function resolveEmployeeName( $profile, int $wp_user_id ): string {
		if ( $wp_user_id ) {
			$wp = get_userdata( $wp_user_id );
			if ( $wp ) {
				$name = trim( ( $wp->first_name ?? '' ) . ' ' . ( $wp->last_name ?? '' ) );
				if ( '' !== $name ) {
					return $name;
				}
				if ( ! empty( $wp->display_name ) ) {
					return $wp->display_name;
				}
			}
		}

		if ( $profile ) {
			$name = trim( ( $profile->first_name ?? '' ) . ' ' . ( $profile->last_name ?? '' ) );
			if ( '' !== $name ) {
				return $name;
			}
		}

		return __( 'Unknown', 'radius-booking-pro' );
	}
}