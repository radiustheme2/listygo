<?php
/**
 * ServiceExtraResource
 *
 * @package RadiusTheme\RadiusBookingPro\Resources
 */

namespace RadiusTheme\RadiusBookingPro\Resources;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Abstracts\BaseResource;

/**
 * ServiceExtraResource
 * Service extra resource transformer
 */
class ServiceExtraResource extends BaseResource {

	/**
	 * Transform a ServiceExtra model into an API-friendly array.
	 *
	 * @param object $extra The ServiceExtra model instance.
	 *
	 * @return array Transformed data.
	 */
	public function transform( $extra ): array {
		return array(
			'id'           => (int) $extra->id,
			'service_id'   => (int) $extra->service_id,
			'title'        => $extra->title,
			'description'  => $extra->description,
			'price'        => (float) $extra->price,
			'duration'     => (int) $extra->duration,
			'min_quantity' => (int) $extra->min_quantity,
			'max_quantity' => (int) $extra->max_quantity,
			'position'     => (int) $extra->position,
			'status'       => $extra->status,
			'created_at'   => $extra->created_at,
			'updated_at'   => $extra->updated_at,
		);
	}
}
