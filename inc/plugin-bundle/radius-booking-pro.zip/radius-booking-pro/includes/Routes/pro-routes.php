<?php

use RadiusTheme\RadiusBookingPro\Controllers\LicenseController;
use RadiusTheme\RadiusBookingPro\Controllers\AnalyticsController;
use RadiusTheme\RadiusBookingPro\Controllers\DynamicPricingController;
use RadiusTheme\RadiusBookingPro\Controllers\AppointmentProController;
use RadiusTheme\RadiusBookingPro\Controllers\ChatbotController;
use RadiusTheme\RadiusBookingPro\Controllers\ChatbotProController;
use RadiusTheme\RadiusBookingPro\Controllers\CouponController;
use RadiusTheme\RadiusBookingPro\Controllers\CustomerPanelProController;
use RadiusTheme\RadiusBookingPro\Controllers\CustomFieldController;
use RadiusTheme\RadiusBookingPro\Controllers\InvoiceProController;
use RadiusTheme\RadiusBookingPro\Controllers\EmployeePayoutController;
use RadiusTheme\RadiusBookingPro\Controllers\LocationController;
use RadiusTheme\RadiusBookingPro\Controllers\PayoutController;
use RadiusTheme\RadiusBookingPro\Controllers\WhatsAppController;
use RadiusTheme\RadiusBookingPro\Controllers\CustomRolesController;
use RadiusTheme\RadiusBookingPro\Controllers\RolesController;
use RadiusTheme\RadiusBookingPro\Controllers\ServiceExtraController;

// License Routes.
$router->get( 'license/status', array( LicenseController::class, 'status' ) );
$router->post( 'license/activate', array( LicenseController::class, 'activate' ) );
$router->post( 'license/deactivate', array( LicenseController::class, 'deactivate' ) );

// Invoice Routes (Pro).
$router->post( '/invoice/send', array( InvoiceProController::class, 'sendInvoiceEmail' ) );

// Roles & Permissions management (Pro): matrix editor + team-member assignment.
$router->get( 'roles-permissions', array( RolesController::class, 'index' ) );
$router->put( 'roles-permissions', array( RolesController::class, 'update' ) );
$router->get( 'roles-permissions/members', array( RolesController::class, 'members' ) );
$router->get( 'roles-permissions/users', array( RolesController::class, 'searchUsers' ) );
$router->post( 'roles-permissions/members', array( RolesController::class, 'assignMember' ) );

// Custom booking roles (Pro).
$router->get( 'custom-roles', array( CustomRolesController::class, 'index' ) );
$router->post( 'custom-roles', array( CustomRolesController::class, 'store' ) );
$router->put( 'custom-roles/(?P<slug>[a-zA-Z0-9_-]+)', array( CustomRolesController::class, 'update' ) );
$router->delete( 'custom-roles/(?P<slug>[a-zA-Z0-9_-]+)', array( CustomRolesController::class, 'destroy' ) );

$router->resource( 'locations', LocationController::class );
$router->get( 'locations/all', array( LocationController::class, 'getAllLocation' ) );
$router->delete( 'locations/bulk-delete/', array( LocationController::class, 'bulkDelete' ) );

// Custom Fields Routes.
$router->resource( 'custom-fields', CustomFieldController::class );
$router->get( 'custom-fields/service/(?P<service_id>\d+)', array( CustomFieldController::class, 'getFieldsByService' ) );
$router->delete( 'custom-fields/bulk-delete/', array( CustomFieldController::class, 'bulkDelete' ) );

// Analytics Routes.
$router->get( 'analytics/kpi-summary', array( AnalyticsController::class, 'kpiSummary' ) );
$router->get( 'analytics/revenue', array( AnalyticsController::class, 'revenue' ) );
$router->get( 'analytics/appointments', array( AnalyticsController::class, 'appointments' ) );
$router->get( 'analytics/employees', array( AnalyticsController::class, 'employees' ) );
$router->get( 'analytics/services', array( AnalyticsController::class, 'services' ) );
$router->get( 'analytics/customers', array( AnalyticsController::class, 'customers' ) );

// Coupon Routes.
$router->resource( 'coupons', CouponController::class );
$router->post( 'coupons/validate', array( CouponController::class, 'validateCouponCode' ) );
$router->get( 'coupons/auto-apply/(?P<service_id>\d+)', array( CouponController::class, 'getAutoApply' ) );
$router->delete( 'coupons/bulk-delete/', array( CouponController::class, 'bulkDelete' ) );

// Dynamic Pricing Routes.
$router->resource( 'dynamic-pricing', DynamicPricingController::class );
$router->delete( 'dynamic-pricing/bulk-delete/', array( DynamicPricingController::class, 'bulkDelete' ) );
$router->post( 'dynamic-pricing/calculate', array( DynamicPricingController::class, 'calculatePrice' ) );

// Payment Gateway Routes (Stripe + PayPal).
$router->post( 'appointments/create-intent', array( AppointmentProController::class, 'createIntend' ) );
$router->post( 'appointments/verify-intent', array( AppointmentProController::class, 'verifyIntent' ) );
$router->post( 'appointments/(?P<id>\d+)/woocommerce-order', array( AppointmentProController::class, 'createWooOrder' ) );

// Customer Cancel & Reschedule Routes.
$router->post( 'customer/dashboard/(?P<user_id>\d+)/(?P<appointment_id>\d+)/appointment/cancel', array( CustomerPanelProController::class, 'customerAppointmentCancel' ) );
$router->post( 'customer/dashboard/reschedule-appointment/(?P<appointment_id>\d+)', array( CustomerPanelProController::class, 'rescheduleAppointment' ) );

// Chatbot Public Routes.
$router->post( 'chatbot/message', array( ChatbotController::class, 'sendMessage' ) );
$router->get( 'chatbot/config', array( ChatbotController::class, 'getConfig' ) );

// Chatbot Knowledge Base CRUD Routes.
$router->get( 'chatbot/knowledge', array( ChatbotProController::class, 'getKnowledge' ) );
$router->post( 'chatbot/knowledge', array( ChatbotProController::class, 'createKnowledge' ) );
$router->put( 'chatbot/knowledge/(?P<id>[a-zA-Z0-9-]+)', array( ChatbotProController::class, 'updateKnowledge' ) );
$router->delete( 'chatbot/knowledge/(?P<id>[a-zA-Z0-9-]+)', array( ChatbotProController::class, 'deleteKnowledge' ) );

// Admin Payout Routes.
$router->get( 'payouts', array( PayoutController::class, 'index' ) );
$router->get( 'payouts/(?P<id>\d+)', array( PayoutController::class, 'show' ) );
$router->post( 'payouts/(?P<id>\d+)/approve', array( PayoutController::class, 'approve' ) );
$router->post( 'payouts/(?P<id>\d+)/complete', array( PayoutController::class, 'complete' ) );
$router->post( 'payouts/(?P<id>\d+)/hold', array( PayoutController::class, 'hold' ) );
$router->post( 'payouts/(?P<id>\d+)/unhold', array( PayoutController::class, 'unhold' ) );
$router->post( 'payouts/(?P<id>\d+)/reject', array( PayoutController::class, 'reject' ) );
$router->get( 'payouts/admin-income', array( PayoutController::class, 'adminIncome' ) );
$router->get( 'payouts/employee-summary/(?P<employee_id>\d+)', array( PayoutController::class, 'employeeSummary' ) );

// WhatsApp Notification Routes (admin-only).
$rtrb_wa_perm = array( 'permission_callback' => array( WhatsAppController::class, 'permission_check' ) );
$router->get( 'whatsapp/notifications', array( WhatsAppController::class, 'index' ), $rtrb_wa_perm );
$router->get( 'whatsapp/notifications/(?P<id>[a-zA-Z0-9._-]+)', array( WhatsAppController::class, 'show' ), $rtrb_wa_perm );
$router->put( 'whatsapp/notifications/(?P<id>[a-zA-Z0-9._-]+)', array( WhatsAppController::class, 'update' ), $rtrb_wa_perm );
$router->get( 'whatsapp/settings', array( WhatsAppController::class, 'get_settings' ), $rtrb_wa_perm );
$router->put( 'whatsapp/settings', array( WhatsAppController::class, 'update_settings' ), $rtrb_wa_perm );
$router->post( 'whatsapp/test-connection', array( WhatsAppController::class, 'test_connection' ), $rtrb_wa_perm );
$router->post( 'whatsapp/test', array( WhatsAppController::class, 'send_test' ), $rtrb_wa_perm );
$router->get( 'whatsapp/logs', array( WhatsAppController::class, 'logs' ), $rtrb_wa_perm );
$router->delete( 'whatsapp/logs', array( WhatsAppController::class, 'clear_logs' ), $rtrb_wa_perm );

// Employee Payout Routes.
$router->get( 'employee/dashboard/(?P<eid>\d+)/payouts/balance', array( EmployeePayoutController::class, 'getBalance' ) );
$router->get( 'employee/dashboard/(?P<eid>\d+)/payouts', array( EmployeePayoutController::class, 'listPayouts' ) );
$router->post( 'employee/dashboard/(?P<eid>\d+)/payouts', array( EmployeePayoutController::class, 'requestPayout' ) );
$router->get( 'employee/dashboard/(?P<eid>\d+)/payouts/details', array( EmployeePayoutController::class, 'getPayoutDetails' ) );
$router->put( 'employee/dashboard/(?P<eid>\d+)/payouts/details', array( EmployeePayoutController::class, 'savePayoutDetails' ) );

// Service Extras Routes.
$router->get( 'services/(?P<service_id>\d+)/extras', array( ServiceExtraController::class, 'index' ) );
$router->get( 'services/(?P<service_id>\d+)/extras/public', array( ServiceExtraController::class, 'publicIndex' ) );
$router->get( 'services/(?P<service_id>\d+)/extras/(?P<id>\d+)', array( ServiceExtraController::class, 'show' ) );
$router->post( 'services/(?P<service_id>\d+)/extras', array( ServiceExtraController::class, 'store' ) );
$router->put( 'services/(?P<service_id>\d+)/extras/(?P<id>\d+)', array( ServiceExtraController::class, 'update' ) );
$router->delete( 'services/(?P<service_id>\d+)/extras/(?P<id>\d+)', array( ServiceExtraController::class, 'destroy' ) );
$router->post( 'services/(?P<service_id>\d+)/extras/reorder', array( ServiceExtraController::class, 'reorder' ) );
$router->delete( 'services/(?P<service_id>\d+)/extras/bulk-delete', array( ServiceExtraController::class, 'bulkDelete' ) );