<?php
namespace RadiusTheme\RadiusBookingPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBookingPro\Repositories\AnalyticsRepository;

/**
 * Business logic for the Analytics module.
 */
class AnalyticsService {

	/**
	 * @var AnalyticsRepository
	 */
	private AnalyticsRepository $repo;

	/**
	 * @param AnalyticsRepository $repo Repository instance.
	 */
	public function __construct( AnalyticsRepository $repo ) {
		$this->repo = $repo;
	}

	/**
	 * Compute the previous period dates based on current range.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array [ prev_from, prev_to ]
	 */
	private function previousPeriod( string $from, string $to ): array {
		$diff      = (int) ( ( strtotime( $to ) - strtotime( $from ) ) / 86400 ) + 1;
		$prev_to   = gmdate( 'Y-m-d', strtotime( $from . ' -1 day' ) );
		$prev_from = gmdate( 'Y-m-d', strtotime( $prev_to . ' -' . ( $diff - 1 ) . ' days' ) );

		return array( $prev_from, $prev_to );
	}

	/**
	 * Calculate percentage change.
	 *
	 * @param float $current  Current value.
	 * @param float $previous Previous value.
	 *
	 * @return float
	 */
	private function percentageChange( float $current, float $previous ): float {
		if ( 0.0 === $previous ) {
			return $current > 0 ? 100 : 0;
		}

		return round( ( ( $current - $previous ) / $previous ) * 100, 2 );
	}

	/**
	 * KPI Summary: revenue, appointments, new customers, avg revenue, cancellation rate.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function kpiSummary( string $from, string $to ): array {
		list( $prev_from, $prev_to ) = $this->previousPeriod( $from, $to );

		$revenue      = $this->repo->totalRevenue( $from, $to );
		$prev_revenue = $this->repo->totalRevenue( $prev_from, $prev_to );

		$appointments      = $this->repo->totalAppointments( $from, $to );
		$prev_appointments = $this->repo->totalAppointments( $prev_from, $prev_to );

		$new_cust      = $this->repo->newCustomers( $from, $to );
		$prev_new_cust = $this->repo->newCustomers( $prev_from, $prev_to );

		$avg_rev      = $appointments > 0 ? round( $revenue / $appointments, 2 ) : 0;
		$prev_avg_rev = $prev_appointments > 0 ? round( $prev_revenue / $prev_appointments, 2 ) : 0;

		$cancelled      = $this->repo->cancelledAppointments( $from, $to );
		$prev_cancelled = $this->repo->cancelledAppointments( $prev_from, $prev_to );

		$cancel_rate      = $appointments > 0 ? round( ( $cancelled / $appointments ) * 100, 1 ) : 0;
		$prev_cancel_rate = $prev_appointments > 0 ? round( ( $prev_cancelled / $prev_appointments ) * 100, 1 ) : 0;

		return array(
			'total_revenue'        => array(
				'value'      => $revenue,
				'previous'   => $prev_revenue,
				'change_pct' => $this->percentageChange( $revenue, $prev_revenue ),
			),
			'total_appointments'   => array(
				'value'      => $appointments,
				'previous'   => $prev_appointments,
				'change_pct' => $this->percentageChange( (float) $appointments, (float) $prev_appointments ),
			),
			'new_customers'        => array(
				'value'      => $new_cust,
				'previous'   => $prev_new_cust,
				'change_pct' => $this->percentageChange( (float) $new_cust, (float) $prev_new_cust ),
			),
			'avg_revenue_per_appt' => array(
				'value'      => $avg_rev,
				'previous'   => $prev_avg_rev,
				'change_pct' => $this->percentageChange( $avg_rev, $prev_avg_rev ),
			),
			'cancellation_rate'    => array(
				'value'      => $cancel_rate,
				'previous'   => $prev_cancel_rate,
				'change_pct' => $this->percentageChange( $cancel_rate, $prev_cancel_rate ),
			),
			'currency_symbol'      => get_rtrb_currency_symbol(),
			'currency'             => get_rtrb_currency(),
		);
	}

	/**
	 * Revenue analytics: trend, by service, by employee.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function revenue( string $from, string $to ): array {
		$trend_raw = $this->repo->revenueTrend( $from, $to );
		$labels    = array();
		$data      = array();

		foreach ( $trend_raw as $row ) {
			$labels[] = $row->date_label;
			$data[]   = (float) $row->total;
		}

		$by_service  = array_map(
			function ( $row ) {
				return array(
					'service_id'   => (int) $row->service_id,
					'service_name' => $row->service_name,
					'revenue'      => (float) $row->revenue,
				);
			},
			$this->repo->revenueByService( $from, $to )
		);

		$by_employee = array_map(
			function ( $row ) {
				return array(
					'employee_id'   => (int) $row->employee_id,
					'employee_name' => $row->employee_name ?: 'Unknown',
					'revenue'       => (float) $row->revenue,
				);
			},
			$this->repo->revenueByEmployee( $from, $to )
		);

		return array(
			'trend'       => compact( 'labels', 'data' ),
			'by_service'  => array_values( $by_service ),
			'by_employee' => array_values( $by_employee ),
		);
	}

	/**
	 * Appointment analytics: status, over time, peak hours, busiest days.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function appointments( string $from, string $to ): array {
		// By status.
		$status_raw = $this->repo->appointmentsByStatus( $from, $to );
		$by_status  = array(
			'pending'   => 0,
			'confirmed' => 0,
			'completed' => 0,
			'cancelled' => 0,
		);
		foreach ( $status_raw as $row ) {
			if ( isset( $by_status[ $row->status ] ) ) {
				$by_status[ $row->status ] = (int) $row->total;
			}
		}

		// Over time.
		$over_time_raw = $this->repo->appointmentsOverTime( $from, $to );
		$ot_labels     = array();
		$ot_data       = array();
		foreach ( $over_time_raw as $row ) {
			$ot_labels[] = $row->date_label;
			$ot_data[]   = (int) $row->total;
		}

		// Peak hours.
		$peak_raw  = $this->repo->peakHours( $from, $to );
		$peak_data = array_fill( 0, 24, 0 );
		foreach ( $peak_raw as $row ) {
			$peak_data[ (int) $row->hour ] = (int) $row->total;
		}
		$peak_hours = array();
		for ( $h = 0; $h < 24; $h++ ) {
			$peak_hours[] = array(
				'hour'  => $h,
				'label' => gmdate( 'gA', mktime( $h, 0, 0 ) ),
				'count' => $peak_data[ $h ],
			);
		}

		// Busiest days.
		$days_raw    = $this->repo->busiestDays( $from, $to );
		$day_names   = array( 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' );
		$days_filled = array_fill( 0, 7, 0 );
		foreach ( $days_raw as $row ) {
			$days_filled[ (int) $row->weekday - 1 ] = (int) $row->total;
		}
		$busiest_days = array();
		for ( $d = 0; $d < 7; $d++ ) {
			$busiest_days[] = array(
				'day'   => $day_names[ $d ],
				'count' => $days_filled[ $d ],
			);
		}

		return array(
			'by_status'    => $by_status,
			'over_time'    => array(
				'labels' => $ot_labels,
				'data'   => $ot_data,
			),
			'peak_hours'   => $peak_hours,
			'busiest_days' => $busiest_days,
		);
	}

	/**
	 * Employee performance data.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function employees( string $from, string $to ): array {
		$raw = $this->repo->employeePerformance( $from, $to );

		$performance = array_map(
			function ( $row ) {
				$total = (int) $row->total_appointments;
				return array(
					'employee_id'        => (int) $row->employee_id,
					'employee_name'      => $row->employee_name ?: 'Unknown',
					'total_appointments' => $total,
					'revenue'            => (float) $row->revenue,
					'completion_rate'    => $total > 0 ? round( ( (int) $row->completed / $total ) * 100, 1 ) : 0,
					'cancellation_rate'  => $total > 0 ? round( ( (int) $row->cancelled / $total ) * 100, 1 ) : 0,
				);
			},
			$raw
		);

		return array(
			'performance' => array_values( $performance ),
		);
	}

	/**
	 * Service analytics: popular services + revenue per service.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function services( string $from, string $to ): array {
		$popular_raw = $this->repo->popularServices( $from, $to );
		$revenue_raw = $this->repo->revenueByService( $from, $to );

		$total_appts = $this->repo->totalAppointments( $from, $to );

		$popular = array_map(
			function ( $row ) use ( $total_appts ) {
				$count = (int) $row->appointment_count;
				return array(
					'service_id'        => (int) $row->service_id,
					'service_name'      => $row->service_name,
					'appointment_count' => $count,
					'utilization_pct'   => $total_appts > 0 ? round( ( $count / $total_appts ) * 100, 1 ) : 0,
				);
			},
			$popular_raw
		);

		$revenue = array_map(
			function ( $row ) {
				return array(
					'service_id'    => (int) $row->service_id,
					'service_name'  => $row->service_name,
					'total_revenue' => (float) $row->revenue,
				);
			},
			$revenue_raw
		);

		return array(
			'popular' => array_values( $popular ),
			'revenue' => array_values( $revenue ),
		);
	}

	/**
	 * Customer analytics: new vs returning, top by revenue, retention.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 *
	 * @return array
	 */
	public function customers( string $from, string $to ): array {
		list( $prev_from, $prev_to ) = $this->previousPeriod( $from, $to );

		// New vs returning.
		$nv_raw    = $this->repo->newVsReturningCustomers( $from, $to );
		$nv_labels = array();
		$nv_new    = array();
		$nv_ret    = array();
		foreach ( $nv_raw as $row ) {
			$nv_labels[] = $row->date_label;
			$nv_new[]    = (int) $row->new_customers;
			$nv_ret[]    = (int) $row->returning_customers;
		}

		// Top customers by revenue.
		$top_raw = $this->repo->topCustomersByRevenue( $from, $to );
		$top     = array_map(
			function ( $row ) {
				return array(
					'customer_id'       => (int) $row->customer_id,
					'customer_name'     => $row->customer_name ?: 'Unknown',
					'total_revenue'     => (float) $row->total_revenue,
					'appointment_count' => (int) $row->appointment_count,
				);
			},
			$top_raw
		);

		// Retention rate.
		$retention_rate = $this->repo->customerRetentionRate( $from, $to, $prev_from, $prev_to );

		return array(
			'new_vs_returning' => array(
				'labels'    => $nv_labels,
				'new'       => $nv_new,
				'returning' => $nv_ret,
			),
			'top_by_revenue'   => array_values( $top ),
			'retention_rate'   => $retention_rate,
		);
	}
}
