<?php

namespace RadiusTheme\RadiusBookingPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use DateTime;
use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBooking\Helpers\BookingHelper;
use RadiusTheme\RadiusBooking\Helpers\SettingsHelper;
use RadiusTheme\RadiusBooking\Models\Payment;
use RadiusTheme\RadiusBooking\Repositories\AppointmentRepository;
use RadiusTheme\RadiusBooking\Repositories\ServiceRepository;
use RadiusTheme\RadiusBooking\Repositories\UserRepository;

/**
 * Pro appointment service — reschedule logic.
 */
class AppointmentProService {

	/**
	 * Reschedule an existing appointment.
	 *
	 * @param int    $id      Appointment ID.
	 * @param string $new_date New appointment date (Y-m-d).
	 * @param string $new_time New start time (H:i:s).
	 *
	 * @return array Result with success status and message.
	 */
	public function rescheduleAppointment( $id, $new_date, $new_time ) {
		// Check if rescheduling is allowed in customer settings.
		$customer_settings = SettingsHelper::get_setting( 'customer' );
		$allow_reschedule  = $customer_settings['allowReschedule'] ?? false;

		if ( ! $allow_reschedule ) {
			return array(
				'success' => false,
				'message' => __( 'Booking rescheduling is not allowed.', 'radius-booking-pro' ),
			);
		}

		$appointment_repo = Container::resolve( AppointmentRepository::class );
		$service_repo     = Container::resolve( ServiceRepository::class );

		$appointment = $appointment_repo->findOrFail( $id );

		// Calculate new end time.
		$service   = $service_repo->find( $appointment->service_id );
		$start     = new DateTime( $new_time );
		$minutes   = $service->duration / 60;
		$end_time  = $start->modify( "+{$minutes} minutes" );

		$min_reschedule_time = $service->get_min_reschedule_time() ?? 0;

		if ( 'disabled' !== $min_reschedule_time ) {
			$check = $this->checkMinRescheduleTime( $appointment, $min_reschedule_time );

			if ( false === $check['valid'] ) {
				return array(
					'success' => false,
					'message' => $check['message'],
				);
			}
		}

		$updated = $appointment_repo->update(
			$id,
			array(
				'appointment_date' => $new_date,
				'start_time'       => $new_time,
				'end_time'         => $end_time->format( 'H:i:s' ),
			)
		);

		if ( $updated ) {
			Payment::find( $appointment->get_payment_id() )->update(
				array(
					'booking_date_time' => $new_date . ' ' . $new_time,
				)
			);
		}

		return array(
			'success' => $updated,
			'message' => __( 'Appointment rescheduled successfully', 'radius-booking-pro' ),
		);
	}

	/**
	 * Check if the minimum reschedule time requirement is met.
	 *
	 * @param object $appointment        The appointment object.
	 * @param int    $min_reschedule_time Minimum reschedule time in seconds.
	 *
	 * @return array Array with 'valid' boolean and optional 'message'.
	 */
	private function checkMinRescheduleTime( $appointment, $min_reschedule_time ) {
		$user_repo   = Container::resolve( UserRepository::class );
		$employee_id = $appointment->get_employee_id() ?? null;
		$employee    = $employee_id ? $user_repo->get_profile( $employee_id ) : null;

		$appointment_date = $appointment->appointment_date();
		$appointment_time = $appointment->start_time();

		// Convert seconds to minutes.
		$minimum_minutes = $min_reschedule_time / 60;

		// Determine timezone - use employee's timezone or fall back to site timezone.
		$timezone = ( $employee && ! empty( $employee->timezone ) )
			? new \DateTimeZone( $employee->timezone )
			: wp_timezone();

		$current_datetime     = new \DateTime( 'now', $timezone );
		$appointment_datetime = new \DateTime(
			$appointment_date . ' ' . $appointment_time,
			$timezone
		);

		// Calculate the minimum required time before appointment.
		$minimum_required_datetime = clone $current_datetime;
		$minimum_required_datetime->modify( "+{$minimum_minutes} minutes" );

		$cancellation_deadline = clone $appointment_datetime;
		$cancellation_deadline->modify( "-{$minimum_minutes} minutes" );

		if ( $appointment_datetime->getTimestamp() < $minimum_required_datetime->getTimestamp() ) {
			$time_text = BookingHelper::formatMinutesAsReadableTime( $minimum_minutes );

			return array(
				'valid'   => false,
				'message' => sprintf(
					/* translators: %1$s: Minimum time required, %2$s: Appointment date/time, %3$s: Rescheduling deadline */
					__( ' Reschedule not allowed. This service requires %1$s advance notice for  rescheduling. Your appointment is scheduled for %2$s, and the rescheduling deadline was %3$s.', 'radius-booking-pro' ),
					$time_text,
					$appointment_datetime->format( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ),
					$cancellation_deadline->format( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) )
				),
			);
		}

		return array( 'valid' => true );
	}
}
