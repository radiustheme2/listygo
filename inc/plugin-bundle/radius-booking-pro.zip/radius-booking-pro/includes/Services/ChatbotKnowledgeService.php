<?php

namespace RadiusTheme\RadiusBookingPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ChatbotKnowledgeService
 *
 * Manages the chatbot knowledge base (FAQ entries).
 */
class ChatbotKnowledgeService {

	/**
	 * Option key for knowledge base storage.
	 *
	 * @var string
	 */
	private $option_key = 'rtrb_chatbotKnowledge_settings';

	/**
	 * Get all knowledge entries.
	 *
	 * @return array
	 */
	public function getAll(): array {
		return get_option( $this->option_key, self::seed_entries() );
	}

	/**
	 * Seed FAQ entries used as defaults when no knowledge has been saved yet.
	 *
	 * @return array
	 */
	private static function seed_entries(): array {
		return array(
			array(
				'id'       => 'default-cancellation',
				'question' => __( 'What is your cancellation policy?', 'radius-booking-pro' ),
				'answer'   => __( 'You can cancel your appointment up to 24 hours before the scheduled time. Please contact us or use the My Bookings page to cancel.', 'radius-booking-pro' ),
				'category' => 'policy',
			),
			array(
				'id'       => 'default-reschedule',
				'question' => __( 'Can I reschedule my appointment?', 'radius-booking-pro' ),
				'answer'   => __( 'Yes, you can reschedule your appointment up to 12 hours before the scheduled time through the My Bookings page.', 'radius-booking-pro' ),
				'category' => 'policy',
			),
			array(
				'id'       => 'default-payment',
				'question' => __( 'What payment methods do you accept?', 'radius-booking-pro' ),
				'answer'   => __( 'We accept various payment methods including online payments and pay-at-venue options. Check the booking form for available methods.', 'radius-booking-pro' ),
				'category' => 'payment',
			),
		);
	}

	/**
	 * Create a new knowledge entry.
	 *
	 * @param array $data Entry data with question, answer, category.
	 *
	 * @return array The created entry.
	 */
	public function create( array $data ): array {
		$entries = $this->getAll();

		$entry = array(
			'id'       => wp_generate_uuid4(),
			'question' => sanitize_text_field( $data['question'] ?? '' ),
			'answer'   => wp_kses_post( $data['answer'] ?? '' ),
			'category' => sanitize_text_field( $data['category'] ?? 'general' ),
		);

		$entries[] = $entry;
		update_option( $this->option_key, $entries );

		return $entry;
	}

	/**
	 * Update a knowledge entry by ID.
	 *
	 * @param string $id   Entry ID.
	 * @param array  $data Updated data.
	 *
	 * @return array|null Updated entry or null if not found.
	 */
	public function update( string $id, array $data ): ?array {
		$entries = $this->getAll();
		$updated = null;

		foreach ( $entries as &$entry ) {
			if ( $entry['id'] === $id ) {
				if ( isset( $data['question'] ) ) {
					$entry['question'] = sanitize_text_field( $data['question'] );
				}
				if ( isset( $data['answer'] ) ) {
					$entry['answer'] = wp_kses_post( $data['answer'] );
				}
				if ( isset( $data['category'] ) ) {
					$entry['category'] = sanitize_text_field( $data['category'] );
				}
				$updated = $entry;
				break;
			}
		}

		if ( $updated ) {
			update_option( $this->option_key, $entries );
		}

		return $updated;
	}

	/**
	 * Delete a knowledge entry by ID.
	 *
	 * @param string $id Entry ID.
	 *
	 * @return bool True if deleted.
	 */
	public function delete( string $id ): bool {
		$entries  = $this->getAll();
		$filtered = array_values(
			array_filter(
				$entries,
				function ( $entry ) use ( $id ) {
					return $entry['id'] !== $id;
				}
			)
		);

		if ( count( $filtered ) === count( $entries ) ) {
			return false;
		}

		update_option( $this->option_key, $filtered );

		return true;
	}

	/**
	 * Search knowledge entries by query.
	 *
	 * @param string $query Search query.
	 *
	 * @return array Matching entries.
	 */
	public function search( string $query ): array {
		$entries = $this->getAll();
		$query   = strtolower( $query );

		return array_values(
			array_filter(
				$entries,
				function ( $entry ) use ( $query ) {
					return str_contains( strtolower( $entry['question'] ), $query )
						|| str_contains( strtolower( $entry['answer'] ), $query );
				}
			)
		);
	}
}
