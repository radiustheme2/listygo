<?php

namespace RadiusTheme\RadiusBookingPro\Services;

use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBooking\Helpers\SettingsHelper;
use RadiusTheme\RadiusBooking\Models\Appointment;
use RadiusTheme\RadiusBooking\Models\Service;
use RadiusTheme\RadiusBooking\Repositories\AppointmentRepository;
use RadiusTheme\RadiusBooking\Repositories\ServiceRepository;
use RadiusTheme\RadiusBooking\Repositories\UserRepository;
use RadiusTheme\RadiusBooking\Services\AppointmentService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ChatbotService
 *
 * Integrates with OpenAI GPT and Google Gemini for the AI booking assistant.
 * Uses function calling to interact with existing booking services.
 */
class ChatbotService {

	/**
	 * Maximum tool-call loop iterations.
	 */
	private const MAX_TOOL_ITERATIONS = 5;

	/**
	 * @var AppointmentService
	 */
	private $appointment_service;

	/**
	 * @var ServiceRepository
	 */
	private $service_repository;

	/**
	 * @var UserRepository
	 */
	private $user_repository;

	/**
	 * @var AppointmentRepository
	 */
	private $appointment_repository;

	/**
	 * Structured UI data collected during tool execution.
	 * Sent to frontend for rich rendering in "modern" mode.
	 *
	 * @var array|null
	 */
	private $ui_data = null;

	/**
	 * Constructor.
	 *
	 * @param AppointmentService    $appointment_service    Appointment service.
	 * @param ServiceRepository     $service_repository     Service repository.
	 * @param UserRepository        $user_repository        User repository.
	 * @param AppointmentRepository $appointment_repository Appointment repository.
	 */
	public function __construct(
		AppointmentService $appointment_service,
		ServiceRepository $service_repository,
		UserRepository $user_repository,
		AppointmentRepository $appointment_repository
	) {
		$this->appointment_service    = $appointment_service;
		$this->service_repository     = $service_repository;
		$this->user_repository        = $user_repository;
		$this->appointment_repository = $appointment_repository;
	}

	/**
	 * Process a user message through the configured AI provider.
	 *
	 * @param string $message             User message.
	 * @param array  $conversation_history Previous messages.
	 * @param array  $completed_steps      Booking flow steps already completed.
	 *
	 * @return array Response with reply text.
	 */
	public function processMessage( string $message, array $conversation_history = array(), array $completed_steps = array() ): array {
		$settings = SettingsHelper::get_setting( 'chatbot' );
		$provider = $settings['provider'] ?? 'openai';

		// Check API key based on provider.
		if ( 'gemini' === $provider ) {
			$api_key = $settings['geminiApiKey'] ?? '';
		} else {
			$api_key = $settings['apiKey'] ?? '';
		}

		if ( empty( $api_key ) ) {
			return array(
				'reply' => __( 'The chatbot is not configured yet. Please contact the administrator.', 'radius-booking-pro' ),
			);
		}

		$this->ui_data = null;
		$system_prompt = $this->buildSystemPrompt( $completed_steps );
		$tools         = $this->getToolDefinitions();

		// Build messages array.
		$messages   = array();
		$messages[] = array(
			'role'    => 'system',
			'content' => $system_prompt,
		);

		// Add conversation history (last 20 messages).
		$history = array_slice( $conversation_history, -20 );
		foreach ( $history as $msg ) {
			$messages[] = array(
				'role'    => sanitize_text_field( $msg['role'] ?? 'user' ),
				'content' => wp_kses_post( $msg['content'] ?? '' ),
			);
		}

		// Add current user message.
		$messages[] = array(
			'role'    => 'user',
			'content' => sanitize_text_field( $message ),
		);

		if ( 'gemini' === $provider ) {
			return $this->processWithGemini( $messages, $tools, $settings );
		}

		return $this->processWithOpenAI( $messages, $tools, $settings );
	}

	/**
	 * Process messages using OpenAI with tool-call loop.
	 *
	 * @param array $messages Chat messages.
	 * @param array $tools    Tool definitions.
	 * @param array $settings Chatbot settings.
	 *
	 * @return array
	 */
	private function processWithOpenAI( array $messages, array $tools, array $settings ): array {
		$iterations = 0;
		while ( $iterations < self::MAX_TOOL_ITERATIONS ) {
			$response = $this->callOpenAI( $messages, $tools, $settings );
			if ( is_wp_error( $response ) ) {
				return array(
					'reply' => 'I\'m having trouble connecting right now. Please try again in a moment.',
				);
			}

			$choice = $response['choices'][0]['message'] ?? null;
			if ( ! $choice ) {
				return array(
					'reply' => 'I couldn\'t process your request. Please try again.',
				);
			}

			// If there are tool calls, execute them.
			if ( ! empty( $choice['tool_calls'] ) ) {
				$messages[] = $choice;

				foreach ( $choice['tool_calls'] as $tool_call ) {
					$function_name = $tool_call['function']['name'] ?? '';
					$arguments     = json_decode( $tool_call['function']['arguments'] ?? '{}', true );
					$result        = $this->executeToolCall( $function_name, $arguments ?: array() );

					$messages[] = array(
						'role'         => 'tool',
						'tool_call_id' => $tool_call['id'],
						'content'      => wp_json_encode( $result ),
					);
				}

				++$iterations;
				continue;
			}

			$result = array(
				'reply' => $choice['content'] ?? 'I\'m not sure how to help with that.',
			);
			if ( $this->ui_data ) {
				$result['ui_data'] = $this->ui_data;
			}
			return $result;
		}

		return array(
			'reply' => 'I\'ve been processing for too long. Could you simplify your request?',
		);
	}

	/**
	 * Process messages using Google Gemini with tool-call loop.
	 *
	 * @param array $messages Chat messages (OpenAI format, will be converted).
	 * @param array $tools    Tool definitions (OpenAI format, will be converted).
	 * @param array $settings Chatbot settings.
	 *
	 * @return array
	 */
	private function processWithGemini( array $messages, array $tools, array $settings ): array {
		$gemini_contents = $this->convertMessagesToGemini( $messages );
		$gemini_tools    = $this->convertToolsToGemini( $tools );
		$system_prompt   = '';

		// Extract system instruction (first message if role is system).
		if ( ! empty( $messages ) && 'system' === $messages[0]['role'] ) {
			$system_prompt = $messages[0]['content'];
		}

		$iterations = 0;
		while ( $iterations < self::MAX_TOOL_ITERATIONS ) {
			$response = $this->callGemini( $gemini_contents, $gemini_tools, $system_prompt, $settings );
			if ( is_wp_error( $response ) ) {
				return array(
					'reply' => 'I\'m having trouble connecting right now. Please try again in a moment.',
				);
			}

			$candidate = $response['candidates'][0] ?? null;
			if ( ! $candidate ) {
				return array(
					'reply' => 'I couldn\'t process your request. Please try again.',
				);
			}

			$parts = $candidate['content']['parts'] ?? array();
			// Check for function calls in the response.
			$function_calls = array_filter( $parts, fn( $p ) => isset( $p['functionCall'] ) );

			if ( ! empty( $function_calls ) ) {
				// Rebuild model response: keep functionCall parts with
				// thoughtSignature (required by Gemini 3) and ensure args
				// is always a JSON object, never a JSON array.
				$clean_parts = array();
				foreach ( $parts as $part ) {
					if ( isset( $part['functionCall'] ) ) {
						$fc_args    = $part['functionCall']['args'] ?? array();
						$clean_part = array(
							'functionCall' => array(
								'name' => $part['functionCall']['name'],
								'args' => empty( $fc_args ) ? (object) array() : (object) $fc_args,
							),
						);
						// Preserve thoughtSignature if present (required by Gemini 3).
						if ( isset( $part['thoughtSignature'] ) ) {
							$clean_part['thoughtSignature'] = $part['thoughtSignature'];
						}
						$clean_parts[] = $clean_part;
					} elseif ( isset( $part['text'] ) ) {
						$clean_parts[] = array( 'text' => $part['text'] );
					}
				}

				$gemini_contents[] = array(
					'role'  => 'model',
					'parts' => $clean_parts,
				);

				// Execute each function call and add results.
				$function_responses = array();
				foreach ( $function_calls as $fc ) {
					$name   = $fc['functionCall']['name'] ?? '';
					$args   = (array) ( $fc['functionCall']['args'] ?? array() );
					$result = $this->executeToolCall( $name, $args );

					$function_responses[] = array(
						'functionResponse' => array(
							'name'     => $name,
							'response' => (object) $result,
						),
					);
				}

				$gemini_contents[] = array(
					'role'  => 'user',
					'parts' => $function_responses,
				);

				++$iterations;
				continue;
			}

			// No function calls, extract text reply.
			$text_parts = array_filter( $parts, fn( $p ) => isset( $p['text'] ) );
			$reply      = '';
			foreach ( $text_parts as $tp ) {
				$reply .= $tp['text'];
			}

			$result = array(
				'reply' => $reply ?: 'I\'m not sure how to help with that.',
			);
			if ( $this->ui_data ) {
				$result['ui_data'] = $this->ui_data;
			}
			return $result;
		}

		return array(
			'reply' => 'I\'ve been processing for too long. Could you simplify your request?',
		);
	}

	/**
	 * Build the system prompt with business context.
	 *
	 * @param array $completed_steps Booking flow steps already completed.
	 *
	 * @return string
	 */
	private function buildSystemPrompt( array $completed_steps = array() ): string {
		$business  = SettingsHelper::get_setting( 'business' );
		$chatbot   = SettingsHelper::get_setting( 'chatbot' );
		$knowledge = Container::resolve( ChatbotKnowledgeService::class )->getAll();

		$bot_name     = $chatbot['botName'] ?? 'Booking Assistant';
		$company_name = $business['companyName'] ?? get_bloginfo( 'name' );
		$phone        = $business['phone'] ?? '';
		$address      = $business['address'] ?? '';

		$today    = wp_date( 'Y-m-d' );
		$day_name = wp_date( 'l' );
		$timezone = wp_timezone_string();

		$currency_symbol = function_exists( 'get_rtrb_currency_symbol' ) ? get_rtrb_currency_symbol() : '$';

		$response_style = $chatbot['responseStyle'] ?? 'modern';
		$is_modern      = 'modern' === $response_style;

		$prompt  = "You are {$bot_name}, a professional and friendly booking assistant for {$company_name}.\n\n";

		$prompt .= "## Your Personality\n";
		$prompt .= "- Warm, professional, and conversational — like a real receptionist who genuinely cares.\n";
		$prompt .= "- Use natural language with personality. Avoid sounding robotic or generic.\n";
		$prompt .= "- Adapt your tone to the customer: casual if they're casual, formal if they're formal.\n";
		$prompt .= "- Use the customer's name if they provide it.\n\n";

		$prompt .= "## Date & Time Context\n";
		$prompt .= "Today is {$today} ({$day_name}). Timezone: {$timezone}.\n";
		$prompt .= "When a customer says 'tomorrow', 'next Monday', etc., calculate the correct date from today ({$today}).\n";
		$prompt .= "Always use YYYY-MM-DD format when calling tools.\n\n";

		$prompt .= "## Currency\n";
		$prompt .= "Always use the currency symbol \"{$currency_symbol}\" when mentioning prices. Never use \$ or any other currency symbol.\n\n";

		if ( $phone || $address ) {
			$prompt .= "## Business Info\n";
			if ( $phone ) {
				$prompt .= "Phone: {$phone}\n";
			}
			if ( $address ) {
				$prompt .= "Address: {$address}\n";
			}
			$prompt .= "\n";
		}

		$prompt .= "## Booking Flow\n";
		$prompt .= "Guide the customer step by step. IMPORTANT: Each step is completed ONCE — never go back to a previous step.\n";
		$prompt .= "1. **Service** — If the customer hasn't chosen a service yet, call `get_services` to show the options.\n";
		$prompt .= "   If they already mentioned or selected a service, skip this — do NOT call `get_services` again.\n";
		$prompt .= "2. **Staff** — Once a service is chosen, call `get_service_employees` with the service_id.\n";
		$prompt .= "3. **Date** — Once a staff member is chosen, call `get_available_dates` with the service_id and employee_id.\n";
		$prompt .= "4. **Time** — When the customer picks a date, call `check_availability` with the service_id, employee_id, and that date.\n";
		$prompt .= "5. **Confirm** — Summarize the booking details (service, staff, date, time, duration, price) and ask for confirmation.\n";
		$prompt .= "6. **Collect Info** — After confirmation, ask ONLY for their name and email. Do NOT call any tools at this step. Just ask the question in plain text.\n";
		$prompt .= "7. **Book** — Once you have the name and email, call `create_booking` with ALL the collected details.\n\n";

		$prompt .= "## State Awareness (CRITICAL)\n";
		$prompt .= "Read the conversation history carefully to determine what has already been done:\n";
		$prompt .= "- If a service was already shown or selected → NEVER call `get_services` again.\n";
		$prompt .= "- If a staff member was already shown or selected → NEVER call `get_service_employees` again.\n";
		$prompt .= "- If dates were already shown or a date was selected → NEVER call `get_available_dates` again.\n";
		$prompt .= "- If time slots were already shown or a time was selected → NEVER call `check_availability` again.\n";
		$prompt .= "- If you are asking for customer name/email → call NO tools at all. Just ask the question.\n";
		$prompt .= "- NEVER repeat a completed step. Only move forward in the flow.\n\n";

		$prompt .= "## Rules\n";
		$prompt .= "- Always use tools to look up real data. Never make up services, prices, or availability.\n";
		$prompt .= "- Only use dates today ({$today}) or in the future.\n";
		$prompt .= "- If you don't know something, say so honestly and offer alternatives.\n";
		$prompt .= "- Keep responses focused but not robotic. 2-4 sentences is ideal for most replies.\n";
		$prompt .= "- When asking a question, only ask ONE thing at a time to keep the conversation flowing.\n";
		$prompt .= "- When a user asks to book a service and you need to determine which service, call `get_services` ONCE. Do not call it multiple times in the same conversation.\n";

		if ( $is_modern ) {
			$prompt .= "\n## UI Card Mode (Active)\n";
			$prompt .= "The chat interface renders interactive cards automatically:\n";
			$prompt .= "- **Service cards** appear when you call `get_services` — customers can tap to select.\n";
			$prompt .= "- **Staff cards** appear when you call `get_service_employees` — customers can tap to choose a staff member.\n";
			$prompt .= "- **Date picker calendar** appears when you call `get_available_dates` — customers can tap an available date.\n";
			$prompt .= "- **Time slot buttons** appear when you call `check_availability` — customers can tap a time.\n";
			$prompt .= "- **Booking confirmation card** appears when you call `create_booking`.\n\n";
			$prompt .= "Because of this:\n";
			$prompt .= "- When calling `get_services`: Write a short, friendly intro like \"Here are our services — tap one to get started!\" Do NOT list service names, prices, or durations in your text.\n";
			$prompt .= "- When calling `get_service_employees`: Write something like \"Great choice! Now pick your preferred staff member:\" Do NOT list staff names in your text.\n";
			$prompt .= "- When calling `get_available_dates`: Write something like \"Here's their availability — pick a date that works for you!\" Do NOT list dates in your text.\n";
			$prompt .= "- When calling `check_availability`: Write something like \"Perfect! Here are the available times:\" Do NOT list times in your text.\n";
			$prompt .= "- When calling `create_booking`: Write a congratulatory message. The card shows the details.\n";
			$prompt .= "- When asking for customer name/email: Write a friendly request. Do NOT call any tools or show any cards.\n";
			$prompt .= "- For all other messages (questions, conversation, errors): Write naturally and helpfully. Do NOT be overly brief.\n\n";
			$prompt .= "### CRITICAL RULES — Violations break the user experience:\n";
			$prompt .= "1. NEVER call `get_services` if a service was already selected or shown earlier in the conversation. The service step is DONE.\n";
			$prompt .= "2. NEVER call `get_service_employees` if a staff member was already selected. The staff step is DONE.\n";
			$prompt .= "3. NEVER call `get_available_dates` if a date was already picked. The date step is DONE.\n";
			$prompt .= "4. NEVER call `check_availability` if a time was already picked. The time step is DONE.\n";
			$prompt .= "5. When the customer picks a staff member, immediately call `get_available_dates`. Do NOT ask who they want again.\n";
			$prompt .= "6. When the customer picks a date from the calendar, immediately call `check_availability`. Do NOT call `get_available_dates` again.\n";
			$prompt .= "7. When asking for name and email before booking, call NO tools at all. Just write a text message asking for their information.\n";
			$prompt .= "8. Each response must advance the conversation exactly ONE step forward. Never go backward.\n";
		}

		// Inject completed steps context so the AI knows the current booking state.
		if ( ! empty( $completed_steps ) ) {
			$step_labels = array(
				'service_shown'   => 'Services have been shown/selected — do NOT call get_services',
				'staff_shown'     => 'Staff members have been shown/selected — do NOT call get_service_employees',
				'dates_shown'     => 'Available dates have been shown/date selected — do NOT call get_available_dates',
				'timeslots_shown' => 'Time slots have been shown/time selected — do NOT call check_availability',
				'booking_created' => 'Booking has been created — the flow is complete',
			);
			$prompt .= "\n## CURRENT BOOKING STATE (from UI tracking)\n";
			$prompt .= "The following steps have ALREADY been completed in this conversation. DO NOT repeat them:\n";
			foreach ( $completed_steps as $step ) {
				if ( isset( $step_labels[ $step ] ) ) {
					$prompt .= "- ✓ {$step_labels[ $step ]}\n";
				}
			}
			$prompt .= "Only advance to the NEXT uncompleted step.\n\n";
		}

		if ( ! empty( $knowledge ) ) {
			$prompt .= "\n## Knowledge Base\n";
			$prompt .= "Use these to answer common questions:\n";
			foreach ( $knowledge as $entry ) {
				$prompt .= "- Q: {$entry['question']}\n  A: {$entry['answer']}\n";
			}
			$prompt .= "\n";
		}

		return $prompt;
	}

	/**
	 * Get OpenAI function tool definitions.
	 *
	 * @return array
	 */
	private function getToolDefinitions(): array {
		return array(
			array(
				'type'     => 'function',
				'function' => array(
					'name'        => 'get_services',
					'description' => 'Get the list of available services with their details (name, duration, price). ONLY call this at the very start of a booking when the customer has NOT yet chosen a service. NEVER call this if a service was already selected or discussed in the conversation.',
					'parameters'  => array(
						'type'       => 'object',
						'properties' => new \stdClass(),
					),
				),
			),
			array(
				'type'     => 'function',
				'function' => array(
					'name'        => 'check_availability',
					'description' => 'Check available time slots for a specific employee, service, and date. Call this after the customer picks a date from the calendar.',
					'parameters'  => array(
						'type'       => 'object',
						'properties' => array(
							'service_id'  => array(
								'type'        => 'integer',
								'description' => 'The ID of the service.',
							),
							'employee_id' => array(
								'type'        => 'integer',
								'description' => 'The employee/staff ID.',
							),
							'date'        => array(
								'type'        => 'string',
								'description' => 'The date to check in YYYY-MM-DD format.',
							),
						),
						'required'   => array( 'service_id', 'employee_id', 'date' ),
					),
				),
			),
			array(
				'type'     => 'function',
				'function' => array(
					'name'        => 'create_booking',
					'description' => 'Create a new appointment booking.',
					'parameters'  => array(
						'type'       => 'object',
						'properties' => array(
							'service_id'     => array(
								'type'        => 'integer',
								'description' => 'The service ID.',
							),
							'employee_id'    => array(
								'type'        => 'integer',
								'description' => 'The employee/staff ID.',
							),
							'date'           => array(
								'type'        => 'string',
								'description' => 'Appointment date in YYYY-MM-DD format.',
							),
							'time'           => array(
								'type'        => 'string',
								'description' => 'Appointment time in HH:MM format (24h).',
							),
							'customer_name'  => array(
								'type'        => 'string',
								'description' => 'Customer full name.',
							),
							'customer_email' => array(
								'type'        => 'string',
								'description' => 'Customer email address.',
							),
							'customer_phone' => array(
								'type'        => 'string',
								'description' => 'Customer phone number.',
							),
							'note'           => array(
								'type'        => 'string',
								'description' => 'Optional note for the appointment.',
							),
						),
						'required'   => array( 'service_id', 'employee_id', 'date', 'time', 'customer_name', 'customer_email' ),
					),
				),
			),
			array(
				'type'     => 'function',
				'function' => array(
					'name'        => 'cancel_booking',
					'description' => 'Cancel an existing appointment by its ID.',
					'parameters'  => array(
						'type'       => 'object',
						'properties' => array(
							'appointment_id' => array(
								'type'        => 'integer',
								'description' => 'The appointment ID to cancel.',
							),
						),
						'required'   => array( 'appointment_id' ),
					),
				),
			),
			array(
				'type'     => 'function',
				'function' => array(
					'name'        => 'reschedule_booking',
					'description' => 'Reschedule an existing appointment to a new date and time.',
					'parameters'  => array(
						'type'       => 'object',
						'properties' => array(
							'appointment_id' => array(
								'type'        => 'integer',
								'description' => 'The appointment ID to reschedule.',
							),
							'new_date'       => array(
								'type'        => 'string',
								'description' => 'New date in YYYY-MM-DD format.',
							),
							'new_time'       => array(
								'type'        => 'string',
								'description' => 'New time in HH:MM format (24h).',
							),
						),
						'required'   => array( 'appointment_id', 'new_date', 'new_time' ),
					),
				),
			),
			array(
				'type'     => 'function',
				'function' => array(
					'name'        => 'search_knowledge',
					'description' => 'Search the knowledge base for answers to common questions about policies, hours, payments, etc.',
					'parameters'  => array(
						'type'       => 'object',
						'properties' => array(
							'query' => array(
								'type'        => 'string',
								'description' => 'The search query.',
							),
						),
						'required'   => array( 'query' ),
					),
				),
			),
		array(
				'type'     => 'function',
				'function' => array(
					'name'        => 'get_service_employees',
					'description' => 'Get the list of staff/employees assigned to a specific service. Call this after the customer picks a service so they can choose their preferred staff member.',
					'parameters'  => array(
						'type'       => 'object',
						'properties' => array(
							'service_id' => array(
								'type'        => 'integer',
								'description' => 'The ID of the service.',
							),
						),
						'required'   => array( 'service_id' ),
					),
				),
			),
			array(
				'type'     => 'function',
				'function' => array(
					'name'        => 'get_available_dates',
					'description' => 'Get available dates for a specific employee and service for the next 60 days. Call this after the customer picks a staff member to show them a calendar.',
					'parameters'  => array(
						'type'       => 'object',
						'properties' => array(
							'service_id'  => array(
								'type'        => 'integer',
								'description' => 'The ID of the service.',
							),
							'employee_id' => array(
								'type'        => 'integer',
								'description' => 'The ID of the employee/staff member.',
							),
						),
						'required'   => array( 'service_id', 'employee_id' ),
					),
				),
			),
		);
	}

	/**
	 * Call OpenAI Chat Completions API.
	 *
	 * @param array $messages Chat messages.
	 * @param array $tools    Tool definitions.
	 * @param array $settings Chatbot settings.
	 *
	 * @return array|\WP_Error
	 */
	private function callOpenAI( array $messages, array $tools, array $settings ) {
		$api_key     = $settings['apiKey'];
		$model       = $settings['model'] ?? 'gpt-4o-mini';
		$max_tokens  = (int) ( $settings['maxTokens'] ?? 1024 );
		$temperature = (float) ( $settings['temperature'] ?? 0.7 );

		$body = array(
			'model'       => $model,
			'messages'    => $messages,
			'tools'       => $tools,
			'max_tokens'  => $max_tokens,
			'temperature' => $temperature,
		);

		$response = wp_remote_post(
			'https://api.openai.com/v1/chat/completions',
			array(
				'timeout' => 30,
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . $api_key,
				),
				'body'    => wp_json_encode( $body ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			return new \WP_Error(
				'openai_error',
				$body['error']['message'] ?? 'OpenAI API error',
				array( 'status' => $code )
			);
		}

		return $body;
	}

	/**
	 * Call Google Gemini API.
	 *
	 * @param array  $contents       Gemini-format contents.
	 * @param array  $tools          Gemini-format tool declarations.
	 * @param string $system_prompt  System instruction text.
	 * @param array  $settings       Chatbot settings.
	 *
	 * @return array|\WP_Error
	 */
	private function callGemini( array $contents, array $tools, string $system_prompt, array $settings ) {
		$api_key     = $settings['geminiApiKey'];
		$model       = $settings['geminiModel'] ?? 'gemini-2.0-flash';
		$max_tokens  = (int) ( $settings['maxTokens'] ?? 1024 );
		$temperature = (float) ( $settings['temperature'] ?? 0.7 );
		$url = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent';

		$body = array(
			'contents'         => $contents,
			'generationConfig' => array(
				'maxOutputTokens' => $max_tokens,
				'temperature'     => $temperature,
			),
		);

		if ( ! empty( $system_prompt ) ) {
			$body['systemInstruction'] = array(
				'parts' => array(
					array( 'text' => $system_prompt ),
				),
			);
		}

		if ( ! empty( $tools ) ) {
			$body['tools'] = $tools;
		}

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 30,
				'headers' => array(
					'Content-Type' => 'application/json',
					'x-goog-api-key' => $api_key,
				),
				'body'    => wp_json_encode( $body ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code         = wp_remote_retrieve_response_code( $response );
		$decoded_body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $code ) {
			$error_msg = $decoded_body['error']['message'] ?? 'Gemini API error';
			return new \WP_Error(
				'gemini_error',
				$error_msg,
				array( 'status' => $code )
			);
		}

		return $decoded_body;
	}

	/**
	 * Convert OpenAI-format messages to Gemini contents format.
	 * Skips 'system' role (handled separately as systemInstruction).
	 *
	 * @param array $messages OpenAI-format messages.
	 *
	 * @return array Gemini-format contents.
	 */
	private function convertMessagesToGemini( array $messages ): array {
		$contents = array();

		foreach ( $messages as $msg ) {
			$role = $msg['role'] ?? '';

			// System messages are handled via systemInstruction.
			if ( 'system' === $role ) {
				continue;
			}

			// Map OpenAI roles to Gemini roles.
			$gemini_role = 'user';
			if ( 'assistant' === $role ) {
				$gemini_role = 'model';
			}

			$contents[] = array(
				'role'  => $gemini_role,
				'parts' => array(
					array( 'text' => $msg['content'] ?? '' ),
				),
			);
		}

		return $contents;
	}

	/**
	 * Convert OpenAI-format tool definitions to Gemini function declarations.
	 *
	 * @param array $tools OpenAI-format tools.
	 *
	 * @return array Gemini-format tools.
	 */
	private function convertToolsToGemini( array $tools ): array {
		$declarations = array();

		foreach ( $tools as $tool ) {
			if ( 'function' !== ( $tool['type'] ?? '' ) ) {
				continue;
			}

			$fn = $tool['function'];

			$declaration = array(
				'name'        => $fn['name'],
				'description' => $fn['description'],
			);

			// Convert parameters.
			$params = $fn['parameters'] ?? array();
			if ( ! empty( $params['properties'] ) && ! ( $params['properties'] instanceof \stdClass ) ) {
				$gemini_props = array();
				foreach ( $params['properties'] as $prop_name => $prop_def ) {
					$gemini_prop = array(
						'type'        => strtoupper( $prop_def['type'] ?? 'STRING' ),
						'description' => $prop_def['description'] ?? '',
					);
					// Gemini uses uppercase type names.
					$type_map = array(
						'STRING'  => 'STRING',
						'INTEGER' => 'INTEGER',
						'NUMBER'  => 'NUMBER',
						'BOOLEAN' => 'BOOLEAN',
						'ARRAY'   => 'ARRAY',
						'OBJECT'  => 'OBJECT',
					);
					$gemini_prop['type'] = $type_map[ $gemini_prop['type'] ] ?? 'STRING';
					$gemini_props[ $prop_name ] = $gemini_prop;
				}

				$declaration['parameters'] = array(
					'type'       => 'OBJECT',
					'properties' => $gemini_props,
				);

				if ( ! empty( $params['required'] ) ) {
					$declaration['parameters']['required'] = $params['required'];
				}
			} else {
				// No parameters — empty object.
				$declaration['parameters'] = array(
					'type'       => 'OBJECT',
					'properties' => new \stdClass(),
				);
			}

			$declarations[] = $declaration;
		}

		return array(
			array(
				'functionDeclarations' => $declarations,
			),
		);
	}

	/**
	 * Execute a tool call and return results.
	 *
	 * @param string $name Function name.
	 * @param array  $args Function arguments.
	 *
	 * @return array
	 */
	private function executeToolCall( string $name, array $args ): array {
		switch ( $name ) {
			case 'get_services':
				return $this->toolGetServices();

			case 'check_availability':
				return $this->toolCheckAvailability( $args );

			case 'create_booking':
				return $this->toolCreateBooking( $args );

			case 'cancel_booking':
				return $this->toolCancelBooking( $args );

			case 'reschedule_booking':
				return $this->toolRescheduleBooking( $args );

			case 'search_knowledge':
				return $this->toolSearchKnowledge( $args );

			case 'get_service_employees':
				return $this->toolGetServiceEmployees( $args );

			case 'get_available_dates':
				return $this->toolGetAvailableDates( $args );

			default:
				/* translators: %s: tool name */
				return array( 'error' => sprintf( __( 'Unknown tool: %s', 'radius-booking-pro' ), $name ) );
		}
	}

	/**
	 * Tool: Get all available services.
	 *
	 * @return array
	 */
	private function toolGetServices(): array {
		try {
			$services = $this->service_repository->all();
			$result   = array();

			foreach ( $services as $service ) {
				$duration_minutes = $service->duration ? (int) $service->duration / 60 : null;
				$result[]         = array(
					'id'               => $service->id,
					'name'             => $service->name,
					'duration_minutes' => $duration_minutes,
					'price'            => $service->price ?? null,
					'status'           => $service->status ?? 'visible',
				);
			}

			$currency_symbol = function_exists( 'get_rtrb_currency_symbol' ) ? get_rtrb_currency_symbol() : '$';
			$this->ui_data   = array(
				'type'     => 'services',
				'services' => $result,
				'currency' => $currency_symbol,
			);

			return array( 'services' => $result );
		} catch ( \Exception $e ) {
			return array( 'error' => __( 'Could not retrieve services.', 'radius-booking-pro' ) );
		}
	}

	/**
	 * Tool: Check availability for a service on a date.
	 *
	 * Uses getEmployeeAvailableTimeSlot() which respects the schedule hierarchy:
	 * Special Days > Employee Custom Schedule > Global Schedule.
	 *
	 * @param array $args Arguments with service_id, date, optional employee_id.
	 *
	 * @return array
	 */
	private function toolCheckAvailability( array $args ): array {
		try {
			$service_id  = (int) ( $args['service_id'] ?? 0 );
			$date        = sanitize_text_field( $args['date'] ?? '' );
			$employee_id = (int) ( $args['employee_id'] ?? 0 );

			if ( ! $service_id || ! $date ) {
				return array( 'error' => __( 'Service ID and date are required.', 'radius-booking-pro' ) );
			}

			$slots = array();

			if ( $employee_id ) {
				$availability   = $this->appointment_service->getEmployeeAvailableTimeSlot( $employee_id, $service_id, $date );
				$available_slots = $this->extractAvailableSlots( $availability );
				if ( ! empty( $available_slots ) ) {
					$slots[] = array(
						'employee_id'   => $employee_id,
						'employee_name' => $this->getEmployeeName( $employee_id ),
						'timeslots'     => $available_slots,
					);
				}
			} else {
				// Get all employees assigned to this service.
				$employee_ids = $this->service_repository->getServicesEmployeesIds( $service_id );

				foreach ( $employee_ids as $emp_id ) {
					if ( ! $emp_id ) {
						continue;
					}
					$availability    = $this->appointment_service->getEmployeeAvailableTimeSlot( (int) $emp_id, $service_id, $date );
					$available_slots = $this->extractAvailableSlots( $availability );
					if ( ! empty( $available_slots ) ) {
						$slots[] = array(
							'employee_id'   => (int) $emp_id,
							'employee_name' => $this->getEmployeeName( (int) $emp_id ),
							'timeslots'     => $available_slots,
						);
					}
				}
			}

			// Include service info so the AI can mention price in confirmation.
			$service_info = Service::find( $service_id );
			$service_name = $service_info ? $service_info->name : '';
			$service_price = $service_info ? (float) $service_info->price : 0;
			$duration_min  = $service_info && $service_info->duration ? (int) $service_info->duration / 60 : 0;

			$currency_symbol = function_exists( 'get_rtrb_currency_symbol' ) ? get_rtrb_currency_symbol() : '$';
			$this->ui_data   = array(
				'type'            => 'availability',
				'date'            => $date,
				'service_id'      => $service_id,
				'service_name'    => $service_name,
				'service_price'   => $service_price,
				'duration_minutes' => $duration_min,
				'currency'        => $currency_symbol,
				'slots'           => $slots,
			);

			return array(
				'date'              => $date,
				'service_id'        => $service_id,
				'service_name'      => $service_name,
				'service_price'     => $service_price,
				'duration_minutes'  => $duration_min,
				'available_slots'   => $slots,
				'total_slots_count' => array_sum( array_map( fn( $s ) => count( $s['timeslots'] ), $slots ) ),
			);
		} catch ( \Exception $e ) {
			/* translators: %s: exception message */
			return array( 'error' => sprintf( __( 'Could not check availability: %s', 'radius-booking-pro' ), $e->getMessage() ) );
		}
	}

	/**
	 * Extract only available time slot strings from the availability response.
	 *
	 * @param array $availability Result from getEmployeeAvailableTimeSlot().
	 *
	 * @return array Simple list of available start times (e.g. ['09:00', '09:30', '10:00']).
	 */
	private function extractAvailableSlots( array $availability ): array {
		$available = array();
		$dates     = $availability['schedule']['available_dates'] ?? array();

		foreach ( $dates as $date_info ) {
			if ( empty( $date_info['is_available'] ) ) {
				continue;
			}
			foreach ( $date_info['time_slots'] ?? array() as $slot ) {
				if ( ! empty( $slot['is_available'] ) ) {
					$start = $slot['start_time'] ?? '';
					// Convert H:i:s to H:i for readability.
					$available[] = substr( $start, 0, 5 );
				}
			}
		}

		return $available;
	}

	/**
	 * Tool: Create a booking.
	 *
	 * Creates an Appointment record and processes customer/booking via the
	 * existing BookingService pipeline.
	 *
	 * @param array $args Booking details.
	 *
	 * @return array
	 */
	private function toolCreateBooking( array $args ): array {
		try {
			$service_id     = (int) ( $args['service_id'] ?? 0 );
			$employee_id    = (int) ( $args['employee_id'] ?? 0 );
			$date           = sanitize_text_field( $args['date'] ?? '' );
			$time           = sanitize_text_field( $args['time'] ?? '' );
			$customer_name  = sanitize_text_field( $args['customer_name'] ?? '' );
			$customer_email = sanitize_email( $args['customer_email'] ?? '' );
			$customer_phone = sanitize_text_field( $args['customer_phone'] ?? '' );
			$note           = sanitize_textarea_field( $args['note'] ?? '' );

			if ( ! $service_id || ! $employee_id || ! $date || ! $time || ! $customer_name || ! $customer_email ) {
				return array( 'error' => __( 'Missing required fields: service_id, employee_id, date, time, customer_name, customer_email.', 'radius-booking-pro' ) );
			}

			// Validate availability first.
			$service = Service::find( $service_id );
			if ( ! $service || ! $service->get_id() ) {
				return array( 'error' => __( 'Service not found.', 'radius-booking-pro' ) );
			}

			$duration_seconds = $service->duration ?? 1800;
			$duration_minutes = (int) $duration_seconds / 60;

			// Ensure time is in H:i:s format.
			$start_time = strlen( $time ) === 5 ? $time . ':00' : $time;
			$start_dt   = new \DateTime( $start_time );
			$end_dt     = clone $start_dt;
			$end_dt->modify( "+{$duration_minutes} minutes" );
			$end_time = $end_dt->format( 'H:i:s' );

			// Check if slot is available via isServiceAvailable.
			$availability_check = $this->appointment_service->isServiceAvailable(
				array(
					'service_id'       => $service_id,
					'employee_id'      => $employee_id,
					'appointment_date' => $date,
					'start_time'       => $start_time,
					'end_time'         => $end_time,
				)
			);

			if ( ! $availability_check['available'] ) {
				return array( 'error' => $availability_check['message'] );
			}

			// Determine default appointment status from service settings.
			$default_status = $service->get_appointment_status() ?? 'confirmed';

			// Create the appointment record.
			$appointment = $this->appointment_repository->create(
				array(
					'employee_id'      => $employee_id,
					'service_id'       => $service_id,
					'appointment_date' => $date,
					'start_time'       => $start_time,
					'end_time'         => $end_time,
					'status'           => $default_status,
					'notes'            => $note,
				)
			);

			if ( ! $appointment || ! $appointment->id ) {
				return array( 'error' => __( 'Failed to create appointment record.', 'radius-booking-pro' ) );
			}

			// Get employee-specific price for this service.
			$employee_price = $this->service_repository->getAssignServices( $service_id, $employee_id );
			$price          = (float) ( $employee_price->price ?? $service->price ?? 0 );

			// Process booking (customer creation, payment record, etc.)
			// via the same pipeline the normal booking form uses.
			// The data structure must match what the normal booking form sends.
			$name_parts   = explode( ' ', $customer_name, 2 );
			$booking_data = array(
				'employee_id'      => $employee_id,
				'service_id'       => $service_id,
				'appointment_date' => $date,
				'start_time'       => $start_time,
				'end_time'         => $end_time,
				'grand_total'      => $price,
				'total'            => $price,
				'persons'          => 1,
				'bookings'         => array(
					array(
						'customer_info' => array(
							'first_name' => $name_parts[0],
							'last_name'  => $name_parts[1] ?? '',
							'email'      => $customer_email,
							'phone'      => $customer_phone,
						),
					),
				),
				'payments'         => array(
					'getway' => 'offline',
				),
			);

			$this->appointment_service->processAppointmentBookings( $booking_data, $appointment->id );

			$currency_symbol = function_exists( 'get_rtrb_currency_symbol' ) ? get_rtrb_currency_symbol() : '$';
			$this->ui_data   = array(
				'type'            => 'booking_confirmed',
				'appointment_id'  => $appointment->id,
				'service_name'    => $service->name,
				'employee_name'   => $this->getEmployeeName( $employee_id ),
				'date'            => $date,
				'time'            => substr( $start_time, 0, 5 ),
				'duration_minutes' => $duration_minutes,
				'price'           => $price,
				'currency'        => $currency_symbol,
				'status'          => $default_status,
				'customer_name'   => $customer_name,
			);

			return array(
				'success'        => true,
				'appointment_id' => $appointment->id,
				'price'          => $price,
				'message'        => sprintf(
					/* translators: 1: appointment ID, 2: date, 3: time, 4: formatted total price */
					__( 'Appointment #%1$d booked successfully for %2$s at %3$s. Total: $%4$s.', 'radius-booking-pro' ),
					$appointment->id,
					$date,
					substr( $start_time, 0, 5 ),
					number_format( $price, 2 )
				),
			);
		} catch ( \Exception $e ) {
			/* translators: %s: exception message */
			return array( 'error' => sprintf( __( 'Could not create booking: %s', 'radius-booking-pro' ), $e->getMessage() ) );
		}
	}

	/**
	 * Tool: Cancel a booking.
	 *
	 * @param array $args Arguments with appointment_id.
	 *
	 * @return array
	 */
	private function toolCancelBooking( array $args ): array {
		try {
			$appointment_id = (int) ( $args['appointment_id'] ?? 0 );

			if ( ! $appointment_id ) {
				return array( 'error' => __( 'Appointment ID is required.', 'radius-booking-pro' ) );
			}

			$appointment = $this->appointment_repository->find( $appointment_id );

			if ( ! $appointment ) {
				return array( 'error' => __( 'Appointment not found.', 'radius-booking-pro' ) );
			}

			$result = $this->appointment_service->cancelAppointment( $appointment_id );

			if ( ! $result ) {
				return array( 'error' => __( 'Could not cancel the appointment.', 'radius-booking-pro' ) );
			}

			return array(
				'success' => true,
				'message' => sprintf(
					/* translators: %d: appointment ID */
					__( 'Appointment #%d has been cancelled.', 'radius-booking-pro' ),
					$appointment_id
				),
			);
		} catch ( \Exception $e ) {
			/* translators: %s: exception message */
			return array( 'error' => sprintf( __( 'Could not cancel appointment: %s', 'radius-booking-pro' ), $e->getMessage() ) );
		}
	}

	/**
	 * Tool: Reschedule a booking.
	 *
	 * @param array $args Arguments with appointment_id, new_date, new_time.
	 *
	 * @return array
	 */
	private function toolRescheduleBooking( array $args ): array {
		try {
			$appointment_id = (int) ( $args['appointment_id'] ?? 0 );
			$new_date       = sanitize_text_field( $args['new_date'] ?? '' );
			$new_time       = sanitize_text_field( $args['new_time'] ?? '' );

			if ( ! $appointment_id || ! $new_date || ! $new_time ) {
				return array( 'error' => __( 'Appointment ID, new date, and new time are required.', 'radius-booking-pro' ) );
			}

			$appointment = $this->appointment_repository->find( $appointment_id );

			if ( ! $appointment ) {
				return array( 'error' => __( 'Appointment not found.', 'radius-booking-pro' ) );
			}

			// Ensure time is in H:i:s format.
			$new_time_formatted = strlen( $new_time ) === 5 ? $new_time . ':00' : $new_time;

			$result = $this->appointment_service->rescheduleAppointment( $appointment_id, $new_date, $new_time_formatted );

			if ( is_array( $result ) && isset( $result['success'] ) && false === $result['success'] ) {
				return array( 'error' => $result['message'] ?? __( 'Could not reschedule.', 'radius-booking-pro' ) );
			}

			return array(
				'success' => true,
				'message' => sprintf(
					/* translators: 1: appointment ID, 2: new date, 3: new time */
					__( 'Appointment #%1$d has been rescheduled to %2$s at %3$s.', 'radius-booking-pro' ),
					$appointment_id,
					$new_date,
					substr( $new_time_formatted, 0, 5 )
				),
			);
		} catch ( \Exception $e ) {
			/* translators: %s: exception message */
			return array( 'error' => sprintf( __( 'Could not reschedule appointment: %s', 'radius-booking-pro' ), $e->getMessage() ) );
		}
	}

	/**
	 * Tool: Search the knowledge base.
	 *
	 * @param array $args Arguments with query.
	 *
	 * @return array
	 */
	private function toolSearchKnowledge( array $args ): array {
		$query   = sanitize_text_field( $args['query'] ?? '' );
		$service = Container::resolve( ChatbotKnowledgeService::class );
		$results = $service->search( $query );

		if ( empty( $results ) ) {
			return array( 'message' => __( 'No matching knowledge base entries found.', 'radius-booking-pro' ) );
		}

		return array( 'entries' => $results );
	}

	/**
	 * Tool: Get employees assigned to a service.
	 *
	 * @param array $args Arguments with service_id.
	 *
	 * @return array
	 */
	private function toolGetServiceEmployees( array $args ): array {
		try {
			$service_id = (int) ( $args['service_id'] ?? 0 );

			if ( ! $service_id ) {
				return array( 'error' => __( 'Service ID is required.', 'radius-booking-pro' ) );
			}

			$service = Service::find( $service_id );
			if ( ! $service || ! $service->get_id() ) {
				return array( 'error' => __( 'Service not found.', 'radius-booking-pro' ) );
			}

			$employee_ids    = $this->service_repository->getServicesEmployeesIds( $service_id );
			$employees       = array();
			$currency_symbol = function_exists( 'get_rtrb_currency_symbol' ) ? get_rtrb_currency_symbol() : '$';

			foreach ( $employee_ids as $emp_id ) {
				if ( ! $emp_id ) {
					continue;
				}
                $is_employee  = $this->user_repository->findById( (int) $emp_id );
                if( ! $is_employee ) {
                    continue;
                }
				$profile       = $this->user_repository->get_profile( (int) $emp_id );
				$employee_name = $this->getEmployeeName( (int) $emp_id );
				$image_url     = $profile && method_exists( $profile, 'getImageUrl' ) ? $profile->getImageUrl() : '';

				// Get employee-specific price for this service.
				$emp_service = $this->service_repository->getAssignServices( $service_id, (int) $emp_id );
				$emp_price   = $emp_service ? (float) ( $emp_service->price ?? $service->price ?? 0 ) : (float) ( $service->price ?? 0 );

				$employees[] = array(
					'id'        => (int) $emp_id,
					'name'      => $employee_name,
					'image_url' => $image_url,
					'price'     => $emp_price,
				);
			}

			if ( empty( $employees ) ) {
				return array( 'error' => __( 'No staff members are assigned to this service.', 'radius-booking-pro' ) );
			}

			$service_name     = $service->name;
			$duration_minutes = $service->duration ? (int) $service->duration / 60 : 0;

			$this->ui_data = array(
				'type'             => 'employees',
				'employees'        => $employees,
				'service_id'       => $service_id,
				'service_name'     => $service_name,
				'duration_minutes' => $duration_minutes,
				'currency'         => $currency_symbol,
			);

			return array(
				'service_id'   => $service_id,
				'service_name' => $service_name,
				'employees'    => $employees,
				'message'      => sprintf(
					/* translators: 1: number of staff members, 2: service name */
					__( '%1$d staff members available for %2$s. Staff cards are now shown to the customer.', 'radius-booking-pro' ),
					count( $employees ),
					$service_name
				),
			);
		} catch ( \Exception $e ) {
			/* translators: %s: exception message */
			return array( 'error' => sprintf( __( 'Could not retrieve employees: %s', 'radius-booking-pro' ), $e->getMessage() ) );
		}
	}

	/**
	 * Tool: Get available dates for an employee and service (next 60 days).
	 *
	 * @param array $args Arguments with service_id and employee_id.
	 *
	 * @return array
	 */
	private function toolGetAvailableDates( array $args ): array {
		try {
			$service_id  = (int) ( $args['service_id'] ?? 0 );
			$employee_id = (int) ( $args['employee_id'] ?? 0 );

			if ( ! $service_id || ! $employee_id ) {
				return array( 'error' => __( 'Service ID and employee ID are required.', 'radius-booking-pro' ) );
			}

			$service = Service::find( $service_id );
			if ( ! $service || ! $service->get_id() ) {
				return array( 'error' => __( 'Service not found.', 'radius-booking-pro' ) );
			}

			$available_dates_set = array();
			$today               = new \DateTime( wp_date( 'Y-m-d' ) );
			$end_date            = ( clone $today )->modify( '+60 days' );

			$availability = $this->appointment_service->getEmployeeAvailableDateTime( $employee_id, $service_id );
			$dates        = $availability['schedule']['available_dates'] ?? array();

			foreach ( $dates as $date_info ) {
				if ( empty( $date_info['is_available'] ) ) {
					continue;
				}

				$date_str = $date_info['date'] ?? '';
				if ( ! $date_str ) {
					continue;
				}

				$date_obj = new \DateTime( $date_str );
				if ( $date_obj >= $today && $date_obj <= $end_date ) {
					$available_dates_set[ $date_str ] = true;
				}
			}

			ksort( $available_dates_set );
			$available_dates = array_keys( $available_dates_set );

			$service_name     = $service->name;
			$service_price    = (float) ( $service->price ?? 0 );
			$duration_minutes = $service->duration ? (int) $service->duration / 60 : 0;
			$currency_symbol  = function_exists( 'get_rtrb_currency_symbol' ) ? get_rtrb_currency_symbol() : '$';
			$employee_name    = $this->getEmployeeName( $employee_id );

			$this->ui_data = array(
				'type'             => 'date_picker',
				'available_dates'  => $available_dates,
				'service_id'       => $service_id,
				'employee_id'      => $employee_id,
				'employee_name'    => $employee_name,
				'service_name'     => $service_name,
				'service_price'    => $service_price,
				'duration_minutes' => $duration_minutes,
				'currency'         => $currency_symbol,
			);

			return array(
				'service_id'      => $service_id,
				'employee_id'     => $employee_id,
				'employee_name'   => $employee_name,
				'service_name'    => $service_name,
				'available_dates' => count( $available_dates ),
				'date_range'      => ! empty( $available_dates )
					? sprintf(
						/* translators: 1: first available date, 2: last available date */
						__( '%1$s to %2$s', 'radius-booking-pro' ),
						$available_dates[0],
						end( $available_dates )
					)
					: __( 'none', 'radius-booking-pro' ),
				'message'         => sprintf(
					/* translators: 1: count of available dates, 2: employee name */
					__( '%1$d available dates found for %2$s. A calendar is now shown to the customer.', 'radius-booking-pro' ),
					count( $available_dates ),
					$employee_name
				),
			);
		} catch ( \Exception $e ) {
			/* translators: %s: exception message */
			return array( 'error' => sprintf( __( 'Could not retrieve available dates: %s', 'radius-booking-pro' ), $e->getMessage() ) );
		}
	}

	/**
	 * Get employee display name.
	 *
	 * @param int $employee_id Employee user ID.
	 *
	 * @return string
	 */
	private function getEmployeeName( int $employee_id ): string {
		$profile = $this->user_repository->get_profile( $employee_id );

		if ( ! $profile ) {
			return '';
		}

		// 1. Try profile's own first/last name.
		$first = trim( $profile->first_name ?? '' );
		$last  = trim( $profile->last_name ?? '' );
		if ( $first || $last ) {
			return trim( $first . ' ' . $last );
		}

		// 2. Fall back to WordPress user data.
		if ( ! empty( $profile->wp_user_id ) ) {
			$wp_user = get_userdata( $profile->wp_user_id );
			if ( $wp_user ) {
				$wp_first = trim( $wp_user->first_name ?? '' );
				$wp_last  = trim( $wp_user->last_name ?? '' );
				if ( $wp_first || $wp_last ) {
					return trim( $wp_first . ' ' . $wp_last );
				}
				if ( ! empty( $wp_user->display_name ) ) {
					return $wp_user->display_name;
				}
			}
		}

		return '';
	}
}
