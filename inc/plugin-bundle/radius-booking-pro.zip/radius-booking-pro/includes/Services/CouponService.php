<?php

namespace RadiusTheme\RadiusBookingPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBookingPro\Repositories\CouponRepository;

/**
 * Services/CouponService.php
 * Business logic layer for Coupons.
 */
class CouponService {

	/**
	 * Coupon Repository
	 *
	 * @var CouponRepository
	 */
	private CouponRepository $couponRepo;

	/**
	 * Constructor.
	 *
	 * @param CouponRepository $couponRepo The coupon repository instance.
	 */
	public function __construct( CouponRepository $couponRepo ) {
		$this->couponRepo = $couponRepo;
	}

	/**
	 * Validate a coupon code for a given service and amount.
	 *
	 * @param string   $code      The coupon code.
	 * @param int|null $serviceId The service ID.
	 * @param float    $amount    The order amount.
	 *
	 * @return array
	 */
	public function validateCoupon( string $code, $serviceId = null, $amount = 0 ) {
		$coupon = $this->couponRepo->findByCode( $code );

		if ( ! $coupon ) {
			return array(
				'valid'   => false,
				'message' => __( 'Invalid coupon code.', 'radius-booking-pro' ),
			);
		}

		$validation = $coupon->isValid( $serviceId, $amount );

		if ( ! $validation['valid'] ) {
			return $validation;
		}

		$discount = $this->calculateDiscount( $coupon, $amount );

		return array(
			'valid'          => true,
			'message'        => __( 'Coupon applied successfully.', 'radius-booking-pro' ),
			'coupon_id'      => $coupon->id,
			'code'           => $coupon->code,
			'discount_type'  => $coupon->discount_type,
			'discount_value' => $coupon->discount_value,
			'discount'       => $discount,
		);
	}

	/**
	 * Apply a coupon: validate, increment usage, return discount info.
	 *
	 * @param string   $code      The coupon code.
	 * @param int|null $serviceId The service ID.
	 * @param float    $amount    The order amount.
	 *
	 * @return array
	 */
	public function applyCoupon( string $code, $serviceId = null, $amount = 0 ) {
		$result = $this->validateCoupon( $code, $serviceId, $amount );

		if ( $result['valid'] ) {
			$this->couponRepo->incrementUsage( $result['coupon_id'] );
		}

		return $result;
	}

	/**
	 * Get the best auto-apply coupon for a service and amount.
	 *
	 * @param int|null $serviceId The service ID.
	 * @param float    $amount    The order amount.
	 *
	 * @return array|null
	 */
	public function getAutoApplyCoupons( $serviceId = null, $amount = 0 ) {
		$coupons = $this->couponRepo->getAutoApplyCoupons( $serviceId );

		if ( empty( $coupons ) ) {
			return null;
		}

		$bestCoupon   = null;
		$bestDiscount = 0;

		foreach ( $coupons as $coupon ) {
			$validation = $coupon->isValid( $serviceId, $amount );
			if ( ! $validation['valid'] ) {
				continue;
			}

			$discount = $this->calculateDiscount( $coupon, $amount );
			if ( $discount > $bestDiscount ) {
				$bestDiscount = $discount;
				$bestCoupon   = $coupon;
			}
		}

		if ( ! $bestCoupon ) {
			return null;
		}

		return array(
			'coupon_id'      => $bestCoupon->id,
			'code'           => $bestCoupon->code,
			'discount_type'  => $bestCoupon->discount_type,
			'discount_value' => $bestCoupon->discount_value,
			'discount'       => $bestDiscount,
		);
	}

	/**
	 * Calculate the actual discount amount.
	 *
	 * @param object $coupon The coupon model instance.
	 * @param float  $amount The order amount.
	 *
	 * @return float
	 */
	public function calculateDiscount( $coupon, $amount ) {
		if ( 'percentage' === $coupon->discount_type ) {
			$discount = ( $amount * $coupon->discount_value ) / 100;
			// Cap at max_discount if set.
			if ( $coupon->max_discount && $discount > $coupon->max_discount ) {
				$discount = $coupon->max_discount;
			}
		} else {
			$discount = $coupon->discount_value;
		}

		// Ensure discount doesn't exceed the amount.
		return min( $discount, $amount );
	}
}