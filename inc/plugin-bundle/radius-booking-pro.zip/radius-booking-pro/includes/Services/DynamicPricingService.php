<?php

namespace RadiusTheme\RadiusBookingPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBookingPro\Repositories\DynamicPricingRepository;

/**
 * Class DynamicPricingService
 *
 * Evaluates dynamic pricing rules against a booking context
 * and calculates the adjusted price.
 */
class DynamicPricingService {

	/**
	 * Dynamic Pricing Repository.
	 *
	 * @var DynamicPricingRepository
	 */
	private DynamicPricingRepository $repository;

	/**
	 * Constructor.
	 *
	 * @param DynamicPricingRepository $repository The repository instance.
	 */
	public function __construct( DynamicPricingRepository $repository ) {
		$this->repository = $repository;
	}

	/**
	 * Calculate the dynamic price for a booking.
	 *
	 * Evaluates all active rules for the given service, date, and time,
	 * applies matching adjustments in priority order, and returns the final price.
	 *
	 * @param float  $basePrice The base service price.
	 * @param int    $serviceId The service ID.
	 * @param string $date      The appointment date (Y-m-d).
	 * @param string $time      The appointment start time (H:i or H:i:s).
	 *
	 * @return array{
	 *     original_price: float,
	 *     final_price: float,
	 *     total_adjustment: float,
	 *     applied_rules: array
	 * }
	 */
	public function calculatePrice( $basePrice, $serviceId, $date, $time ) {
		$rules = $this->repository->getActiveRulesForService( $serviceId );

		/**
		 * Filter the list of dynamic pricing rules before evaluation.
		 *
		 * @param array  $rules     The active rules for this service.
		 * @param int    $serviceId The service ID.
		 * @param string $date      The appointment date.
		 * @param string $time      The appointment time.
		 */
		$rules = apply_filters( 'rtrb_dynamic_pricing_rules', $rules, $serviceId, $date, $time );

		$context = array(
			'service_id' => $serviceId,
			'date'       => $date,
			'time'       => $time,
			'base_price' => $basePrice,
		);

		$appliedRules    = array();
		$totalAdjustment = 0;

		// First-match-wins: rules are pre-sorted by priority ASC, created_at ASC
		// in the repository. Apply only the first matching rule and stop. This
		// avoids accidentally stacking overlapping rules (e.g. Weekend +20% and
		// May Surge +10% both firing on a Saturday in May for a +30% surcharge).
		foreach ( $rules as $rule ) {
			if ( ! $this->ruleMatches( $rule, $context ) ) {
				continue;
			}

			$adjustment = $this->calculateAdjustment( $rule, $basePrice );

			$appliedRules[] = array(
				'id'              => $rule->id,
				'name'            => $rule->name,
				'rule_type'       => $rule->rule_type,
				'adjustment_type' => $rule->adjustment_type,
				'adjustment_value' => $rule->adjustment_value,
				'calculated'      => $adjustment,
			);

			$totalAdjustment += $adjustment;
			break;
		}

		$finalPrice = max( 0, $basePrice + $totalAdjustment );

		/**
		 * Filter the final calculated dynamic price.
		 *
		 * @param float $finalPrice      The calculated final price.
		 * @param float $basePrice       The original base price.
		 * @param array $appliedRules    Array of rules that were applied.
		 * @param array $context         The booking context.
		 */
		$finalPrice = apply_filters( 'rtrb_dynamic_pricing_final_price', $finalPrice, $basePrice, $appliedRules, $context );

		return array(
			'original_price'   => (float) $basePrice,
			'final_price'      => (float) $finalPrice,
			'total_adjustment' => (float) $totalAdjustment,
			'applied_rules'    => $appliedRules,
		);
	}

	/**
	 * Check if a rule matches the current booking context.
	 *
	 * @param object $rule    The pricing rule.
	 * @param array  $context The booking context.
	 *
	 * @return bool
	 */
	private function ruleMatches( $rule, array $context ) {
		$conditions = $rule->getConditions();

		switch ( $rule->rule_type ) {
			case 'time_of_day':
				return $this->matchTimeOfDay( $conditions, $context['time'] );

			case 'day_of_week':
				return $this->matchDayOfWeek( $conditions, $context['date'] );

			case 'date_range':
				return $this->matchDateRange( $conditions, $context['date'] );

			case 'season':
				return $this->matchSeason( $conditions, $context['date'] );

			case 'slot_availability':
				return $this->matchSlotAvailability( $conditions, $context );

			default:
				return false;
		}
	}

	/**
	 * Match time-of-day condition.
	 *
	 * Conditions: { "start_time": "18:00", "end_time": "22:00" }
	 *
	 * @param array  $conditions The rule conditions.
	 * @param string $time       The appointment time (H:i or H:i:s).
	 *
	 * @return bool
	 */
	private function matchTimeOfDay( array $conditions, $time ) {
		$startTime = $conditions['start_time'] ?? null;
		$endTime   = $conditions['end_time'] ?? null;

		if ( ! $startTime || ! $endTime ) {
			return false;
		}

		// Normalize to H:i format for comparison.
		$timeNorm  = substr( $time, 0, 5 );
		$startNorm = substr( $startTime, 0, 5 );
		$endNorm   = substr( $endTime, 0, 5 );

		return $timeNorm >= $startNorm && $timeNorm <= $endNorm;
	}

	/**
	 * Match day-of-week condition.
	 *
	 * Conditions: { "days": [1, 6, 7] } (1=Monday, 7=Sunday, ISO-8601)
	 *
	 * @param array  $conditions The rule conditions.
	 * @param string $date       The appointment date (Y-m-d).
	 *
	 * @return bool
	 */
	private function matchDayOfWeek( array $conditions, $date ) {
		$days = $conditions['days'] ?? array();
		if ( empty( $days ) ) {
			return false;
		}

		// ISO-8601: 1=Monday, 7=Sunday.
		$dayOfWeek = (int) gmdate( 'N', strtotime( $date ) );

		return in_array( $dayOfWeek, array_map( 'intval', $days ), true );
	}

	/**
	 * Match date-range condition.
	 *
	 * Conditions: { "start_date": "2026-12-20", "end_date": "2026-12-31" }
	 *
	 * @param array  $conditions The rule conditions.
	 * @param string $date       The appointment date (Y-m-d).
	 *
	 * @return bool
	 */
	private function matchDateRange( array $conditions, $date ) {
		$startDate = $conditions['start_date'] ?? null;
		$endDate   = $conditions['end_date'] ?? null;

		if ( ! $startDate || ! $endDate ) {
			return false;
		}

		return $date >= $startDate && $date <= $endDate;
	}

	/**
	 * Match season condition (recurring annually).
	 *
	 * Conditions: { "start_month_day": "12-15", "end_month_day": "01-05" }
	 * Supports cross-year ranges (e.g., Dec 15 to Jan 5).
	 *
	 * @param array  $conditions The rule conditions.
	 * @param string $date       The appointment date (Y-m-d).
	 *
	 * @return bool
	 */
	private function matchSeason( array $conditions, $date ) {
		$startMd = $conditions['start_month_day'] ?? null;
		$endMd   = $conditions['end_month_day'] ?? null;

		if ( ! $startMd || ! $endMd ) {
			return false;
		}

		$currentMd = gmdate( 'm-d', strtotime( $date ) );

		// Handle cross-year ranges (e.g., 12-15 to 01-05).
		if ( $startMd <= $endMd ) {
			return $currentMd >= $startMd && $currentMd <= $endMd;
		}

		return $currentMd >= $startMd || $currentMd <= $endMd;
	}

	/**
	 * Match slot availability condition.
	 *
	 * Conditions: { "threshold": 3 }
	 * Matches when fewer than 'threshold' slots remain for the time period.
	 *
	 * @param array $conditions The rule conditions.
	 * @param array $context    The booking context.
	 *
	 * @return bool
	 */
	private function matchSlotAvailability( array $conditions, array $context ) {
		$threshold = (int) ( $conditions['threshold'] ?? 0 );
		if ( $threshold <= 0 ) {
			return false;
		}

		/**
		 * Filter to get the number of remaining available slots.
		 *
		 * External code should hook into this to provide the actual
		 * remaining slot count for the given service, date, and time.
		 *
		 * @param int|null $remaining  Default null (rule won't match if not provided).
		 * @param int      $serviceId  The service ID.
		 * @param string   $date       The appointment date.
		 * @param string   $time       The appointment time.
		 */
		$remaining = apply_filters(
			'rtrb_dynamic_pricing_remaining_slots',
			null,
			$context['service_id'],
			$context['date'],
			$context['time']
		);

		if ( null === $remaining ) {
			return false;
		}

		return (int) $remaining <= $threshold;
	}

	/**
	 * Calculate the price adjustment for a single rule.
	 *
	 * @param object $rule      The pricing rule.
	 * @param float  $basePrice The base price.
	 *
	 * @return float The adjustment amount (positive = increase, negative = decrease).
	 */
	private function calculateAdjustment( $rule, $basePrice ) {
		$value = (float) $rule->adjustment_value;

		if ( 'percentage' === $rule->adjustment_type ) {
			return ( $basePrice * $value ) / 100;
		}

		// Fixed amount.
		return $value;
	}

	/**
	 * Get all active rules, optionally filtered by service.
	 *
	 * @param int|null $serviceId The service ID.
	 *
	 * @return array
	 */
	public function getActiveRules( $serviceId = null ) {
		return $this->repository->getActiveRulesForService( $serviceId );
	}
}
