<?php
/**
 * Payout Service
 */

namespace RadiusTheme\RadiusBookingPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBooking\Helpers\SettingsHelper;
use RadiusTheme\RadiusBooking\Models\UserProfile;
use RadiusTheme\RadiusBooking\Repositories\EmployeeRepository;
use RadiusTheme\RadiusBooking\Services\EmployeePanelService;
use RadiusTheme\RadiusBookingPro\Repositories\PayoutRepository;
use RadiusTheme\RadiusBookingPro\Resources\PayoutResource;

/**
 * Class PayoutService
 *
 * Business logic for payout operations.
 */
class PayoutService {

	/**
	 * @var PayoutRepository
	 */
	private PayoutRepository $payoutRepository;

	/**
	 * @var EmployeeRepository
	 */
	private EmployeeRepository $employeeRepository;

	/**
	 * PayoutService constructor.
	 *
	 * @param PayoutRepository   $payoutRepository   Payout repository.
	 * @param EmployeeRepository $employeeRepository Employee repository.
	 */
	public function __construct( PayoutRepository $payoutRepository, EmployeeRepository $employeeRepository ) {
		$this->payoutRepository   = $payoutRepository;
		$this->employeeRepository = $employeeRepository;
	}

	/**
	 * Get payout settings with defaults.
	 *
	 * @return array Payout settings.
	 */
	public function getPayoutSettings() {
		return SettingsHelper::get_setting( 'payout' );
	}

	/**
	 * Calculate commission on an amount.
	 *
	 * @param float $amount The gross amount.
	 *
	 * @return float The commission amount.
	 */
	public function calculateCommission( $amount ) {
		$settings       = $this->getPayoutSettings();
		$commissionType = $settings['commissionType'] ?? 'percentage';
		$commissionRate = (float) ( $settings['commissionRate'] ?? 0 );

		if ( $commissionRate <= 0 ) {
			return 0.0;
		}

		if ( 'percentage' === $commissionType ) {
			return round( $amount * ( $commissionRate / 100 ), 2 );
		}

		// Fixed commission per payout.
		return round( $commissionRate, 2 );
	}

	/**
	 * Get available balance breakdown for an employee.
	 *
	 * @param int $employeeId Employee ID.
	 *
	 * @return array Balance breakdown.
	 */
	public function getAvailableBalance( $employeeId ) {
		// Resolve every employee_id that belongs to the same WP user. With the
		// Classified Listing integration each listing-as-staff is a separate
		// employee row, so a single $employeeId would only see one shard's
		// earnings/payouts. Earnings & Commission show correct totals on the
		// Payments tab because that path already uses the related ids — mirror
		// it here so the Payouts tab and the Overview balance card agree.
		$relatedIds = Container::resolve( EmployeePanelService::class )
			->getRelatedEmployeeIds( (int) $employeeId );

		$totalEarnings = $this->employeeRepository->getTotalEarnings( $relatedIds );
		$totalPaidOut  = $this->payoutRepository->getTotalPaidOut( $relatedIds );
		$totalPending  = $this->payoutRepository->getTotalPending( $relatedIds );

		// Each payment row carries the commission rate/type that was in effect
		// when it was paid. Summing across rows keeps historical earnings
		// frozen — a later rate change only applies to future payments.
		$totalCommission = $this->sumCommissionForEmployee( $relatedIds );

		$settings       = $this->getPayoutSettings();
		$commissionType = $settings['commissionType'] ?? 'percentage';
		$commissionRate = (float) ( $settings['commissionRate'] ?? 0 );

		$netEarnings      = $totalEarnings - $totalCommission;
		$availableBalance = max( 0, $netEarnings - $totalPaidOut - $totalPending );

		return array(
			'total_earnings'    => round( $totalEarnings, 2 ),
			'total_commission'  => round( $totalCommission, 2 ),
			'net_earnings'      => round( $netEarnings, 2 ),
			'total_paid_out'    => round( $totalPaidOut, 2 ),
			'total_pending'     => round( $totalPending, 2 ),
			'available_balance' => round( $availableBalance, 2 ),
			'commission_type'   => $commissionType,
			'commission_rate'   => $commissionRate,
			'currency'          => array(
				'currency_symbol' => get_rtrb_currency_symbol(),
				'currency'        => get_rtrb_currency(),
			),
		);
	}

	/**
	 * Sum commission across paid/partial payments for an employee (or the set
	 * of related employee_ids in the CL listing-as-staff flow) using each
	 * payment row's snapshotted rate/type. Rows missing a snapshot fall back
	 * to the current global setting so very old data isn't silently treated
	 * as zero.
	 *
	 * @param int|int[] $employeeId Single employee id or array of related ids.
	 *
	 * @return float
	 */
	private function sumCommissionForEmployee( $employeeId ): float {
		global $wpdb;

		$ids = is_array( $employeeId ) ? $employeeId : array( $employeeId );
		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );
		if ( empty( $ids ) ) {
			return 0.0;
		}

		$prefix   = $wpdb->prefix . 'radius_booking_';
		$settings = $this->getPayoutSettings();
		$fallType = $settings['commissionType'] ?? 'percentage';
		$fallRate = (float) ( $settings['commissionRate'] ?? 0 );

		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		// Bindings are: fallType, fallRate, fallType, fallRate, then each id.
		$bindings = array_merge( array( $fallType, $fallRate, $fallType, $fallRate ), $ids );

		$sql = "SELECT COALESCE(SUM(
				CASE
					WHEN COALESCE(p.commission_type, %s) = 'percentage'
						THEN p.amount * (COALESCE(p.commission_rate, %f) / 100)
					WHEN COALESCE(p.commission_type, %s) = 'fixed'
						THEN COALESCE(p.commission_rate, %f)
					ELSE 0
				END
			), 0)
			FROM {$prefix}payments p
			INNER JOIN {$prefix}customer_bookings cb ON cb.id = p.booking_id
			INNER JOIN {$prefix}appointments a ON a.id = cb.appointment_id
			WHERE p.status IN ('paid', 'partial_payment')
			AND a.deleted_at IS NULL
			AND a.employee_id IN ({$placeholders})";

		$result = $wpdb->get_var( $wpdb->prepare( $sql, $bindings ) );

		return round( (float) $result, 2 );
	}

	/**
	 * Get admin income summary based on appointment earnings.
	 *
	 * Commission is calculated on total appointment revenue across all employees,
	 * not just on processed payouts.
	 *
	 * @return array Admin income breakdown.
	 */
	public function getAdminIncomeSummary() {
		global $wpdb;

		$prefix = $wpdb->prefix . 'radius_booking_';

		// Total earnings from all appointments (paid/partial payments).
		$totalAppointmentRevenue = (float) $wpdb->get_var(
			"SELECT COALESCE(SUM(p.amount), 0)
			FROM {$prefix}payments p
			INNER JOIN {$prefix}customer_bookings cb ON cb.id = p.booking_id
			INNER JOIN {$prefix}appointments a ON a.id = cb.appointment_id
			WHERE p.status IN ('paid', 'partial_payment')
			AND a.deleted_at IS NULL"
		);

		$settings       = $this->getPayoutSettings();
		$commissionType = $settings['commissionType'] ?? 'percentage';
		$commissionRate = (float) ( $settings['commissionRate'] ?? 0 );

		// Sum commission per payment using its snapshotted rate/type so a
		// later setting change doesn't retroactively shift admin income.
		$totalCommission = (float) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COALESCE(SUM(
					CASE
						WHEN COALESCE(p.commission_type, %s) = 'percentage'
							THEN p.amount * (COALESCE(p.commission_rate, %f) / 100)
						WHEN COALESCE(p.commission_type, %s) = 'fixed'
							THEN COALESCE(p.commission_rate, %f)
						ELSE 0
					END
				), 0)
				FROM {$prefix}payments p
				INNER JOIN {$prefix}customer_bookings cb ON cb.id = p.booking_id
				INNER JOIN {$prefix}appointments a ON a.id = cb.appointment_id
				WHERE p.status IN ('paid', 'partial_payment')
				AND a.deleted_at IS NULL",
				$commissionType,
				$commissionRate,
				$commissionType,
				$commissionRate
			)
		);
		$totalCommission = round( $totalCommission, 2 );

		// Payout totals from the payouts table.
		$payoutsTable = $prefix . 'payouts';

		$payoutTotals = $wpdb->get_row(
			"SELECT
				COALESCE(SUM(CASE WHEN status = 'paid' THEN net_amount ELSE 0 END), 0) AS total_paid_to_employees,
				COALESCE(SUM(CASE WHEN status IN ('pending', 'processing', 'on_hold') THEN net_amount ELSE 0 END), 0) AS total_pending_payouts
			FROM {$payoutsTable}",
			ARRAY_A
		);

		$totalPaidOut = (float) ( $payoutTotals['total_paid_to_employees'] ?? 0 );
		$totalPending = (float) ( $payoutTotals['total_pending_payouts'] ?? 0 );

		return array(
			'total_appointment_revenue' => round( $totalAppointmentRevenue, 2 ),
			'total_commission_earned'   => round( $totalCommission, 2 ),
			'commission_type'           => $commissionType,
			'commission_rate'           => $commissionRate,
			'total_paid_to_employees'   => round( $totalPaidOut, 2 ),
			'total_pending_payouts'     => round( $totalPending, 2 ),
			'currency'                  => array(
				'currency_symbol' => get_rtrb_currency_symbol(),
				'currency'        => get_rtrb_currency(),
			),
		);
	}

	/**
	 * Get paginated list of appointments with commission breakdown.
	 *
	 * @param int $page    Current page.
	 * @param int $perPage Items per page.
	 *
	 * @return array Paginated appointment list with commission per row.
	 */
	public function getCommissionAppointments( $page = 1, $perPage = 15 ) {
		global $wpdb;

		$prefix = $wpdb->prefix . 'radius_booking_';

		$settings       = $this->getPayoutSettings();
		$commissionType = $settings['commissionType'] ?? 'percentage';
		$commissionRate = (float) ( $settings['commissionRate'] ?? 0 );

		$offset = ( $page - 1 ) * $perPage;

		// Total count.
		$total = (int) $wpdb->get_var(
			"SELECT COUNT(DISTINCT a.id)
			FROM {$prefix}appointments a
			INNER JOIN {$prefix}customer_bookings cb ON cb.appointment_id = a.id
			INNER JOIN {$prefix}payments p ON p.booking_id = cb.id
			WHERE p.status IN ('paid', 'partial_payment')
			AND a.deleted_at IS NULL"
		);

		// Paginated rows. Pull each payment's snapshotted commission so the
		// breakdown reflects what was charged at the time of payment.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT
					a.id AS appointment_id,
					a.appointment_date,
					a.start_time,
					a.end_time,
					a.created_at AS appointment_created_at,
					a.status AS appointment_status,
					a.employee_id,
					s.name AS service_name,
					p.amount AS paid_amount,
					p.status AS payment_status,
					p.payment_method,
					p.paid_at,
					p.commission_rate AS row_commission_rate,
					p.commission_type AS row_commission_type
				FROM {$prefix}appointments a
				INNER JOIN {$prefix}customer_bookings cb ON cb.appointment_id = a.id
				INNER JOIN {$prefix}payments p ON p.booking_id = cb.id
				LEFT JOIN {$prefix}services s ON s.id = a.service_id
				WHERE p.status IN ('paid', 'partial_payment')
				AND a.deleted_at IS NULL
				ORDER BY a.appointment_date DESC, a.start_time DESC
				LIMIT %d OFFSET %d",
				$perPage,
				$offset
			),
			ARRAY_A
		);

		// Pre-load profiles for all employees in this page in one query.
		$employee_ids = array_values( array_unique( array_map( fn( $r ) => (int) $r['employee_id'], $rows ) ) );
		$profiles_by_user_id = array();
		if ( ! empty( $employee_ids ) ) {
			$profiles = UserProfile::whereIn( 'user_id', $employee_ids )->get();
			foreach ( $profiles as $p ) {
				$profiles_by_user_id[ (int) $p->user_id ] = $p;
			}
		}

		// Build result with commission per appointment.
		$items = array();
		foreach ( $rows as $row ) {
			$amount = (float) $row['paid_amount'];

			// Use the per-payment snapshot if it exists; fall back to the
			// current global setting only for legacy rows that never got one.
			$rowType = ! empty( $row['row_commission_type'] ) ? $row['row_commission_type'] : $commissionType;
			$rowRate = isset( $row['row_commission_rate'] ) && '' !== $row['row_commission_rate']
				? (float) $row['row_commission_rate']
				: $commissionRate;

			$commission = 0.0;
			if ( $rowRate > 0 ) {
				if ( 'percentage' === $rowType ) {
					$commission = round( $amount * ( $rowRate / 100 ), 2 );
				} else {
					$commission = round( $rowRate, 2 );
				}
			}

			$rb_user_id    = (int) $row['employee_id'];
			$profile       = $profiles_by_user_id[ $rb_user_id ] ?? null;
			$wp_user_id    = $profile ? (int) $profile->wp_user_id : 0;
			$employee_name = PayoutResource::resolveEmployeeName( $profile, $wp_user_id );

			$items[] = array(
				'appointment_id'     => (int) $row['appointment_id'],
				'appointment_date'   => $row['appointment_date'],
				'start_time'         => $row['start_time'],
				'end_time'           => $row['end_time'],
				'created_at'         => $row['appointment_created_at'],
				'appointment_status' => $row['appointment_status'],
				'service_name'       => $row['service_name'] ?? __( 'Unknown', 'radius-booking-pro' ),
				'employee_id'        => (int) $row['employee_id'],
				'employee_name'      => $employee_name,
				'paid_amount'        => $amount,
				'commission'         => $commission,
				'employee_earning'   => round( $amount - $commission, 2 ),
				'payment_method'     => $row['payment_method'],
				'payment_status'     => $row['payment_status'],
				'paid_at'            => $row['paid_at'],
			);
		}

		$lastPage = max( 1, (int) ceil( $total / $perPage ) );

		return array(
			'items'      => $items,
			'pagination' => array(
				'current_page'   => $page,
				'last_page'      => $lastPage,
				'per_page'       => $perPage,
				'total'          => $total,
				'has_more_pages' => $page < $lastPage,
			),
			'currency'   => array(
				'currency_symbol' => get_rtrb_currency_symbol(),
				'currency'        => get_rtrb_currency(),
			),
		);
	}

	/**
	 * Request a payout for an employee.
	 *
	 * @param int    $employeeId  Employee ID.
	 * @param float  $amount      Requested amount.
	 * @param string $method      Payout method.
	 * @param string $note        Employee note.
	 *
	 * @return array Result with success/error.
	 */
	public function requestPayout( $employeeId, $amount, $method, $note = '' ) {
		$settings = $this->getPayoutSettings();
		$minimum  = (float) ( $settings['minimumPayoutAmount'] ?? 0 );

		if ( $amount <= 0 ) {
			return array(
				'success' => false,
				'message' => __( 'Payout amount must be greater than zero.', 'radius-booking-pro' ),
			);
		}

		if ( $minimum > 0 && $amount < $minimum ) {
			return array(
				'success' => false,
				'message' => sprintf(
					/* translators: %s: minimum amount */
					__( 'Minimum payout amount is %s.', 'radius-booking-pro' ),
					$minimum
				),
			);
		}

		// Validate payout method.
		$methods         = $settings['payoutMethods'] ?? array();
		$enabledMethods  = array_keys( array_filter( $methods, fn( $m ) => ! empty( $m['enabled'] ) ) );
		if ( ! empty( $enabledMethods ) && ! in_array( $method, $enabledMethods, true ) ) {
			return array(
				'success' => false,
				'message' => __( 'Invalid payout method.', 'radius-booking-pro' ),
			);
		}

		// Check available balance.
		$balance = $this->getAvailableBalance( $employeeId );
		if ( $amount > $balance['available_balance'] ) {
			return array(
				'success' => false,
				'message' => __( 'Requested amount exceeds available balance.', 'radius-booking-pro' ),
			);
		}

		// Commission is pre-deducted from the balance (both percentage and fixed
		// are calculated against earnings/appointments in getAvailableBalance),
		// so the requested amount is the net the employee receives.
		$commission = 0.0;
		$netAmount  = $amount;

		$payout = $this->payoutRepository->create(
			array(
				'employee_id'       => $employeeId,
				'amount'            => $amount,
				'commission_amount' => $commission,
				'net_amount'        => $netAmount,
				'status'            => 'pending',
				'payout_method'     => sanitize_text_field( $method ),
				'employee_note'     => sanitize_textarea_field( $note ),
			)
		);

		return array(
			'success' => true,
			'message' => __( 'Payout request submitted successfully.', 'radius-booking-pro' ),
			'payout'  => $payout,
		);
	}

	/**
	 * Approve a pending payout.
	 *
	 * @param int    $payoutId Payout ID.
	 * @param string $note     Admin note.
	 *
	 * @return array Result with success/error.
	 */
	public function approvePayout( $payoutId, $note = '' ) {
		$payout = $this->payoutRepository->find( $payoutId );

		if ( ! $payout ) {
			return array(
				'success' => false,
				'message' => __( 'Payout not found.', 'radius-booking-pro' ),
			);
		}

		if ( 'pending' !== $payout->status ) {
			return array(
				'success' => false,
				'message' => __( 'Only pending payouts can be approved.', 'radius-booking-pro' ),
			);
		}

		$this->payoutRepository->update(
			$payoutId,
			array(
				'status'       => 'processing',
				'admin_note'   => sanitize_textarea_field( $note ),
				'processed_by' => get_current_user_id(),
				'processed_at' => current_time( 'mysql' ),
			)
		);

		return array(
			'success' => true,
			'message' => __( 'Payout moved to processing.', 'radius-booking-pro' ),
		);
	}

	/**
	 * Complete an approved payout.
	 *
	 * @param int    $payoutId Payout ID.
	 * @param string $note     Admin note.
	 *
	 * @return array Result with success/error.
	 */
	public function completePayout( $payoutId, $note = '' ) {
		$payout = $this->payoutRepository->find( $payoutId );

		if ( ! $payout ) {
			return array(
				'success' => false,
				'message' => __( 'Payout not found.', 'radius-booking-pro' ),
			);
		}

		if ( 'processing' !== $payout->status ) {
			return array(
				'success' => false,
				'message' => __( 'Only payouts in processing can be marked paid.', 'radius-booking-pro' ),
			);
		}

		$updateData = array(
			'status'       => 'paid',
			'completed_at' => current_time( 'mysql' ),
		);

		if ( $note ) {
			$updateData['admin_note'] = sanitize_textarea_field( $note );
		}

		if ( ! $payout->processed_by ) {
			$updateData['processed_by'] = get_current_user_id();
			$updateData['processed_at'] = current_time( 'mysql' );
		}

		$this->payoutRepository->update( $payoutId, $updateData );

		return array(
			'success' => true,
			'message' => __( 'Payout marked as paid.', 'radius-booking-pro' ),
		);
	}

	/**
	 * Reject a pending payout.
	 *
	 * @param int    $payoutId Payout ID.
	 * @param string $note     Admin rejection reason.
	 *
	 * @return array Result with success/error.
	 */
	public function rejectPayout( $payoutId, $note = '' ) {
		$payout = $this->payoutRepository->find( $payoutId );

		if ( ! $payout ) {
			return array(
				'success' => false,
				'message' => __( 'Payout not found.', 'radius-booking-pro' ),
			);
		}

		if ( ! in_array( $payout->status, array( 'pending', 'processing', 'on_hold' ), true ) ) {
			return array(
				'success' => false,
				'message' => __( 'Only pending, processing, or on-hold payouts can be rejected.', 'radius-booking-pro' ),
			);
		}

		$this->payoutRepository->update(
			$payoutId,
			array(
				'status'       => 'rejected',
				'admin_note'   => sanitize_textarea_field( $note ),
				'processed_by' => get_current_user_id(),
				'processed_at' => current_time( 'mysql' ),
			)
		);

		return array(
			'success' => true,
			'message' => __( 'Payout rejected.', 'radius-booking-pro' ),
		);
	}

	/**
	 * Move a payout to the `on_hold` state.
	 *
	 * Allowed from `pending` or `processing`. The on_hold state is a
	 * temporary parking slot — admins can resume it back to processing
	 * via {@see unholdPayout()} or reject it outright.
	 *
	 * @param int    $payoutId Payout ID.
	 * @param string $note     Admin note explaining the reason for the hold.
	 *
	 * @return array Result with success/error.
	 */
	public function holdPayout( $payoutId, $note = '' ) {
		$payout = $this->payoutRepository->find( $payoutId );

		if ( ! $payout ) {
			return array(
				'success' => false,
				'message' => __( 'Payout not found.', 'radius-booking-pro' ),
			);
		}

		if ( ! in_array( $payout->status, array( 'pending', 'processing' ), true ) ) {
			return array(
				'success' => false,
				'message' => __( 'Only pending or processing payouts can be put on hold.', 'radius-booking-pro' ),
			);
		}

		$this->payoutRepository->update(
			$payoutId,
			array(
				'status'       => 'on_hold',
				'admin_note'   => sanitize_textarea_field( $note ),
				'processed_by' => get_current_user_id(),
				'processed_at' => current_time( 'mysql' ),
			)
		);

		return array(
			'success' => true,
			'message' => __( 'Payout placed on hold.', 'radius-booking-pro' ),
		);
	}

	/**
	 * Resume an on-hold payout, returning it to the `processing` state.
	 *
	 * @param int    $payoutId Payout ID.
	 * @param string $note     Optional admin note.
	 *
	 * @return array Result with success/error.
	 */
	public function unholdPayout( $payoutId, $note = '' ) {
		$payout = $this->payoutRepository->find( $payoutId );

		if ( ! $payout ) {
			return array(
				'success' => false,
				'message' => __( 'Payout not found.', 'radius-booking-pro' ),
			);
		}

		if ( 'on_hold' !== $payout->status ) {
			return array(
				'success' => false,
				'message' => __( 'Only on-hold payouts can be resumed.', 'radius-booking-pro' ),
			);
		}

		$updateData = array(
			'status'       => 'processing',
			'processed_by' => get_current_user_id(),
			'processed_at' => current_time( 'mysql' ),
		);

		if ( $note ) {
			$updateData['admin_note'] = sanitize_textarea_field( $note );
		}

		$this->payoutRepository->update( $payoutId, $updateData );

		return array(
			'success' => true,
			'message' => __( 'Payout resumed to processing.', 'radius-booking-pro' ),
		);
	}
}