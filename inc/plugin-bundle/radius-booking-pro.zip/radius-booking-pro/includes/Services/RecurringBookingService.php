<?php
/**
 * Handles recurring appointment creation (pro feature).
 */
namespace RadiusTheme\RadiusBookingPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Core\Container\Container;
use RadiusTheme\RadiusBooking\Models\Appointment;
use RadiusTheme\RadiusBooking\Models\Service;
use RadiusTheme\RadiusBooking\Repositories\AppointmentRepository;
use RadiusTheme\RadiusBooking\Services\BookingService;

class RecurringBookingService {

	/**
	 * Creates recurring appointments based on the provided data and parent appointment ID.
	 *
	 * @param array $data The data for creating recurring appointments, including cart items.
	 * @param int $parent_id The ID of the parent appointment.
	 *
	 * @return void
	 */
	public function createRecurringAppointments( array $data, int $parent_id ): void {
		$data = apply_filters( 'radius_booking_before_create_recurring_appointments', $data, $parent_id );

		$recurring_data = $data['cart_items'] ?? array();
		if ( empty( $recurring_data ) ) {
			return;
		}

		$parentAppointment = Appointment::find( $parent_id );
		if ( ! $parentAppointment || ! $parentAppointment->get_id() ) {
			do_action( 'radius_booking_parent_appointment_not_found', $parent_id, $data );
			return;
		}

		do_action( 'radius_booking_before_recurring_appointments_loop', $parentAppointment, $recurring_data, $data );

		$payment_id = $parentAppointment->get_payment_id();

		// Resolve the service's recurring-payment flag once instead of querying
		// it inside the per-child loop (was Service::find() on every iteration).
		$service_id        = $data['service_id'] ?? 0;
		$service           = $service_id ? Service::find( $service_id ) : null;
		$service_recurring = $service ? $service->recurring_payment() : false;

		foreach ( $recurring_data as $recurring ) {
			$recurring['parent_payment_id'] = $payment_id;
			$this->createSingleRecurringAppointment( $recurring, $data, $parent_id, $service_recurring );
		}

		do_action( 'radius_booking_after_create_recurring_appointments', $parent_id, $recurring_data, $data );
	}

	/**
	 * Creates a single recurring appointment.
	 *
	 * @param array $recurring The recurring appointment data.
	 * @param array $originalData The original appointment data.
	 * @param int $parent_id The parent appointment ID.
	 *
	 * @return void
	 */
	public function createSingleRecurringAppointment( array $recurring, array $originalData, int $parent_id, $service_recurring = null ): void {
		$recurring = apply_filters( 'radius_booking_before_create_single_recurring', $recurring, $originalData, $parent_id );

		do_action( 'radius_booking_create_single_recurring_start', $recurring, $originalData, $parent_id );

		$appointmentData = array(
			'status'    => $originalData['status'],
			'notes'     => $originalData['notes'] ?? '',
			'parent_id' => $parent_id,
			...$recurring,
		);

		$appointmentData = apply_filters( 'radius_booking_recurring_appointment_data', $appointmentData, $recurring, $originalData, $parent_id );

		$originalData['parent_payment_id'] = $recurring['parent_payment_id'] ?? null;
		$appointmentRepository             = Container::resolve( AppointmentRepository::class );
		$appointment                       = $appointmentRepository->create( $appointmentData );

		do_action( 'radius_booking_recurring_appointment_created', $appointment, $appointmentData, $parent_id );

		// Callers pass the pre-resolved flag (see createRecurringAppointments) so
		// we don't hit the DB per child; resolve lazily only if omitted.
		if ( null === $service_recurring ) {
			$service           = Service::find( $originalData['service_id'] );
			$service_recurring = $service ? $service->recurring_payment() : false;
		}
		$originalData['recurring_payment'] = $service_recurring;

		if ( ! empty( $recurring['appointment_date'] ) ) {
			$originalData['appointment_date'] = $recurring['appointment_date'];
		}
		if ( ! empty( $recurring['start_time'] ) ) {
			$originalData['start_time'] = $recurring['start_time'];
		}

		$bookingService = Container::resolve( BookingService::class );
		$bookingService->createBookingsForAppointment( $originalData, $appointment->get_id(), true );

		do_action( 'radius_booking_after_create_single_recurring', $appointment, $recurring, $originalData, $parent_id );
	}
}
