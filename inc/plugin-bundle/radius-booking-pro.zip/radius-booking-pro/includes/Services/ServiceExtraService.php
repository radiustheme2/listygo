<?php
/**
 * ServiceExtraService
 *
 * Business logic layer for Service Extras.
 *
 * @package RadiusTheme\RadiusBookingPro\Services
 */

namespace RadiusTheme\RadiusBookingPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBookingPro\Repositories\ServiceExtraRepository;
use RadiusTheme\RadiusBookingPro\Repositories\BookingExtraRepository;

/**
 * Class ServiceExtraService
 *
 * Handles business logic for service extras including validation,
 * price calculation, and duration calculation.
 */
class ServiceExtraService {

	/**
	 * ServiceExtra Repository
	 *
	 * @var ServiceExtraRepository
	 */
	private ServiceExtraRepository $extraRepo;

	/**
	 * BookingExtra Repository
	 *
	 * @var BookingExtraRepository
	 */
	private BookingExtraRepository $bookingExtraRepo;

	/**
	 * Constructor.
	 *
	 * @param ServiceExtraRepository $extraRepo        The service extra repository.
	 * @param BookingExtraRepository $bookingExtraRepo The booking extra repository.
	 */
	public function __construct( ServiceExtraRepository $extraRepo, BookingExtraRepository $bookingExtraRepo ) {
		$this->extraRepo        = $extraRepo;
		$this->bookingExtraRepo = $bookingExtraRepo;
	}

	/**
	 * Validate selected extras for a service.
	 *
	 * @param int   $serviceId      The service ID.
	 * @param array $selectedExtras Array of selected extras: [['id' => int, 'quantity' => int], ...].
	 * @param array $serviceSettings Service extras settings (extras_enabled, extras_selection_type, etc.).
	 *
	 * @return array{valid: bool, message: string, validated_extras: array}
	 */
	public function validateSelection( int $serviceId, array $selectedExtras, array $serviceSettings ): array {
		// If extras are not enabled, no extras should be selected.
		if ( empty( $serviceSettings['extras_enabled'] ) ) {
			if ( ! empty( $selectedExtras ) ) {
				return array(
					'valid'            => false,
					'message'          => __( 'Extras are not enabled for this service.', 'radius-booking-pro' ),
					'validated_extras' => array(),
				);
			}
			return array(
				'valid'            => true,
				'message'          => '',
				'validated_extras' => array(),
			);
		}

		$selectionType     = $serviceSettings['extras_selection_type'] ?? 'single';
		$mandatoryExtra    = ! empty( $serviceSettings['mandatory_extra'] );
		$minSelectedExtras = (int) ( $serviceSettings['min_selected_extras'] ?? 0 );
		$maxSelectedExtras = (int) ( $serviceSettings['max_selected_extras'] ?? 3 );

		$validatedExtras = array();
		$totalCount      = 0;

		// Get all active extras for this service.
		$serviceExtras = $this->extraRepo->getActiveByService( $serviceId );
		$extraMap      = array();
		foreach ( $serviceExtras as $extra ) {
			$extraMap[ $extra->id ] = $extra;
		}

		// Validate each selected extra.
		foreach ( $selectedExtras as $selection ) {
			$extraId  = isset( $selection['id'] ) ? (int) $selection['id'] : 0;
			$quantity = isset( $selection['quantity'] ) ? (int) $selection['quantity'] : 1;

			// Check if extra exists and belongs to this service.
			if ( ! isset( $extraMap[ $extraId ] ) ) {
				return array(
					'valid'            => false,
					'message'          => __( 'Invalid extra selected.', 'radius-booking-pro' ),
					'validated_extras' => array(),
				);
			}

			$extra = $extraMap[ $extraId ];

			// Check if extra is active.
			if ( ! $extra->isValid() ) {
				return array(
					'valid'            => false,
					'message'          => sprintf(
						/* translators: %s: extra title */
						__( 'The extra "%s" is not available.', 'radius-booking-pro' ),
						$extra->title
					),
					'validated_extras' => array(),
				);
			}

			// Validate quantity.
			$qtyValidation = $extra->validateQuantity( $quantity );
			if ( ! $qtyValidation['valid'] ) {
				return array(
					'valid'            => false,
					'message'          => $qtyValidation['message'],
					'validated_extras' => array(),
				);
			}

			$validatedExtras[] = array(
				'id'       => $extraId,
				'quantity' => $qtyValidation['adjusted_quantity'],
				'extra'    => $extra,
			);

			++$totalCount;
		}

		// Single selection mode: max 1 extra.
		if ( 'single' === $selectionType && $totalCount > 1 ) {
			return array(
				'valid'            => false,
				'message'          => __( 'Only one extra can be selected for this service.', 'radius-booking-pro' ),
				'validated_extras' => array(),
			);
		}

		// Mandatory extra check.
		if ( $mandatoryExtra && $totalCount < 1 ) {
			return array(
				'valid'            => false,
				'message'          => __( 'At least one extra is required for this service.', 'radius-booking-pro' ),
				'validated_extras' => array(),
			);
		}

		// Min selection check.
		if ( $minSelectedExtras > 0 && $totalCount < $minSelectedExtras ) {
			return array(
				'valid'            => false,
				'message'          => sprintf(
					/* translators: %d: minimum number of extras */
					__( 'Please select at least %d extra(s).', 'radius-booking-pro' ),
					$minSelectedExtras
				),
				'validated_extras' => array(),
			);
		}

		// Max selection check (multiple mode only).
		if ( 'multiple' === $selectionType && $totalCount > $maxSelectedExtras ) {
			return array(
				'valid'            => false,
				'message'          => sprintf(
					/* translators: %d: maximum number of extras */
					__( 'You can select up to %d extra(s).', 'radius-booking-pro' ),
					$maxSelectedExtras
				),
				'validated_extras' => array(),
			);
		}

		return array(
			'valid'            => true,
			'message'          => '',
			'validated_extras' => $validatedExtras,
		);
	}

	/**
	 * Calculate the total price for selected extras.
	 *
	 * @param array $selectedExtras Array of selected extras: [['id' => int, 'quantity' => int], ...].
	 *
	 * @return float Total price for all selected extras.
	 */
	public function calculateExtrasPrice( array $selectedExtras ): float {
		$total = 0.0;

		foreach ( $selectedExtras as $selection ) {
			$extraId  = isset( $selection['id'] ) ? (int) $selection['id'] : 0;
			$quantity = isset( $selection['quantity'] ) ? (int) $selection['quantity'] : 1;

			if ( ! $extraId ) {
				continue;
			}

			$extra = $this->extraRepo->find( $extraId );
			if ( $extra && $extra->isValid() ) {
				$total += $extra->calculatePrice( $quantity );
			}
		}

		return $total;
	}

	/**
	 * Calculate the total duration for selected extras.
	 *
	 * @param array $selectedExtras Array of selected extras: [['id' => int, 'quantity' => int], ...].
	 *
	 * @return int Total duration in minutes for all selected extras.
	 */
	public function calculateExtrasDuration( array $selectedExtras ): int {
		$duration = 0;

		foreach ( $selectedExtras as $selection ) {
			$extraId  = isset( $selection['id'] ) ? (int) $selection['id'] : 0;
			$quantity = isset( $selection['quantity'] ) ? (int) $selection['quantity'] : 1;

			if ( ! $extraId ) {
				continue;
			}

			$extra = $this->extraRepo->find( $extraId );
			if ( $extra && $extra->isValid() ) {
				$duration += $extra->calculateDuration( $quantity );
			}
		}

		return $duration;
	}

	/**
	 * Get extras for a service with full details.
	 *
	 * @param int $serviceId The service ID.
	 *
	 * @return array Array of extra data.
	 */
	public function getExtrasForService( int $serviceId ): array {
		return $this->extraRepo->getActiveByService( $serviceId );
	}

	/**
	 * Create booking extras snapshot.
	 *
	 * @param int   $bookingId      The booking ID.
	 * @param array $selectedExtras Array of selected extras.
	 *
	 * @return array Array of created booking extras.
	 */
	public function createBookingExtrasSnapshot( int $bookingId, array $selectedExtras ): array {
		return $this->bookingExtraRepo->createSnapshot( $bookingId, $selectedExtras );
	}

	/**
	 * Get booking extras.
	 *
	 * @param int $bookingId The booking ID.
	 *
	 * @return array Array of booking extras.
	 */
	public function getBookingExtras( int $bookingId ): array {
		return $this->bookingExtraRepo->getByBooking( $bookingId );
	}

	/**
	 * Get the total extras price for a booking.
	 *
	 * @param int $bookingId The booking ID.
	 *
	 * @return float Total extras price.
	 */
	public function getBookingExtrasTotal( int $bookingId ): float {
		return $this->bookingExtraRepo->getTotalPriceByBooking( $bookingId );
	}

	/**
	 * Get the total extras duration for a booking.
	 *
	 * @param int $bookingId The booking ID.
	 *
	 * @return int Total extras duration in minutes.
	 */
	public function getBookingExtrasDuration( int $bookingId ): int {
		return $this->bookingExtraRepo->getTotalDurationByBooking( $bookingId );
	}
}
