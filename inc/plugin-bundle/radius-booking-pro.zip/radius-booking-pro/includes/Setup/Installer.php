<?php

namespace RadiusTheme\RadiusBookingPro\Setup;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use RadiusTheme\RadiusBooking\Databases\DatabaseManager;
use RadiusTheme\RadiusBookingPro\Common\Keys;

/**
 * Installer class for setting up the Radius Booking Pro plugin.
 *
 * Handles DB version tracking and running migrations when the
 * schema version is bumped (mirrors the free plugin pattern).
 *
 * @since 1.0.0
 */
class Installer {

	/**
	 * Initialize installer hooks.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'update' ), 5 );
	}

	/**
	 * Compare stored DB version against the constant and run
	 * migrations when behind.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function update() {
		$current_version = get_option( Keys::RADIUS_BOOKING_PRO_DB_VERSION, '0' );

		if ( version_compare( $current_version, RADIUS_BOOKING_PRO_DB_VERSION, '<' ) ) {
			$installer = new self();
			$installer->run();
		}
	}

	/**
	 * Run the installer: create tables, then stamp the version.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function run() {
		$this->create_tables();
		$this->add_version();
	}

	/**
	 * Persist version info in wp_options.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function add_version(): void {
		$installed = get_option( Keys::RADIUS_BOOKING_PRO_INSTALLED );

		if ( ! $installed ) {
			update_option( Keys::RADIUS_BOOKING_PRO_INSTALLED, time() );
		}

		self::update_db_version();
		update_option( Keys::RADIUS_BOOKING_PRO_VERSION, RADIUS_BOOKING_PRO_VERSION );
	}

	/**
	 * Update DB version option to current constant value.
	 *
	 * @param string|null $version Override version or null for current.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function update_db_version( $version = null ) {
		update_option(
			Keys::RADIUS_BOOKING_PRO_DB_VERSION,
			is_null( $version ) ? RADIUS_BOOKING_PRO_DB_VERSION : $version
		);
	}

	/**
	 * Create or update database tables via DatabaseManager.
	 *
	 * Pro migration classes are already registered in DatabaseHook
	 * via the `rtrb_booking_migration_classes` filter.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function create_tables() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		if ( ! function_exists( 'dbDelta' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		}

		DatabaseManager::migrate();
	}
}