<?php
/**
 * Appointment Context Resolver
 *
 * Turns an appointment id into the data a WhatsApp notification needs:
 * merge-tag values plus resolved recipient phone numbers. Reuses the free
 * plugin's AppointmentResource so the values match the email notifications.
 *
 * @package RadiusTheme\RadiusBookingPro\WhatsApp\Context
 */

namespace RadiusTheme\RadiusBookingPro\WhatsApp\Context;

use RadiusTheme\RadiusBooking\Models\Appointment;
use RadiusTheme\RadiusBooking\Resources\AppointmentResource;
use RadiusTheme\RadiusBooking\Helpers\SettingsHelper;
use RadiusTheme\RadiusBooking\Helpers\MultiStaffHelper;
use RadiusTheme\RadiusBookingPro\WhatsApp\WhatsAppSettings;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class AppointmentContextResolver
 */
class AppointmentContextResolver {

	/**
	 * Resolve an appointment id into notification context.
	 *
	 * @param int $appointment_id Appointment id.
	 * @return array|null {
	 *     @type array $merge_tags Placeholder values.
	 *     @type array $phones     ['customer' => string, 'employee' => string, 'admin' => string[]].
	 *     @type array $data       Raw transformed booking.
	 * }
	 */
	public static function resolve( $appointment_id ) {
		if ( empty( $appointment_id ) ) {
			return null;
		}

		$appointment = Appointment::find( $appointment_id );

		if ( ! $appointment ) {
			return null;
		}

		$booking = ( new AppointmentResource() )->transform( $appointment );

		if ( empty( $booking ) ) {
			return null;
		}

		$customer = isset( $booking['customer'] ) && isset( $booking['customer']->customer_info )
			? $booking['customer']->customer_info
			: array();

		$currency = function_exists( 'get_rtrb_currency_symbol' ) ? get_rtrb_currency_symbol() : '';

		$price_value = ! empty( $booking['dynamic_pricing']['final_price'] )
			? $booking['dynamic_pricing']['final_price']
			: ( isset( $booking['customer']->price ) ? $booking['customer']->price : 0 );

		$merge_tags = array(
			'customer_name'  => isset( $customer['name'] ) ? $customer['name'] : '',
			'customer_email' => isset( $customer['email'] ) ? $customer['email'] : '',
			'customer_phone' => isset( $customer['phone'] ) ? $customer['phone'] : '',
			'staff_name'     => isset( $booking['employee_name'] ) ? $booking['employee_name'] : '',
			'staff_email'    => isset( $booking['employee_email'] ) ? $booking['employee_email'] : '',
			'staff_phone'    => isset( $booking['employee_phone'] ) ? $booking['employee_phone'] : '',
			'service_name'   => isset( $booking['service_name'] ) ? $booking['service_name'] : '',
			'booking_id'     => isset( $booking['customer']->id ) ? $booking['customer']->id : ( isset( $booking['id'] ) ? $booking['id'] : '' ),
			'booking_date'   => ! empty( $booking['appointment_date'] ) ? date_i18n( 'l, F j, Y', strtotime( $booking['appointment_date'] ) ) : '',
			'time'           => ! empty( $booking['start_time'] ) ? date_i18n( 'g:i A', strtotime( $booking['start_time'] ) ) : '',
			'duration'       => isset( $booking['customer']->duration ) ? ( (int) $booking['customer']->duration / 60 ) . ' ' . __( 'minutes', 'radius-booking-pro' ) : '',
			'location'       => ! empty( $booking['location_info']['address'] ) ? $booking['location_info']['address'] : '',
			'price'          => $currency . number_format( (float) $price_value, 2 ),
			'status'         => isset( $booking['status'] ) ? $booking['status'] : '',
			'notes'          => isset( $booking['notes'] ) ? $booking['notes'] : '',
		);

		// Multi-staff: names + phones of every assigned staff member.
		$merge_tags['all_staff_names'] = MultiStaffHelper::allStaffNamesString( $appointment_id );

		return array(
			'merge_tags' => $merge_tags,
			'phones'     => array(
				'customer'     => $merge_tags['customer_phone'],
				'employee'     => $merge_tags['staff_phone'],
				'employee_all' => MultiStaffHelper::getStaffPhones( $appointment_id ),
				'admin'        => self::admin_phones(),
			),
			'data'       => $booking,
		);
	}

	/**
	 * Admin notification phone numbers (from WhatsApp settings, fallback to business phone).
	 *
	 * @return array
	 */
	public static function admin_phones() {
		$configured = WhatsAppSettings::get_value( 'admin_numbers', array() );

		if ( is_array( $configured ) && ! empty( $configured ) ) {
			return $configured;
		}

		$business = SettingsHelper::get_setting( 'business' );

		if ( ! empty( $business['phone'] ) ) {
			return array( $business['phone'] );
		}

		return array();
	}

	/**
	 * Sample merge-tag data for previews / test messages.
	 *
	 * @return array
	 */
	public static function preview_merge_tags() {
		return array(
			'customer_name'  => 'John Doe',
			'customer_email' => 'john@example.com',
			'customer_phone' => '+1 (555) 123-4567',
			'staff_name'     => 'Sarah Johnson',
			'staff_email'    => 'sarah@example.com',
			'staff_phone'    => '+1 (555) 987-6543',
			'service_name'   => 'Hair Cut & Styling',
			'booking_id'     => 'BK-2025-001',
			'booking_date'   => date_i18n( 'l, F j, Y' ),
			'time'           => '2:00 PM',
			'duration'       => '60 minutes',
			'location'       => '123 Main St, Suite 200',
			'price'          => '$75.00',
			'status'         => 'Confirmed',
			'notes'          => 'Please arrive 10 minutes early',
		);
	}
}
