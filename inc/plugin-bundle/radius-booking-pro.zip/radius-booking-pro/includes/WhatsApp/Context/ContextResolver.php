<?php
/**
 * Context Resolver Dispatcher
 *
 * Routes an appointment id to the correct per-booking-type resolver.
 *
 * @package RadiusTheme\RadiusBookingPro\WhatsApp\Context
 */

namespace RadiusTheme\RadiusBookingPro\WhatsApp\Context;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class ContextResolver
 */
class ContextResolver {

	/**
	 * Resolve context for a booking type.
	 *
	 * @param string $booking_type   appointment|meeting|event.
	 * @param int    $appointment_id Appointment id.
	 * @return array|null
	 */
	public static function resolve( $booking_type, $appointment_id ) {
		switch ( $booking_type ) {
			case 'meeting':
				return MeetingContextResolver::resolve( $appointment_id );
			case 'event':
				return EventContextResolver::resolve( $appointment_id );
			case 'appointment':
			default:
				return AppointmentContextResolver::resolve( $appointment_id );
		}
	}

	/**
	 * Sample merge tags for a booking type (previews / test messages).
	 *
	 * @param string $booking_type appointment|meeting|event.
	 * @return array
	 */
	public static function preview_merge_tags( $booking_type ) {
		switch ( $booking_type ) {
			case 'meeting':
				return MeetingContextResolver::preview_merge_tags();
			case 'event':
				return EventContextResolver::preview_merge_tags();
			case 'appointment':
			default:
				return AppointmentContextResolver::preview_merge_tags();
		}
	}

	/**
	 * Merge-tag catalogue (tag => label) for a booking type, for the UI inserter.
	 *
	 * @param string $booking_type appointment|meeting|event.
	 * @return array
	 */
	public static function tag_catalogue( $booking_type ) {
		$common = array(
			'customer_name'  => __( 'Customer Name', 'radius-booking-pro' ),
			'customer_email' => __( 'Customer Email', 'radius-booking-pro' ),
			'customer_phone' => __( 'Customer Phone', 'radius-booking-pro' ),
			'staff_name'     => __( 'Staff Name', 'radius-booking-pro' ),
			'staff_phone'    => __( 'Staff Phone', 'radius-booking-pro' ),
			'booking_id'     => __( 'Booking ID', 'radius-booking-pro' ),
			'status'         => __( 'Status', 'radius-booking-pro' ),
			'site_name'      => __( 'Site Name', 'radius-booking-pro' ),
			'site_url'       => __( 'Site URL', 'radius-booking-pro' ),
		);

		switch ( $booking_type ) {
			case 'meeting':
				$specific = array(
					'meeting_type_name' => __( 'Meeting Type', 'radius-booking-pro' ),
					'booking_date'      => __( 'Meeting Date', 'radius-booking-pro' ),
					'time'              => __( 'Start Time', 'radius-booking-pro' ),
					'end_time'          => __( 'End Time', 'radius-booking-pro' ),
					'duration'          => __( 'Duration', 'radius-booking-pro' ),
					'meeting_link'      => __( 'Meeting Link', 'radius-booking-pro' ),
					'location'          => __( 'Location', 'radius-booking-pro' ),
					'notes'             => __( 'Notes', 'radius-booking-pro' ),
				);
				break;
			case 'event':
				$specific = array(
					'event_name'          => __( 'Event Name', 'radius-booking-pro' ),
					'event_date'          => __( 'Event Date', 'radius-booking-pro' ),
					'event_time'          => __( 'Event Time', 'radius-booking-pro' ),
					'event_location'      => __( 'Event Location', 'radius-booking-pro' ),
					'ticket_name'         => __( 'Ticket Name', 'radius-booking-pro' ),
					'ticket_quantity'     => __( 'Ticket Quantity', 'radius-booking-pro' ),
					'registration_number' => __( 'Registration No.', 'radius-booking-pro' ),
				);
				break;
			case 'appointment':
			default:
				$specific = array(
					'service_name'    => __( 'Service Name', 'radius-booking-pro' ),
					'booking_date'    => __( 'Booking Date', 'radius-booking-pro' ),
					'time'            => __( 'Appointment Time', 'radius-booking-pro' ),
					'duration'        => __( 'Duration', 'radius-booking-pro' ),
					'location'        => __( 'Location', 'radius-booking-pro' ),
					'price'           => __( 'Price', 'radius-booking-pro' ),
					'all_staff_names' => __( 'All Staff Names', 'radius-booking-pro' ),
					'notes'           => __( 'Notes', 'radius-booking-pro' ),
				);
				break;
		}

		$merged = array_merge( $specific, $common );
		$out    = array();

		foreach ( $merged as $tag => $label ) {
			$out[] = array(
				'tag'   => '{' . $tag . '}',
				'label' => $label,
			);
		}

		return $out;
	}
}
