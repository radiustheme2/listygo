<?php
/**
 * Event Context Resolver
 *
 * Resolves an appointment id (booking_type = event) into WhatsApp merge-tag
 * values and recipient phone numbers. Mirrors the merge tags used by the free
 * Customer\EventRegistrationConfirmed email.
 *
 * @package RadiusTheme\RadiusBookingPro\WhatsApp\Context
 */

namespace RadiusTheme\RadiusBookingPro\WhatsApp\Context;

use RadiusTheme\RadiusBooking\Models\Appointment;
use RadiusTheme\RadiusBooking\Models\Event;
use RadiusTheme\RadiusBooking\Models\EventRegistration;
use RadiusTheme\RadiusBooking\Models\EventTicketType;
use RadiusTheme\RadiusBooking\Resources\AppointmentResource;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class EventContextResolver
 */
class EventContextResolver {

	/**
	 * Resolve an appointment id into event notification context.
	 *
	 * @param int $appointment_id Appointment id.
	 * @return array|null
	 */
	public static function resolve( $appointment_id ) {
		if ( empty( $appointment_id ) ) {
			return null;
		}

		$appointment = Appointment::find( $appointment_id );
		if ( ! $appointment ) {
			return null;
		}

		$booking = ( new AppointmentResource() )->transform( $appointment );
		if ( empty( $booking ) ) {
			return null;
		}

		$customer = isset( $booking['customer'] ) && isset( $booking['customer']->customer_info )
			? $booking['customer']->customer_info
			: array();

		$event        = ! empty( $appointment->event_id ) ? Event::find( $appointment->event_id ) : null;
		$registration = EventRegistration::where( 'appointment_id', (int) $appointment_id )->first();
		$ticket_type  = ( $registration && ! empty( $registration->ticket_type_id ) ) ? EventTicketType::find( $registration->ticket_type_id ) : null;

		$merge_tags = array(
			'customer_name'       => isset( $customer['name'] ) ? $customer['name'] : '',
			'customer_email'      => isset( $customer['email'] ) ? $customer['email'] : '',
			'customer_phone'      => isset( $customer['phone'] ) ? $customer['phone'] : '',
			'staff_name'          => isset( $booking['employee_name'] ) ? $booking['employee_name'] : '',
			'staff_phone'         => isset( $booking['employee_phone'] ) ? $booking['employee_phone'] : '',
			'event_name'          => $event ? $event->name : '',
			'event_date'          => ( $event && ! empty( $event->start_date ) ) ? date_i18n( 'l, F j, Y', strtotime( $event->start_date ) ) : '',
			'event_time'          => ( $event && ! empty( $event->start_time ) ) ? date_i18n( 'g:i A', strtotime( $event->start_time ) ) : '',
			'event_location'      => $event ? self::event_location( $event ) : '',
			'ticket_name'         => $ticket_type ? $ticket_type->name : '',
			'ticket_quantity'     => $registration ? $registration->quantity : 1,
			'registration_number' => $registration ? $registration->registration_number : '',
			'booking_id'          => isset( $booking['id'] ) ? $booking['id'] : '',
			'status'              => isset( $booking['status'] ) ? $booking['status'] : '',
		);

		return array(
			'merge_tags' => $merge_tags,
			'phones'     => array(
				'customer' => $merge_tags['customer_phone'],
				'employee' => $merge_tags['staff_phone'],
				'admin'    => AppointmentContextResolver::admin_phones(),
			),
			'data'       => $booking,
		);
	}

	/**
	 * Human-readable event location.
	 *
	 * @param Event $event Event model.
	 * @return string
	 */
	private static function event_location( $event ) {
		switch ( $event->location_type ?? '' ) {
			case 'online':
				return ! empty( $event->location_value ) ? $event->location_value : __( 'Online', 'radius-booking-pro' );
			case 'physical':
				return ! empty( $event->location_value ) ? $event->location_value : __( 'In Person', 'radius-booking-pro' );
			default:
				return ! empty( $event->location_value ) ? $event->location_value : '';
		}
	}

	/**
	 * Sample merge tags for previews / test messages.
	 *
	 * @return array
	 */
	public static function preview_merge_tags() {
		return array(
			'customer_name'       => 'John Doe',
			'customer_email'      => 'john@example.com',
			'customer_phone'      => '+1 (555) 123-4567',
			'staff_name'          => 'Sarah Johnson',
			'staff_phone'         => '+1 (555) 987-6543',
			'event_name'          => 'Annual Tech Conference',
			'event_date'          => date_i18n( 'l, F j, Y' ),
			'event_time'          => '9:00 AM',
			'event_location'      => 'Convention Center, Hall A',
			'ticket_name'         => 'General Admission',
			'ticket_quantity'     => 2,
			'registration_number' => 'REG-2025-0042',
			'booking_id'          => 'EV-2025-001',
			'status'              => 'Confirmed',
		);
	}
}
