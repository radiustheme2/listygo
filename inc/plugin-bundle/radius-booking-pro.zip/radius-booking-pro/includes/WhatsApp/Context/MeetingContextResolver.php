<?php
/**
 * Meeting Context Resolver
 *
 * Resolves an appointment id (booking_type = meeting) into WhatsApp merge-tag
 * values and recipient phone numbers. Mirrors the merge tags used by the free
 * Customer\MeetingConfirmed email.
 *
 * @package RadiusTheme\RadiusBookingPro\WhatsApp\Context
 */

namespace RadiusTheme\RadiusBookingPro\WhatsApp\Context;

use RadiusTheme\RadiusBooking\Models\Appointment;
use RadiusTheme\RadiusBooking\Models\MeetingType;
use RadiusTheme\RadiusBooking\Resources\AppointmentResource;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class MeetingContextResolver
 */
class MeetingContextResolver {

	/**
	 * Resolve an appointment id into meeting notification context.
	 *
	 * @param int $appointment_id Appointment id.
	 * @return array|null
	 */
	public static function resolve( $appointment_id ) {
		if ( empty( $appointment_id ) ) {
			return null;
		}

		$appointment = Appointment::find( $appointment_id );
		if ( ! $appointment ) {
			return null;
		}

		$booking = ( new AppointmentResource() )->transform( $appointment );
		if ( empty( $booking ) ) {
			return null;
		}

		$customer = isset( $booking['customer'] ) && isset( $booking['customer']->customer_info )
			? $booking['customer']->customer_info
			: array();

		$meeting_type = ! empty( $appointment->meeting_type_id ) ? MeetingType::find( $appointment->meeting_type_id ) : null;

		$ml               = isset( $booking['meeting_link'] ) ? (array) $booking['meeting_link'] : array();
		$integration_link = ! empty( $ml['join_url'] )
			? $ml['join_url']
			: ( $meeting_type && ! empty( $meeting_type->location_details ) ? $meeting_type->location_details : '' );

		$merge_tags = array(
			'customer_name'     => isset( $customer['name'] ) ? $customer['name'] : '',
			'customer_email'    => isset( $customer['email'] ) ? $customer['email'] : '',
			'customer_phone'    => isset( $customer['phone'] ) ? $customer['phone'] : '',
			'staff_name'        => isset( $booking['employee_name'] ) ? $booking['employee_name'] : '',
			'staff_email'       => isset( $booking['employee_email'] ) ? $booking['employee_email'] : '',
			'staff_phone'       => isset( $booking['employee_phone'] ) ? $booking['employee_phone'] : '',
			'meeting_type_name' => $meeting_type ? $meeting_type->name : '',
			'booking_id'        => isset( $booking['id'] ) ? $booking['id'] : '',
			'booking_date'      => ! empty( $booking['appointment_date'] ) ? date_i18n( 'l, F j, Y', strtotime( $booking['appointment_date'] ) ) : '',
			'time'              => ! empty( $booking['start_time'] ) ? date_i18n( 'g:i A', strtotime( $booking['start_time'] ) ) : '',
			'end_time'          => ! empty( $booking['end_time'] ) ? date_i18n( 'g:i A', strtotime( $booking['end_time'] ) ) : '',
			'duration'          => $meeting_type ? $meeting_type->duration . ' ' . __( 'minutes', 'radius-booking-pro' ) : '',
			'meeting_link'      => $integration_link,
			'location'          => $meeting_type ? self::meeting_location( $meeting_type ) : '',
			'status'            => isset( $booking['status'] ) ? $booking['status'] : '',
			'notes'             => isset( $booking['notes'] ) ? $booking['notes'] : '',
		);

		return array(
			'merge_tags' => $merge_tags,
			'phones'     => array(
				'customer' => $merge_tags['customer_phone'],
				'employee' => $merge_tags['staff_phone'],
				'admin'    => AppointmentContextResolver::admin_phones(),
			),
			'data'       => $booking,
		);
	}

	/**
	 * Human-readable meeting location from the meeting type.
	 *
	 * @param MeetingType $meeting_type Meeting type.
	 * @return string
	 */
	private static function meeting_location( $meeting_type ) {
		switch ( $meeting_type->location_type ?? '' ) {
			case 'google_meet':
				return __( 'Google Meet', 'radius-booking-pro' );
			case 'zoom':
				return __( 'Zoom', 'radius-booking-pro' );
			case 'in_person':
				return ! empty( $meeting_type->location_details ) ? $meeting_type->location_details : __( 'In Person', 'radius-booking-pro' );
			case 'phone':
				return __( 'Phone Call', 'radius-booking-pro' );
			default:
				return ! empty( $meeting_type->location_details ) ? $meeting_type->location_details : '';
		}
	}

	/**
	 * Sample merge tags for previews / test messages.
	 *
	 * @return array
	 */
	public static function preview_merge_tags() {
		return array(
			'customer_name'     => 'John Doe',
			'customer_email'    => 'john@example.com',
			'customer_phone'    => '+1 (555) 123-4567',
			'staff_name'        => 'Sarah Johnson',
			'staff_email'       => 'sarah@example.com',
			'staff_phone'       => '+1 (555) 987-6543',
			'meeting_type_name' => 'Strategy Call',
			'booking_id'        => 'MT-2025-001',
			'booking_date'      => date_i18n( 'l, F j, Y' ),
			'time'              => '2:00 PM',
			'end_time'          => '2:30 PM',
			'duration'          => '30 minutes',
			'meeting_link'      => 'https://meet.google.com/abc-defg-hij',
			'location'          => 'Google Meet',
			'status'            => 'Confirmed',
			'notes'             => '',
		);
	}
}
