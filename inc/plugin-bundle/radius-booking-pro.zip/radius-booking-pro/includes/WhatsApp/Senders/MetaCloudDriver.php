<?php
/**
 * Meta WhatsApp Cloud API Driver
 *
 * Sends WhatsApp messages directly through Meta's Graph API — no third-party
 * middleman. Requires a WhatsApp Business phone number id + a permanent access
 * token from the Meta / Facebook developer console.
 *
 * @package RadiusTheme\RadiusBookingPro\WhatsApp\Senders
 */

namespace RadiusTheme\RadiusBookingPro\WhatsApp\Senders;

use RadiusTheme\RadiusBookingPro\WhatsApp\WhatsAppSettings;
use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class MetaCloudDriver
 */
class MetaCloudDriver implements WhatsAppSenderInterface {

	const API_BASE = 'https://graph.facebook.com';

	/**
	 * @inheritDoc
	 */
	public function send( $to, $body, $args = array() ) {
		$settings = WhatsAppSettings::get();

		$phone_number_id = $settings['meta_phone_number_id'];
		$access_token    = $settings['meta_access_token'];

		if ( empty( $phone_number_id ) || empty( $access_token ) ) {
			return new WP_Error( 'rtrb_whatsapp_not_configured', __( 'Meta Cloud API is not configured. Add your Phone Number ID and Access Token first.', 'radius-booking-pro' ) );
		}

		$to_number = Phone::digits( $to, $settings['default_country_code'] );
		if ( empty( $to_number ) ) {
			return new WP_Error( 'rtrb_whatsapp_invalid_recipient', __( 'The recipient does not have a valid phone number.', 'radius-booking-pro' ) );
		}

		if ( ! empty( $args['content_sid'] ) ) {
			// For Meta, the "content" reference is an approved template NAME.
			$payload = array(
				'messaging_product' => 'whatsapp',
				'to'                => $to_number,
				'type'              => 'template',
				'template'          => array(
					'name'     => sanitize_text_field( $args['content_sid'] ),
					'language' => array( 'code' => $this->language( $settings ) ),
				),
			);

			$params = $this->template_parameters( $args );
			if ( ! empty( $params ) ) {
				$payload['template']['components'] = array(
					array(
						'type'       => 'body',
						'parameters' => $params,
					),
				);
			}
		} else {
			if ( '' === trim( (string) $body ) ) {
				return new WP_Error( 'rtrb_whatsapp_empty_body', __( 'Message body is empty.', 'radius-booking-pro' ) );
			}
			$payload = array(
				'messaging_product' => 'whatsapp',
				'to'                => $to_number,
				'type'              => 'text',
				'text'              => array(
					'preview_url' => true,
					'body'        => $body,
				),
			);
		}

		/**
		 * Filter the Meta Cloud API request payload before sending.
		 *
		 * @param array  $payload   Request body.
		 * @param string $to_number Normalized recipient number.
		 * @param array  $args      Extra arguments.
		 */
		$payload = apply_filters( 'rtrb_whatsapp_meta_payload', $payload, $to_number, $args );

		$endpoint = sprintf( '%s/%s/%s/messages', self::API_BASE, $this->version( $settings ), rawurlencode( $phone_number_id ) );

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => 30,
				'headers' => array(
					'Authorization' => 'Bearer ' . $access_token,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		return $this->parse( $response );
	}

	/**
	 * @inheritDoc
	 */
	public function test_connection() {
		$settings = WhatsAppSettings::get();

		$phone_number_id = $settings['meta_phone_number_id'];
		$access_token    = $settings['meta_access_token'];

		if ( empty( $phone_number_id ) || empty( $access_token ) ) {
			return new WP_Error( 'rtrb_whatsapp_not_configured', __( 'Add your Meta Phone Number ID and Access Token first.', 'radius-booking-pro' ) );
		}

		$endpoint = add_query_arg(
			array( 'fields' => 'verified_name,display_phone_number' ),
			sprintf( '%s/%s/%s', self::API_BASE, $this->version( $settings ), rawurlencode( $phone_number_id ) )
		);

		$response = wp_remote_get(
			$endpoint,
			array(
				'timeout' => 20,
				'headers' => array(
					'Authorization' => 'Bearer ' . $access_token,
				),
			)
		);

		return $this->parse( $response );
	}

	/**
	 * Convert ordered {1: val, 2: val} content variables into Meta body params.
	 *
	 * @param array $args Send args.
	 * @return array
	 */
	private function template_parameters( $args ) {
		if ( empty( $args['content_variables'] ) || ! is_array( $args['content_variables'] ) ) {
			return array();
		}

		$vars = $args['content_variables'];
		ksort( $vars, SORT_NUMERIC );

		$params = array();
		foreach ( $vars as $value ) {
			$params[] = array(
				'type' => 'text',
				'text' => (string) $value,
			);
		}

		return $params;
	}

	/**
	 * Graph API version.
	 *
	 * @param array $settings Settings.
	 * @return string
	 */
	private function version( $settings ) {
		return ! empty( $settings['meta_api_version'] ) ? $settings['meta_api_version'] : 'v21.0';
	}

	/**
	 * Template language code.
	 *
	 * @param array $settings Settings.
	 * @return string
	 */
	private function language( $settings ) {
		return ! empty( $settings['meta_template_language'] ) ? $settings['meta_template_language'] : 'en_US';
	}

	/**
	 * Parse a Graph API response.
	 *
	 * @param array|WP_Error $response Raw response.
	 * @return true|WP_Error
	 */
	private function parse( $response ) {
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code >= 200 && $code < 300 ) {
			return true;
		}

		$message = '';
		if ( is_array( $data ) && ! empty( $data['error']['message'] ) ) {
			$message = $data['error']['message'];
		}

		if ( '' === $message ) {
			/* translators: %d: HTTP status code. */
			$message = sprintf( __( 'Meta Cloud API request failed (HTTP %d).', 'radius-booking-pro' ), $code );
		}

		return new WP_Error( 'rtrb_whatsapp_api_error', $message, array( 'status' => $code ) );
	}
}
