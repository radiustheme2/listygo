<?php
/**
 * Phone number helper.
 *
 * @package RadiusTheme\RadiusBookingPro\WhatsApp\Senders
 */

namespace RadiusTheme\RadiusBookingPro\WhatsApp\Senders;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Phone
 */
class Phone {

	/**
	 * Normalize a phone number to E.164 (e.g. +14155551234).
	 *
	 * @param string $number          Raw phone number.
	 * @param string $default_country Optional dialing code (e.g. "1" or "+1") used
	 *                                when the number has no country prefix.
	 * @return string Normalized number, or empty string if it cannot be normalized.
	 */
	public static function normalize( $number, $default_country = '' ) {
		$number = trim( (string) $number );

		if ( '' === $number ) {
			return '';
		}

		$has_plus = 0 === strpos( $number, '+' );
		$digits   = preg_replace( '/\D+/', '', $number );

		if ( '' === $digits ) {
			return '';
		}

		if ( $has_plus ) {
			return '+' . $digits;
		}

		$cc = preg_replace( '/\D+/', '', (string) $default_country );

		if ( '' !== $cc ) {
			return '+' . $cc . $digits;
		}

		return '+' . $digits;
	}

	/**
	 * Digits-only international format (no "+"), as required by the Meta Cloud API.
	 *
	 * @param string $number          Raw phone number.
	 * @param string $default_country Optional dialing code.
	 * @return string
	 */
	public static function digits( $number, $default_country = '' ) {
		return ltrim( self::normalize( $number, $default_country ), '+' );
	}
}
