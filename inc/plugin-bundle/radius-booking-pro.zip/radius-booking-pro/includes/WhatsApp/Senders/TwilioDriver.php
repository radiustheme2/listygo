<?php
/**
 * Twilio WhatsApp Driver
 *
 * Sends WhatsApp messages through the Twilio REST API.
 *
 * @package RadiusTheme\RadiusBookingPro\WhatsApp\Senders
 */

namespace RadiusTheme\RadiusBookingPro\WhatsApp\Senders;

use RadiusTheme\RadiusBookingPro\WhatsApp\WhatsAppSettings;
use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class TwilioDriver
 */
class TwilioDriver implements WhatsAppSenderInterface {

	const API_BASE = 'https://api.twilio.com/2010-04-01';

	/**
	 * @inheritDoc
	 */
	public function send( $to, $body, $args = array() ) {
		$settings = WhatsAppSettings::get();

		$account_sid = $settings['account_sid'];
		$auth_token  = $settings['auth_token'];
		$from        = $settings['from_number'];

		if ( empty( $account_sid ) || empty( $auth_token ) || empty( $from ) ) {
			return new WP_Error( 'rtrb_whatsapp_not_configured', __( 'Twilio is not configured. Add your credentials first.', 'radius-booking-pro' ) );
		}

		$to_number = Phone::normalize( $to, $settings['default_country_code'] );
		if ( empty( $to_number ) ) {
			return new WP_Error( 'rtrb_whatsapp_invalid_recipient', __( 'The recipient does not have a valid phone number.', 'radius-booking-pro' ) );
		}

		$payload = array(
			'From' => $this->wa_address( $from, $settings['default_country_code'] ),
			'To'   => $this->wa_address( $to_number, $settings['default_country_code'] ),
		);

		if ( ! empty( $args['content_sid'] ) ) {
			$payload['ContentSid'] = sanitize_text_field( $args['content_sid'] );
			if ( ! empty( $args['content_variables'] ) && is_array( $args['content_variables'] ) ) {
				$payload['ContentVariables'] = wp_json_encode( $args['content_variables'] );
			}
		} else {
			if ( '' === trim( (string) $body ) ) {
				return new WP_Error( 'rtrb_whatsapp_empty_body', __( 'Message body is empty.', 'radius-booking-pro' ) );
			}
			$payload['Body'] = $body;
		}

		/** This filter is documented in includes/WhatsApp/Senders/TwilioDriver.php */
		$payload = apply_filters( 'rtrb_whatsapp_twilio_payload', $payload, $to_number, $args );

		$endpoint = sprintf( '%s/Accounts/%s/Messages.json', self::API_BASE, rawurlencode( $account_sid ) );

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => 30,
				'headers' => array(
					'Authorization' => 'Basic ' . base64_encode( $account_sid . ':' . $auth_token ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
				),
				'body'    => $payload,
			)
		);

		return $this->parse( $response );
	}

	/**
	 * @inheritDoc
	 */
	public function test_connection() {
		$settings = WhatsAppSettings::get();

		if ( empty( $settings['account_sid'] ) || empty( $settings['auth_token'] ) ) {
			return new WP_Error( 'rtrb_whatsapp_not_configured', __( 'Add your Twilio Account SID and Auth Token first.', 'radius-booking-pro' ) );
		}

		$endpoint = sprintf( '%s/Accounts/%s.json', self::API_BASE, rawurlencode( $settings['account_sid'] ) );

		$response = wp_remote_get(
			$endpoint,
			array(
				'timeout' => 20,
				'headers' => array(
					'Authorization' => 'Basic ' . base64_encode( $settings['account_sid'] . ':' . $settings['auth_token'] ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
				),
			)
		);

		return $this->parse( $response );
	}

	/**
	 * Prefix a number with Twilio's `whatsapp:` channel scheme.
	 *
	 * @param string $number Number.
	 * @param string $cc     Default country code.
	 * @return string
	 */
	private function wa_address( $number, $cc ) {
		$number = trim( (string) $number );
		if ( 0 === strpos( $number, 'whatsapp:' ) ) {
			return $number;
		}
		return 'whatsapp:' . Phone::normalize( $number, $cc );
	}

	/**
	 * Parse a wp_remote_* response.
	 *
	 * @param array|WP_Error $response Raw response.
	 * @return true|WP_Error
	 */
	private function parse( $response ) {
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code >= 200 && $code < 300 ) {
			return true;
		}

		$message = is_array( $data ) && ! empty( $data['message'] )
			? $data['message']
			/* translators: %d: HTTP status code. */
			: sprintf( __( 'Twilio request failed (HTTP %d).', 'radius-booking-pro' ), $code );

		return new WP_Error( 'rtrb_whatsapp_api_error', $message, array( 'status' => $code ) );
	}
}
