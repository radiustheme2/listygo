<?php
/**
 * WhatsApp Sender Interface
 *
 * Contract every provider driver (Twilio, Meta Cloud API, …) implements so the
 * notification layer stays provider-agnostic.
 *
 * @package RadiusTheme\RadiusBookingPro\WhatsApp\Senders
 */

namespace RadiusTheme\RadiusBookingPro\WhatsApp\Senders;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Interface WhatsAppSenderInterface
 */
interface WhatsAppSenderInterface {

	/**
	 * Send a WhatsApp message.
	 *
	 * @param string $to   Recipient phone number (any format).
	 * @param string $body Plain-text message body.
	 * @param array  $args {
	 *     Optional template overrides.
	 *
	 *     @type string $content_sid       Provider template reference (Twilio Content SID
	 *                                      or Meta template name).
	 *     @type array  $content_variables Ordered variables for the template.
	 * }
	 * @return true|\WP_Error
	 */
	public function send( $to, $body, $args = array() );

	/**
	 * Verify the stored credentials.
	 *
	 * @return true|\WP_Error
	 */
	public function test_connection();
}
