<?php
/**
 * WhatsApp Delivery Logger
 *
 * Keeps a capped, rolling log of the most recent WhatsApp send attempts so
 * the admin can see delivery successes/failures without external tooling.
 *
 * @package RadiusTheme\RadiusBookingPro\WhatsApp
 */

namespace RadiusTheme\RadiusBookingPro\WhatsApp;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class WhatsAppLogger
 */
class WhatsAppLogger {

	/**
	 * Option key.
	 *
	 * @var string
	 */
	const OPTION_KEY = 'rtrb_whatsapp_log';

	/**
	 * Maximum number of retained log entries.
	 *
	 * @var int
	 */
	const MAX_ENTRIES = 50;

	/**
	 * Record a successful send.
	 *
	 * @param string $notification_id Notification id.
	 * @param string $to              Recipient number.
	 * @return void
	 */
	public static function log_success( $notification_id, $to ) {
		self::add(
			array(
				'status'          => 'success',
				'notification_id' => $notification_id,
				'to'              => self::mask( $to ),
				'message'         => '',
			)
		);
	}

	/**
	 * Record a failed send.
	 *
	 * @param string $notification_id Notification id.
	 * @param string $to              Recipient number.
	 * @param string $error           Error message.
	 * @return void
	 */
	public static function log_failure( $notification_id, $to, $error ) {
		self::add(
			array(
				'status'          => 'failed',
				'notification_id' => $notification_id,
				'to'              => self::mask( $to ),
				'message'         => $error,
			)
		);
	}

	/**
	 * Get the log entries (newest first).
	 *
	 * @return array
	 */
	public static function get() {
		$log = get_option( self::OPTION_KEY, array() );

		return is_array( $log ) ? $log : array();
	}

	/**
	 * Clear the log.
	 *
	 * @return void
	 */
	public static function clear() {
		delete_option( self::OPTION_KEY );
	}

	/**
	 * Prepend an entry and trim to the cap.
	 *
	 * @param array $entry Entry data.
	 * @return void
	 */
	private static function add( $entry ) {
		$entry['time'] = current_time( 'mysql' );

		$log = self::get();
		array_unshift( $log, $entry );
		$log = array_slice( $log, 0, self::MAX_ENTRIES );

		update_option( self::OPTION_KEY, $log, false );
	}

	/**
	 * Partially mask a phone number for privacy in the log.
	 *
	 * @param string $number Phone number.
	 * @return string
	 */
	private static function mask( $number ) {
		$number = (string) $number;
		$len    = strlen( $number );

		if ( $len <= 4 ) {
			return $number;
		}

		return substr( $number, 0, 3 ) . str_repeat( '*', max( 0, $len - 5 ) ) . substr( $number, -2 );
	}
}
