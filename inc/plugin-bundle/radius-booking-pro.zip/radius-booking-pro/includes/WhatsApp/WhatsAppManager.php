<?php
/**
 * WhatsApp Manager
 *
 * Central registry for WhatsApp notifications. Defines the available
 * notification types, instantiates them, seeds default settings, and wires
 * each one to its trigger action. Mirrors the role of EmailManager in free.
 *
 * @package RadiusTheme\RadiusBookingPro\WhatsApp
 */

namespace RadiusTheme\RadiusBookingPro\WhatsApp;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class WhatsAppManager
 */
class WhatsAppManager {

	/**
	 * Action Scheduler hook used to deliver immediate notifications off-request.
	 */
	const ASYNC_SEND_HOOK = 'rtrb_whatsapp_send';

	/**
	 * Action Scheduler group for deferred immediate sends.
	 */
	const ASYNC_SEND_GROUP = 'whatsapp-notifications';

	/**
	 * Registered notification instances keyed by id.
	 *
	 * @var WhatsAppNotification[]
	 */
	private $notifications = array();

	/**
	 * Boot the manager: build, seed, and register all notifications.
	 *
	 * @return void
	 */
	public function init() {
		foreach ( $this->get_definitions() as $definition ) {
			$notification = new WhatsAppNotification( $definition );

			$this->maybe_seed_defaults( $notification );
			$notification->register_hooks();

			$this->notifications[ $notification->get_id() ] = $notification;
		}

		// Single background handler for deferred immediate sends (registered
		// once here, not per-notification, so it fires exactly once per job).
		add_action( self::ASYNC_SEND_HOOK, array( $this, 'process_async_send' ), 10, 2 );

		/**
		 * Fires after all WhatsApp notifications are registered.
		 *
		 * @param WhatsAppManager $manager Manager instance.
		 */
		do_action( 'rtrb_whatsapp_notifications_initialized', $this );
	}

	/**
	 * Deliver a deferred immediate notification (Action Scheduler callback).
	 *
	 * @param string $notification_id Notification id.
	 * @param int    $appointment_id  Appointment id.
	 * @return void
	 */
	public function process_async_send( $notification_id, $appointment_id ) {
		$notification = $this->get_notification( $notification_id );

		if ( ! $notification || ! $notification->is_enabled() ) {
			return;
		}

		$notification->deliver_for_appointment( (int) $appointment_id );
	}

	/**
	 * Seed default settings into the options table on first run.
	 *
	 * @param WhatsAppNotification $notification Notification instance.
	 * @return void
	 */
	private function maybe_seed_defaults( WhatsAppNotification $notification ) {
		$option_key = 'rtrb_whatsapp_' . $notification->get_id();

		if ( false === get_option( $option_key, false ) ) {
			update_option( $option_key, $notification->get_default_settings(), false );
		}
	}

	/**
	 * Get all registered notifications.
	 *
	 * @return WhatsAppNotification[]
	 */
	public function get_notifications() {
		if ( empty( $this->notifications ) ) {
			foreach ( $this->get_definitions() as $definition ) {
				$notification = new WhatsAppNotification( $definition );
				$this->notifications[ $notification->get_id() ] = $notification;
			}
		}

		return $this->notifications;
	}

	/**
	 * Get only the reminder notifications.
	 *
	 * @return WhatsAppNotification[]
	 */
	public function get_reminder_notifications() {
		return array_filter(
			$this->get_notifications(),
			function ( $notification ) {
				return $notification->is_reminder();
			}
		);
	}

	/**
	 * Get a single notification by id.
	 *
	 * @param string $id Notification id.
	 * @return WhatsAppNotification|null
	 */
	public function get_notification( $id ) {
		$notifications = $this->get_notifications();

		return isset( $notifications[ $id ] ) ? $notifications[ $id ] : null;
	}

	/**
	 * The catalogue of WhatsApp notification definitions.
	 *
	 * @return array
	 */
	public function get_definitions() {
		$definitions = array(
			// --- Customer ---------------------------------------------------.
			array(
				'id'              => 'customer_appointment_confirmed',
				'title'           => __( 'Appointment Confirmed - Customer', 'radius-booking-pro' ),
				'description'     => __( 'Sent to the customer when their appointment is confirmed.', 'radius-booking-pro' ),
				'recipient_type'  => 'customer',
				'trigger'         => 'radius_booking_appointment_status_confirmed',
				'status'          => 'confirmed',
				'arg_type'        => 'appointment_id',
				'default_message' => __( "✅ Hi {customer_name}, your appointment for {service_name} is confirmed for {booking_date} at {time}. See you soon!", 'radius-booking-pro' ),
			),
			array(
				'id'              => 'customer_appointment_pending',
				'title'           => __( 'Appointment Pending - Customer', 'radius-booking-pro' ),
				'description'     => __( 'Sent to the customer when their appointment is received and awaiting confirmation.', 'radius-booking-pro' ),
				'recipient_type'  => 'customer',
				'trigger'         => 'radius_booking_appointment_status_pending',
				'status'          => 'pending',
				'arg_type'        => 'appointment_id',
				'default_message' => __( "🕓 Hi {customer_name}, we received your booking request for {service_name} on {booking_date} at {time}. We'll confirm shortly.", 'radius-booking-pro' ),
			),
			array(
				'id'              => 'customer_appointment_cancelled',
				'title'           => __( 'Appointment Cancelled - Customer', 'radius-booking-pro' ),
				'description'     => __( 'Sent to the customer when their appointment is cancelled.', 'radius-booking-pro' ),
				'recipient_type'  => 'customer',
				'trigger'         => 'radius_booking_appointment_status_cancelled',
				'status'          => 'cancelled',
				'arg_type'        => 'appointment_id',
				'default_message' => __( "❌ Hi {customer_name}, your appointment for {service_name} on {booking_date} at {time} has been cancelled.", 'radius-booking-pro' ),
			),
			array(
				'id'              => 'customer_appointment_completed',
				'title'           => __( 'Appointment Completed - Customer', 'radius-booking-pro' ),
				'description'     => __( 'Sent to the customer when their appointment is marked complete.', 'radius-booking-pro' ),
				'recipient_type'  => 'customer',
				'trigger'         => 'radius_booking_appointment_status_completed',
				'status'          => 'completed',
				'arg_type'        => 'appointment_id',
				'default_message' => __( "🙏 Thank you {customer_name}! Your {service_name} appointment is complete. We hope to see you again.", 'radius-booking-pro' ),
			),

			// --- Employee ---------------------------------------------------.
			array(
				'id'              => 'employee_appointment_assigned',
				'title'           => __( 'Appointment Assigned - Staff', 'radius-booking-pro' ),
				'description'     => __( 'Sent to a staff member when an appointment is assigned to them.', 'radius-booking-pro' ),
				'recipient_type'  => 'employee',
				'trigger'         => 'radius_booking_appointment_staff_assigned',
				'status'          => 'assigned',
				'arg_type'        => 'appointment_id',
				'default_message' => __( "📌 Hi {staff_name}, a new appointment ({service_name}) with {customer_name} is scheduled for {booking_date} at {time}.", 'radius-booking-pro' ),
			),
			array(
				'id'              => 'employee_appointment_cancelled',
				'title'           => __( 'Appointment Cancelled - Staff', 'radius-booking-pro' ),
				'description'     => __( 'Sent to the assigned staff member when an appointment is cancelled.', 'radius-booking-pro' ),
				'recipient_type'  => 'employee',
				'trigger'         => 'radius_booking_appointment_status_cancelled',
				'status'          => 'cancelled',
				'arg_type'        => 'appointment_id',
				'default_message' => __( "❌ Hi {staff_name}, the appointment ({service_name}) with {customer_name} on {booking_date} at {time} has been cancelled.", 'radius-booking-pro' ),
			),

			// --- Reminders (scheduled, not status-triggered) ----------------.
			array(
				'id'               => 'customer_appointment_reminder',
				'title'            => __( 'Appointment Reminder - Customer', 'radius-booking-pro' ),
				'description'      => __( 'Sent to the customer a set time before their appointment.', 'radius-booking-pro' ),
				'recipient_type'   => 'customer',
				'trigger'          => '', // Scheduled by WhatsAppReminderService, not a status hook.
				'status'           => 'reminder',
				'arg_type'         => 'appointment_id',
				'is_reminder'      => true,
				'reminder_minutes' => 1440,
				'default_message'  => __( "⏰ Reminder: Hi {customer_name}, your {service_name} appointment is on {booking_date} at {time}. See you soon!", 'radius-booking-pro' ),
			),
			array(
				'id'               => 'employee_appointment_reminder',
				'title'            => __( 'Appointment Reminder - Staff', 'radius-booking-pro' ),
				'description'      => __( 'Sent to the assigned staff member a set time before the appointment.', 'radius-booking-pro' ),
				'recipient_type'   => 'employee',
				'trigger'          => '', // Scheduled by WhatsAppReminderService, not a status hook.
				'status'           => 'reminder',
				'arg_type'         => 'appointment_id',
				'is_reminder'      => true,
				'reminder_minutes' => 120,
				'default_message'  => __( "⏰ Reminder: Hi {staff_name}, you have a {service_name} appointment with {customer_name} on {booking_date} at {time}.", 'radius-booking-pro' ),
			),

			// --- Meeting ----------------------------------------------------.
			array(
				'id'              => 'customer_meeting_confirmed',
				'title'           => __( 'Meeting Confirmed - Customer', 'radius-booking-pro' ),
				'description'     => __( 'Sent to the customer when their meeting is confirmed.', 'radius-booking-pro' ),
				'recipient_type'  => 'customer',
				'trigger'         => 'radius_booking_meeting_status_confirmed',
				'status'          => 'confirmed',
				'booking_type'    => 'meeting',
				'arg_type'        => 'appointment_id',
				'default_message' => __( "✅ Hi {customer_name}, your {meeting_type_name} meeting is confirmed for {booking_date} at {time}. Join: {meeting_link}", 'radius-booking-pro' ),
			),
			array(
				'id'              => 'customer_meeting_cancelled',
				'title'           => __( 'Meeting Cancelled - Customer', 'radius-booking-pro' ),
				'description'     => __( 'Sent to the customer when their meeting is cancelled.', 'radius-booking-pro' ),
				'recipient_type'  => 'customer',
				'trigger'         => 'radius_booking_meeting_status_cancelled',
				'status'          => 'cancelled',
				'booking_type'    => 'meeting',
				'arg_type'        => 'appointment_id',
				'default_message' => __( "❌ Hi {customer_name}, your {meeting_type_name} meeting on {booking_date} at {time} has been cancelled.", 'radius-booking-pro' ),
			),
			array(
				'id'              => 'employee_meeting_confirmed',
				'title'           => __( 'Meeting Confirmed - Staff', 'radius-booking-pro' ),
				'description'     => __( 'Sent to the assigned staff member when a meeting is confirmed.', 'radius-booking-pro' ),
				'recipient_type'  => 'employee',
				'trigger'         => 'radius_booking_meeting_status_confirmed',
				'status'          => 'confirmed',
				'booking_type'    => 'meeting',
				'arg_type'        => 'appointment_id',
				'default_message' => __( "📌 Hi {staff_name}, a {meeting_type_name} meeting with {customer_name} is confirmed for {booking_date} at {time}.", 'radius-booking-pro' ),
			),
			array(
				'id'               => 'customer_meeting_reminder',
				'title'            => __( 'Meeting Reminder - Customer', 'radius-booking-pro' ),
				'description'      => __( 'Sent to the customer a set time before their meeting.', 'radius-booking-pro' ),
				'recipient_type'   => 'customer',
				'trigger'          => '',
				'status'           => 'reminder',
				'booking_type'     => 'meeting',
				'arg_type'         => 'appointment_id',
				'is_reminder'      => true,
				'reminder_minutes' => 60,
				'default_message'  => __( "⏰ Reminder: Hi {customer_name}, your {meeting_type_name} meeting is on {booking_date} at {time}. Join: {meeting_link}", 'radius-booking-pro' ),
			),
			array(
				'id'               => 'employee_meeting_reminder',
				'title'            => __( 'Meeting Reminder - Staff', 'radius-booking-pro' ),
				'description'      => __( 'Sent to the assigned staff member a set time before the meeting.', 'radius-booking-pro' ),
				'recipient_type'   => 'employee',
				'trigger'          => '',
				'status'           => 'reminder',
				'booking_type'     => 'meeting',
				'arg_type'         => 'appointment_id',
				'is_reminder'      => true,
				'reminder_minutes' => 60,
				'default_message'  => __( "⏰ Reminder: Hi {staff_name}, you have a {meeting_type_name} meeting with {customer_name} on {booking_date} at {time}.", 'radius-booking-pro' ),
			),

			// --- Event ------------------------------------------------------.
			array(
				'id'              => 'customer_event_confirmed',
				'title'           => __( 'Event Registration Confirmed - Customer', 'radius-booking-pro' ),
				'description'     => __( 'Sent to the customer when they register for an event.', 'radius-booking-pro' ),
				'recipient_type'  => 'customer',
				'trigger'         => 'radius_booking_event_registered',
				'status'          => 'confirmed',
				'booking_type'    => 'event',
				'arg_type'        => 'event_registration',
				'default_message' => __( "🎟️ Hi {customer_name}, you're registered for {event_name} on {event_date} at {event_time}. Ticket: {ticket_name} ({registration_number}).", 'radius-booking-pro' ),
			),
			array(
				'id'              => 'customer_event_cancelled',
				'title'           => __( 'Event Registration Cancelled - Customer', 'radius-booking-pro' ),
				'description'     => __( 'Sent to the customer when their event registration is cancelled.', 'radius-booking-pro' ),
				'recipient_type'  => 'customer',
				'trigger'         => 'radius_booking_event_registration_cancelled',
				'status'          => 'cancelled',
				'booking_type'    => 'event',
				'arg_type'        => 'event_registration',
				'default_message' => __( "❌ Hi {customer_name}, your registration for {event_name} on {event_date} has been cancelled.", 'radius-booking-pro' ),
			),
			array(
				'id'               => 'customer_event_reminder',
				'title'            => __( 'Event Reminder - Customer', 'radius-booking-pro' ),
				'description'      => __( 'Sent to the customer a set time before the event.', 'radius-booking-pro' ),
				'recipient_type'   => 'customer',
				'trigger'          => '',
				'status'           => 'reminder',
				'booking_type'     => 'event',
				'arg_type'         => 'event_registration',
				'is_reminder'      => true,
				'reminder_minutes' => 1440,
				'default_message'  => __( "⏰ Reminder: Hi {customer_name}, {event_name} is on {event_date} at {event_time} at {event_location}. See you there!", 'radius-booking-pro' ),
			),

			// --- Admin ------------------------------------------------------.
			array(
				'id'              => 'admin_new_appointment',
				'title'           => __( 'New Appointment - Admin', 'radius-booking-pro' ),
				'description'     => __( 'Sent to admin number(s) when a new appointment is created.', 'radius-booking-pro' ),
				'recipient_type'  => 'admin',
				'trigger'         => 'radius_booking_booking_created',
				'status'          => 'created',
				'arg_type'        => 'customer_booking',
				'default_message' => __( "🔔 New appointment: {customer_name} booked {service_name} on {booking_date} at {time} with {staff_name}.", 'radius-booking-pro' ),
			),
		);

		/**
		 * Filter the WhatsApp notification definitions.
		 *
		 * @param array $definitions Notification definitions.
		 */
		return apply_filters( 'rtrb_whatsapp_notification_definitions', $definitions );
	}
}
