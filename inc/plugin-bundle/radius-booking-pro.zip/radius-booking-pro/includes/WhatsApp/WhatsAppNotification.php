<?php
/**
 * WhatsApp Notification
 *
 * A single, config-driven notification type. Instances are created by
 * WhatsAppManager from a definition array, mirroring the structure of the
 * free plugin's per-email classes without duplicating boilerplate per type.
 *
 * @package RadiusTheme\RadiusBookingPro\WhatsApp
 */

namespace RadiusTheme\RadiusBookingPro\WhatsApp;

use RadiusTheme\RadiusBooking\Emails\MergeTags;
use RadiusTheme\RadiusBookingPro\WhatsApp\Context\ContextResolver;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class WhatsAppNotification
 */
class WhatsAppNotification {

	/**
	 * Notification definition.
	 *
	 * @var array
	 */
	protected $def;

	/**
	 * Cached settings.
	 *
	 * @var array|null
	 */
	protected $settings = null;

	/**
	 * Constructor.
	 *
	 * @param array $definition {
	 *     @type string $id             Unique id, e.g. "customer_appointment_confirmed".
	 *     @type string $title          Human title.
	 *     @type string $description    Short description.
	 *     @type string $recipient_type customer|employee|admin.
	 *     @type string $trigger        WP action name to listen on.
	 *     @type string $status         Semantic status label.
	 *     @type string $booking_type   appointment (resolver key).
	 *     @type string $arg_type       appointment_id|customer_booking.
	 *     @type string $default_message Default message body with merge tags.
	 * }
	 */
	public function __construct( array $definition ) {
		$this->def = wp_parse_args(
			$definition,
			array(
				'id'               => '',
				'title'            => '',
				'description'      => '',
				'recipient_type'   => 'customer',
				'trigger'          => '',
				'status'           => '',
				'booking_type'     => 'appointment',
				'arg_type'         => 'appointment_id',
				'default_message'  => '',
				'is_reminder'      => false,
				'reminder_minutes' => 1440,
			)
		);
	}

	/**
	 * Register the WordPress trigger hook.
	 *
	 * @return void
	 */
	public function register_hooks() {
		if ( ! empty( $this->def['trigger'] ) ) {
			add_action( $this->def['trigger'], array( $this, 'trigger' ), 20, 10 );
		}
	}

	/**
	 * Notification id.
	 *
	 * @return string
	 */
	public function get_id() {
		return $this->def['id'];
	}

	/**
	 * Definition accessor.
	 *
	 * @return array
	 */
	public function get_definition() {
		return $this->def;
	}

	/**
	 * Booking type this notification targets (appointment|meeting|event).
	 *
	 * @return string
	 */
	public function get_booking_type() {
		return $this->def['booking_type'];
	}

	/**
	 * Option key for this notification's settings.
	 *
	 * @return string
	 */
	protected function option_key() {
		return 'rtrb_whatsapp_' . $this->def['id'];
	}

	/**
	 * Default per-notification settings.
	 *
	 * @return array
	 */
	public function get_default_settings() {
		$defaults = array(
			'enabled'     => false,
			'message'     => $this->def['default_message'],
			'content_sid' => '',
		);

		if ( $this->def['is_reminder'] ) {
			$defaults['reminder_minutes'] = (int) $this->def['reminder_minutes'];
		}

		return $defaults;
	}

	/**
	 * Whether this is a reminder notification (scheduled, not status-triggered).
	 *
	 * @return bool
	 */
	public function is_reminder() {
		return (bool) $this->def['is_reminder'];
	}

	/**
	 * Configured minutes-before for a reminder notification.
	 *
	 * @return int
	 */
	public function get_reminder_minutes() {
		$settings = $this->get_settings();

		return isset( $settings['reminder_minutes'] ) ? (int) $settings['reminder_minutes'] : (int) $this->def['reminder_minutes'];
	}

	/**
	 * Get merged settings.
	 *
	 * @return array
	 */
	public function get_settings() {
		if ( null !== $this->settings ) {
			return $this->settings;
		}

		$saved = get_option( $this->option_key(), array() );

		if ( ! is_array( $saved ) ) {
			$saved = array();
		}

		$this->settings = wp_parse_args( $saved, $this->get_default_settings() );

		return $this->settings;
	}

	/**
	 * Persist new settings.
	 *
	 * @param array $new_settings Partial settings.
	 * @return bool
	 */
	public function update_settings( $new_settings ) {
		$settings = array_merge( $this->get_settings(), (array) $new_settings );

		update_option( $this->option_key(), $settings, false );
		$this->settings = $settings;

		return true;
	}

	/**
	 * Whether this notification is enabled (and the channel is configured).
	 *
	 * @return bool
	 */
	public function is_enabled() {
		$settings = $this->get_settings();

		return ! empty( $settings['enabled'] ) && WhatsAppSettings::is_configured();
	}

	/**
	 * Trigger callback wired to the WordPress action.
	 *
	 * @param mixed ...$args Hook arguments.
	 * @return bool
	 */
	public function trigger( ...$args ) {
		if ( ! $this->is_enabled() ) {
			return false;
		}

		$appointment_id = $this->extract_appointment_id( $args );

		if ( empty( $appointment_id ) ) {
			return false;
		}

		// Immediate (non-reminder) notifications fire on the booking status hook,
		// which runs inline on the booking POST. Each Twilio send is a blocking
		// wp_remote_post (30s timeout, no retry) and there can be several
		// recipients — so defer the actual send to a background job and let the
		// request return. Reminders already run off-request, so they deliver
		// directly. See WhatsAppManager::process_async_send().
		if ( ! $this->is_reminder() && function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action(
				WhatsAppManager::ASYNC_SEND_HOOK,
				array(
					'notification_id' => $this->get_id(),
					'appointment_id'  => (int) $appointment_id,
				),
				WhatsAppManager::ASYNC_SEND_GROUP
			);
			return true;
		}

		return $this->deliver_for_appointment( (int) $appointment_id );
	}

	/**
	 * Resolve context and send the WhatsApp message for an appointment.
	 *
	 * Split out of trigger() so it can run either inline (reminders / no Action
	 * Scheduler) or from the deferred background job.
	 *
	 * @param int $appointment_id Appointment id.
	 * @return bool True if at least one recipient was sent to.
	 */
	public function deliver_for_appointment( int $appointment_id ) {
		if ( empty( $appointment_id ) ) {
			return false;
		}

		$context = ContextResolver::resolve( $this->def['booking_type'], $appointment_id );

		if ( empty( $context ) ) {
			return false;
		}

		$recipients = $this->resolve_recipients( $context['phones'] );

		if ( empty( $recipients ) ) {
			return false;
		}

		$settings = $this->get_settings();
		$body     = MergeTags::replace( $settings['message'], $context['merge_tags'] );

		$send_args = array();
		if ( ! empty( $settings['content_sid'] ) ) {
			$send_args['content_sid']       = $settings['content_sid'];
			$send_args['content_variables'] = $this->build_content_variables( $context['merge_tags'] );
		}

		/**
		 * Fire before a WhatsApp notification is sent.
		 *
		 * @param array               $context Resolved context.
		 * @param WhatsAppNotification $this   Notification instance.
		 */
		do_action( 'rtrb_whatsapp_before_send', $context, $this );

		$sent = false;
		foreach ( $recipients as $to ) {
			$result = WhatsAppSender::send( $to, $body, $send_args );

			if ( is_wp_error( $result ) ) {
				WhatsAppLogger::log_failure( $this->get_id(), $to, $result->get_error_message() );
			} else {
				$sent = true;
				WhatsAppLogger::log_success( $this->get_id(), $to );
			}
		}

		return $sent;
	}

	/**
	 * Extract the appointment id from the raw hook arguments.
	 *
	 * @param array $args Hook args.
	 * @return int|null
	 */
	protected function extract_appointment_id( $args ) {
		$first = isset( $args[0] ) ? $args[0] : null;

		if ( null === $first ) {
			return null;
		}

		if ( 'customer_booking' === $this->def['arg_type'] ) {
			if ( is_object( $first ) && method_exists( $first, 'get_appointment_id' ) ) {
				return $first->get_appointment_id();
			}
			return null;
		}

		// Event hooks pass an EventRegistration object carrying appointment_id.
		if ( 'event_registration' === $this->def['arg_type'] ) {
			if ( is_object( $first ) && isset( $first->appointment_id ) ) {
				return (int) $first->appointment_id;
			}
			return is_object( $first ) ? null : (int) $first;
		}

		if ( is_object( $first ) ) {
			return method_exists( $first, 'get_id' ) ? $first->get_id() : ( isset( $first->id ) ? $first->id : null );
		}

		return (int) $first;
	}

	/**
	 * Resolve recipient phone numbers for this notification's audience.
	 *
	 * @param array $phones Phones map from the resolver.
	 * @return array List of non-empty phone numbers.
	 */
	protected function resolve_recipients( $phones ) {
		switch ( $this->def['recipient_type'] ) {
			case 'admin':
				$list = isset( $phones['admin'] ) ? (array) $phones['admin'] : array();
				break;
			case 'employee':
				// Multi-staff: notify every assigned staff member.
				if ( ! empty( $phones['employee_all'] ) && is_array( $phones['employee_all'] ) ) {
					$list = $phones['employee_all'];
				} else {
					$list = isset( $phones['employee'] ) ? array( $phones['employee'] ) : array();
				}
				break;
			case 'customer':
			default:
				$list = isset( $phones['customer'] ) ? array( $phones['customer'] ) : array();
				break;
		}

		return array_values( array_filter( array_map( 'trim', $list ) ) );
	}

	/**
	 * Build ordered variables for a Twilio content template ({{1}}, {{2}}, ...).
	 *
	 * Uses the notification's own merge tags in a stable order so an approved
	 * template can reference them positionally.
	 *
	 * @param array $merge_tags Merge tag values.
	 * @return array
	 */
	protected function build_content_variables( $merge_tags ) {
		$order = array( 'customer_name', 'service_name', 'booking_date', 'time', 'staff_name', 'location', 'status' );
		$vars  = array();
		$i     = 1;

		foreach ( $order as $key ) {
			$vars[ (string) $i ] = isset( $merge_tags[ $key ] ) ? (string) $merge_tags[ $key ] : '';
			$i++;
		}

		return $vars;
	}

	/**
	 * Send a test message to a given number using preview data.
	 *
	 * @param string $to Recipient phone number.
	 * @return true|\WP_Error
	 */
	public function send_test( $to ) {
		$settings   = $this->get_settings();
		$merge_tags = ContextResolver::preview_merge_tags( $this->def['booking_type'] );
		$body       = MergeTags::replace( $settings['message'], $merge_tags );

		$send_args = array();
		if ( ! empty( $settings['content_sid'] ) ) {
			$send_args['content_sid']       = $settings['content_sid'];
			$send_args['content_variables'] = $this->build_content_variables( $merge_tags );
		}

		return WhatsAppSender::send( $to, $body, $send_args );
	}

	/**
	 * Transform to an array for the REST API / admin UI.
	 *
	 * @return array
	 */
	public function to_array() {
		$settings = $this->get_settings();

		return array(
			'id'               => $this->def['id'],
			'name'             => $this->def['title'],
			'description'      => $this->def['description'],
			'type'             => $this->def['recipient_type'],
			'booking_type'     => $this->def['booking_type'],
			'status'           => $this->def['status'],
			'event'            => $this->def['trigger'],
			'enabled'          => (bool) $settings['enabled'],
			'message'          => $settings['message'],
			'content_sid'      => $settings['content_sid'],
			'is_reminder'      => (bool) $this->def['is_reminder'],
			'reminder_minutes' => isset( $settings['reminder_minutes'] ) ? (int) $settings['reminder_minutes'] : (int) $this->def['reminder_minutes'],
		);
	}
}
