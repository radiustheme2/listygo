<?php
/**
 * WhatsApp Reminder Service
 *
 * Schedules and cancels WhatsApp appointment reminders via Action Scheduler,
 * parallel to the free email ReminderService but for the WhatsApp channel.
 * Appointment-only for now (meeting / event reminders can be added later).
 *
 * @package RadiusTheme\RadiusBookingPro\WhatsApp
 */

namespace RadiusTheme\RadiusBookingPro\WhatsApp;

use RadiusTheme\RadiusBooking\Models\Appointment;
use RadiusTheme\RadiusBooking\Resources\AppointmentResource;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class WhatsAppReminderService
 */
class WhatsAppReminderService {

	/**
	 * Action Scheduler hook name.
	 *
	 * @var string
	 */
	const REMINDER_HOOK = 'rtrb_whatsapp_process_reminder';

	/**
	 * Action Scheduler group.
	 *
	 * @var string
	 */
	const REMINDER_GROUP = 'booking-whatsapp-reminders';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register_hooks() {
		// Service appointments — signature ($appointment_id).
		add_action( 'radius_booking_appointment_status_confirmed', array( $this, 'schedule_reminders' ), 25, 1 );
		add_action( 'radius_booking_appointment_status_pending', array( $this, 'schedule_reminders' ), 25, 1 );
		add_action( 'radius_booking_appointment_status_cancelled', array( $this, 'cancel_reminders' ), 25, 1 );
		add_action( 'radius_booking_appointment_status_completed', array( $this, 'cancel_reminders' ), 25, 1 );

		// Meetings — signature ($appointment, $meeting_type).
		add_action( 'radius_booking_meeting_status_confirmed', array( $this, 'handle_meeting_schedule' ), 25, 2 );
		add_action( 'radius_booking_meeting_status_pending', array( $this, 'handle_meeting_schedule' ), 25, 2 );
		add_action( 'radius_booking_meeting_status_cancelled', array( $this, 'handle_meeting_cancel' ), 25, 2 );
		add_action( 'radius_booking_meeting_status_completed', array( $this, 'handle_meeting_cancel' ), 25, 2 );

		// Events — signature ($registration, $event|$previous_status).
		add_action( 'radius_booking_event_registration_status_confirmed', array( $this, 'handle_event_schedule' ), 25, 2 );
		add_action( 'radius_booking_event_registration_status_pending', array( $this, 'handle_event_schedule' ), 25, 2 );
		add_action( 'radius_booking_event_registration_cancelled', array( $this, 'handle_event_cancel' ), 25, 2 );

		add_action( self::REMINDER_HOOK, array( $this, 'process_reminder' ), 10, 2 );
	}

	/**
	 * Meeting status hook adapter — schedule.
	 *
	 * @param object|int $appointment Appointment model or id.
	 * @return void
	 */
	public function handle_meeting_schedule( $appointment, $meeting_type = null ) {
		$this->schedule_reminders( $this->appointment_id_from_object( $appointment ) );
	}

	/**
	 * Meeting status hook adapter — cancel.
	 *
	 * @param object|int $appointment Appointment model or id.
	 * @return void
	 */
	public function handle_meeting_cancel( $appointment, $meeting_type = null ) {
		$this->cancel_reminders( $this->appointment_id_from_object( $appointment ) );
	}

	/**
	 * Event registration hook adapter — schedule.
	 *
	 * @param object|int $registration EventRegistration model or appointment id.
	 * @return void
	 */
	public function handle_event_schedule( $registration, $event = null ) {
		$this->schedule_reminders( $this->appointment_id_from_registration( $registration ) );
	}

	/**
	 * Event registration hook adapter — cancel.
	 *
	 * @param object|int $registration EventRegistration model or appointment id.
	 * @return void
	 */
	public function handle_event_cancel( $registration, $previous_status = null ) {
		$this->cancel_reminders( $this->appointment_id_from_registration( $registration ) );
	}

	/**
	 * Extract an appointment id from an Appointment model or scalar.
	 *
	 * @param mixed $appointment Appointment model or id.
	 * @return int
	 */
	private function appointment_id_from_object( $appointment ) {
		if ( is_object( $appointment ) ) {
			if ( method_exists( $appointment, 'get_id' ) ) {
				return (int) $appointment->get_id();
			}
			return (int) ( $appointment->id ?? 0 );
		}
		return (int) $appointment;
	}

	/**
	 * Extract an appointment id from an EventRegistration model or scalar.
	 *
	 * @param mixed $registration EventRegistration model or appointment id.
	 * @return int
	 */
	private function appointment_id_from_registration( $registration ) {
		if ( is_object( $registration ) ) {
			return (int) ( $registration->appointment_id ?? 0 );
		}
		return (int) $registration;
	}

	/**
	 * Schedule WhatsApp reminders for an appointment.
	 *
	 * @param int $appointment_id Appointment id.
	 * @return void
	 */
	public function schedule_reminders( $appointment_id ) {
		$appointment_id = (int) $appointment_id;

		if ( ! $appointment_id || ! function_exists( 'as_schedule_single_action' ) ) {
			return;
		}

		// Nothing to schedule if the channel is off.
		if ( ! WhatsAppSettings::is_configured() ) {
			return;
		}

		$appointment = Appointment::find( $appointment_id );
		if ( ! $appointment ) {
			return;
		}

		$booking = ( new AppointmentResource() )->transform( $appointment );
		if ( empty( $booking ) || empty( $booking['appointment_date'] ) || empty( $booking['start_time'] ) ) {
			return;
		}

		$booking_type     = $this->normalize_booking_type( $booking['booking_type'] ?? 'service_booking' );
		$booking_datetime = $booking['appointment_date'] . ' ' . $booking['start_time'];

		try {
			$local_dt          = new \DateTime( $booking_datetime, wp_timezone() );
			$booking_timestamp = $local_dt->getTimestamp();
		} catch ( \Exception $e ) {
			return;
		}

		// Clear existing reminders first to avoid duplicates on re-confirm.
		$this->cancel_existing_reminders( $appointment_id );

		$manager = new WhatsAppManager();

		foreach ( $manager->get_reminder_notifications() as $notification ) {
			// Only schedule reminders that match this booking's type.
			if ( $notification->get_booking_type() !== $booking_type ) {
				continue;
			}
			if ( ! $notification->is_enabled() ) {
				continue;
			}

			$minutes_before     = absint( $notification->get_reminder_minutes() );
			$reminder_timestamp = $booking_timestamp - ( $minutes_before * MINUTE_IN_SECONDS );

			// Skip reminders whose time has already passed.
			if ( $reminder_timestamp <= time() ) {
				continue;
			}

			as_schedule_single_action(
				$reminder_timestamp,
				self::REMINDER_HOOK,
				array(
					'notification_id' => $notification->get_id(),
					'appointment_id'  => $appointment_id,
				),
				self::REMINDER_GROUP
			);
		}
	}

	/**
	 * Map a stored appointment booking_type to a notification booking_type.
	 *
	 * @param string $booking_type Stored value (service_booking|meeting|event).
	 * @return string appointment|meeting|event.
	 */
	private function normalize_booking_type( $booking_type ) {
		switch ( $booking_type ) {
			case 'meeting':
				return 'meeting';
			case 'event':
				return 'event';
			default:
				return 'appointment';
		}
	}

	/**
	 * Fire a scheduled reminder.
	 *
	 * @param string $notification_id Notification id.
	 * @param int    $appointment_id  Appointment id.
	 * @return void
	 */
	public function process_reminder( $notification_id, $appointment_id ) {
		$manager      = new WhatsAppManager();
		$notification = $manager->get_notification( $notification_id );

		if ( ! $notification || ! $notification->is_enabled() ) {
			return;
		}

		$appointment = Appointment::find( $appointment_id );
		if ( ! $appointment ) {
			return;
		}

		$status = $appointment->get_status();
		if ( in_array( $status, array( 'cancelled', 'completed' ), true ) ) {
			return;
		}

		$notification->trigger( (int) $appointment_id );
	}

	/**
	 * Cancel all scheduled reminders for an appointment.
	 *
	 * @param int $appointment_id Appointment id.
	 * @return void
	 */
	public function cancel_reminders( $appointment_id ) {
		$appointment_id = (int) $appointment_id;

		if ( ! $appointment_id ) {
			return;
		}

		$this->cancel_existing_reminders( $appointment_id );
	}

	/**
	 * Unschedule every reminder notification for an appointment.
	 *
	 * @param int $appointment_id Appointment id.
	 * @return void
	 */
	private function cancel_existing_reminders( $appointment_id ) {
		if ( ! function_exists( 'as_unschedule_all_actions' ) ) {
			return;
		}

		$manager = new WhatsAppManager();

		foreach ( $manager->get_reminder_notifications() as $notification ) {
			as_unschedule_all_actions(
				self::REMINDER_HOOK,
				array(
					'notification_id' => $notification->get_id(),
					'appointment_id'  => $appointment_id,
				),
				self::REMINDER_GROUP
			);
		}
	}
}
