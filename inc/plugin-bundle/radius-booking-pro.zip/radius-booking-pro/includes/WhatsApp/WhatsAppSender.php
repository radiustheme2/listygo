<?php
/**
 * WhatsApp Sender Facade
 *
 * Resolves the configured provider driver (Twilio or Meta Cloud API) and
 * delegates sending / connection tests to it. The notification layer only ever
 * talks to this class, so adding a provider never touches notification code.
 *
 * @package RadiusTheme\RadiusBookingPro\WhatsApp
 */

namespace RadiusTheme\RadiusBookingPro\WhatsApp;

use RadiusTheme\RadiusBookingPro\WhatsApp\Senders\MetaCloudDriver;
use RadiusTheme\RadiusBookingPro\WhatsApp\Senders\TwilioDriver;
use RadiusTheme\RadiusBookingPro\WhatsApp\Senders\WhatsAppSenderInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class WhatsAppSender
 */
class WhatsAppSender {

	/**
	 * Resolve the driver for the configured provider.
	 *
	 * @return WhatsAppSenderInterface
	 */
	public static function driver() {
		$provider = WhatsAppSettings::get_value( 'provider', 'twilio' );

		switch ( $provider ) {
			case 'meta':
				$driver = new MetaCloudDriver();
				break;
			case 'twilio':
			default:
				$driver = new TwilioDriver();
				break;
		}

		/**
		 * Filter the resolved WhatsApp sender driver.
		 *
		 * Allows registering a custom provider driver implementing
		 * WhatsAppSenderInterface.
		 *
		 * @param WhatsAppSenderInterface $driver   Resolved driver.
		 * @param string                  $provider Provider key.
		 */
		return apply_filters( 'rtrb_whatsapp_sender_driver', $driver, $provider );
	}

	/**
	 * Send a message via the active provider.
	 *
	 * @param string $to   Recipient number.
	 * @param string $body Message body.
	 * @param array  $args Template args.
	 * @return true|\WP_Error
	 */
	public static function send( $to, $body, $args = array() ) {
		return self::driver()->send( $to, $body, $args );
	}

	/**
	 * Test the active provider's credentials.
	 *
	 * @return true|\WP_Error
	 */
	public static function test_connection() {
		return self::driver()->test_connection();
	}
}
