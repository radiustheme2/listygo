<?php
/**
 * WhatsApp Global Settings
 *
 * Reads/writes the global WhatsApp (Twilio) configuration stored in the
 * `rtrb_whatsapp_settings` option. This is the single source of truth for
 * provider credentials and channel-wide toggles.
 *
 * @package RadiusTheme\RadiusBookingPro\WhatsApp
 */

namespace RadiusTheme\RadiusBookingPro\WhatsApp;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class WhatsAppSettings
 */
class WhatsAppSettings {

	/**
	 * Option key for global WhatsApp settings.
	 *
	 * @var string
	 */
	const OPTION_KEY = 'rtrb_whatsapp_settings';

	/**
	 * Default global settings.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'enabled'                => false,
			'provider'               => 'twilio',
			// Shared.
			'default_country_code'   => '',
			'admin_numbers'          => array(),
			// Twilio.
			'account_sid'            => '',
			'auth_token'             => '',
			'from_number'            => '',
			'sandbox_mode'           => false,
			// Meta WhatsApp Cloud API.
			'meta_phone_number_id'   => '',
			'meta_access_token'      => '',
			'meta_business_id'       => '',
			'meta_api_version'       => 'v21.0',
			'meta_template_language' => 'en_US',
		);
	}

	/**
	 * Get the full settings array (merged with defaults).
	 *
	 * @return array
	 */
	public static function get() {
		$settings = get_option( self::OPTION_KEY, array() );

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		return wp_parse_args( $settings, self::defaults() );
	}

	/**
	 * Get a single setting value.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback value.
	 * @return mixed
	 */
	public static function get_value( $key, $default = '' ) {
		$settings = self::get();

		return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
	}

	/**
	 * Persist new settings (merged over existing).
	 *
	 * @param array $new_settings Partial or full settings array.
	 * @return array The saved settings.
	 */
	public static function update( $new_settings ) {
		$settings = array_merge( self::get(), (array) $new_settings );

		update_option( self::OPTION_KEY, $settings, false );

		return $settings;
	}

	/**
	 * Whether the WhatsApp channel is usable (enabled + credentials for the
	 * selected provider present).
	 *
	 * @return bool
	 */
	public static function is_configured() {
		$settings = self::get();

		if ( empty( $settings['enabled'] ) ) {
			return false;
		}

		if ( 'meta' === $settings['provider'] ) {
			return ! empty( $settings['meta_phone_number_id'] ) && ! empty( $settings['meta_access_token'] );
		}

		return ! empty( $settings['account_sid'] )
			&& ! empty( $settings['auth_token'] )
			&& ! empty( $settings['from_number'] );
	}

	/**
	 * Return settings safe for exposing to the admin UI (secret tokens masked).
	 *
	 * @return array
	 */
	public static function get_public() {
		$settings = self::get();

		$settings['auth_token_set'] = ! empty( $settings['auth_token'] );
		$settings['auth_token']     = ! empty( $settings['auth_token'] ) ? str_repeat( '•', 12 ) : '';

		$settings['meta_access_token_set'] = ! empty( $settings['meta_access_token'] );
		$settings['meta_access_token']     = ! empty( $settings['meta_access_token'] ) ? str_repeat( '•', 12 ) : '';

		$settings['is_configured'] = self::is_configured();

		return $settings;
	}
}
