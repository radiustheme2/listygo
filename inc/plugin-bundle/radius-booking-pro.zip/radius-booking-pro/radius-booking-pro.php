<?php

/**
 * Plugin Name:       Radius Booking Pro
 * Plugin URI:        https://radiusbooking.co
 * Description:       The Pro Add-on of Radius Booking plugin with advanced features and functionalities to enhance your booking experience.
 * Version:           1.0.6
 * Author:            RadiusTheme
 * Author URI:        https://radiusbooking.co
 * Text Domain:       radius-booking-pro
 * Domain Path:       /languages
 * Requires PHP:      7.1
 * Requires WP:       5.5.0
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Requires Plugins:  radius-booking
 * Namespace:         RadiusBookingPro
 *
 * @package RadiusBookingPro
 */

defined( 'ABSPATH' ) || exit;


final class RadiusBookingPro {
    /**
     * Plugin version.
     *
     * @var string
     */
    const VERSION = '1.0.6';

    /**
     * Database schema version.
     *
     * Bump this whenever a migration changes (new table, new column, etc.)
     * so the Installer re-runs DatabaseManager::migrate().
     *
     * @var string
     */
    const DBVERSION = '1.0.6';

    /**
     * Plugin slug.
     *
     * @var string
     *
     * @since 1.0.0
     */
    const SLUG = 'radius-booking-pro';

    /**
     * Minimum required version of the free Radius Booking plugin.
     *
     * @var string
     */
    const MIN_FREE_VERSION = '1.0.20';

    /**
     * Holds various class instances.
     *
     * @var array
     *
     * @since 1.0.0
     */
    private $container = [];

    /**
     * Constructor for the PluginName class.
     *
     * Sets up all the appropriate hooks and actions within our plugin.
     *
     * @since 1.0.0
     */
    private function __construct() {
        require_once __DIR__ . '/vendor/autoload.php';

        $this->define_constants();

        register_activation_hook( __FILE__, [ $this, 'activate' ] );
        register_deactivation_hook( __FILE__, [ $this, 'deactivate' ] );

        // Delay initialization until plugins_loaded to ensure free plugin has loaded first.
        // This guarantees RADIUS_BOOKING_VERSION is defined before we check it.
        add_action( 'plugins_loaded', [ $this, 'on_plugins_loaded' ], 5 );
    }

    /**
     * Initialize plugin after all plugins are loaded.
     *
     * @since 1.0.6
     *
     * @return void
     */
    public function on_plugins_loaded(): void {
        // Check if free plugin version meets minimum requirement.
        if ( ! $this->check_free_plugin_version() ) {
            add_action( 'admin_notices', [ $this, 'free_version_notice' ] );
            return;
        }

        add_action( 'wp_loaded', [ $this, 'flush_rewrite_rules' ] );
        $this->init_plugin();
    }

    /**
     * Check if the free Radius Booking plugin version meets the minimum requirement.
     *
     * @since 1.0.6
     *
     * @return bool True if version is sufficient, false otherwise.
     */
    private function check_free_plugin_version(): bool {
        if ( ! defined( 'RADIUS_BOOKING_VERSION' ) ) {
            return false;
        }

        return version_compare( RADIUS_BOOKING_VERSION, self::MIN_FREE_VERSION, '>=' );
    }

    /**
     * Display admin notice when free plugin version is outdated.
     *
     * @since 1.0.6
     *
     * @return void
     */
    public function free_version_notice(): void {
        $message = sprintf(
            /* translators: 1: Required version, 2: Current version */
            __( 'Radius Booking Pro requires Radius Booking version %1$s or higher. You are using version %2$s. Please update the free plugin to use Pro features.', 'radius-booking-pro' ),
            self::MIN_FREE_VERSION,
            defined( 'RADIUS_BOOKING_VERSION' ) ? RADIUS_BOOKING_VERSION : __( 'unknown', 'radius-booking-pro' )
        );

        printf(
            '<div class="notice notice-error"><p><strong>%s</strong></p></div>',
            esc_html( $message )
        );
    }

    /**
     * Initializes the PluginBoilerplate() class.
     *
     * Checks for an existing PluginBoilerplate() instance
     * and if it doesn't find one, creates it.
     *
     * @since 1.0.0
     *
     * @return RadiusBookingPro|bool
     */
    public static function init() {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new RadiusBookingPro();
        }

        return $instance;
    }

    /**
     * Magic getter to bypass referencing plugin.
     *
     * @since 1.0.0
     *
     * @param $prop
     *
     * @return mixed
     */
    public function __get( $prop ) {
        if ( array_key_exists( $prop, $this->container ) ) {
            return $this->container[ $prop ];
        }

        return $this->{$prop};
    }

    /**
     * Magic isset to bypass referencing plugin.
     *
     * @since 1.0.0
     *
     * @param $prop
     *
     * @return mixed
     */
    public function __isset( $prop ) {
        return isset( $this->{$prop} ) || isset( $this->container[ $prop ] );
    }

    /**
     * Define the constants.
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function define_constants() {
        define( 'RADIUS_BOOKING_PRO_VERSION', self::VERSION );
        define( 'RADIUS_BOOKING_PRO_DB_VERSION', self::DBVERSION );
        define( 'RADIUS_BOOKING_PRO_SLUG', self::SLUG );
        define( 'RADIUS_BOOKING_PRO_FILE', __FILE__ );
        define( 'RADIUS_BOOKING_PRO_DIR', __DIR__ );
        define( 'RADIUS_BOOKING_PRO_PATH', dirname( RADIUS_BOOKING_PRO_FILE ) );
        define( 'RADIUS_BOOKING_PRO_INCLUDES', RADIUS_BOOKING_PRO_PATH . '/includes' );
        define( 'RADIUS_BOOKING_PRO_TEMPLATE_PATH', RADIUS_BOOKING_PRO_PATH . '/views' );
        define( 'RADIUS_BOOKING_PRO_URL', plugins_url( '', RADIUS_BOOKING_PRO_FILE ) );
        define( 'RADIUS_BOOKING_PRO_BUILD', RADIUS_BOOKING_PRO_URL . '/build' );
        define( 'RADIUS_BOOKING_PRO_ASSETS', RADIUS_BOOKING_PRO_URL . '/assets' );
        define( 'RADIUS_BOOKING_PRO_PRODUCTION', 'yes' );
        define( 'RADIUS_BOOKING_PRO_SL_STORE_URL', 'https://radiustheme.com/' );
        define( 'RADIUS_BOOKING_PRO_ITEM_ID', 299600 );
    }

    /**
     * Load the plugin after all plugins are loaded.
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function init_plugin() {
        $this->includes();
        $this->init_hooks();

        /**
         * Fires after the plugin is loaded.
         *
         * @since 1.0.0
         */
        do_action( 'radius_booking_pro_loaded' );
    }

    /**
     * Activating the plugin.
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function activate() {
        // Flag to trigger pro migrations on next admin page load.
        update_option( 'rtrb_pro_needs_migration', true );
    }

    /**
     * Placeholder for deactivation function.
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function deactivate() {
        //
    }

    /**
     * Flush rewrite rules after plugin is activated.
     *
     * Nothing being added here yet.
     *
     * @since 1.0.0
     */
    public function flush_rewrite_rules() {
        // fix rewrite rules
    }

    /**
     * Run the installer to create necessary migrations and seeders.
     *
     * @since 1.0.0
     *
     * @return void
     */
    private function install() {
        $installer = new RadiusTheme\RadiusBookingPro\Setup\Installer();
        $installer->run();
    }

    /**
     * Include the required files.
     *
     * @since 0.2.0
     *
     * @return void
     */
    public function includes() {
        if ( $this->is_request( 'admin' ) ) {
            $this->container['admin_menu'] = new RadiusTheme\RadiusBookingPro\Admin\Menu();

	        $license_key = trim( get_option( 'rtrb_pro_license_key', '' ) );

	        if ( ! empty( $license_key ) ) {
		        $this->container['software_licensing'] = new \RadiusTheme\RadiusBookingPro\License\PluginUpdater(
			        RADIUS_BOOKING_PRO_SL_STORE_URL,
			        __FILE__,
			        array(
				        'version' => RADIUS_BOOKING_PRO_VERSION,
				        'license' => $license_key,
				        'item_id' => RADIUS_BOOKING_PRO_ITEM_ID,
				        'author'  => 'RadiusTheme',
				        'beta'    => false,
			        )
		        );
	        }
        }
		$this->container['assets']   = new RadiusTheme\RadiusBookingPro\Assets\LoadAssets();
    }

    /**
     * Initialize the hooks.
     *
     * @since 0.2.0
     *
     * @return void
     */
    public function init_hooks() {
        // Init classes
        add_action( 'init', [ $this, 'init_classes' ] );
        // Add the plugin page links
//        add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), [ $this, 'plugin_action_links' ] );
    }


    /**
     * Instantiate the required classes.
     *
     * @since 0.2.0
     *
     * @return void
     */
    public function init_classes() {
	    $classes = array(
		    'RadiusTheme\RadiusBookingPro\Hooks\DatabaseHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\SettingsHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\AppointmentHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\RouteHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\ServiceHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\ServiceExtraHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\AnalyticsHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\CustomFieldHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\IntegrationHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\PaymentHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\CouponHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\PayoutHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\DynamicPricingHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\ExportImportHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\ChatbotHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\WhatsAppHook',
		    'RadiusTheme\RadiusBookingPro\Hooks\PermissionsHook',
	    );
	    $class_names = apply_filters( 'rtrb_pro_init_classes', $classes );

	    foreach ( $class_names as $class_name ) {
		    $this->init_hooks_for_class( $class_name );
	    }
    }

	/**
	 * Initializes hooks for a given class.
	 *
	 * @param string $class_name The fully qualified class name.
	 * @since 1.0.0
	 */
	private function init_hooks_for_class( $class_name ) {
		$instance = new $class_name();
		if ( method_exists( $instance, 'init_hooks' ) ) {
			$instance->init_hooks();
		}
	}

    /**
     * What type of request is this.
     *
     * @since 0.2.0
     *
     * @param string $type admin, ajax, cron or frontend
     *
     * @return bool
     */
    private function is_request( $type ) {
        switch ( $type ) {
            case 'admin':
                return is_admin();

            case 'ajax':
                return defined( 'DOING_AJAX' );

            case 'rest':
                return defined( 'REST_REQUEST' );

            case 'cron':
                return defined( 'DOING_CRON' );

            case 'frontend':
                return ( ! is_admin() || defined( 'DOING_AJAX' ) ) && ! defined( 'DOING_CRON' );
        }
    }

    /**
     * Plugin action links
     *
     * @param array $links
     *
     * @since 0.2.0
     *
     * @return array
     */
    public function plugin_action_links( $links ) {
        $links[] = '<a href="' . admin_url( 'admin.php?page=plugin_name#/settings' ) . '">' . __( 'Settings', 'radius-booking-pro' ) . '</a>';
        $links[] = '<a href="#" target="_blank">' . __( 'Documentation', 'radius-booking-pro' ) . '</a>';

        return $links;
    }
}



/**
 * Initialize the main plugin.
 *
 * @since 1.0.0
 *
 * @return \RadiusBookingPro|bool
 */
function radius_booking_pro_main_function() {
    return RadiusBookingPro::init();
}

/*
 * Kick-off the plugin.
 *
 * @since 1.0.0
 */
radius_booking_pro_main_function();
