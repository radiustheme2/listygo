<?php
/**
 * Pro Classifier - Auto-detect AI classification (Pro feature).
 *
 * Hooks into the free plugin's `rtrs_ai_auto_classify` filter to provide
 * AI-powered content classification when no schema types are manually selected.
 *
 * @package Rtrsp\AI
 * @since   1.0.0
 */

namespace Rtrsp\AI;

use Rtrs\AI\AIInit;
use Rtrs\AI\ContentExtractor;
use Rtrs\AI\SchemaClassifier;
use Rtrs\Modules\Schema\Helpers\SchemaFns;

defined( 'ABSPATH' ) || exit;

class ProClassifier {

	/**
	 * Perform auto-classification (Pro feature).
	 *
	 * First checks if a schema type is already configured for the post type
	 * in rtrs_schema_settings. If found, uses that directly (no AI call).
	 * Otherwise falls back to AI-powered content classification.
	 *
	 * @param  \WP_Error  $default  Default WP_Error from free plugin.
	 * @param  int  $post_id  Post ID to classify.
	 *
	 * @return array|\WP_Error Classification result or WP_Error on failure.
	 */
	public static function auto_classify( $default, $post_id ) {
		// Step 1: Check if a schema type is configured for this post type.
		$from_settings = self::classify_from_settings( $post_id );

		if ( $from_settings ) {
			return $from_settings;
		}

		// Step 2: No configured type — fall back to AI classification.
		$extractor       = new ContentExtractor();
		$compact_payload = $extractor->extract_for_classification( $post_id );

		if ( is_wp_error( $compact_payload ) ) {
			return $compact_payload;
		}

		$classifier     = new SchemaClassifier();
		$classification = $classifier->classify( $compact_payload );

		if ( is_wp_error( $classification ) ) {
			return $classification;
		}

		$threshold = (int) AIInit::getSetting( 'confidence_threshold', 60 );

		if ( $classification['confidence'] < $threshold ) {
			$classification['primary_type'] = 'Article';
			$classification['reasoning']    .= ' (Below confidence threshold, defaulted to Article)';
		}

		return $classification;
	}

	/**
	 * Try to resolve schema type from rtrs_schema_settings for the post type.
	 *
	 * @param  int  $post_id  Post ID.
	 *
	 * @return array|null Classification array or null if no type configured.
	 */
	private static function classify_from_settings( $post_id ) {
		$post = get_post( $post_id );

		if ( ! $post ) {
			return null;
		}

		$schema_post_type = SchemaFns::getPostTypeAutoSchemaConfig( $post->post_type );
		$setting_type_key = $schema_post_type['schema_type'] ?? '';

		if ( empty( $setting_type_key ) ) {
			return null;
		}

		$schema_type = AIInit::SNIPPET_TO_SCHEMA_TYPE[ $setting_type_key ] ?? $setting_type_key;

		return [
			'primary_type'    => $schema_type,
			'secondary_types' => [],
			'confidence'      => 100,
			'reasoning'       => __( 'Resolved from schema settings for this post type.', 'review-schema-pro' ),
		];
	}
}
