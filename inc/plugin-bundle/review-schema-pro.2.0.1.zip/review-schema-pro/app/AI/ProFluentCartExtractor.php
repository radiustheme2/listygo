<?php
/**
 * Pro FluentCart Extractor - FluentCart product data extraction and schema filling (Pro feature).
 *
 * Hooks into the free plugin's `rtrs_ai_extract_fluentcart_product_data`
 * and `rtrs_ai_fill_product_schema` filters.
 *
 * @package Rtrsp\AI
 * @since   1.0.0
 */

namespace Rtrsp\AI;

use Rtrs\AI\ContentExtractor;
use Rtrs\Helpers\Functions;
use Rtrs\Modules\Review\Helpers\ReviewFns;

defined( 'ABSPATH' ) || exit;

class ProFluentCartExtractor {

	/**
	 * Check if FluentCart is active.
	 *
	 * @return bool
	 */
	public static function is_fluentcart_active() {
		return defined( 'FLUENTCART_VERSION' ) || class_exists( 'FluentCart\App\App' );
	}

	/**
	 * Extract FluentCart product data (Pro feature).
	 *
	 * @param null     $default Default null from free plugin.
	 * @param \WP_Post $post    Post object.
	 *
	 * @return array|null Product data or null.
	 */
	public static function extract_fluentcart_product_data( $default, $post ) {
		if ( ! self::is_fluentcart_active() ) {
			return null;
		}

		if ( 'fluent-products' !== $post->post_type ) {
			return null;
		}

		// Get product detail from FluentCart's custom table.
		$product_detail = self::get_product_detail( $post->ID );

		if ( ! $product_detail ) {
			return null;
		}

		// Get currency from FluentCart settings.
		$currency = self::get_currency();

		// Get pricing info - convert from cents to decimal.
		$pricing = [
			'currency'   => $currency,
			'min_price'  => self::cents_to_decimal( $product_detail->min_price ?? 0 ),
			'max_price'  => self::cents_to_decimal( $product_detail->max_price ?? 0 ),
		];

		// Get variations/pricing tiers.
		$variations  = self::get_product_variations( $post->ID );
		$has_variations = ! empty( $variations ) && count( $variations ) > 1;

		// Determine product type.
		$product_type = 'simple';
		if ( $has_variations ) {
			$product_type = 'variable';
		}

		// Get the default variation for pricing.
		$default_variation = self::get_default_variation( $post->ID, $product_detail );

		if ( $default_variation ) {
			$item_price    = self::cents_to_decimal( $default_variation->item_price ?? 0 );
			$compare_price = self::cents_to_decimal( $default_variation->compare_price ?? 0 );

			$pricing['price']         = $item_price;
			$pricing['regular_price'] = $compare_price > 0 ? $compare_price : $item_price;
			$pricing['on_sale']       = $compare_price > 0 && $compare_price > $item_price;

			if ( $pricing['on_sale'] ) {
				$pricing['sale_price'] = $item_price;
			}
		}

		// Stock status.
		$stock_status     = $product_detail->stock_availability ?? 'in_stock';
		$availability_map = [
			'in_stock'    => 'https://schema.org/InStock',
			'out_stock'   => 'https://schema.org/OutOfStock',
			'backorder'   => 'https://schema.org/BackOrder',
			'pre_order'   => 'https://schema.org/PreOrder',
		];

		// Get SKU from default variation.
		$sku = '';
		if ( $default_variation && ! empty( $default_variation->sku ) ) {
			$sku = $default_variation->sku;
		}
		// Fallback to product ID.
		if ( empty( $sku ) ) {
			$sku = (string) $post->ID;
		}

		// Get brand from taxonomy.
		$brand = '';
		$brand_terms = get_the_terms( $post->ID, 'product-brands' );
		if ( $brand_terms && ! is_wp_error( $brand_terms ) ) {
			$brand = $brand_terms[0]->name;
		}

		// Get categories.
		$categories = [];
		$cat_terms  = get_the_terms( $post->ID, 'product-categories' );
		if ( $cat_terms && ! is_wp_error( $cat_terms ) ) {
			foreach ( $cat_terms as $term ) {
				$categories[] = $term->name;
			}
		}

		// Get gallery images.
		$gallery = self::get_gallery_images( $post->ID );

		// Get reviews/ratings.
		$reviews = self::get_product_reviews( $post );

		// Fulfillment type.
		$fulfillment_type = $product_detail->fulfillment_type ?? 'physical';

		$data = array_filter( [
			'product_type'       => $product_type,
			'fulfillment_type'   => $fulfillment_type,
			'pricing'            => $pricing,
			'stock_status'       => $stock_status,
			'availability'       => $availability_map[ $stock_status ] ?? 'https://schema.org/InStock',
			'sku'                => $sku,
			'brand'              => $brand,
			'categories'         => $categories,
			'gallery'            => $gallery,
			'reviews'            => $reviews,
			'is_virtual'         => 'digital' === $fulfillment_type,
			'is_downloadable'    => 'digital' === $fulfillment_type,
			'variation_count'    => count( $variations ),
			'variations'         => $has_variations ? self::format_variations_for_schema( $variations, $currency, $availability_map ) : null,
		] );

		return $data;
	}

	/**
	 * Get product detail from FluentCart's custom table.
	 *
	 * @param int $product_id Product ID.
	 *
	 * @return object|null
	 */
	private static function get_product_detail( $product_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'fct_product_details';

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE post_id = %d",
				$product_id
			)
		);
	}

	/**
	 * Get product variations from FluentCart's custom table.
	 *
	 * @param int $product_id Product ID.
	 *
	 * @return array
	 */
	private static function get_product_variations( $product_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'fct_product_variations';

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE post_id = %d AND item_status = 'active' ORDER BY serial_index ASC",
				$product_id
			)
		);
	}

	/**
	 * Get the default variation for a product.
	 *
	 * @param int    $product_id     Product ID.
	 * @param object $product_detail Product detail object.
	 *
	 * @return object|null
	 */
	private static function get_default_variation( $product_id, $product_detail ) {
		$default_variation_id = $product_detail->default_variation_id ?? null;

		if ( $default_variation_id ) {
			global $wpdb;
			$table = $wpdb->prefix . 'fct_product_variations';

			$variation = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM {$table} WHERE id = %d",
					$default_variation_id
				)
			);

			if ( $variation ) {
				return $variation;
			}
		}

		// Fallback to first active variation.
		$variations = self::get_product_variations( $product_id );

		return ! empty( $variations ) ? $variations[0] : null;
	}

	/**
	 * Get currency from FluentCart settings.
	 *
	 * @return string
	 */
	private static function get_currency() {
		if ( function_exists( 'fluentCart' ) ) {
			$app = fluentCart();
			if ( $app && method_exists( $app, 'config' ) ) {
				$currency = $app->config->get( 'app.currency', 'USD' );
				if ( $currency ) {
					return $currency;
				}
			}
		}

		// Try getting from options.
		$settings = get_option( 'fluentcart_store_settings', [] );
		if ( ! empty( $settings['currency'] ) ) {
			return $settings['currency'];
		}

		return 'USD';
	}

	/**
	 * Check if the currency is zero-decimal (like JPY, KRW).
	 *
	 * @return bool
	 */
	private static function is_zero_decimal_currency() {
		if ( function_exists( 'fluentCart' ) ) {
			$app = fluentCart();
			if ( $app && method_exists( $app, 'config' ) ) {
				return (bool) $app->config->get( 'app.is_zero_decimal', false );
			}
		}

		// Check from stored settings.
		$settings = get_option( 'fluentcart_store_settings', [] );
		if ( isset( $settings['is_zero_decimal'] ) ) {
			return (bool) $settings['is_zero_decimal'];
		}

		return false;
	}

	/**
	 * Convert FluentCart price from cents to decimal.
	 *
	 * FluentCart stores prices in cents (smallest currency unit).
	 * E.g., $19.99 is stored as 1999.
	 *
	 * @param int|float $amount Price in cents.
	 *
	 * @return float Price in decimal.
	 */
	private static function cents_to_decimal( $amount ) {
		if ( ! is_numeric( $amount ) ) {
			return 0.0;
		}

		// Zero-decimal currencies (JPY, KRW, etc.) don't need conversion.
		if ( self::is_zero_decimal_currency() ) {
			return (float) $amount;
		}

		return round( (float) $amount / 100, 2 );
	}

	/**
	 * Get gallery images for a product.
	 *
	 * @param int $product_id Product ID.
	 *
	 * @return array
	 */
	private static function get_gallery_images( $product_id ) {
		$gallery = [];

		// Get gallery from post meta.
		$gallery_meta = get_post_meta( $product_id, 'fluent-products-gallery-image', true );

		if ( ! empty( $gallery_meta ) && is_array( $gallery_meta ) ) {
			foreach ( $gallery_meta as $img ) {
				if ( ! empty( $img['url'] ) ) {
					$gallery[] = [
						'url'    => $img['url'],
						'width'  => $img['width'] ?? null,
						'height' => $img['height'] ?? null,
					];
				}
			}
		}

		return $gallery;
	}

	/**
	 * Get product reviews/ratings.
	 *
	 * @param \WP_Post $post Post object.
	 *
	 * @return array
	 */
	private static function get_product_reviews( $post ) {
		$reviews = [];

		// Check review-schema plugin's own ratings.
		if ( Functions::isEnableReviewByPostType( $post->post_type ) ) {
			$avg   = ReviewFns::getAvgRatings( $post->ID, true );
			$total = ReviewFns::getTotalRatings( $post->ID );

			if ( $avg && $total ) {
				$reviews = [
					'average_rating' => (float) $avg,
					'review_count'   => (int) $total,
					'rating_counts'  => [ $total ],
				];
			}
		}

		return $reviews;
	}

	/**
	 * Format variations for schema output.
	 *
	 * @param array  $variations       Array of variation objects.
	 * @param string $currency         Currency code.
	 * @param array  $availability_map Availability mapping.
	 *
	 * @return array|null
	 */
	private static function format_variations_for_schema( $variations, $currency, $availability_map ) {
		if ( empty( $variations ) || count( $variations ) <= 1 ) {
			return null;
		}

		$items = [];

		foreach ( $variations as $variation ) {
			$stock         = $variation->stock_status ?? 'in_stock';
			$item_price    = self::cents_to_decimal( $variation->item_price ?? 0 );
			$compare_price = self::cents_to_decimal( $variation->compare_price ?? 0 );

			$items[] = array_filter( [
				'variation_id'  => $variation->id,
				'sku'           => $variation->sku ?: null,
				'name'          => $variation->variation_title ?: null,
				'price'         => $item_price,
				'regular_price' => $compare_price > 0 ? $compare_price : $item_price,
				'sale_price'    => $compare_price > 0 && $compare_price > $item_price
					? $item_price
					: null,
				'currency'      => $currency,
				'stock_status'  => $stock,
				'availability'  => $availability_map[ $stock ] ?? 'https://schema.org/InStock',
			] );
		}

		return [
			'varies_by' => [ 'pricing_tier' ],
			'items'     => $items,
		];
	}

	/**
	 * Fill missing Product schema fields from extracted FluentCart product data.
	 *
	 * This method is called via the rtrs_ai_fill_product_schema filter
	 * after ProProductExtractor::fill_product has run.
	 *
	 * @param array  $schema    The Product schema node.
	 * @param array  $primary   Primary content signals.
	 * @param array  $secondary Secondary content signals.
	 * @param string $permalink Post permalink.
	 * @param string $entity_id Entity @id reference.
	 *
	 * @return array Modified schema.
	 */
	public static function fill_product( $schema, $primary, $secondary, $permalink, $entity_id = '' ) {
		$fct = $secondary['fluentcart_product'] ?? [];

		if ( empty( $fct ) ) {
			return $schema;
		}

		// Name and description.
		if ( empty( $schema['name'] ) && ! empty( $primary['title'] ) ) {
			$schema['name'] = $primary['title'];
		}

		if ( empty( $schema['description'] ) && ! empty( $primary['excerpt'] ) ) {
			$schema['description'] = mb_substr( $primary['excerpt'], 0, 200 );
		}

		if ( empty( $schema['url'] ) && ! empty( $primary['permalink'] ) ) {
			$schema['url'] = $primary['permalink'];
		}

		// Images.
		if ( empty( $schema['image'] ) ) {
			$images = [];

			if ( ! empty( $primary['featured_image']['url'] ) ) {
				$fi       = $primary['featured_image'];
				$images[] = array_filter( [
					'@type'  => 'ImageObject',
					'url'    => $fi['url'],
					'width'  => $fi['width'] ?? null,
					'height' => $fi['height'] ?? null,
				] );
			}

			if ( ! empty( $fct['gallery'] ) ) {
				foreach ( $fct['gallery'] as $img ) {
					$images[] = array_filter( [
						'@type'  => 'ImageObject',
						'url'    => $img['url'],
						'width'  => $img['width'] ?? null,
						'height' => $img['height'] ?? null,
					] );
				}
			}

			if ( count( $images ) === 1 ) {
				$schema['image'] = $images[0];
			} elseif ( ! empty( $images ) ) {
				$schema['image'] = $images;
			}
		}

		// SKU.
		if ( empty( $schema['sku'] ) && ! empty( $fct['sku'] ) ) {
			$schema['sku'] = $fct['sku'];
		}

		// Brand - check product-level first, then fall back to global settings.
		if ( empty( $schema['brand'] ) ) {
			$brand_name = $fct['brand'] ?? '';

			// Fallback to global ecommerce settings.
			if ( empty( $brand_name ) ) {
				$ecommerce_settings = get_option( 'rtrs_schema_ecommerce_settings', [] );
				$brand_name = $ecommerce_settings['brand_name'] ?? '';
			}

			if ( ! empty( $brand_name ) ) {
				$schema['brand'] = [
					'@type' => 'Brand',
					'name'  => $brand_name,
				];
			}
		}

		// Category.
		if ( empty( $schema['category'] ) && ! empty( $fct['categories'] ) ) {
			$schema['category'] = implode( ' > ', $fct['categories'] );
		}

		// Offers.
		if ( empty( $schema['offers'] ) && ! empty( $fct['pricing'] ) ) {
			$pricing      = $fct['pricing'];
			$currency     = $pricing['currency'] ?? 'USD';
			$product_url  = $primary['permalink'] ?? '';
			$availability = $fct['availability'] ?? 'https://schema.org/InStock';

			// Default to 1 year from now.
			$price_valid_until = gmdate( 'Y-m-d', strtotime( '+1 year' ) );

			$seller = [ '@id' => $entity_id ];

			// Variable product with price range.
			if ( ! empty( $pricing['min_price'] ) && ! empty( $pricing['max_price'] )
				&& $pricing['min_price'] !== $pricing['max_price'] ) {

				$offer = [
					'@type'           => 'AggregateOffer',
					'lowPrice'        => $pricing['min_price'],
					'highPrice'       => $pricing['max_price'],
					'offerCount'      => ! empty( $fct['variation_count'] ) ? (int) $fct['variation_count'] : null,
					'price'           => $pricing['min_price'],
					'priceCurrency'   => $currency,
					'priceValidUntil' => $price_valid_until,
					'availability'    => $availability,
					'url'             => $product_url,
					'seller'          => $seller,
				];

				if ( null === $offer['offerCount'] ) {
					unset( $offer['offerCount'] );
				}

				$schema['offers'] = [ $offer ];
			} else {
				// Simple product.
				$current_price = $pricing['price'] ?? $pricing['min_price'] ?? 0;

				$offer = [
					'@type'           => 'Offer',
					'price'           => $current_price,
					'priceCurrency'   => $currency,
					'priceValidUntil' => $price_valid_until,
					'availability'    => $availability,
					'url'             => $product_url,
					'seller'          => $seller,
				];

				$price_specs = [];

				if ( $current_price ) {
					$price_specs[] = [
						'@type'                 => 'UnitPriceSpecification',
						'price'                 => $current_price,
						'priceCurrency'         => $currency,
						'valueAddedTaxIncluded' => false,
						'validThrough'          => $price_valid_until,
					];
				}

				// Add list price if on sale.
				if ( ! empty( $pricing['on_sale'] ) && ! empty( $pricing['regular_price'] )
					&& $pricing['regular_price'] != $current_price ) {
					$price_specs[] = [
						'@type'                 => 'UnitPriceSpecification',
						'price'                 => $pricing['regular_price'],
						'priceCurrency'         => $currency,
						'valueAddedTaxIncluded' => false,
						'validThrough'          => $price_valid_until,
						'priceType'             => 'https://schema.org/ListPrice',
					];
				}

				if ( ! empty( $price_specs ) ) {
					$offer['priceSpecification'] = $price_specs;
				}

				$schema['offers'] = [ $offer ];
			}
		}

		// Aggregate rating.
		if ( empty( $schema['aggregateRating'] ) && ! empty( $fct['reviews'] ) ) {
			$reviews = $fct['reviews'];

			if ( ! empty( $reviews['review_count'] ) && $reviews['review_count'] > 0 ) {
				$rating = [
					'@type'       => 'AggregateRating',
					'ratingValue' => (float) $reviews['average_rating'],
					'bestRating'  => 5,
					'worstRating' => 1,
					'reviewCount' => (int) $reviews['review_count'],
				];

				if ( ! empty( $reviews['rating_counts'] ) && is_array( $reviews['rating_counts'] ) ) {
					$rating['ratingCount'] = (int) array_sum( $reviews['rating_counts'] );
				} else {
					$rating['ratingCount'] = (int) $reviews['review_count'];
				}

				$schema['aggregateRating'] = $rating;
			}
		}

		return $schema;
	}
}
