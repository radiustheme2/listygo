<?php
/**
 * Pro SureCart Extractor - SureCart product data extraction and schema filling (Pro feature).
 *
 * Hooks into the free plugin's `rtrs_ai_extract_surecart_product_data`
 * and `rtrs_ai_fill_product_schema` filters.
 *
 * @package Rtrsp\AI
 * @since   1.0.0
 */

namespace Rtrsp\AI;

use Rtrs\Helpers\Functions;
use Rtrs\Modules\Review\Helpers\ReviewFns;

defined( 'ABSPATH' ) || exit;

class ProSureCartExtractor {

	/**
	 * Check if SureCart is active.
	 *
	 * @return bool
	 */
	public static function is_surecart_active() {
		return defined( 'SURECART_VERSION' ) || function_exists( 'sc_get_product' );
	}

	/**
	 * Extract SureCart product data (Pro feature).
	 *
	 * @param null     $default Default null from free plugin.
	 * @param \WP_Post $post    Post object.
	 *
	 * @return array|null Product data or null.
	 */
	public static function extract_surecart_product_data( $default, $post ) {
		if ( ! self::is_surecart_active() ) {
			return null;
		}

		if ( 'sc_product' !== $post->post_type ) {
			return null;
		}

		// Get product using SureCart's helper function.
		$product = function_exists( 'sc_get_product' ) ? sc_get_product( $post ) : null;

		if ( ! $product ) {
			return null;
		}

		// Get currency from initial price.
		$currency = 'USD';
		$initial_price = null;

		if ( $product->initial_price ) {
			$initial_price = $product->initial_price;
			$currency = $initial_price->currency ?? 'USD';
		}

		// Build pricing info - convert from cents to decimal.
		$pricing = [
			'currency' => $currency,
		];

		// Get min/max from metrics or post meta.
		$min_price = 0;
		$max_price = 0;

		if ( $product->metrics ) {
			$min_price = self::convert_amount( $product->metrics->min_price_amount ?? 0, $currency );
			$max_price = self::convert_amount( $product->metrics->max_price_amount ?? 0, $currency );
		} else {
			// Fallback to post meta.
			$min_price = self::convert_amount( get_post_meta( $post->ID, 'min_price_amount', true ), $currency );
			$max_price = self::convert_amount( get_post_meta( $post->ID, 'max_price_amount', true ), $currency );
		}

		$pricing['min_price'] = $min_price;
		$pricing['max_price'] = $max_price;

		// Get current price from initial price.
		if ( $initial_price ) {
			$current_price = self::convert_amount( $initial_price->amount ?? 0, $currency );
			$scratch_price = self::convert_amount( $initial_price->scratch_amount ?? 0, $currency );

			$pricing['price'] = $current_price;
			$pricing['regular_price'] = $scratch_price > 0 ? $scratch_price : $current_price;
			$pricing['on_sale'] = ! empty( $initial_price->scratch_amount ) && $scratch_price > $current_price;

			if ( $pricing['on_sale'] ) {
				$pricing['sale_price'] = $current_price;
			}
		}

		// Determine product type based on variants.
		$has_variants = ! empty( $product->has_variants );
		$has_multiple_prices = ! empty( $product->has_multiple_prices );
		$product_type = ( $has_variants || $has_multiple_prices ) ? 'variable' : 'simple';

		// Stock status.
		$in_stock = $product->in_stock ?? true;
		$stock_status = $in_stock ? 'in_stock' : 'out_of_stock';

		$availability_map = [
			'in_stock'    => 'https://schema.org/InStock',
			'out_of_stock' => 'https://schema.org/OutOfStock',
			'backorder'   => 'https://schema.org/BackOrder',
			'pre_order'   => 'https://schema.org/PreOrder',
		];

		// SKU.
		$sku = $product->sku ?? get_post_meta( $post->ID, 'sku', true );
		if ( empty( $sku ) ) {
			$sku = (string) $post->ID;
		}

		// Weight.
		$weight = $product->weight ?? '';
		$weight_unit = $product->weight_unit ?? 'kg';

		// Get gallery images.
		$gallery = self::get_gallery_images( $product );

		// Get reviews/ratings.
		$reviews = self::get_product_reviews( $product, $post );

		// Get variants.
		$variations = null;
		$variation_count = 0;

		if ( $has_variants && isset( $product->variants->data ) ) {
			// Get variant option names (e.g., "Size", "Color").
			$variant_options = $product->variant_options->data ?? [];

			$variations = self::format_variations_for_schema(
				$product->variants->data,
				$currency,
				$availability_map,
				$initial_price,
				$variant_options
			);
			$variation_count = count( $product->variants->data );
		} elseif ( $has_multiple_prices && isset( $product->active_prices ) ) {
			// Multiple price tiers.
			$variations = self::format_price_tiers_for_schema(
				$product->active_prices,
				$currency,
				$availability_map
			);
			$variation_count = count( $product->active_prices );
		}

		// Shipping enabled.
		$shipping_enabled = $product->shipping_enabled ?? false;

		$data = array_filter( [
			'product_type'       => $product_type,
			'pricing'            => $pricing,
			'stock_status'       => $stock_status,
			'availability'       => $availability_map[ $stock_status ] ?? 'https://schema.org/InStock',
			'sku'                => $sku,
			'weight'             => $weight ? $weight . ' ' . $weight_unit : '',
			'gallery'            => $gallery,
			'reviews'            => $reviews,
			'is_virtual'         => ! $shipping_enabled,
			'is_downloadable'    => ! $shipping_enabled,
			'variation_count'    => $variation_count,
			'variations'         => $variations,
		] );

		return $data;
	}

	/**
	 * Convert SureCart price from cents to decimal.
	 *
	 * SureCart stores prices in cents (smallest currency unit).
	 * E.g., $19.99 is stored as 1999.
	 *
	 * @param int|float|string $amount   Price in cents.
	 * @param string           $currency Currency code.
	 *
	 * @return float Price in decimal.
	 */
	private static function convert_amount( $amount, $currency = 'USD' ) {
		if ( ! is_numeric( $amount ) || empty( $amount ) ) {
			return 0.0;
		}

		// Use SureCart's currency helper if available.
		if ( class_exists( '\SureCart\Support\Currency' ) ) {
			return (float) \SureCart\Support\Currency::maybeConvertAmount( $amount, $currency );
		}

		// Manual fallback - check for zero-decimal currencies.
		$zero_decimal_currencies = [ 'JPY', 'KRW', 'VND', 'BIF', 'CLP', 'DJF', 'GNF', 'ISK', 'KMF', 'PYG', 'RWF', 'UGX', 'VUV', 'XAF', 'XOF', 'XPF' ];

		if ( in_array( strtoupper( $currency ), $zero_decimal_currencies, true ) ) {
			return (float) $amount;
		}

		return round( (float) $amount / 100, 2 );
	}

	/**
	 * Get gallery images for a product.
	 *
	 * @param object $product SureCart product object.
	 *
	 * @return array
	 */
	private static function get_gallery_images( $product ) {
		$gallery = [];

		// Get featured image.
		if ( $product->featured_image ) {
			$attrs = $product->featured_image->attributes( 'full' );
			if ( ! empty( $attrs->src ) ) {
				$gallery[] = [
					'url'    => $attrs->src,
					'width'  => $attrs->width ?? null,
					'height' => $attrs->height ?? null,
					'alt'    => $attrs->alt ?? '',
				];
			}
		}

		// Get additional gallery images.
		if ( isset( $product->gallery ) && is_array( $product->gallery ) ) {
			foreach ( $product->gallery as $item ) {
				if ( is_object( $item ) && method_exists( $item, 'attributes' ) ) {
					$attrs = $item->attributes( 'full' );
					if ( ! empty( $attrs->src ) ) {
						// Skip if it's the same as featured image.
						if ( ! empty( $gallery[0]['url'] ) && $attrs->src === $gallery[0]['url'] ) {
							continue;
						}
						$gallery[] = [
							'url'    => $attrs->src,
							'width'  => $attrs->width ?? null,
							'height' => $attrs->height ?? null,
							'alt'    => $attrs->alt ?? '',
						];
					}
				}
			}
		}

		return $gallery;
	}

	/**
	 * Get product reviews/ratings.
	 *
	 * @param object   $product SureCart product object.
	 * @param \WP_Post $post    Post object.
	 *
	 * @return array
	 */
	private static function get_product_reviews( $product, $post ) {
		$reviews = [];

		// Check review-schema plugin's own ratings first.
		if ( Functions::isEnableReviewByPostType( $post->post_type ) ) {
			$avg   = ReviewFns::getAvgRatings( $post->ID, true );
			$total = ReviewFns::getTotalRatings( $post->ID );

			if ( $avg && $total ) {
				return [
					'average_rating' => (float) $avg,
					'review_count'   => (int) $total,
					'rating_counts'  => [ $total ],
				];
			}
		}

		// Fallback to SureCart's native reviews.
		$reviews_enabled = $product->reviews_enabled ?? get_post_meta( $post->ID, 'reviews_enabled', true );

		if ( $reviews_enabled ) {
			$total_reviews = $product->total_reviews ?? get_post_meta( $post->ID, 'total_reviews', true );
			$average_stars = $product->average_stars ?? get_post_meta( $post->ID, 'average_stars', true );

			if ( $total_reviews > 0 && $average_stars > 0 ) {
				$reviews = [
					'average_rating' => (float) $average_stars,
					'review_count'   => (int) $total_reviews,
					'rating_counts'  => [ (int) $total_reviews ],
				];
			}
		}

		return $reviews;
	}

	/**
	 * Format variants for schema output.
	 *
	 * SureCart stores variant option values in option_1, option_2, option_3 properties.
	 * The option names (e.g., "Size", "Color") come from variant_options.
	 *
	 * @param array  $variants         Array of variant objects.
	 * @param string $currency         Currency code.
	 * @param array  $availability_map Availability mapping.
	 * @param object $initial_price    Initial price object.
	 * @param array  $variant_options  Array of variant option objects with name/values.
	 *
	 * @return array|null
	 */
	private static function format_variations_for_schema( $variants, $currency, $availability_map, $initial_price, $variant_options = [] ) {
		if ( empty( $variants ) || count( $variants ) <= 1 ) {
			return null;
		}

		$items = [];
		$varies_by = [];

		// Build option name map: option_1 => "Size", option_2 => "Color", etc.
		$option_names = [];
		foreach ( $variant_options as $index => $opt ) {
			$key = 'option_' . ( $index + 1 );
			$option_names[ $key ] = $opt->name ?? '';
			if ( ! empty( $opt->name ) && ! in_array( $opt->name, $varies_by, true ) ) {
				$varies_by[] = $opt->name;
			}
		}

		foreach ( $variants as $variant ) {
			// Get variant price - use variant amount if set, otherwise initial price.
			$variant_amount = isset( $variant->amount ) && $variant->amount
				? $variant->amount
				: ( $initial_price->amount ?? 0 );
			$variant_currency = $variant->currency ?? $currency;

			$item_price = self::convert_amount( $variant_amount, $variant_currency );

			// Stock status.
			$in_stock = isset( $variant->available_stock )
				? $variant->available_stock > 0
				: true;
			$stock = $in_stock ? 'in_stock' : 'out_of_stock';

			// Get variant image.
			$image = '';
			if ( isset( $variant->image ) && is_object( $variant->image ) && method_exists( $variant->image, 'attributes' ) ) {
				$attrs = $variant->image->attributes( 'full' );
				$image = $attrs->src ?? '';
			}

			// Extract variant attributes from option_1, option_2, option_3.
			// Map to option names from variant_options.
			$attributes = [];
			$variant_name_parts = [];

			foreach ( [ 'option_1', 'option_2', 'option_3' ] as $opt_key ) {
				$opt_value = $variant->$opt_key ?? null;
				if ( ! empty( $opt_value ) ) {
					$opt_name = $option_names[ $opt_key ] ?? '';
					if ( $opt_name ) {
						$attributes[ $opt_name ] = $opt_value;
					}
					$variant_name_parts[] = $opt_value;
				}
			}

			// Build variant name from option values (e.g., "Large, Red").
			$variant_name = ! empty( $variant_name_parts ) ? implode( ', ', $variant_name_parts ) : null;

			$item = array_filter( [
				'variation_id'  => $variant->id ?? null,
				'sku'           => $variant->sku ?? null,
				'name'          => $variant_name,
				'price'         => $item_price,
				'currency'      => $variant_currency,
				'stock_status'  => $stock,
				'availability'  => $availability_map[ $stock ] ?? 'https://schema.org/InStock',
				'image'         => $image,
			] );

			// Add attributes if found.
			if ( ! empty( $attributes ) ) {
				$item['attributes'] = $attributes;
			}

			$items[] = $item;
		}

		if ( empty( $items ) ) {
			return null;
		}

		// Default to 'variant' if no specific attribute names were found.
		if ( empty( $varies_by ) ) {
			$varies_by = [ 'variant' ];
		}

		return [
			'varies_by' => $varies_by,
			'items'     => $items,
		];
	}

	/**
	 * Format price tiers for schema output.
	 *
	 * SureCart can have multiple price options for a single product.
	 *
	 * @param array  $prices           Array of price objects.
	 * @param string $currency         Currency code.
	 * @param array  $availability_map Availability mapping.
	 *
	 * @return array|null
	 */
	private static function format_price_tiers_for_schema( $prices, $currency, $availability_map ) {
		if ( empty( $prices ) || count( $prices ) <= 1 ) {
			return null;
		}

		$items = [];

		foreach ( $prices as $price ) {
			if ( ! empty( $price->archived ) ) {
				continue;
			}

			$price_currency = $price->currency ?? $currency;
			$item_price = self::convert_amount( $price->amount ?? 0, $price_currency );

			$items[] = array_filter( [
				'price_id'      => $price->id ?? null,
				'name'          => $price->name ?? null,
				'price'         => $item_price,
				'currency'      => $price_currency,
				'stock_status'  => 'in_stock',
				'availability'  => $availability_map['in_stock'],
			] );
		}

		if ( empty( $items ) ) {
			return null;
		}

		return [
			'varies_by' => [ 'pricing_tier' ],
			'items'     => $items,
		];
	}

	/**
	 * Fill missing Product schema fields from extracted SureCart product data.
	 *
	 * This method is called via the rtrs_ai_fill_product_schema filter
	 * after ProProductExtractor::fill_product has run.
	 *
	 * @param array  $schema    The Product schema node.
	 * @param array  $primary   Primary content signals.
	 * @param array  $secondary Secondary content signals.
	 * @param string $permalink Post permalink.
	 * @param string $entity_id Entity @id reference.
	 *
	 * @return array Modified schema.
	 */
	public static function fill_product( $schema, $primary, $secondary, $permalink, $entity_id = '' ) {
		$sc = $secondary['surecart_product'] ?? [];

		if ( empty( $sc ) ) {
			return $schema;
		}

		// Name and description.
		if ( empty( $schema['name'] ) && ! empty( $primary['title'] ) ) {
			$schema['name'] = $primary['title'];
		}

		if ( empty( $schema['description'] ) && ! empty( $primary['excerpt'] ) ) {
			$schema['description'] = mb_substr( $primary['excerpt'], 0, 200 );
		}

		if ( empty( $schema['url'] ) && ! empty( $primary['permalink'] ) ) {
			$schema['url'] = $primary['permalink'];
		}

		// Images.
		if ( empty( $schema['image'] ) ) {
			$images = [];

			if ( ! empty( $primary['featured_image']['url'] ) ) {
				$fi       = $primary['featured_image'];
				$images[] = array_filter( [
					'@type'  => 'ImageObject',
					'url'    => $fi['url'],
					'width'  => $fi['width'] ?? null,
					'height' => $fi['height'] ?? null,
				] );
			}

			if ( ! empty( $sc['gallery'] ) ) {
				foreach ( $sc['gallery'] as $img ) {
					$images[] = array_filter( [
						'@type'  => 'ImageObject',
						'url'    => $img['url'],
						'width'  => $img['width'] ?? null,
						'height' => $img['height'] ?? null,
					] );
				}
			}

			if ( count( $images ) === 1 ) {
				$schema['image'] = $images[0];
			} elseif ( ! empty( $images ) ) {
				$schema['image'] = $images;
			}
		}

		// SKU.
		if ( empty( $schema['sku'] ) && ! empty( $sc['sku'] ) ) {
			$schema['sku'] = $sc['sku'];
		}

		// Brand - check product-level first, then fall back to global settings.
		if ( empty( $schema['brand'] ) ) {
			$brand_name = '';

			// Try to get brand from SureCart product metadata (if available).
			if ( ! empty( $sc['brand'] ) ) {
				$brand_name = $sc['brand'];
			}

			// Fallback to global ecommerce settings.
			if ( empty( $brand_name ) ) {
				$ecommerce_settings = get_option( 'rtrs_schema_ecommerce_settings', [] );
				$brand_name = $ecommerce_settings['brand_name'] ?? '';
			}

			if ( ! empty( $brand_name ) ) {
				$schema['brand'] = [
					'@type' => 'Brand',
					'name'  => $brand_name,
				];
			}
		}

		// Weight.
		if ( empty( $schema['weight'] ) && ! empty( $sc['weight'] ) ) {
			$schema['weight'] = $sc['weight'];
		}

		// Offers.
		if ( empty( $schema['offers'] ) && ! empty( $sc['pricing'] ) ) {
			$pricing      = $sc['pricing'];
			$currency     = $pricing['currency'] ?? 'USD';
			$product_url  = $primary['permalink'] ?? '';
			$availability = $sc['availability'] ?? 'https://schema.org/InStock';

			// Default to 1 year from now.
			$price_valid_until = gmdate( 'Y-m-d', strtotime( '+1 year' ) );

			$seller = [ '@id' => $entity_id ];

			// Variable product with price range.
			if ( ! empty( $pricing['min_price'] ) && ! empty( $pricing['max_price'] )
				&& $pricing['min_price'] !== $pricing['max_price'] ) {

				$offer = [
					'@type'           => 'AggregateOffer',
					'lowPrice'        => $pricing['min_price'],
					'highPrice'       => $pricing['max_price'],
					'offerCount'      => ! empty( $sc['variation_count'] ) ? (int) $sc['variation_count'] : null,
					'price'           => $pricing['min_price'],
					'priceCurrency'   => $currency,
					'priceValidUntil' => $price_valid_until,
					'availability'    => $availability,
					'url'             => $product_url,
					'seller'          => $seller,
				];

				if ( null === $offer['offerCount'] ) {
					unset( $offer['offerCount'] );
				}

				$schema['offers'] = [ $offer ];
			} else {
				// Simple product.
				$current_price = $pricing['price'] ?? $pricing['min_price'] ?? 0;

				$offer = [
					'@type'           => 'Offer',
					'price'           => $current_price,
					'priceCurrency'   => $currency,
					'priceValidUntil' => $price_valid_until,
					'availability'    => $availability,
					'url'             => $product_url,
					'seller'          => $seller,
				];

				$price_specs = [];

				if ( $current_price ) {
					$price_specs[] = [
						'@type'                 => 'UnitPriceSpecification',
						'price'                 => $current_price,
						'priceCurrency'         => $currency,
						'valueAddedTaxIncluded' => false,
						'validThrough'          => $price_valid_until,
					];
				}

				// Add list price if on sale.
				if ( ! empty( $pricing['on_sale'] ) && ! empty( $pricing['regular_price'] )
					&& $pricing['regular_price'] != $current_price ) {
					$price_specs[] = [
						'@type'                 => 'UnitPriceSpecification',
						'price'                 => $pricing['regular_price'],
						'priceCurrency'         => $currency,
						'valueAddedTaxIncluded' => false,
						'validThrough'          => $price_valid_until,
						'priceType'             => 'https://schema.org/ListPrice',
					];
				}

				if ( ! empty( $price_specs ) ) {
					$offer['priceSpecification'] = $price_specs;
				}

				$schema['offers'] = [ $offer ];
			}
		}

		// Aggregate rating.
		if ( empty( $schema['aggregateRating'] ) && ! empty( $sc['reviews'] ) ) {
			$reviews = $sc['reviews'];

			if ( ! empty( $reviews['review_count'] ) && $reviews['review_count'] > 0 ) {
				$rating = [
					'@type'       => 'AggregateRating',
					'ratingValue' => (float) $reviews['average_rating'],
					'bestRating'  => 5,
					'worstRating' => 1,
					'reviewCount' => (int) $reviews['review_count'],
				];

				if ( ! empty( $reviews['rating_counts'] ) && is_array( $reviews['rating_counts'] ) ) {
					$rating['ratingCount'] = (int) array_sum( $reviews['rating_counts'] );
				} else {
					$rating['ratingCount'] = (int) $reviews['review_count'];
				}

				$schema['aggregateRating'] = $rating;
			}
		}

		return $schema;
	}
}
