<?php

namespace Rtrsp\Controllers\Admin;

use Rtrsp\Traits\SingletonTrait;

class AdminController {
	/**
	 * Initialize the class.
	 */
	use SingletonTrait;

	/**
	 * Initialize the class.
	 */
	public function init() {
		AdminSettings::getInstance();
		RtrsLicensing::init();
	}
}
