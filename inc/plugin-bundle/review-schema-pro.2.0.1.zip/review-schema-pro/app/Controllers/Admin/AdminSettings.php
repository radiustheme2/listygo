<?php


namespace Rtrsp\Controllers\Admin;

use Rtrsp\Traits\SingletonTrait;

class AdminSettings {

	/**
	 * Initialize the class.
	 */
	use SingletonTrait;

	/**
	 * Initialize the class.
	 */
	public function init() {
		add_filter( 'rtrs_register_settings_tabs', [ &$this, 'register_settings_tabs' ] );
	}
	/**
	 * Register tools settings tab.
	 *
	 * @param array $default Default settings tabs.
	 *
	 * @return array Modified settings tabs.
	 */
	public function register_settings_tabs( $default ) {
		$default['tools'] = [
			'label'    => esc_html__( 'Tools', 'review-schema-pro' ),
			'iconHtml' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" fill="currentColor" aria-hidden="true"> <path d="M541.4 162.6C549 155 561.7 156.9 565.5 166.9C572.3 184.6 576 203.9 576 224C576 312.4 504.4 384 416 384C398.5 384 381.6 381.2 365.8 376L178.9 562.9C150.8 591 105.2 591 77.1 562.9C49 534.8 49 489.2 77.1 461.1L264 274.2C258.8 258.4 256 241.6 256 224C256 135.6 327.6 64 416 64C436.1 64 455.4 67.7 473.1 74.5C483.1 78.3 484.9 91 477.4 98.6L388.7 187.3C385.7 190.3 384 194.4 384 198.6L384 240C384 248.8 391.2 256 400 256L441.4 256C445.6 256 449.7 254.3 452.7 251.3L541.4 162.6z"/></svg>',
		];
		return apply_filters( 'rtrsp_register_settings_tabs', $default );
	}
}
