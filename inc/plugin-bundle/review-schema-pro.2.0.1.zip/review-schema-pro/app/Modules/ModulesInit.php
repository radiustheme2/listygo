<?php

/**
 * Modules Initialization Handler
 *
 * Initializes core plugin modules such as Review and Schema.
 *
 * @package Rtrs\Modules
 */

namespace Rtrsp\Modules;

use Rtrs\Helpers\Functions;
use Rtrsp\Modules\Review\ReviewInit;
use Rtrsp\Modules\Schema\SchemaInit;
use Rtrsp\Traits\SingletonTrait;

/**
 * Class ModulesInit
 *
 * Loads and initializes all enabled plugin modules.
 * Uses the Singleton pattern to prevent multiple initializations.
 */
class ModulesInit {
	/**
	 * Singleton trait.
	 */
	use SingletonTrait;

	/**
	 * ModulesInit constructor.
	 *
	 * Triggers initialization of plugin modules.
	 * Constructor is private to enforce singleton usage.
	 *
	 * @return void
	 */
	private function __construct() {
		if ( Functions::review_enabled() ) {
			ReviewInit::getInstance();
		}
		if ( Functions::schema_enabled() ) {
			SchemaInit::getInstance();
		}
	}
}
