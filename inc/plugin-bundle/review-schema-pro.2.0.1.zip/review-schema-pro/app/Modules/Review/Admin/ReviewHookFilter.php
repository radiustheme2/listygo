<?php

namespace Rtrsp\Modules\Review\Admin;

use Rtrs\Helpers\Functions;
use Rtrsp\Traits\SingletonTrait;

class ReviewHookFilter {

	use SingletonTrait;

	/**
	 * Constructor.
	 *
	 * @return void
	 */
	private function __construct() {
		add_filter( 'rtrs_media_settings_options', [ &$this, 'rtrs_media_settings_options' ] );
		add_filter( 'rtrs_each_review_classes', [ $this, 'each_review_classes' ], 10, 3 );
		add_filter( 'rtrs_comments_query_args', [ $this, 'comments_query_args' ], 10, 2 );
		add_filter( 'rtrs_review_section_style_fields', [ $this, 'review_section_style_fields' ] );
		add_filter( 'rtrs_review_sc_css', [ $this, 'rtrs_sc_css' ], 10, 4 );
	}

	/**
	 * Add video upload settings to media settings options.
	 *
	 * @param array $default Default media settings options.
	 *
	 * @return array Modified media settings options.
	 */
	public function rtrs_media_settings_options( $default ) {

		$video_type = apply_filters(
			'rtrs_media_video_type',
			[
				'video/mp4' => esc_html__( 'mp4', 'review-schema-pro' ),
				'video/m4v' => esc_html__( 'm4v', 'review-schema-pro' ),
				'video/mov' => esc_html__( 'mov', 'review-schema-pro' ),
				'video/wmv' => esc_html__( 'wmv', 'review-schema-pro' ),
				'video/avi' => esc_html__( 'avi', 'review-schema-pro' ),
				'video/mpg' => esc_html__( 'mpg', 'review-schema-pro' ),
				'video/mov' => esc_html__( 'mov', 'review-schema-pro' ),
				'video/ogv' => esc_html__( 'ogv', 'review-schema-pro' ),
				'video/3gp' => esc_html__( '3gp', 'review-schema-pro' ),
				'video/3g2' => esc_html__( '3g2', 'review-schema-pro' ),
			]
		);

		$new = [
			'video_section'  => [
				'title' => esc_html__( 'Video Upload Settings', 'review-schema-pro' ),
				'type'  => 'title',
			],
			'video_max_size' => [
				'title'       => esc_html__( 'Video Max Size', 'review-schema-pro' ),
				'type'        => 'number',
				'default'     => 2048,
				'css'         => 'width: 70px',
				'description' => esc_html__( 'Change the value as KB, Like 1M = 1024KB', 'review-schema-pro' ),
			],
			'video_type'     => [
				'title'   => esc_html__( 'Supported Video Type', 'review-schema-pro' ),
				'type'    => 'multi_checkbox',
				'default' => [
					'video/mp4',
					'video/m4v',
					'video/mov',
					'video/wmv',
					'video/avi',
					'video/mpg',
					'video/mov',
					'video/ogv',
					'video/3gp',
					'video/3g2',
				],
				'options' => $video_type,
			],
		];

		$default = array_merge( $default, $new );

		return apply_filters( 'rtrsp_media_settings_options', $default );
	}


	/**
	 * Add custom classes to each review element.
	 *
	 * @param array  $classes Review element classes.
	 * @param array  $p_meta  Post meta data.
	 * @param object $comment Comment object.
	 *
	 * @return array Modified classes.
	 */
	public function each_review_classes( $classes, $p_meta, $comment ) {
		$classes[] = get_comment_meta( get_comment_ID(), 'rt_highlight', true ) == 1 ? 'rtrs-top-review' : '';
		$classes[] = get_comment_meta( get_comment_ID(), 'rt_sticky_review', true ) == 1 ? 'rtrs-sticky-review' : '';

		$purchased_badge = ( isset( $p_meta['purchased_badge'] ) && $p_meta['purchased_badge'][0] == '1' );
		if ( $purchased_badge ) {
			$classes[] = Functions::purchased_user( $comment ) ? 'verified-user' : '';
		}

		$layout = isset( $p_meta['review_layout'][0] ) ? $p_meta['review_layout'][0] : '';
		if ( 'three' === $layout ) {
			$classes[] = 'rtrs-layout-three';
		} elseif ( 'four' === $layout ) {
			$classes[] = 'rtrs-layout-four';
		}

		return $classes;
	}

	/**
	 * Modify comments query args for sticky reviews.
	 *
	 * @param array $args   Comments query arguments.
	 * @param array $p_meta Post meta data.
	 *
	 * @return array Modified query arguments.
	 */
	public function comments_query_args( $args, $p_meta ) {
		$sticky_review = ( isset( $p_meta['sticky_review'] ) && $p_meta['sticky_review'][0] == '1' );
		if ( $sticky_review ) {
			$args['meta_query'] = [
				'relation' => 'OR',
				[
					'key'     => 'rt_sticky_review',
					'value'   => '1',
					'compare' => '!=',
				],
				[
					'key'     => 'rt_sticky_review',
					'compare' => 'NOT EXISTS',
					'value'   => '',
				],
			];
		}
		return $args;
	}
	/**
	 * Add sticky review style fields to review section.
	 *
	 * @param array $styles Style fields.
	 *
	 * @return array Modified style fields.
	 */
	public function review_section_style_fields( $styles ) {
		// Sticky review styles.
		$styles[] = [
			'type'    => 'heading',
			'name'    => 'sticky_review_heading',
			'label'   => esc_html__( 'Sticky Review Style', 'review-schema-pro' ),
		];
		$styles[] = [
			'type'   => 'color',
			'name'   => 'sticky_background_color',
			'id'     => 'rtrs-sticky-background-color',
			'is_pro' => true,
			'label'  => esc_html__( 'Background Color', 'review-schema-pro' ),
		];
		$styles[] = [
			'type'   => 'color',
			'name'   => 'sticky_boxshadow_color',
			'id'     => 'rtrs-sticky-boxshadow-color',
			'is_pro' => true,
			'label'  => esc_html__( 'Box Shadow Color', 'review-schema-pro' ),
		];
		$styles[] = [
			'type'   => 'color',
			'name'   => 'sticky_border_color',
			'id'     => 'rtrs-sticky-border-color',
			'is_pro' => true,
			'label'  => esc_html__( 'Border Color', 'review-schema-pro' ),
		];
		$styles[] = [
			'type'        => 'text',
			'name'        => 'sticky_border_radius',
			'id'          => 'rtrs-sticky-border-radius',
			'is_pro'      => true,
			'class'       => 'small-width',
			'placeholder' => '8px',
			'label'       => esc_html__( 'Border Radius', 'review-schema-pro' ),
		];
		$styles[] = [
			'type'        => 'text',
			'name'        => 'sticky_padding',
			'id'          => 'rtrs-sticky-padding',
			'is_pro'      => true,
			'class'       => 'small-width',
			'placeholder' => '20px',
			'label'       => esc_html__( 'Padding', 'review-schema-pro' ),
		];

		// Highlight review styles.
		$styles[] = [
			'type'    => 'heading',
			'name'    => 'highlight_review_heading',
			'label'   => esc_html__( 'Highlight Review Style', 'review-schema-pro' ),
		];
		$styles[] = [
			'type'   => 'color',
			'name'   => 'highlight_background_color',
			'id'     => 'rtrs-highlight-background-color',
			'is_pro' => true,
			'label'  => esc_html__( 'Background Color', 'review-schema-pro' ),
		];
		$styles[] = [
			'type'   => 'color',
			'name'   => 'highlight_boxshadow_color',
			'id'     => 'rtrs-highlight-boxshadow-color',
			'is_pro' => true,
			'label'  => esc_html__( 'Box Shadow Color', 'review-schema-pro' ),
		];
		$styles[] = [
			'type'   => 'color',
			'name'   => 'highlight_border_color',
			'id'     => 'rtrs-highlight-border-color',
			'is_pro' => true,
			'label'  => esc_html__( 'Border Color', 'review-schema-pro' ),
		];
		$styles[] = [
			'type'        => 'text',
			'name'        => 'highlight_border_radius',
			'id'          => 'rtrs-highlight-border-radius',
			'is_pro'      => true,
			'class'       => 'small-width',
			'placeholder' => '8px',
			'label'       => esc_html__( 'Border Radius', 'review-schema-pro' ),
		];
		$styles[] = [
			'type'        => 'text',
			'name'        => 'highlight_padding',
			'id'          => 'rtrs-highlight-padding',
			'is_pro'      => true,
			'class'       => 'small-width',
			'placeholder' => '20px',
			'label'       => esc_html__( 'Padding', 'review-schema-pro' ),
		];

		return $styles;
	}
	/**
	 * Add sticky review CSS styles.
	 *
	 * @param string $css      CSS string.
	 * @param array  $metaData Shortcode meta data.
	 * @param int    $sc_id    Shortcode ID.
	 * @param object $filter   Filter object.
	 *
	 * @return string Modified CSS string.
	 */
	public function rtrs_sc_css( $css, $metaData, $sc_id, $filter ) {
		// Sticky review styles.
		$css .= $this->build_review_item_css( $metaData, $sc_id, $filter, 'sticky', 'rtrs-sticky-review' );

		// Highlight review styles.
		$css .= $this->build_review_item_css( $metaData, $sc_id, $filter, 'highlight', 'rtrs-top-review' );

		return $css;
	}

	/**
	 * Build CSS for a review item type (sticky or highlight).
	 *
	 * @param array  $metaData Shortcode meta data.
	 * @param int    $sc_id    Shortcode ID.
	 * @param object $filter   Filter object.
	 * @param string $prefix   Meta key prefix (sticky or highlight).
	 * @param string $class    CSS class name.
	 *
	 * @return string CSS string.
	 */
	private function build_review_item_css( $metaData, $sc_id, $filter, $prefix, $class ) {
		$bg      = ! empty( $metaData[ $prefix . '_background_color' ][0] ) ? $filter->sanitize_field( 'color', $metaData[ $prefix . '_background_color' ][0] ) : null;
		$shadow  = ! empty( $metaData[ $prefix . '_boxshadow_color' ][0] ) ? $filter->sanitize_field( 'color', $metaData[ $prefix . '_boxshadow_color' ][0] ) : null;
		$border  = ! empty( $metaData[ $prefix . '_border_color' ][0] ) ? $filter->sanitize_field( 'color', $metaData[ $prefix . '_border_color' ][0] ) : null;
		$radius  = ! empty( $metaData[ $prefix . '_border_radius' ][0] ) ? sanitize_text_field( $metaData[ $prefix . '_border_radius' ][0] ) : null;
		$padding = ! empty( $metaData[ $prefix . '_padding' ][0] ) ? sanitize_text_field( $metaData[ $prefix . '_padding' ][0] ) : null;

		if ( ! $bg && ! $shadow && ! $border && ! $radius && ! $padding ) {
			return '';
		}

		$css = ".rtrs-review-sc-{$sc_id} .rtrs-each-review.{$class}{";
		if ( $bg ) {
			$css .= 'background-color:' . $bg . ';';
		}
		if ( $shadow ) {
			$css .= 'box-shadow:0 2px 8px 0 ' . $shadow . ';';
		}
		if ( $border ) {
			$css .= 'border:1px solid ' . $border . ';';
		}
		if ( $radius ) {
			$css .= 'border-radius:' . $radius . ';';
		}
		if ( $padding ) {
			$css .= 'padding:' . $padding . ';';
		}
		$css .= '}';

		return $css;
	}
}
