<?php
/**
 * Review Initialization Handler
 *
 * Bootstraps review-related functionality, including shortcode registration.
 *
 * @package Rtrs\Review
 */

namespace Rtrsp\Modules\Review;

use Rtrsp\Modules\Review\Admin\ReviewHookFilter;
use Rtrsp\Modules\Review\FrontEnd\FrontEndReviewActionHook;
use Rtrsp\Traits\SingletonTrait;


/**
 * Class ReviewInit
 *
 * Handles initialization tasks for the Review module.
 * Uses the Singleton pattern to ensure a single instance.
 */
class ReviewInit {

	use SingletonTrait;

	/**
	 * ReviewInit constructor.
	 *
	 * Registers required actions and initializes review shortcodes.
	 * Constructor is private to enforce singleton usage.
	 *
	 * @return void
	 */
	private function __construct() {
		ReviewHookFilter::getInstance();
		FrontEndReviewActionHook::getInstance();
	}
}
