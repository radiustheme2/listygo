<?php
namespace Rtrsp\Modules\Schema\Admin;

use Rtrs\Helpers\Functions;
use Rtrs\Modules\Review\Helpers\ReviewFns;
use Rtrs\Modules\Schema\Models\Schema;
use Rtrsp\Traits\SingletonTrait;

/**
 * Handle schema JSON preview via AJAX.
 */
class SchemaAjax {
	/**
	 * Initialize the class.
	 */
	use SingletonTrait;

	/**
	 * Register AJAX actions.
	 */
	private function __construct() {
		add_action( 'wp_ajax_rtrs_get_schema_preview_json', [ $this, 'get_schema_for_preview' ] );
		add_action( 'wp_ajax_rtrs_auto_fill_schema', [ $this, 'auto_fill_schema' ] );
	}

	/**
	 * Generate schema JSON and return preview markup.
	 *
	 * @return void
	 */
	public function get_schema_for_preview() {
		// Verify nonce.
		if ( ! wp_verify_nonce( Functions::get_nonce(), rtrs()->getNonceId() ) ) {
			wp_send_json_error( [ 'message' => __( 'Invalid nonce.',  'review-schema-pro' ) ] );
		}

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied.', 'review-schema-pro' ) ] );
		}

		$post_id = absint( $_POST['post_id'] ?? 0 );
		if ( ! $post_id ) {
			wp_send_json_error( [ 'message' => __( 'Invalid post ID.',  'review-schema-pro' ) ] );
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( [ 'message' => __( 'You cannot preview schema for this post.', 'review-schema-pro' ) ] );
		}

		$post_obj = get_post( $post_id );
		if ( ! $post_obj ) {
			wp_send_json_error( [ 'message' => __( 'Post not found.',  'review-schema-pro' ) ] );
		}
		/**
		 * Setup global post context.
		 */
		global $post;
		$post = $post_obj; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited .
		setup_postdata( $post );

		$schema       = new Schema( $post_id );
		$rich_snippet = $schema->header_schema_data();
		$rich_snippet = $schema->remove_script_wrappers( $rich_snippet );
		/**
		 * Reset global post data.
		 */
		wp_reset_postdata();
		if ( empty( $rich_snippet ) ) {
			wp_send_json_error( [ 'message' => __( 'No schema data generated.',  'review-schema-pro' ) ] );
		}
		ob_start();
		?>
		<form
				id="rtrs-snipet-form"
				method="post"
				target="_blank"
				action="https://search.google.com/test/rich-results"
		>
			<textarea name="code_snippet"><?php echo esc_textarea( $rich_snippet ); ?></textarea>
		</form>
		<?php
		$form_html = ob_get_clean();
		wp_send_json_success(
			[
				'html'     => esc_html( $rich_snippet ),
				'rawJson'  => $rich_snippet,
				'formHtml' => $form_html,
			]
		);
	}

	/**
	 * auto fill schema.
	 *
	 * @since 1.0.0
	 *
	 * @return mixed
	 */
	public function auto_fill_schema() {
		$html     = null;
		$metaData = [];
		if ( ! wp_verify_nonce( Functions::get_nonce(), rtrs()->getNonceId() ) ) {
			wp_send_json_error( [ 'message' => __( 'Invalid nonce.', 'review-schema-pro' ) ], 403 );
		}

		$post_id    = isset( $_REQUEST['post_id'] ) ? absint( $_REQUEST['post_id'] ) : null;
		$schema_cat = isset( $_REQUEST['snippet_cat'] ) ? sanitize_text_field( $_REQUEST['snippet_cat'] ) : null;
		// Capability check - user must be able to edit posts
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( [ 'message' => __( 'You do not have permission to perform this action.',  'review-schema-pro' ) ], 403 );
		}
		// Verify the post exists
		$post = get_post( $post_id );
		if ( ! $post ) {
			wp_send_json_error( [ 'message' => __( 'Post not found.',  'review-schema-pro' ) ], 404 );
		}
		// Check if user can edit this specific post (handles ownership and capabilities)
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( [ 'message' => __( 'You do not have permission to access this post.',  'review-schema-pro' ) ], 403 );
		}
		$rich_snippet     = false;
		$rich_snippet_cat = null;

		if ( $schema_cat == 'post' ) {
			$p_meta           = Functions::getMetaByPostType( 'post' );
			$rich_snippet     = ( isset( $p_meta['rich_snippet'] ) && $p_meta['rich_snippet'][0] == '1' );
			$rich_snippet_cat = isset( $p_meta['rich_snippet_cat'] ) ? $p_meta['rich_snippet_cat'][0] : null;

			if ( $rich_snippet && $rich_snippet_cat ) {
				$schema_cat = $rich_snippet_cat;
			}
			// else {
			// $schema_cat = 'article';
			// }
		}
		if ( $schema_cat ) {
			$helper = new Functions();
			$post   = get_post( $post_id );

			switch ( $schema_cat ) {
				case 'article':
				case 'news_article':
				case 'blog_posting':
					$html = $this->get_article_auto_fill_data( $post, $post_id, $helper, $metaData );
					break;

				case 'product':
					$html = $this->get_product_auto_fill_data( $post, $post_id, $helper );
					break;

				default:
					$html = $this->get_default_auto_fill_data( $post, $post_id, $helper, $metaData );
					break;
			}
		}

		if ( $rich_snippet && $rich_snippet_cat ) {
			$html['category'] = $rich_snippet_cat;
		} else {
			if ( $schema_cat == 'article' ) {
				$html['category'] = 'article';
			}

			$rtrs_schema_settings = get_option( 'rtrs_schema_settings' );
			$post_types           = isset( $rtrs_schema_settings['post_type'] ) && is_array( $rtrs_schema_settings['post_type'] ) ? $rtrs_schema_settings['post_type'] : Functions::default_setting_schema();
			foreach ( $post_types as $key => $value ) {
				if ( isset( $value['post_type'] ) && $value['post_type'] == $schema_cat ) {
					if ( isset( $value['schema_type'] ) && $value['schema_type'] ) {
						$html['category'] = $value['schema_type'];
						break;
					}
				}
			}
		}
		wp_send_json_success( $html );
	}

	/**
	 * Get article auto fill data.
	 *
	 * @param \WP_Post  $post     The post object.
	 * @param int       $post_id  The post ID.
	 * @param Functions $helper   The helper object.
	 * @param array     $metaData The metadata.
	 *
	 * @return array Article auto fill data.
	 */
	private function get_article_auto_fill_data( $post, $post_id, $helper, $metaData ) {
		$article = [];
		if ( ! empty( $post->post_title ) ) {
			$article['headline'] = $helper->sanitizeOutPut( $post->post_title );
		}
		if ( ! empty( $post_url = get_the_permalink( $post_id ) ) ) {
			$article['mainEntityOfPage'] = $helper->sanitizeOutPut( $post_url );
		}
		if ( ! empty( $author = get_the_author_meta( 'display_name', $post->post_author ) ) ) {
			$article['author'] = $helper->sanitizeOutPut( $author );

			if ( ! empty( $url = get_the_author_meta( 'url', $post->post_author ) ) ) {
				$article['author_url'] = $helper->sanitizeOutPut( $url, 'url' );
			}
		}
		if ( ! empty( $image_id = get_post_thumbnail_id( $post->ID ) ) ) {
			$img              = $helper->imageInfo( absint( $image_id ) );
			$article['image'] = [
				'id'  => $img['id'],
				'url' => $helper->sanitizeOutPut( $img['url'], 'url' ),
			];
		}
		if ( ! empty( $post->post_date ) ) {
			$article['datePublished'] = $helper->sanitizeOutPut( $post->post_date );
		}
		if ( ! empty( $post->post_modified ) ) {
			$article['dateModified'] = $helper->sanitizeOutPut( $post->post_modified );
		}
		if ( ! empty( $post->post_excerpt ) ) {
			$article['description'] = sanitize_text_field(
				$helper->sanitizeOutPut(
					$post->post_excerpt,
					'textarea'
				)
			);
		}

		if ( ! empty( $post->post_content ) ) {
			$article['articleBody'] = Functions::filter_content( $post->post_content, 500 );
		}

		return $article;
	}

	/**
	 * Get product auto fill data.
	 *
	 * @param \WP_Post  $post    The post object.
	 * @param int       $post_id The post ID.
	 * @param Functions $helper  The helper object.
	 *
	 * @return array Product auto fill data.
	 */
	private function get_product_auto_fill_data( $post, $post_id, $helper ) {
		$markup = [];

		// if edd
		$post_type = get_post_type( $post_id );
		if ( $post_type == 'download' && function_exists( 'EDD' ) ) {
			$post      = get_post( $post_id );
			$permalink = get_the_permalink( $post->ID );
			$markup    = [
				'@context'    => 'https://schema.org',
				'@type'       => 'Product',
				'@id'         => $permalink . '#comments', // Append '#comments' to differentiate between this @id and the @id generated for the Breadcrumblist.
				'name'        => wp_kses_post( $post->post_title ),
				'url'         => $permalink,
				'description' => wp_strip_all_tags( do_shortcode( $post->post_excerpt ? $post->post_excerpt : $post->post_content ) ),
			];

			$image = get_the_post_thumbnail_url( $post->ID );
			if ( $image ) {
				$markup['image'] = [
					'id'  => get_post_thumbnail_id( $post->ID ),
					'url' => $image,
				];
			}

			$markup['sku'] = $post->ID;
			$brand_name    = rtrs()->get_options( 'rtrs_woocommerce_settings', 'brand_name' );
			if ( $brand_name ) {
				$markup['brand'] = esc_html( $brand_name );
			}

			$identifier_type = rtrs()->get_options( 'rtrs_woocommerce_settings', 'identifier_type' );
			$identifier      = rtrs()->get_options( 'rtrs_woocommerce_settings', 'identifier' );
			if ( $identifier_type && $identifier ) {
				$markup['identifier_type'] = esc_html( $identifier_type );
				$markup['identifier']      = esc_html( $identifier );
			}

			$edd_currency      = function_exists( 'edd_get_currency' ) ? edd_get_currency() : 'USD';
			$price_valid_until = gmdate( 'Y-12-31', time() + YEAR_IN_SECONDS );

			if ( edd_has_variable_prices( $post->ID ) ) {
				$variable_prices = edd_get_variable_prices( $post->ID );

				if ( ! empty( $variable_prices ) ) {
					$prices    = array_map( 'floatval', wp_list_pluck( $variable_prices, 'amount' ) );
					$lowPrice  = min( $prices );
					$highPrice = max( $prices );

					$markup['offers'] = [
						'@type'           => 'AggregateOffer',
						'lowPrice'        => number_format( $lowPrice, 2, '.', '' ),
						'highPrice'       => number_format( $highPrice, 2, '.', '' ),
						'priceCurrency'   => $edd_currency,
						'offerCount'      => count( $variable_prices ),
						'availability'    => 'https://schema.org/InStock',
					];

					$markup['offers']['offers'] = [];
					foreach ( $variable_prices as $variable_price ) {
						$markup['offers']['offers'][] = [
							'@type'           => 'Offer',
							'name'            => esc_html( $variable_price['name'] ?? '' ),
							'price'           => number_format( (float) $variable_price['amount'], 2, '.', '' ),
							'priceCurrency'   => $edd_currency,
							'priceValidUntil' => $price_valid_until,
							'availability'    => 'https://schema.org/InStock',
							'url'             => $permalink,
						];
					}
				}
			} else {
				$price            = edd_get_download_price( $post->ID, false );
				$markup['offers'] = [
					'@type'           => 'Offer',
					'url'             => $permalink,
					'price'           => number_format( (float) $price, 2, '.', '' ),
					'priceValidUntil' => $price_valid_until,
					'priceCurrency'   => $edd_currency,
					'itemCondition'   => 'https://schema.org/NewCondition',
					'availability'    => 'https://schema.org/InStock',
				];
			}

			$download_rating = true;
			if ( $download_rating ) {
				$total_rating = ReviewFns::getTotalRatings( $post->ID );
				if ( $total_rating ) {
					$markup['aggregateRating'] = [
						'@type'       => 'AggregateRating',
						'ratingValue' => (float) ReviewFns::getAvgRatings( $post->ID, true ),
						'reviewCount' => $total_rating,
					];
				}

				// Markup 5 most recent rating/review.
				$comments = get_comments(
					[
						'number'      => 5,
						'post_id'     => $post->ID,
						'status'      => 'approve',
						'post_status' => 'publish',
						'post_type'   => 'download',
						'parent'      => 0,
						'meta_query'  => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
								[
										'key'  => 'rating',
										'type' => 'NUMERIC',
										'compare' => '>',
										'value' => 0,
								],
						],
					]
				);

				if ( $comments ) {
					$markup['review'] = [];
					foreach ( $comments as $comment ) {
						$markup['review'][] = [
							'@type'         => 'Review',
							'reviewRating'  => [
								'@type'       => 'Rating',
								'bestRating'  => '5',
								'ratingValue' => (float) get_comment_meta( $comment->comment_ID, 'rating', true ),
								'worstRating' => '1',
							],
							'author'        => [
								'@type' => 'Person',
								'name'  => get_comment_author( $comment ),
							],
							'reviewBody'    => get_comment_text( $comment ),
							'datePublished' => get_comment_date( 'c', $comment ),
						];
					}
				}
			}
		}

		// if wc
		if ( $post_type == 'product' ) {
			$the_query = new \WP_Query(
				[
					'post_type'      => 'product',
					'posts_per_page' => 1,
					'p'              => $post_id,
				]
			);
			while ( $the_query->have_posts() ) {
				$the_query->the_post();
				global $product;
				if ( is_a( $product, 'WC_Product' ) ) {
					$shop_name = get_bloginfo( 'name' );
					$shop_url  = home_url();
					$currency  = get_woocommerce_currency();
					$permalink = get_permalink( $product->get_id() );

					$markup = [
						'@id'         => $permalink . '#product',
						'name'        => wp_kses_post( $product->get_name() ),
						'url'         => $permalink,
						'description' => sanitize_text_field( $product->get_short_description() ? $product->get_short_description() : $product->get_description() ),
					];

					if ( ! empty( $image_id = $product->get_image_id() ) ) {
						$img             = $helper->imageInfo( absint( $image_id ) );
						$markup['image'] = [
							'id'  => $img['id'],
							'url' => $helper->sanitizeOutPut( $img['url'], 'url' ),
						];
					}

					// Declare SKU or fallback to ID.
					if ( $product->get_sku() ) {
						$markup['sku'] = $product->get_sku();
					} else {
						$markup['sku'] = $product->get_id();
					}

					$brand_name = rtrs()->get_options( 'rtrs_woocommerce_settings', 'brand_name' );
					if ( $brand_name ) {
						$markup['brand'] = esc_html( $brand_name );
					}

					$identifier_type = rtrs()->get_options( 'rtrs_woocommerce_settings', 'identifier_type' );
					$identifier      = rtrs()->get_options( 'rtrs_woocommerce_settings', 'identifier' );
					if ( $identifier_type && $identifier ) {
						$markup['identifier_type'] = esc_html( $identifier_type );
						$markup['identifier']      = esc_html( $identifier );
					}

					if ( '' !== $product->get_price() ) {
						// Assume prices will be valid until the end of next year, unless on sale and there is an end date.
						$price_valid_until = gmdate( 'Y-12-31', time() + YEAR_IN_SECONDS );

						if ( $product->is_type( 'variable' ) ) {
							$lowest  = $product->get_variation_price( 'min', false );
							$highest = $product->get_variation_price( 'max', false );

							if ( $lowest === $highest ) {
								$markup_offer = [
									'@type' => 'Offer',
									'price' => wc_format_decimal( $lowest, wc_get_price_decimals() ),
									'priceValidUntil' => $price_valid_until,
									'priceSpecification' => [
										'price'                 => wc_format_decimal( $lowest, wc_get_price_decimals() ),
										'priceCurrency'         => $currency,
										'valueAddedTaxIncluded' => wc_prices_include_tax() ? 'true' : 'false',
									],
								];
							} else {
								$markup_offer = [
									'@type'    => 'AggregateOffer',
									'lowPrice' => wc_format_decimal( $lowest, wc_get_price_decimals() ),
									'highPrice' => wc_format_decimal( $highest, wc_get_price_decimals() ),
									'offerCount' => count( $product->get_children() ),
								];
							}
						} else {
							if ( $product->is_on_sale() && $product->get_date_on_sale_to() ) {
								$price_valid_until = gmdate( 'Y-m-d', $product->get_date_on_sale_to()->getTimestamp() );
							}
							$markup_offer = [
								'@type' => 'Offer',
								'price' => wc_format_decimal( $product->get_price(), wc_get_price_decimals() ),
								'priceValidUntil' => $price_valid_until,
								'priceSpecification' => [
									'price' => wc_format_decimal( $product->get_price(), wc_get_price_decimals() ),
									'priceCurrency' => $currency,
									'valueAddedTaxIncluded' => wc_prices_include_tax() ? 'true' : 'false',
								],
							];
						}

						$markup_offer += [
							'priceCurrency' => $currency,
							'availability'  => 'https://schema.org/' . ( $product->is_in_stock() ? 'InStock' : 'OutOfStock' ),
							'url'           => $permalink,
							'seller'        => [
								'@type' => 'Organization',
								'name'  => $shop_name,
								'url'   => $shop_url,
							],
						];

						$markup['offers'] = [ apply_filters( 'woocommerce_structured_data_product_offer', $markup_offer, $product ) ];
					}

					if ( $product->get_rating_count() && wc_review_ratings_enabled() ) {
						$markup['aggregateRating'] = [
							'@type'       => 'AggregateRating',
							'ratingValue' => (float) $product->get_average_rating(),
							'reviewCount' => $product->get_review_count(),
						];

						// Markup 5 most recent rating/review.
						$comments = get_comments(
							[
								'number'      => 5,
								'post_id'     => $product->get_id(),
								'status'      => 'approve',
								'post_status' => 'publish',
								'post_type'   => 'product',
								'parent'      => 0,
								'meta_query'  => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
										[
												'key'  => 'rating',
												'type' => 'NUMERIC',
												'compare' => '>',
												'value' => 0,
										],
								],
							]
						);

						if ( $comments ) {
							$markup['review'] = [];
							foreach ( $comments as $comment ) {
								$markup['review'][] = [
									'@type'  => 'Review',
									'reviewRating' => [
										'@type'       => 'Rating',
										'bestRating'  => '5',
										'ratingValue' => (float) get_comment_meta( $comment->comment_ID, 'rating', true ),
										'worstRating' => '1',
									],
									'author' => [
										'@type' => 'Person',
										'name' => get_comment_author( $comment ),
									],
									'reviewBody' => get_comment_text( $comment ),
									'datePublished' => get_comment_date( 'c', $comment ),
								];
							}
						}
					}
				}
			}
			wp_reset_postdata();
		}

		return $markup;
	}

	/**
	 * Get default auto fill data.
	 *
	 * @param \WP_Post  $post     The post object.
	 * @param int       $post_id  The post ID.
	 * @param Functions $helper   The helper object.
	 * @param array     $metaData The metadata.
	 *
	 * @return array Default auto fill data.
	 */
	private function get_default_auto_fill_data( $post, $post_id, $helper, $metaData ) {
		$article = [];
		if ( ! empty( $post->post_title ) ) {
			$article['headline'] = $helper->sanitizeOutPut( $post->post_title );
		}
		if ( ! empty( $post_url = get_the_permalink( $post_id ) ) ) {
			$article['mainEntityOfPage'] = $helper->sanitizeOutPut( $post_url );
		}
		if ( ! empty( $author = get_the_author_meta( 'display_name', $post->post_author ) ) ) {
			$article['author'] = $helper->sanitizeOutPut( $author );

			if ( ! empty( $url = get_the_author_meta( 'url', $post->post_author ) ) ) {
				$article['author_url'] = $helper->sanitizeOutPut( $url, 'url' );
			}
		}
		if ( ! empty( $image_id = get_post_thumbnail_id( $post->ID ) ) ) {
			$img              = $helper->imageInfo( absint( $image_id ) );
			$article['image'] = [
				'id'  => $img['id'],
				'url' => $helper->sanitizeOutPut( $img['url'], 'url' ),
			];
		}
		if ( ! empty( $post->post_date ) ) {
			$article['datePublished'] = $helper->sanitizeOutPut( $post->post_date );
		}
		if ( ! empty( $post->post_modified ) ) {
			$article['dateModified'] = $helper->sanitizeOutPut( $post->post_modified );
		}
		if ( ! empty( $post->post_excerpt ) ) {
			$article['description'] = sanitize_text_field(
				$helper->sanitizeOutPut(
					$post->post_excerpt,
					'textarea'
				)
			);
		}

		if ( ! empty( $post->post_content ) ) {
			$article['articleBody'] = Functions::filter_content( $post->post_content, 500 );
		}

		return $article;
	}
}
