/**
 * Pro FAQ Suggestion — Classic Editor Extension.
 *
 * Hooks into the free plugin's classic editor panel to suggest FAQ schema
 * generation when no existing FAQ meta exists and FAQPage is not selected.
 *
 * Uses wp.hooks filters/actions registered in the free plugin's classic-editor-panel.js:
 * - rtrs_ai_classic_should_show_faq_suggestion → decides if suggestion panel shows
 * - rtrs_ai_classic_render_faq_suggestion      → renders the suggestion panel into the slot
 *
 * @package Review_Schema_Pro
 * @since   1.2.0
 */
( function() {
	'use strict';

	if ( typeof wp === 'undefined' || typeof wp.hooks === 'undefined' ) {
		return;
	}

	var hooks = wp.hooks;
	var i18n  = ( window.aiseProFaqData || {} ).i18n || {};

	/** CSS custom property with fallback. */
	var PRIMARY_COLOR = 'var(--rtrs-primary-color, #5D3DFD)';

	/**
	 * Filter: should the FAQ suggestion panel be shown?
	 *
	 * Returns true when there is no existing FAQ meta data
	 * and FAQPage is not among the user-selected schema types.
	 */
	hooks.addFilter(
		'rtrs_ai_classic_should_show_faq_suggestion',
		'rtrs-pro/classic-faq-suggestion',
		function( result, context ) {
			if ( context.hasFaqData ) {
				return false;
			}

			var types = context.forceTypes.filter( function( t ) {
				return t !== 'auto_detect';
			} );

			if ( types.indexOf( 'FAQPage' ) !== -1 ) {
				return false;
			}

			return true;
		}
	);

	/**
	 * Action: render the FAQ suggestion panel into the provided slot element.
	 *
	 * @param {HTMLElement} slot  The container element to render into.
	 * @param {Object}      props Contains proceedGenerate callback and defaultCount.
	 */
	hooks.addAction(
		'rtrs_ai_classic_render_faq_suggestion',
		'rtrs-pro/classic-faq-suggestion',
		function( slot, props ) {
			var count = props.defaultCount || 5;

			/** Escape HTML for safe insertion. */
			function esc( str ) {
				if ( str == null ) { return ''; }
				return String( str )
					.replace( /&/g, '&amp;' )
					.replace( /</g, '&lt;' )
					.replace( />/g, '&gt;' )
					.replace( /"/g, '&quot;' )
					.replace( /'/g, '&#039;' );
			}

			var html = '';
			html += '<div class="aise-notice" style="border-left-color:#7c3aed;background:#f5f0ff;padding:12px">';
			html += '<p style="margin:0 0 8px;font-weight:500">' + esc( i18n.faqSuggestionHint ) + '</p>';
			html += '<p style="margin:0 0 10px;font-size:12px">' + esc( i18n.faqSuggestionQuestion ) + '</p>';

			/* FAQ count input */
			html += '<div style="margin-bottom:10px">';
			html += '<label style="display:block;font-size:12px;margin-bottom:4px;font-weight:500">' + esc( i18n.faqCountLabel ) + '</label>';
			html += '<input type="number" id="aise-classic-faq-count" min="1" max="20" value="' + count + '" ';
			html += 'style="width:60px;padding:4px 8px;border-color:#949494;border-width:1px;border-style:solid;border-radius:4px">';
			html += '</div>';

			/* Action buttons */
			html += '<div style="display:flex;gap:8px">';
			html += '<button type="button" id="aise-classic-faq-generate" ';
			html += 'style="display:inline-flex;align-items:center;padding:6px 12px;font-size:13px;font-weight:600;line-height:1.5;';
			html += 'color:' + PRIMARY_COLOR + ';background:transparent;border:1px solid ' + PRIMARY_COLOR + ';border-radius:4px;cursor:pointer">';
			html += esc( i18n.generateWithFaqs ) + '</button>';
			html += '<button type="button" id="aise-classic-faq-skip" ';
			html += 'style="display:inline-flex;align-items:center;padding:6px 12px;font-size:13px;font-weight:500;line-height:1.5;';
			html += 'color:#757575;background:transparent;border:1px solid #d0d0d0;border-radius:4px;cursor:pointer">';
			html += esc( i18n.skip ) + '</button>';
			html += '</div></div>';

			slot.innerHTML = html;

			/* Attach events */
			var input = document.getElementById( 'aise-classic-faq-count' );
			if ( input ) {
				input.addEventListener( 'focus', function() {
					this.style.borderColor = PRIMARY_COLOR;
					this.style.boxShadow = 'none';
					this.style.outline = 'none';
				} );
				input.addEventListener( 'blur', function() {
					this.style.borderColor = '#949494';
					this.style.boxShadow = '';
					this.style.outline = '';
				} );
				input.addEventListener( 'change', function() {
					count = parseInt( this.value, 10 ) || 1;
				} );
			}

			var generateBtn = document.getElementById( 'aise-classic-faq-generate' );
			if ( generateBtn ) {
				generateBtn.addEventListener( 'click', function() {
					var finalCount = input ? ( parseInt( input.value, 10 ) || 1 ) : count;
					props.proceedGenerate( true, { faqCount: finalCount } );
				} );
			}

			var skipBtn = document.getElementById( 'aise-classic-faq-skip' );
			if ( skipBtn ) {
				skipBtn.addEventListener( 'click', function() {
					props.proceedGenerate( false );
				} );
			}
		}
	);

} )();
