<?php
/**
 * @wordpress-plugin
 * Plugin Name:       Schema Engine AI Pro
 * Plugin URI:        https://www.radiustheme.com/downloads/wordpress-review-structure-data-schema-plugin/?utm_source=WordPress&utm_medium=reviewschema&utm_campaign=pro_click
 * Description:       This is a pro version of SchemaEngine AI Plugin
 * Version:           2.0.1
 * Author:            RadiusTheme
 * Author URI:        https://radiustheme.com
 * Text Domain:       review-schema-pro
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define PLUGIN_FILE.
if ( ! defined( 'RTRSP_PLUGIN_FILE' ) ) {
	define( 'RTRSP_PLUGIN_FILE', __FILE__ );
}

// Define VERSION.
if ( ! defined( 'RTRSP_VERSION' ) ) {
	define( 'RTRSP_VERSION', '2.0.1' );
}

define( 'RTRSP_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Base plugin slug.
 */
define( 'RTRSP_BASE_PLUGIN', 'review-schema/review-schema.php' );

/**
 * Check if the base SchemaEngine AI plugin is active.
 *
 * @return bool
 */
function rtrsp_is_base_plugin_active() {
	$active_plugins = apply_filters( 'active_plugins', get_option( 'active_plugins', [] ) );

	if ( in_array( RTRSP_BASE_PLUGIN, $active_plugins, true ) ) {
		return true;
	}

	// Multisite: check network-activated plugins.
	if ( is_multisite() ) {
		$network_plugins = get_site_option( 'active_sitewide_plugins', [] );
		if ( isset( $network_plugins[ RTRSP_BASE_PLUGIN ] ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Check if the base plugin file exists (installed but maybe not active).
 *
 * @return bool
 */
function rtrsp_is_base_plugin_installed() {
	$plugin_file = WP_PLUGIN_DIR . '/' . RTRSP_BASE_PLUGIN;
	return file_exists( $plugin_file );
}

/**
 * On activation: auto-activate base plugin if installed, or block activation if not installed.
 */
register_activation_hook( RTRSP_PLUGIN_FILE, function () {
	if ( rtrsp_is_base_plugin_active() ) {
		// Base plugin already active — nothing to do.
		add_option( 'rtrsp_activation_redirect', true );
		return;
	}

	if ( rtrsp_is_base_plugin_installed() ) {
		// Base plugin is installed but not active — activate it.
		$result = activate_plugin( RTRSP_BASE_PLUGIN );

		if ( is_wp_error( $result ) ) {
			deactivate_plugins( plugin_basename( RTRSP_PLUGIN_FILE ) );
			wp_die(
				sprintf(
					/* translators: %s: error message */
					esc_html__( 'Failed to activate SchemaEngine AI: %s', 'review-schema-pro' ),
					esc_html( $result->get_error_message() )
				),
				esc_html__( 'Plugin Activation Error', 'review-schema-pro' ),
				[ 'back_link' => true ]
			);
		}

		add_option( 'rtrsp_activation_redirect', true );
		return;
	}

	// Base plugin is not installed at all — block activation.
	deactivate_plugins( plugin_basename( RTRSP_PLUGIN_FILE ) );
	wp_die(
		sprintf(
			'<strong>%s</strong> %s',
			esc_html__( 'SchemaEngine AI', 'review-schema-pro' ),
			esc_html__( 'plugin must be installed and activated before activating SchemaEngine AI Pro.', 'review-schema-pro' )
		),
		esc_html__( 'Plugin Activation Error', 'review-schema-pro' ),
		[ 'back_link' => true ]
	);
} );

/**
 * Runtime check: if base plugin is not active (e.g. deactivated after pro was activated),
 * show an admin notice and stop loading the pro plugin.
 */
if ( ! rtrsp_is_base_plugin_active() ) {
	// Auto-deactivate pro plugin when base plugin is not active.
	add_action( 'admin_init', function () {
		deactivate_plugins( plugin_basename( RTRSP_PLUGIN_FILE ) );
		if ( isset( $_GET['activate'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			unset( $_GET['activate'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}
	} );

	add_action( 'admin_notices', function () {
		$class = 'notice notice-error';
		$text  = esc_html__( 'SchemaEngine AI', 'review-schema-pro' );
		$link  = esc_url(
			add_query_arg(
				[
					'tab'       => 'plugin-information',
					'plugin'    =>  'review-schema-pro',
					'TB_iframe' => 'true',
					'width'     => '640',
					'height'    => '500',
				],
				admin_url( 'plugin-install.php' )
			)
		);
		$link_pro = 'https://www.radiustheme.com/downloads/review-schema';

		printf(
			'<div class="%1$s"><p><a target="_blank" href="%3$s"><strong>SchemaEngine AI Pro</strong></a> is not working because you also need to install and activate <a class="thickbox open-plugin-details-modal" href="%2$s"><strong>%4$s</strong></a> plugin to get pro features.</p></div>',
			esc_attr( $class ),
			$link,
			esc_url( $link_pro ),
			$text
		);
	} );

	// Stop loading the rest of the pro plugin.
	return;
}

add_action( 'rtrs_ai_loaded', function () {
	if ( ! class_exists( 'Rtrsp' ) ) {
		require_once 'app/Rtrsp.php';
	}
} );

// Redirect to settings page after activation.
class RtrspActivation {
	public function __construct() {
		add_action( 'admin_init', [ $this, 'plugin_redirect' ] );
	}

	public function plugin_redirect() {
		if ( get_option( 'rtrsp_activation_redirect', false ) ) {
			delete_option( 'rtrsp_activation_redirect' );
			wp_redirect( admin_url( 'admin.php?page=review-schema#/tools' ) );
		}
	}
}
new RtrspActivation();

