<?php
/**
 * Review layout four template.
 *
 * @author      RadiusTheme
 * @package     review-schema-pro/templates/review
 * @version     1.1.0
 *
 * @var object $comment         Comment object.
 * @var string $comment_classes Wrapper classes.
 * @var array  $p_meta          Post type meta.
 * @var string $review_edit     Whether review edit is enabled.
 * @var array  $args            Reply args.
 * @var int    $add_below       Reply anchor element.
 * @var int    $depth           Thread depth.
 */

use Rtrs\Modules\Review\Helpers\ReviewFns;

?>
<div class="<?php echo esc_attr( $comment_classes ); ?>">
	<?php if ( get_option( 'show_avatars' ) ) { ?>
		<div class="rtrs-review-imgholder">
			<?php
			if ( get_comment_meta( get_comment_ID(), 'rt_anonymous', true ) ) {
				$avatar = RTRS_URL . '/assets/imgs/avatar.jpg';
			} else {
				$avatar = get_avatar_url( $comment->comment_author_email, [ 'size' => '70' ] );
			}
			?>
			<img src="<?php echo esc_url( $avatar ); ?>" alt="">
		</div>
	<?php } ?>

	<div class="rtrs-review-body">

		<?php
		$rating = get_comment_meta( get_comment_ID(), 'rating', true );
		$title  = get_comment_meta( get_comment_ID(), 'rt_title', true );
		?>

		<ul class="rtrs-review-meta mg-b-5">
			<?php if ( $rating ) { ?>
				<li class="rtrs-review-rating"><?php echo ReviewFns::review_stars( $rating ); ?></li>
			<?php } ?>
		</ul>

		<?php if ( $title ) { ?>
			<h4 class="rtrs-review-title"><?php echo esc_html( $title ); ?></h4>
		<?php } ?>

		<ul class="rtrs-review-meta">
			<?php rtrs()->get_partial_path( 'author', [ 'p_meta' => $p_meta ] ); ?>

			<li class="rtrs-review-date">
				<i class="rtrs-calendar"></i>
				<?php echo ReviewFns::comment_review_time( $comment ); ?>
				<?php if ( 'yes' === $review_edit && get_current_user_id() && (int) $comment->user_id === get_current_user_id() ) { ?>
					<span class="rtrs-review-edit-btn" data-comment-post-id="<?php echo esc_attr( $comment->comment_post_ID ); ?>" data-comment-id="<?php echo esc_attr( $comment->comment_ID ); ?>">
						<?php esc_html_e( '(Edit)', 'review-schema' ); ?>
					</span>
				<?php } ?>
			</li>

			<?php rtrs()->get_partial_path( 'share', [ 'p_meta' => $p_meta ] ); ?>
		</ul>

		<?php comment_text(); ?>

		<?php if ( '0' === $comment->comment_approved ) : ?>
			<p><em class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'review-schema' ); ?></em></p>
		<?php endif; ?>

		<?php rtrs()->get_partial_path( 'attachment', [ 'p_meta' => $p_meta ] ); ?>

		<?php rtrs()->get_partial_path( 'pros-cons', [ 'p_meta' => $p_meta ] ); ?>

		<?php
		ob_start();
		rtrs()->get_partial_path( 'highlight', [ 'p_meta' => $p_meta ] );
		rtrs()->get_partial_path( 'helpful', [ 'p_meta' => $p_meta ] );
		$action_area = ob_get_clean();
		if ( trim( $action_area ) ) {
			echo '<div class="rtrs-action-area">' . $action_area . '</div>';
		}
		?>

		<?php
		rtrs()->get_partial_path(
			'reply',
			[
				'args'      => $args,
				'add_below' => $add_below,
				'depth'     => $depth,
			]
		);
		?>
	</div>
</div>
