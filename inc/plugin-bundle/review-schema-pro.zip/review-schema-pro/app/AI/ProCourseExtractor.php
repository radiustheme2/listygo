<?php
/**
 * Pro Course Extractor - Course data extraction and schema filling (Pro feature).
 *
 * Builds the Tutor LMS / LearnPress course data (moved from the free ContentExtractor).
 *
 * Hooks into the free plugin's `rtrs_ai_extract_course_data`,
 * `rtrs_ai_fill_course_schema`, and `rtrs_ai_type_template` filters.
 *
 * @package Rtrsp\AI
 * @since   1.0.0
 */

namespace Rtrsp\AI;

use Rtrs\Helpers\Functions;
use Rtrs\Modules\Review\Helpers\ReviewFns;
use Rtrs\Modules\Schema\Helpers\SchemaFns;

defined( 'ABSPATH' ) || exit;

class ProCourseExtractor {

	/**
	 * Extract course data (Pro feature).
	 *
	 * Supports Tutor LMS and LearnPress.
	 *
	 * @param null     $default Default null from free plugin.
	 * @param \WP_Post $post    Post object.
	 *
	 * @return array|null Course data or null.
	 */
	public static function extract_course_data( $default, $post ) {
		// Password-protected: no product/course data reaches the AI or saved schema.
		if ( \Rtrsp\Helpers\FnsPro::is_schema_protected( $post ) ) {
			return $default;
		}

		if ( 'courses' === $post->post_type && function_exists( 'tutor_utils' ) ) {
			return self::build_tutor_course_data( $post );
		}

		if ( 'lp_course' === $post->post_type && function_exists( 'learn_press_get_course' ) ) {
			return self::build_learnpress_course_data( $post );
		}

		return $default;
	}

	/**
	 * Get Course AI prompt template.
	 *
	 * @param string $template    Existing template (empty for pro-gated types).
	 * @param string $type        Schema type name.
	 * @param string $entity_type Entity type (Organization/Person).
	 *
	 * @return string Template string.
	 */
	public static function get_course_template( $template, $type, $entity_type ) {
		if ( 'Course' !== $type ) {
			return $template;
		}

		$entity_frag = ( 'Person' === $entity_type ) ? 'person' : 'organization';

		return <<<TPL
Required fields for Course:
- name, description
- provider: {"@id": "{site_url}/#{$entity_frag}"} (reference to global entity — do NOT inline Organization)
- educationalLevel (if determinable)
- offers (Offer with price, priceCurrency — if course has pricing data)
- aggregateRating (if reviews exist)
TPL;
	}

	/**
	 * Fill missing Course schema fields from extracted course data.
	 *
	 * @param array  $schema    The Course schema node.
	 * @param array  $primary   Primary content signals.
	 * @param array  $secondary Secondary content signals.
	 * @param string $permalink Post permalink.
	 * @param string $entity_id Entity @id reference.
	 *
	 * @return array Modified schema.
	 */
	public static function fill_course_schema( $schema, $primary, $secondary, $permalink, $entity_id = '' ) {
		$tutor = $secondary['tutor_course'] ?? [];

		if ( empty( $schema['name'] ) && ! empty( $primary['title'] ) ) {
			$schema['name'] = $primary['title'];
		}

		if ( empty( $schema['description'] ) && ! empty( $primary['excerpt'] ) ) {
			$schema['description'] = mb_substr( $primary['excerpt'], 0, 200 );
		}

		if ( empty( $schema['url'] ) && ! empty( $primary['permalink'] ) ) {
			$schema['url'] = $primary['permalink'];
		}

		if ( empty( $schema['image'] ) && ! empty( $primary['featured_image']['url'] ) ) {
			$fi              = $primary['featured_image'];
			$schema['image'] = array_filter( [
				'@type'  => 'ImageObject',
				'url'    => $fi['url'],
				'width'  => $fi['width'] ?? null,
				'height' => $fi['height'] ?? null,
			] );
		}

		if ( empty( $schema['provider'] ) && $entity_id ) {
			$schema['provider'] = [ '@id' => $entity_id ];
		}

		if ( empty( $tutor ) ) {
			return $schema;
		}

		// Instructor as author.
		if ( empty( $schema['author'] ) && ! empty( $tutor['instructor']['name'] ) ) {
			$author = [ '@type' => 'Person', 'name' => $tutor['instructor']['name'] ];
			if ( ! empty( $tutor['instructor']['url'] ) ) {
				$author['url'] = $tutor['instructor']['url'];
			}
			$schema['author'] = $author;
		}

		// Course level → educationalLevel.
		if ( empty( $schema['educationalLevel'] ) && ! empty( $tutor['level'] ) ) {
			$level_map = [
				'all_levels'   => 'Beginner',
				'beginner'     => 'Beginner',
				'intermediate' => 'Intermediate',
				'expert'       => 'Advanced',
			];
			$schema['educationalLevel'] = $level_map[ $tutor['level'] ] ?? ucfirst( $tutor['level'] );
		}

		// Duration → timeRequired (ISO 8601).
		if ( empty( $schema['timeRequired'] ) && ! empty( $tutor['duration'] ) ) {
			$dur = $tutor['duration'];
			if ( is_array( $dur ) ) {
				$h = (int) ( $dur['hours'] ?? 0 );
				$m = (int) ( $dur['minutes'] ?? 0 );
				$s = (int) ( $dur['seconds'] ?? 0 );
				if ( $h > 0 || $m > 0 || $s > 0 ) {
					$iso = 'PT';
					if ( $h > 0 ) {
						$iso .= $h . 'H';
					}
					if ( $m > 0 ) {
						$iso .= $m . 'M';
					}
					if ( $s > 0 ) {
						$iso .= $s . 'S';
					}
					$schema['timeRequired'] = $iso;
				}
			}
		}

		// Price → offers.
		if ( empty( $schema['offers'] ) ) {
			if ( 'free' === ( $tutor['price_type'] ?? '' ) ) {
				$schema['offers'] = [
					[
						'@type'         => 'Offer',
						'price'         => '0',
						'priceCurrency' => 'USD',
						'availability'  => 'https://schema.org/InStock',
						'url'           => $permalink,
						'category'      => 'Free',
					],
				];
			} elseif ( ! empty( $tutor['price'] ) ) {
				$offer = [
					'@type'         => 'Offer',
					'price'         => $tutor['price'],
					'priceCurrency' => $tutor['currency'] ?: 'USD',
					'availability'  => 'https://schema.org/InStock',
					'url'           => $permalink,
				];

				// LearnPress sale price support.
				if ( ! empty( $tutor['sale_price'] ) && (float) $tutor['sale_price'] > 0 ) {
					$offer['price'] = $tutor['sale_price'];
				}

				$schema['offers'] = [ $offer ];
			}
		}

		// Number of enrolled students.
		if ( empty( $schema['totalHistoricalEnrollment'] ) && ! empty( $tutor['enrolled'] ) ) {
			$schema['totalHistoricalEnrollment'] = $tutor['enrolled'];
		}

		return $schema;
	}

	/**
	 * Extract Tutor LMS course data for schema generation.
	 *
	 * @return array|null Course data or null if not a Tutor course.
	 */
	private static function build_tutor_course_data( $post ) {
		if ( ! function_exists( 'tutor_utils' ) ) {
			return null;
		}

		$post_id = $post->ID;
		$utils   = tutor_utils();

		// Duration.
		$duration = get_post_meta( $post_id, '_course_duration', true );

		// Level.
		$level = get_post_meta( $post_id, '_tutor_course_level', true );

		// Price.
		$price_type = get_post_meta( $post_id, '_tutor_course_price_type', true );
		$price      = '';
		$currency   = '';

		if ( 'paid' === $price_type ) {
			$product_id = get_post_meta( $post_id, '_tutor_course_product_id', true );

			if ( $product_id && function_exists( 'wc_get_product' ) ) {
				$product  = wc_get_product( $product_id );
				$price    = $product ? $product->get_price() : '';
				$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';
			}

			if ( ! $price ) {
				$price = get_post_meta( $post_id, 'tutor_course_price', true );
			}
		}

		// Instructor.
		$instructors = $utils->get_instructors_by_course( $post_id );
		$instructor  = [];

		if ( ! empty( $instructors ) && is_array( $instructors ) ) {
			$inst = is_object( $instructors[0] ) ? $instructors[0] : null;

			$inst_name = $inst ? self::author_name( $inst->ID ?? 0 ) : '';
			if ( '' !== $inst_name ) {
				$instructor = [
					'name' => $inst_name,
					'url'  => self::author_url( $inst->ID ?? 0 ),
				];
			}
		}

		// Rating — check review-schema's own ratings first, then Tutor native.
		$rating = [];

		if ( Functions::isEnableReviewByPostType( $post->post_type ) ) {
			$avg   = ReviewFns::getAvgRatings( $post_id, true );
			$total = ReviewFns::getTotalRatings( $post_id );

			if ( $avg && $total ) {
				$rating = [
					'average_rating' => (float) $avg,
					'review_count'   => (int) $total,
					'rating_count'   => (int) $total,
				];
			}
		} else {
			$rating_data = $utils->get_course_rating( $post_id );

			if ( $rating_data && ! empty( $rating_data->rating_avg ) && $rating_data->rating_avg > 0 ) {
				$rating = [
					'average_rating' => (float) $rating_data->rating_avg,
					'rating_count'   => (int) ( $rating_data->rating_count ?? 0 ),
				];
			}
		}

		// Enrolled students.
		$enrolled = method_exists( $utils, 'count_enrolled_users_by_course' )
			? (int) $utils->count_enrolled_users_by_course( $post_id )
			: 0;

		// Course benefits / requirements.
		$benefits     = get_post_meta( $post_id, '_tutor_course_benefits', true );
		$requirements = get_post_meta( $post_id, '_tutor_course_requirements', true );

		return array_filter(
			[
				'duration'     => $duration,
				'level'        => $level,
				'price_type'   => $price_type,
				'price'        => $price,
				'currency'     => $currency,
				'instructor'   => $instructor,
				'rating'       => $rating,
				'enrolled'     => $enrolled,
				'benefits'     => $benefits,
				'requirements' => $requirements,
			]
		);
	}

	/**
	 * Extract LearnPress course data for schema generation.
	 *
	 * @return array|null Course data or null if not a LearnPress course.
	 */
	private static function build_learnpress_course_data( $post ) {
		if ( ! function_exists( 'learn_press_get_course' ) ) {
			return null;
		}

		$post_id = $post->ID;

		// Price.
		$price    = '';
		$currency = '';

		$lp_course = learn_press_get_course( $post_id );

		if ( $lp_course && method_exists( $lp_course, 'get_price' ) ) {
			$price = $lp_course->get_price();
		}

		if ( ! $price ) {
			$price = get_post_meta( $post_id, '_lp_regular_price', true )
				?: get_post_meta( $post_id, '_lp_price', true );
		}

		$price_type = ( $price && (float) $price > 0 ) ? 'paid' : 'free';

		if ( 'paid' === $price_type ) {
			$currency = function_exists( 'learn_press_get_currency' ) ? learn_press_get_currency() : 'USD';
		}

		$sale_price = get_post_meta( $post_id, '_lp_sale_price', true );

		// Level.
		$level = get_post_meta( $post_id, '_lp_level', true );

		// Duration.
		$duration = get_post_meta( $post_id, '_lp_duration', true );

		// Instructor.
		$author_id  = $post->post_author;
		$instructor = [];

		$inst_name = $author_id ? self::author_name( $author_id ) : '';
		if ( '' !== $inst_name ) {
			$instructor = [
				'name' => $inst_name,
				'url'  => self::author_url( $author_id ),
			];
		}

		// Rating — check review-schema's own ratings first, then LearnPress native.
		$rating = [];

		if ( Functions::isEnableReviewByPostType( $post->post_type ) ) {
			$avg   = ReviewFns::getAvgRatings( $post_id, true );
			$total = ReviewFns::getTotalRatings( $post_id );

			if ( $avg && $total ) {
				$rating = [
					'average_rating' => (float) $avg,
					'review_count'   => (int) $total,
					'rating_count'   => (int) $total,
				];
			}
		} else {
			// Fallback to LearnPress native ratings (learnpress-course-review plugin).
			global $wpdb;

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Aggregating native ratings via JOIN; caching is not applicable per-request.
			$result = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT COUNT(cm.meta_value) AS rating_count, AVG(cm.meta_value) AS rating_avg
					FROM {$wpdb->comments} c
					INNER JOIN {$wpdb->commentmeta} cm ON c.comment_ID = cm.comment_id
					WHERE c.comment_post_ID = %d
					AND c.comment_approved = 1
					AND cm.meta_key = '_lpr_rating'",
					$post_id
				)
			);

			if ( $result && $result->rating_count > 0 && (float) $result->rating_avg > 0 ) {
				$rating = [
					'average_rating' => round( (float) $result->rating_avg, 2 ),
					'review_count'   => (int) $result->rating_count,
					'rating_count'   => (int) $result->rating_count,
				];
			}
		}

		return array_filter(
			[
				'duration'   => $duration,
				'level'      => $level,
				'price_type' => $price_type,
				'price'      => $price,
				'sale_price' => $sale_price,
				'currency'   => $currency,
				'instructor' => $instructor,
				'rating'     => $rating,
			]
		);
	}

	/**
	 * Instructor display name via the free author helper (free 3.1.4+).
	 *
	 * With an older free plugin, the display name is used only when it is not
	 * the login name (never publish a username).
	 *
	 * @param int $user_id User ID.
	 * @return string
	 */
	private static function author_name( $user_id ) {
		if ( method_exists( SchemaFns::class, 'get_author_schema_name' ) ) {
			return SchemaFns::get_author_schema_name( $user_id );
		}
		$user = get_userdata( absint( $user_id ) );
		if ( ! $user ) {
			return '';
		}
		$display = trim( wp_strip_all_tags( (string) $user->display_name ) );

		return ( '' !== $display && strtolower( $display ) !== strtolower( (string) $user->user_login ) ) ? $display : '';
	}

	/**
	 * Instructor URL via the free author helper (free 3.1.4+); none with older free.
	 *
	 * @param int $user_id User ID.
	 * @return string
	 */
	private static function author_url( $user_id ) {
		return method_exists( SchemaFns::class, 'get_author_schema_url' ) ? SchemaFns::get_author_schema_url( $user_id ) : '';
	}
}
