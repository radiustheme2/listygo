<?php
/**
 * AJAX review pagination (Pro).
 *
 * Moved from the free plugin. Free renders WordPress page links ("Number");
 * Pro adds the "Number Ajax", "Load More" and "Auto Scroll" modes:
 * - `rtrs_pagination_type`               — registers the three options.
 * - `rtrs_review_pagination`             — renders their markup (template + shortcode).
 * - `rtrs_review_number_pagination_class` — keeps shortcode page links on AJAX.
 * - `wp_ajax(_nopriv)_rtrs_pagination`    — returns the next page of reviews.
 *
 * The review query, page count and page links are the free plugin's shared
 * ReviewAjax helpers, the same ones its sort/filter handler uses.
 *
 * @package Rtrsp\Modules\Review\FrontEnd
 */

namespace Rtrsp\Modules\Review\FrontEnd;

use Rtrs\Helpers\Functions;
use Rtrs\Modules\Review\Ajax\ReviewAjax;
use Rtrsp\Traits\SingletonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ReviewPagination
 */
class ReviewPagination {

	use SingletonTrait;

	/**
	 * Pagination types provided here.
	 */
	const TYPES = [ 'number-ajax', 'load-more', 'auto-scroll' ];

	/**
	 * Script / style handle.
	 */
	const HANDLE = 'rtrsp-review-pagination';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function init() {
		add_filter( 'rtrs_pagination_type', [ $this, 'register_types' ] );
		add_action( 'rtrs_review_pagination', [ $this, 'render' ], 10, 3 );
		add_filter( 'rtrs_review_number_pagination_class', [ $this, 'number_class' ], 10, 2 );
		add_action( 'wp_ajax_rtrs_pagination', [ $this, 'ajax_page' ] );
		add_action( 'wp_ajax_nopriv_rtrs_pagination', [ $this, 'ajax_page' ] );
	}

	/**
	 * Add the AJAX pagination types to the review config options.
	 *
	 * @param array $types Type key => label.
	 * @return array
	 */
	public function register_types( $types ) {
		$types = is_array( $types ) ? $types : [];

		return array_merge(
			$types,
			[
				'number-ajax' => esc_html__( 'Number Ajax', 'review-schema-pro' ),
				'load-more'   => esc_html__( 'Load More', 'review-schema-pro' ),
				'auto-scroll' => esc_html__( 'Auto Scroll', 'review-schema-pro' ),
			]
		);
	}

	/**
	 * Shortcode review lists page with AJAX, since the host page is not the source post.
	 *
	 * @param string $class   Wrapper classes.
	 * @param string $context "shortcode".
	 * @return string
	 */
	public function number_class( $class, $context = '' ) {
		if ( 'shortcode' !== $context ) {
			return $class;
		}
		$this->enqueue();

		return trim( $class . ' rtrs-paginate-ajax' );
	}

	/**
	 * Print the markup of an AJAX pagination type.
	 *
	 * @param string $type      Pagination type.
	 * @param int    $max_pages Number of review pages.
	 * @param string $context   "template" or "shortcode".
	 * @return void
	 */
	public function render( $type, $max_pages, $context = 'template' ) {
		if ( ! in_array( $type, self::TYPES, true ) ) {
			return;
		}
		$max_pages = absint( $max_pages );
		$this->enqueue();

		if ( 'number-ajax' === $type ) {
			if ( $max_pages < 2 ) {
				return;
			}
			$args = [
				'prev_text' => '<i class="rtrs-angle-left"></i>',
				'next_text' => '<i class="rtrs-angle-right"></i>',
			];
			if ( 'shortcode' === $context ) {
				$args['total'] = $max_pages;
			}
			echo '<div class="rtrs-paginate rtrs-paginate-ajax" data-max="' . esc_attr( $max_pages ) . '">';
			paginate_comments_links( $args );
			echo '</div>';
			return;
		}

		if ( 'load-more' === $type ) {
			printf(
				'<div class="rtrs-paginate rtrs-paginate-load-more rtrs-align-center"><a href="#" id="rtrs-load-more" data-current_page="1" data-max="%1$s">%2$s</a></div>',
				esc_attr( $max_pages ),
				esc_html__( 'Load More', 'review-schema-pro' )
			);
			return;
		}

		printf( '<div class="rtrs-paginate rtrs-paginate-onscroll" data-current_page="1" data-max="%s"></div>', esc_attr( $max_pages ) );
	}

	/**
	 * Enqueue the pagination script and style (footer; safe during the_content).
	 *
	 * @return void
	 */
	private function enqueue() {
		wp_enqueue_style( self::HANDLE, rtrsp()->get_assets_uri( 'css/review-pagination.css' ), [ 'rtrs-app' ], RTRSP_VERSION );
		wp_enqueue_script( self::HANDLE, rtrsp()->get_assets_uri( 'js/review-pagination.js' ), [ 'jquery', 'rtrs-app' ], RTRSP_VERSION, true );
		wp_localize_script( self::HANDLE, 'rtrspPagination', [ 'loadMore' => esc_html__( 'Load More', 'review-schema-pro' ) ] );
	}

	/**
	 * AJAX: one page of reviews plus fresh page links.
	 *
	 * Public (nopriv) like the free sort/filter handler: the nonce is CSRF
	 * protection only; the page count is always computed server-side.
	 *
	 * @return void
	 */
	public function ajax_page() {
		if ( ! wp_verify_nonce( Functions::get_nonce(), rtrs()->getNonceId() ) ) {
			wp_send_json_error( [ 'message' => 'Not allowed' ], 403 );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Verified above.
		$sort_by   = isset( $_REQUEST['sort_by'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['sort_by'] ) ) : '';
		$filter_by = isset( $_REQUEST['filter_by'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['filter_by'] ) ) : '';
		$cur_page  = isset( $_REQUEST['current_page'] ) ? absint( $_REQUEST['current_page'] ) : 1;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$reviews  = ReviewAjax::getInstance();
		$max_page = $reviews->get_review_page_count( $sort_by, $filter_by );

		ob_start();
		$reviews->get_reviews( $sort_by, $filter_by );
		$review = ob_get_clean();

		wp_send_json_success(
			[
				'review'     => $review,
				'pagination' => $reviews->paginate_comments_links( $cur_page, $max_page ),
			]
		);
	}
}
