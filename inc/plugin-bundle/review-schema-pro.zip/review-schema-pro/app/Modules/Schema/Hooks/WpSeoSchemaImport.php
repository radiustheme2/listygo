<?php
/**
 * WP SEO Structured Data Schema import: Pro schema types (Pro).
 *
 * The free plugin's importer (Rtrs\Modules\Schema\Ajax\WpSeoSchema) migrates
 * per-post schema from the WP SEO Structured Data Schema plugin. Pro schema
 * types are mapped here, moved from the free importer, through its
 * `rtrs_wpseo_schema_field_data` filter.
 *
 * @package Rtrsp\Modules\Schema\Hooks
 */

namespace Rtrsp\Modules\Schema\Hooks;

use Rtrs\Modules\Schema\Ajax\WpSeoSchema;
use Rtrsp\Traits\SingletonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WpSeoSchemaImport
 */
class WpSeoSchemaImport {

	use SingletonTrait;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function init() {
		add_filter( 'rtrs_wpseo_schema_field_data', [ $this, 'map' ], 10, 4 );
	}

	/**
	 * Map one post's WP SEO Structured Data meta to review-schema meta for a Pro type.
	 *
	 * @param array       $data     Mapped data so far (empty for types the free importer does not map).
	 * @param string      $type     review-schema type key (e.g. product, recipe).
	 * @param array       $kseo     Source plugin meta.
	 * @param WpSeoSchema $importer Free importer (shared conversion helpers).
	 *
	 * @return array
	 */
	public function map( $data, $type, $kseo, $importer ) {
		if ( ! empty( $data ) || ! is_array( $kseo ) || ! $importer instanceof WpSeoSchema ) {
			return $data;
		}

		switch ( $type ) {
			case 'product':
				return self::get_product_schema_field_data_map( $kseo, $importer );
			case 'course':
				return self::get_course_schema_field_data_map( $kseo, $importer );
			case 'job_posting':
				return self::get_job_posting_schema_field_data_map( $kseo, $importer );
			case 'recipe':
				return self::get_recipe_schema_field_data_map( $kseo, $importer );
			case 'software_app':
				return self::get_software_app_schema_field_data_map( $kseo, $importer );
			case 'book':
				return self::get_book_schema_field_data_map( $kseo, $importer );
			case 'tv_series':
				return self::get_tv_series_schema_field_data_map( $kseo, $importer );
			case 'vacation_rental':
				return self::get_vacation_rental_schema_field_data_map( $kseo, $importer );
			case 'vehicle_listing':
				return self::get_vehicle_listing_schema_field_data_map( $kseo, $importer );
			case 'Restaurant':
				// Opening hours parsing is a free importer helper (public since free 3.1.4).
				return is_callable( [ $importer, 'parse_opening_hours' ] ) ? self::get_restaurant_schema_field_data_map( $kseo, $importer ) : $data;
		}

		return $data;
	}

	/**
	 * Map product schema fields.
	 *
	 * @param array $_kseo Source meta data.
	 *
	 * @param WpSeoSchema $importer Free importer (shared conversion helpers).
	 *
	 * @return array Review-schema formatted data.
	 */
	private static function get_product_schema_field_data_map( $_kseo, WpSeoSchema $importer ) {
		return [
			[
				'status'            => 'show',
				'name'              => $_kseo['name'] ?? '',
				'image'             => $importer->image_url_to_id( $_kseo['image'] ?? '' ),
				'description'       => $_kseo['description'] ?? '',
				'sku'               => $_kseo['sku'] ?? '',
				'brand'             => $_kseo['brand'] ?? '',
				'identifier_type'   => $_kseo['identifier_type'] ?? '',
				'identifier'        => $_kseo['identifier'] ?? '',
				'reviewRatingValue' => $_kseo['reviewRatingValue'] ?? '',
				'reviewBestRating'  => $_kseo['reviewBestRating'] ?? '',
				'reviewWorstRating' => $_kseo['reviewWorstRating'] ?? '',
				'reviewAuthor'      => $_kseo['reviewAuthor'] ?? '',
				'ratingValue'       => $_kseo['ratingValue'] ?? '',
				'reviewCount'       => $_kseo['reviewCount'] ?? '',
				'priceCurrency'     => $_kseo['priceCurrency'] ?? '',
				'price'             => $_kseo['price'] ?? '',
				'priceValidUntil'   => $importer->to_iso8601( $_kseo['priceValidUntil'] ?? '' ),
				'availability'      => $_kseo['availability'] ?? '',
				'itemCondition'     => $_kseo['itemCondition'] ?? '',
				'url'               => $_kseo['url'] ?? '',
			],
		];
	}

	/**
	 * Map course schema fields.
	 *
	 * @param array $_kseo Source meta data.
	 *
	 * @param WpSeoSchema $importer Free importer (shared conversion helpers).
	 *
	 * @return array Review-schema formatted data.
	 */
	private static function get_course_schema_field_data_map( $_kseo, WpSeoSchema $importer ) {
		$data = [
			'status'          => 'show',
			'name'            => $_kseo['name'] ?? '',
			'description'     => $_kseo['description'] ?? '',
			'provider'        => $_kseo['provider'] ?? '',
			'courseMode'       => $_kseo['courseMode'] ?? '',
			'duration'        => $_kseo['duration'] ?? '',
			'repeatFrequency' => $_kseo['repeatFrequency'] ?? '',
			'repeatCount'     => $_kseo['repeatCount'] ?? '',
			'startDate'       => $importer->to_iso8601( $_kseo['startDate'] ?? '' ),
			'endDate'         => $importer->to_iso8601( $_kseo['endDate'] ?? '' ),
			'locationName'    => $_kseo['locationName'] ?? '',
			'locationAddress' => $_kseo['locationAddress'] ?? '',
			'image'           => $importer->image_url_to_id( $_kseo['image'] ?? '' ),
			'category'        => $_kseo['category'] ?? '',
			'price'           => $_kseo['price'] ?? '',
			'priceCurrency'   => $_kseo['priceCurrency'] ?? '',
			'availability'    => $_kseo['availability'] ?? '',
			'url'             => $_kseo['url'] ?? '',
			'validFrom'       => $importer->to_iso8601( $_kseo['validFrom'] ?? '' ),
			'performerType'   => $_kseo['performerType'] ?? '',
			'performerName'   => $_kseo['performerName'] ?? '',
		];

		$data = array_merge( $data, $importer->map_review_fields( $_kseo ) );

		return [ $data ];
	}

	/**
	 * Map job posting schema fields.
	 *
	 * @param array $_kseo Source meta data.
	 *
	 * @param WpSeoSchema $importer Free importer (shared conversion helpers).
	 *
	 * @return array Review-schema formatted data.
	 */
	private static function get_job_posting_schema_field_data_map( $_kseo, WpSeoSchema $importer ) {
		return [
			[
				'status'                => 'show',
				'title'                 => $_kseo['title'] ?? '',
				'salaryAmount'          => $_kseo['salaryAmount'] ?? '',
				'currency'              => $_kseo['currency'] ?? '',
				'salaryAt'              => $_kseo['salaryAt'] ?? '',
				'validThrough'          => $importer->to_iso8601( $_kseo['validThrough'] ?? '' ),
				'description'           => $_kseo['description'] ?? '',
				'employmentType'        => $_kseo['employmentType'] ?? '',
				'workHours'             => $_kseo['workHours'] ?? '',
				'hiringOrganization'    => $_kseo['hiringOrganization'] ?? '',
				'addressLocality'       => $_kseo['addressLocality'] ?? '',
				'addressRegion'         => $_kseo['addressRegion'] ?? '',
				'postalCode'            => $_kseo['postalCode'] ?? '',
				'streetAddress'         => $_kseo['streetAddress'] ?? '',
				'jobBenefits'           => $_kseo['jobBenefits'] ?? '',
				'educationRequirements' => $_kseo['educationRequirements'] ?? '',
				'experienceRequirements' => $_kseo['experienceRequirements'] ?? '',
				'industry'              => $_kseo['industry'] ?? '',
				'occupationalCategory'  => $_kseo['occupationalCategory'] ?? '',
				'qualifications'        => $_kseo['qualifications'] ?? '',
				'responsibilities'      => $_kseo['responsibilities'] ?? '',
				'skills'                => $_kseo['skills'] ?? '',
			],
		];
	}

	/**
	 * Map recipe schema fields.
	 *
	 * @param array $_kseo Source meta data.
	 *
	 * @param WpSeoSchema $importer Free importer (shared conversion helpers).
	 *
	 * @return array Review-schema formatted data.
	 */
	private static function get_recipe_schema_field_data_map( $_kseo, WpSeoSchema $importer ) {
		$instructions = [];
		if ( ! empty( $_kseo['recipe_instructions'] ) && is_array( $_kseo['recipe_instructions'] ) ) {
			foreach ( $_kseo['recipe_instructions'] as $step ) {
				$instructions[] = [
					'name'  => $step['name'] ?? '',
					'text'  => $step['text'] ?? '',
					'image' => $importer->image_url_to_id( $step['image'] ?? '' ),
					'url'   => $step['url'] ?? '',
				];
			}
		}

		$video_info = [];
		if ( ! empty( $_kseo['video_info'] ) && is_array( $_kseo['video_info'] ) ) {
			foreach ( $_kseo['video_info'] as $vi ) {
				$video_info[] = [
					'name'         => $vi['name'] ?? '',
					'description'  => $vi['description'] ?? '',
					'thumbnailUrl' => $importer->image_url_to_id( $vi['thumbnailUrl'] ?? '' ),
					'contentUrl'   => $vi['contentUrl'] ?? '',
					'embedUrl'     => $vi['embedUrl'] ?? '',
					'uploadDate'   => $importer->to_iso8601( $vi['uploadDate'] ?? '' ),
					'duration'     => $vi['duration'] ?? '',
				];
			}
		}

		$data = [
			'status'               => 'show',
			'name'                 => $_kseo['name'] ?? '',
			'author'               => $_kseo['author'] ?? '',
			'datePublished'        => $importer->to_iso8601( $_kseo['datePublished'] ?? '' ),
			'image'                => $importer->image_url_to_id( $_kseo['image'] ?? '' ),
			'description'          => $_kseo['description'] ?? '',
			'keywords'             => $_kseo['keywords'] ?? '',
			'recipeCategory'       => $_kseo['recipeCategory'] ?? '',
			'recipeCuisine'        => $_kseo['recipeCuisine'] ?? '',
			'prepTime'             => $_kseo['prepTime'] ?? '',
			'cookTime'             => $_kseo['cookTime'] ?? '',
			'recipeIngredient'     => $_kseo['recipeIngredient'] ?? '',
			'calories'             => $_kseo['calories'] ?? '',
			'fatContent'           => $_kseo['fatContent'] ?? '',
			'recipeYield'          => $_kseo['recipeYield'] ?? '',
			'suitableForDiet'      => $_kseo['suitableForDiet'] ?? '',
			'ratingValue'          => $_kseo['ratingValue'] ?? '',
			'reviewCount'          => $_kseo['reviewCount'] ?? '',
			'bestRating'           => $_kseo['bestRating'] ?? '',
			'worstRating'          => $_kseo['worstRating'] ?? '',
		];

		if ( ! empty( $instructions ) ) {
			$data['recipe_instructions'] = $instructions;
		}
		if ( ! empty( $video_info ) ) {
			$data['video_info'] = $video_info;
		}

		$data = array_merge( $data, $importer->map_review_fields( $_kseo ) );

		return [ $data ];
	}

	/**
	 * Map software application schema fields.
	 *
	 * @param array $_kseo Source meta data.
	 *
	 * @param WpSeoSchema $importer Free importer (shared conversion helpers).
	 *
	 * @return array Review-schema formatted data.
	 */
	private static function get_software_app_schema_field_data_map( $_kseo, WpSeoSchema $importer ) {
		$data = [
			'status'               => 'show',
			'name'                 => $_kseo['name'] ?? '',
			'description'          => $_kseo['description'] ?? '',
			'image'                => $importer->image_url_to_id( $_kseo['image'] ?? '' ),
			'price'                => $_kseo['price'] ?? '',
			'priceCurrency'        => $_kseo['priceCurrency'] ?? '',
			'applicationCategory'  => $_kseo['applicationCategory'] ?? '',
			'operatingSystem'      => $_kseo['operatingSystem'] ?? '',
			'softwareVersion'      => $_kseo['softwareVersion'] ?? '',
			'downloadUrl'          => $_kseo['downloadUrl'] ?? '',
			'aggregate_ratingValue' => $_kseo['aggregate_ratingValue'] ?? '',
			'aggregate_bestRating'  => $_kseo['aggregate_bestRating'] ?? '',
			'aggregate_worstRating' => $_kseo['aggregate_worstRating'] ?? '',
			'aggregate_ratingCount' => $_kseo['aggregate_ratingCount'] ?? '',
		];

		$data = array_merge( $data, $importer->map_review_fields( $_kseo ) );

		return [ $data ];
	}

	/**
	 * Map book schema fields.
	 *
	 * @param array $_kseo Source meta data.
	 *
	 * @param WpSeoSchema $importer Free importer (shared conversion helpers).
	 *
	 * @return array Review-schema formatted data.
	 */
	private static function get_book_schema_field_data_map( $_kseo, WpSeoSchema $importer ) {
		$data = [
			'status'         => 'show',
			'name'           => $_kseo['name'] ?? '',
			'datePublished'  => $importer->to_iso8601( $_kseo['datePublished'] ?? '' ),
			'author'         => $_kseo['author'] ?? '',
			'author_sameAs'  => $_kseo['author_sameAs'] ?? '',
			'bookFormat'     => $_kseo['bookFormat'] ?? '',
			'isbn'           => $_kseo['isbn'] ?? '',
			'workExample'    => $_kseo['workExample'] ?? '',
			'url'            => $_kseo['url'] ?? '',
			'sameAs'         => $_kseo['sameAs'] ?? '',
			'numberOfPages'  => $_kseo['numberOfPages'] ?? '',
			'copyrightHolder' => $_kseo['copyrightHolder'] ?? '',
			'copyrightYear'  => $_kseo['copyrightYear'] ?? '',
			'description'    => $_kseo['description'] ?? '',
			'genre'          => $_kseo['genre'] ?? '',
			'inLanguage'     => $_kseo['inLanguage'] ?? '',
		];

		$data = array_merge( $data, $importer->map_review_fields( $_kseo ) );

		return [ $data ];
	}

	/**
	 * Map TV series (TVEpisode) schema fields.
	 *
	 * @param array $_kseo Source meta data.
	 *
	 * @param WpSeoSchema $importer Free importer (shared conversion helpers).
	 *
	 * @return array Review-schema formatted data.
	 */
	private static function get_tv_series_schema_field_data_map( $_kseo, WpSeoSchema $importer ) {
		return [
			[
				'status'        => 'show',
				'name'          => $_kseo['name'] ?? '',
				'author'        => $_kseo['author'] ?? '',
				'actor'         => $_kseo['actor'] ?? '',
				'episodeNumber' => $_kseo['episodeNumber'] ?? '',
				'seasonNumber'  => $_kseo['seasonNumber'] ?? '',
				'seriesName'    => $_kseo['seriesName'] ?? '',
				'seriesURL'     => $_kseo['seriesURL'] ?? '',
				'startDate'     => $importer->to_iso8601( $_kseo['startDate'] ?? '' ),
				'sameAs'        => $_kseo['sameAs'] ?? '',
				'url'           => $_kseo['url'] ?? '',
			],
		];
	}

	/**
	 * Map vacation rental schema fields.
	 *
	 * @param array $_kseo Source meta data.
	 *
	 * @param WpSeoSchema $importer Free importer (shared conversion helpers).
	 *
	 * @return array Review-schema formatted data.
	 */
	private static function get_vacation_rental_schema_field_data_map( $_kseo, WpSeoSchema $importer ) {
		$data = [
			'status'                 => 'show',
			'additionalType'         => $_kseo['additionalType'] ?? '',
			'name'                   => $_kseo['name'] ?? '',
			'description'            => $_kseo['description'] ?? '',
			'priceRange'             => $_kseo['priceRange'] ?? '',
			'telephone'              => $_kseo['telephone'] ?? '',
			'identifier'             => $_kseo['identifier'] ?? '',
			'latitude'               => $_kseo['latitude'] ?? '',
			'longitude'              => $_kseo['longitude'] ?? '',
			'containsPlaceType'      => $_kseo['containsPlaceType'] ?? '',
			'occupancy'              => $_kseo['occupancy'] ?? '',
			'numberOfBathroomsTotal' => $_kseo['numberOfBathroomsTotal'] ?? '',
			'numberOfBedrooms'       => $_kseo['numberOfBedrooms'] ?? '',
			'numberOfRooms'          => $_kseo['numberOfRooms'] ?? '',
			'floorSizeValue'         => $_kseo['floorSizeValue'] ?? '',
			'unitCode'               => $_kseo['unitCode'] ?? '',
			'streetAddress'          => $_kseo['streetAddress'] ?? '',
			'addressLocality'        => $_kseo['addressLocality'] ?? '',
			'region'                 => $_kseo['region'] ?? '',
			'postalCode'             => $_kseo['postalCode'] ?? '',
			'addressCountry'         => $_kseo['addressCountry'] ?? '',
		];

		// Map beds group.
		if ( ! empty( $_kseo['beds'] ) && is_array( $_kseo['beds'] ) ) {
			$beds = [];
			foreach ( $_kseo['beds'] as $bed ) {
				$beds[] = [
					'numberOfBeds' => $bed['numberOfBeds'] ?? '',
					'typeOfBed'    => $bed['typeOfBed'] ?? '',
				];
			}
			$data['beds'] = $beds;
		}

		// Map amenity features group.
		if ( ! empty( $_kseo['amenityFeature'] ) && is_array( $_kseo['amenityFeature'] ) ) {
			$amenities = [];
			foreach ( $_kseo['amenityFeature'] as $amenity ) {
				$amenities[] = [
					'feature' => $amenity['feature'] ?? '',
					'value'   => $amenity['value'] ?? '',
				];
			}
			$data['amenityFeature'] = $amenities;
		}

		// Map images group.
		if ( ! empty( $_kseo['images'] ) && is_array( $_kseo['images'] ) ) {
			$images = [];
			foreach ( $_kseo['images'] as $img ) {
				$image_id = $importer->image_url_to_id( $img['image'] ?? '' );
				if ( $image_id ) {
					$images[] = [
						'image' => $image_id,
					];
				}
			}
			if ( ! empty( $images ) ) {
				$data['images'] = $images;
			}
		}

		// Map reviews group.
		if ( ! empty( $_kseo['reviews'] ) && is_array( $_kseo['reviews'] ) ) {
			$reviews = [];
			foreach ( $_kseo['reviews'] as $review ) {
				$reviews[] = [
					'author'        => $review['author'] ?? '',
					'ratingValue'   => $review['ratingValue'] ?? '',
					'bestRating'    => $review['bestRating'] ?? '',
					'datePublished' => $importer->to_iso8601( $review['datePublished'] ?? '' ),
				];
			}
			$data['reviews'] = $reviews;
		}

		// Map aggregate rating.
		if ( ! empty( $_kseo['aggregate_ratingValue'] ) ) {
			$data['aggregate_ratingValue'] = $_kseo['aggregate_ratingValue'];
			$data['aggregate_bestRating']  = $_kseo['aggregate_bestRating'] ?? '';
			$data['aggregate_worstRating'] = $_kseo['aggregate_worstRating'] ?? '';
			$data['aggregate_ratingCount'] = $_kseo['aggregate_ratingCount'] ?? '';
		}

		return [ $data ];
	}

	/**
	 * Map vehicle listing schema fields.
	 *
	 * @param array $_kseo Source meta data.
	 *
	 * @param WpSeoSchema $importer Free importer (shared conversion helpers).
	 *
	 * @return array Review-schema formatted data.
	 */
	private static function get_vehicle_listing_schema_field_data_map( $_kseo, WpSeoSchema $importer ) {
		$data = [
			'status'                 => 'show',
			'type'                   => $_kseo['type'] ?? '',
			'name'                   => $_kseo['name'] ?? '',
			'IdentificationNumber'   => $_kseo['IdentificationNumber'] ?? '',
			'url'                    => $_kseo['url'] ?? '',
			'description'            => $_kseo['description'] ?? '',
			'offers_price'           => $_kseo['offers_price'] ?? '',
			'priceCurrency'          => $_kseo['priceCurrency'] ?? '',
			'priceValidUntil'        => $importer->to_iso8601( $_kseo['priceValidUntil'] ?? '' ),
			'availability'           => $_kseo['availability'] ?? '',
			'itemCondition'          => $_kseo['itemCondition'] ?? '',
			'brand'                  => $_kseo['brand'] ?? '',
			'model'                  => $_kseo['model'] ?? '',
			'vehicleConfiguration'   => $_kseo['vehicleConfiguration'] ?? '',
			'vehicleModelDate'       => $_kseo['vehicleModelDate'] ?? '',
			'mileageFromOdometer'    => $_kseo['mileageFromOdometer'] ?? '',
			'unitCode'               => $_kseo['unitCode'] ?? '',
			'color'                  => $_kseo['color'] ?? '',
			'vehicleInteriorColor'   => $_kseo['vehicleInteriorColor'] ?? '',
			'vehicleInteriorType'    => $_kseo['vehicleInteriorType'] ?? '',
			'bodyType'               => $_kseo['bodyType'] ?? '',
			'driveWheelConfiguration' => $_kseo['driveWheelConfiguration'] ?? '',
			'fuelType'               => $_kseo['fuelType'] ?? '',
			'vehicleTransmission'    => $_kseo['vehicleTransmission'] ?? '',
			'numberOfDoors'          => $_kseo['numberOfDoors'] ?? '',
			'vehicleSeatingCapacity' => $_kseo['vehicleSeatingCapacity'] ?? '',
			'shippingRate'           => $_kseo['shippingRate'] ?? '',
			'shippingDestination'    => $_kseo['shippingDestination'] ?? '',
			'addressRegion'          => $_kseo['addressRegion'] ?? '',
			'handlingTimeMinimum'    => $_kseo['handlingTimeMinimum'] ?? '',
			'handlingTimeMaximum'    => $_kseo['handlingTimeMaximum'] ?? '',
			'transitTimeMinimum'     => $_kseo['transitTimeMinimum'] ?? '',
			'transitTimeMaximum'     => $_kseo['transitTimeMaximum'] ?? '',
			'applicableCountry'      => $_kseo['applicableCountry'] ?? '',
			'merchantReturnDays'     => $_kseo['merchantReturnDays'] ?? '',
			'reviewRatingValue'      => $_kseo['reviewRatingValue'] ?? '',
			'reviewBestRating'       => $_kseo['reviewBestRating'] ?? '',
			'reviewWorstRating'      => $_kseo['reviewWorstRating'] ?? '',
			'reviewAuthor'           => $_kseo['reviewAuthor'] ?? '',
			'ratingValue'            => $_kseo['ratingValue'] ?? '',
			'reviewCount'            => $_kseo['reviewCount'] ?? '',
		];

		// Map images group.
		if ( ! empty( $_kseo['images'] ) && is_array( $_kseo['images'] ) ) {
			$images = [];
			foreach ( $_kseo['images'] as $img ) {
				$image_id = $importer->image_url_to_id( $img['image'] ?? '' );
				if ( $image_id ) {
					$images[] = [
						'image' => $image_id,
					];
				}
			}
			if ( ! empty( $images ) ) {
				$data['images'] = $images;
			}
		}

		return [ $data ];
	}

	/**
	 * Map restaurant schema fields.
	 *
	 * Moved from the free importer (Restaurant is a Pro type).
	 *
	 * @param array       $_kseo    Source meta data.
	 * @param WpSeoSchema $importer Free importer (shared conversion helpers).
	 *
	 * @return array Review-schema formatted data.
	 */
	private static function get_restaurant_schema_field_data_map( $_kseo, $importer ) {
		$image_id = $importer->image_url_to_id( $_kseo['image'] ?? '' );

		$data = [
			'status'        => 'show',
			'name'          => $_kseo['name'] ?? '',
			'description'   => $_kseo['description'] ?? '',
			'image'         => $image_id ? [ $image_id ] : [],
			'priceRange'    => $_kseo['priceRange'] ?? '',
			'telephone'     => $_kseo['telephone'] ?? '',
			'servesCuisine' => $_kseo['servesCuisine'] ?? '',
		];

		// Map address (wp-seo stores as single text field).
		if ( ! empty( $_kseo['address'] ) ) {
			$data['address'] = [
				0 => [
					'streetAddress'   => is_string( $_kseo['address'] ) ? $_kseo['address'] : '',
					'addressLocality' => '',
					'addressRegion'   => '',
					'postalCode'      => '',
					'addressCountry'  => '',
				],
			];
		}

		// Map opening hours (key must be openingHours with dayOfWeek sub-key).
		if ( ! empty( $_kseo['openingHours'] ) ) {
			$data['openingHours'] = $importer->parse_opening_hours( $_kseo['openingHours'] );
		}

		// Map menu sections with menu items and nutrition.
		if ( ! empty( $_kseo['menuName'] ) || ! empty( $_kseo['menu_items'] ) ) {
			$menu_section = [
				'name' => $_kseo['menuName'] ?? '',
				'desc' => $_kseo['menuDescription'] ?? '',
			];

			// Menu section image.
			if ( ! empty( $_kseo['menuImage'] ) ) {
				$menu_img_id = $importer->image_url_to_id( $_kseo['menuImage'] );
				if ( $menu_img_id ) {
					$menu_section['images'] = [ $menu_img_id ];
				}
			}

			// Menu offer availability dates.
			if ( ! empty( $_kseo['menuOfferAvailabilityStarts'] ) ) {
				$menu_section['availabilityStarts'] = $_kseo['menuOfferAvailabilityStarts'];
			}
			if ( ! empty( $_kseo['menuOfferAvailabilityEnds'] ) ) {
				$menu_section['availabilityEnds'] = $_kseo['menuOfferAvailabilityEnds'];
			}

			// Menu items with nutrition.
			if ( ! empty( $_kseo['menu_items'] ) && is_array( $_kseo['menu_items'] ) ) {
				$menu_items = [];
				foreach ( $_kseo['menu_items'] as $mi ) {
					$item = [
						'name'          => $mi['name'] ?? '',
						'desc'          => $mi['description'] ?? '',
						'price'         => $mi['offers_price'] ?? '',
						'priceCurrency' => $mi['offers_priceCurrency'] ?? '',
					];

					// Nutrition fields.
					$nutrition_map = [
						'nutrition_calories'              => 'calories',
						'nutrition_carbohydrateContent'   => 'carbohydrateContent',
						'nutrition_cholesterolContent'    => 'cholesterolContent',
						'nutrition_fatContent'            => 'fatContent',
						'nutrition_fiberContent'          => 'fiberContent',
						'nutrition_proteinContent'        => 'proteinContent',
						'nutrition_saturatedFatContent'   => 'saturatedFatContent',
						'nutrition_servingSize'           => 'servingSize',
						'nutrition_sodiumContent'         => 'sodiumContent',
						'nutrition_sugarContent'          => 'sugarContent',
						'nutrition_transFatContent'       => 'transFatContent',
						'nutrition_unsaturatedFatContent' => 'unsaturatedFatContent',
					];
					foreach ( $nutrition_map as $wp_seo_key => $rtrs_key ) {
						if ( ! empty( $mi[ $wp_seo_key ] ) ) {
							$item[ $rtrs_key ] = $mi[ $wp_seo_key ];
						}
					}

					$menu_items[] = $item;
				}
				$menu_section['menu_items'] = $menu_items;
			}

			$data['menu_sections'] = [ $menu_section ];
		}

		return [ $data ];
	}
}
